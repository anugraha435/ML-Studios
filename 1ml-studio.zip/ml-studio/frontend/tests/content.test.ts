import { describe, expect, it } from 'vitest';
import { CATEGORIES, LESSONS, LESSON_INDEX } from '../src/content';

describe('lesson content integrity', () => {
  it('has a lesson for every index entry, with matching category', () => {
    expect(LESSONS.length).toBe(LESSON_INDEX.length);
    LESSON_INDEX.forEach((e) => { const l = LESSONS.find((x) => x.id === e.id)!; expect(l, e.id).toBeTruthy(); expect(l.category).toBe(e.category); expect(l.algorithmId).toBe(e.algorithmId); });
  });
  it('ids unique, related ids resolve', () => {
    const ids = new Set(LESSONS.map((l) => l.id)); expect(ids.size).toBe(LESSONS.length);
    for (const l of LESSONS) for (const r of l.related) expect(ids.has(r), `${l.id} -> ${r}`).toBe(true);
  });
  it('every lesson is substantial', () => {
    for (const l of LESSONS) {
      const words = [l.intro, l.simple, l.technical, l.example.body].join(' ').split(/\s+/).length;
      expect(words, l.id).toBeGreaterThan(280);
      expect(l.pros.length, l.id).toBeGreaterThanOrEqual(3); expect(l.cons.length, l.id).toBeGreaterThanOrEqual(3); expect(l.applications.length, l.id).toBeGreaterThanOrEqual(3);
      expect(l.quiz.length, l.id).toBeGreaterThanOrEqual(3);
      for (const q of l.quiz) { expect(q.options.length).toBeGreaterThanOrEqual(3); expect(q.answerIndex).toBeLessThan(q.options.length); expect(q.explanation.length).toBeGreaterThan(20); }
      expect(l.math?.length ?? 0, l.id).toBeGreaterThan(0);
    }
  });
  it('math compiles with KaTeX (strict, throwOnError)', async () => {
    const katex = (await import('katex')).default;
    for (const l of LESSONS) {
      for (const m of l.math ?? []) katex.renderToString(m.tex, { displayMode: true, throwOnError: true });
      const texts = [l.intro, l.simple, l.technical, l.example.body, ...(l.math ?? []).map((m) => m.note ?? '')];
      for (const t of texts) for (const mm of t.matchAll(/(?<!\\)\$([^$\n]+?)\$/g)) katex.renderToString(mm[1], { throwOnError: true });
    }
  });
  it('contains no exclamation-mark hype or emoji', () => {
    for (const l of LESSONS) { const { math, ...prose } = l; const s = JSON.stringify(prose); expect(/!/.test(s), l.id).toBe(false); expect(/[\u{1F300}-\u{1FAFF}]/u.test(s)).toBe(false); }
  });
});

import { TRACK_MINUTES } from '../src/content/tracks';
describe('track metadata', () => {
  it('track reading minutes equal the sum of the lessons', () => {
    for (const c of CATEGORIES) expect(TRACK_MINUTES[c.id]).toBe(LESSONS.filter((l) => l.category === c.id).reduce((a, l) => a + l.readingMinutes, 0));
  });
});
