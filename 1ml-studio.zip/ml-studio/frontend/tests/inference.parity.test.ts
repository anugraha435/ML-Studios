import { describe, expect, it } from 'vitest';
import bundle from '../src/data/research/models.json';
import parity from '../src/data/research/parity.json';
import results from '../src/data/research/results.json';
import { predictProba, recordFromRow, type ModelBundle, type ModelKey } from '../src/lib/cardio/inference';

const b = bundle as unknown as ModelBundle;
const keys: ModelKey[] = ['lr', 'dt', 'rf', 'svm'];

describe('browser inference matches scikit-learn', () => {
  for (const k of keys) {
    it(`${k}: ${parity.rows.length} rows agree with predict_proba to 1e-9`, () => {
      const exp = (parity.expected as Record<string, number[]>)[k];
      let maxErr = 0;
      parity.rows.forEach((row, i) => {
        const p = predictProba(b.models[k], recordFromRow(row as (number | null)[]));
        maxErr = Math.max(maxErr, Math.abs(p - exp[i]));
      });
      expect(maxErr).toBeLessThan(1e-9);
    });
  }
  it('thresholds equal the training-only OOF thresholds in results.json', () => {
    for (const k of keys) expect(b.models[k].threshold).toBeCloseTo((results as any).calibration[k].threshold, 12);
  });
});

import shap from '../src/data/research/shap.json';
import { explainLogistic, FEATURES } from '../src/lib/cardio/inference';
describe('browser linear SHAP matches the published SHAP values', () => {
  it('reproduces S_lr for all 61 test records and is additive', () => {
    const lr = b.models.lr; let maxErr = 0;
    (shap as any).X_test.forEach((row: (number | null)[], i: number) => {
      const rec = Object.fromEntries((shap as any).features.map((f: string, k: number) => [f, row[k]])) as any;
      const e = explainLogistic(lr, rec);
      e.contributions.forEach((c) => { const j = (shap as any).features.indexOf(c.feature); maxErr = Math.max(maxErr, Math.abs(c.contribution - (shap as any).S_lr[i][j])); });
      const p = predictProba(lr, rec); expect(Math.abs(1 / (1 + Math.exp(-e.logit)) - p)).toBeLessThan(1e-9);
    });
    expect(maxErr).toBeLessThan(1e-9); expect(FEATURES.length).toBe(13);
  });
});
