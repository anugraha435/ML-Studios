import { describe, expect, it } from 'vitest';
import { search, SEARCH_INDEX } from '../src/lib/search';
describe('global search', () => {
  it('finds lessons, algorithms, metrics and research pages', () => {
    expect(search('roc')[0].to).toMatch(/roc/);
    expect(search('random forest').some((r) => r.to === '/algorithms/random-forest')).toBe(true);
    expect(search('brier').some((r) => r.to === '/learn/brier-score')).toBe(true);
    expect(search('shap').some((r) => r.to === '/research/explainability')).toBe(true);
    expect(search('sensitivity').length).toBeGreaterThan(0);
  });
  it('returns nothing for gibberish and for empty input', () => { expect(search('qzxvbn')).toEqual([]); expect(search('  ')).toEqual([]); });
  it('every result target is unique per document id and well formed', () => { SEARCH_INDEX.forEach((d) => expect(d.to.startsWith('/')).toBe(true)); });
});
