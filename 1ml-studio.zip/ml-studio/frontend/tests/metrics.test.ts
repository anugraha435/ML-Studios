import { describe, expect, it } from 'vitest';
import { CURVES, MODEL_KEYS, NOT_REPORTED, R, SHAP, fmt } from '../src/data/metrics';
import { rocAuc } from '../src/lib/ml/metrics';

describe('research metrics are internally consistent (no hand-typed values)', () => {
  it('confusion counts add to the test set and reproduce the reported ratios', () => {
    for (const k of MODEL_KEYS) {
      const t = R.test[k].at_threshold;
      expect(t.tn + t.fp + t.fn + t.tp).toBe(R.split.n_test);
      expect(t.sensitivity).toBeCloseTo(t.tp / (t.tp + t.fn), 12);
      expect(t.specificity).toBeCloseTo(t.tn / (t.tn + t.fp), 12);
      expect(t.precision).toBeCloseTo(t.tp / (t.tp + t.fp), 12);
      expect(t.accuracy).toBeCloseTo((t.tp + t.tn) / R.split.n_test, 12);
      expect(t.f1).toBeCloseTo((2 * t.tp) / (2 * t.tp + t.fp + t.fn), 12);
    }
  });
  it('stored test probabilities recompute the reported AUC and counts', () => {
    for (const k of MODEL_KEYS) {
      expect(rocAuc(CURVES.yTest, CURVES.curves[k].probs)).toBeCloseTo(R.test[k].at_threshold.roc_auc, 10);
      const thr = R.test[k].at_threshold.threshold; const p = CURVES.curves[k].probs;
      const tp = p.filter((v, i) => v >= thr && CURVES.yTest[i] === 1).length;
      expect(tp).toBe(R.test[k].at_threshold.tp);
    }
  });
  it('dataset counts match the thesis (303 = 164 + 139; 242 + 61)', () => {
    expect(R.data.n).toBe(303); expect(R.data.n_absent).toBe(164); expect(R.data.n_present).toBe(139);
    expect(R.split.n_train).toBe(242); expect(R.split.n_test).toBe(61);
  });
  it('SHAP additivity holds and shapes are right', () => {
    expect(SHAP.S_rf.length).toBe(61); expect(SHAP.S_rf[0].length).toBe(13); expect(SHAP.lr_additivity_max_abs_error).toBeLessThan(1e-9);
  });
  it('missing values render as "Not yet reported", never as a number', () => {
    expect(fmt(undefined)).toBe(NOT_REPORTED); expect(fmt(null)).toBe(NOT_REPORTED); expect(fmt(NaN)).toBe(NOT_REPORTED);
  });
});
