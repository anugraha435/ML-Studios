import { describe, expect, it } from 'vitest';
import fx from './fixtures.json';
import { fitForest, fitKnn, fitLinear, fitLogistic, fitSvm, fitTree, kmeansFit, predictClass, predictLinear } from '../src/lib/ml/models';
import { brier, confusion, f1, rocAuc, silhouette } from '../src/lib/ml/metrics';
import type { Kernel } from '../src/lib/ml/models';

const { X, y, Xt } = fx as { X: number[][]; y: number[]; Xt: number[][] };
const close = (a: number, b: number, tol: number, msg = '') => expect(Math.abs(a - b), `${msg} ${a} vs ${b}`).toBeLessThan(tol);

describe('algorithms agree with scikit-learn', () => {
  it('OLS and ridge coefficients', () => {
    const m = fitLinear(X, fx.yr);
    fx.ols.coef.forEach((c, i) => close(m.coef[i], c, 1e-8)); close(m.intercept, fx.ols.b, 1e-8);
    const r = fitLinear(X, fx.yr, 3);
    fx.ridge.coef.forEach((c, i) => close(r.coef[i], c, 1e-8)); close(r.intercept, fx.ridge.b, 1e-8);
    expect(predictLinear(m, [X[0]])[0]).toBeCloseTo(m.intercept + m.coef[0] * X[0][0] + m.coef[1] * X[0][1], 10);
  });
  it('logistic regression (L2, C=1)', () => {
    const m = fitLogistic(X, y, 2, 1);
    fx.logit.coef.forEach((c, i) => close(m.models[0].coef[i], c, 1e-5)); close(m.models[0].intercept, fx.logit.b, 1e-5);
    m.predictProba(Xt).forEach((p, i) => close(p[1], fx.logit.proba[i], 1e-5));
  });
  for (const name of ['rbf', 'lin', 'poly'] as const) {
    it(`SVM ${name}: decision values and support vectors`, () => {
      const f = fx.svm[name];
      const m = fitSvm(X, y, 2, f.C, f.kernel as Kernel).models[0];
      expect(m.svIdx.length).toBe(f.nsv);
      expect(m.svIdx.slice().sort((a, b) => a - b)).toEqual(f.sv);
      m.decision(Xt).forEach((d, i) => close(d, f.dec[i], 2e-3, `${name}[${i}]`));
    });
  }
  it('kNN probabilities (k=5)', () => { fitKnn(X, y, 2, 5).predictProba(Xt).forEach((p, i) => close(p[1], fx.knn[i], 1e-12)); });
  for (const d of [2, 3, 5] as const) {
    it(`decision tree depth ${d}: training predictions and test probabilities`, () => {
      const f = (fx as any)[`tree${d}`];
      const t = fitTree(X, y, 2, { maxDepth: d, minSamplesSplit: 2 });
      expect(predictClass(t, X)).toEqual(f.pred_train);
      t.predictProba(Xt).forEach((p, i) => close(p[1], f.proba_test[i], 1e-12));
      t.importances.forEach((v, i) => close(v, f.imp[i], 1e-9));
    });
  }
  it('ROC-AUC (with and without ties), Brier, silhouette', () => {
    close(rocAuc(y, fx.auc.score), fx.auc.v, 1e-12); close(rocAuc(y, fx.auc_ties.score), fx.auc_ties.v, 1e-12);
    close(brier(y, fx.auc.score), fx.brier, 1e-12);
    close(silhouette(X, fx.sil.assign), fx.sil.v, 1e-12);
  });
});

describe('behavioural checks', () => {
  it('forest is reproducible for a seed and learns the blobs', () => {
    const a = fitForest(X, y, 2, { nTrees: 25, maxDepth: 4, seed: 5 }), b = fitForest(X, y, 2, { nTrees: 25, maxDepth: 4, seed: 5 });
    expect(a.predictProba(Xt)).toEqual(b.predictProba(Xt));
    expect(a.oobScore!).toBeGreaterThan(0.7);
  });
  it('k-means converges and inertia does not increase', () => {
    const s = kmeansFit(X, 2, 1);
    expect(s.converged).toBe(true);
    expect(new Set(s.assign).size).toBe(2);
  });
  it('F1 from confusion counts', () => { const c = confusion([1, 1, 0, 0, 1], [1, 0, 0, 1, 1]); expect(c).toEqual({ tp: 2, fn: 1, tn: 1, fp: 1 }); expect(f1(c)).toBeCloseTo(4 / 6, 12); });
});
