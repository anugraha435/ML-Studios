import { describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';
import { DataError, parseCsvText, validateFile } from '../src/lib/data/table';
import { inferTask } from '../src/lib/data/preprocess';
import { DEFAULT_PARAMS, runModel, type AlgoId } from '../src/lib/pipeline/run';

const load = (n: string) => parseCsvText(readFileSync(`public/datasets/${n}.csv`, 'utf8'), n);
const base = { params: DEFAULT_PARAMS, testFraction: 0.25 };

describe('CSV validation', () => {
  it('rejects wrong type, empty and oversize files', () => {
    expect(() => validateFile({ name: 'x.exe', size: 10 })).toThrow(DataError);
    expect(() => validateFile({ name: 'x.csv', size: 0 })).toThrow(/empty/);
    expect(() => validateFile({ name: 'x.csv', size: 6 * 1024 * 1024 })).toThrow(/limit/);
  });
  it('rejects too few rows, duplicate headers, single column', () => {
    expect(() => parseCsvText('a,b\n1,2\n3,4', 't')).toThrow(/At least 20/);
    const rows = Array.from({ length: 25 }, (_, i) => `${i},${i * 2}`).join('\n');
    expect(() => parseCsvText(`a,a\n${rows}`, 't')).toThrow(/unique/);
    expect(() => parseCsvText(`a\n${Array.from({ length: 25 }, (_, i) => i).join('\n')}`, 't')).toThrow(/only one column/);
  });
  it('detects types, missing values and semicolon delimiters', () => {
    const rows = Array.from({ length: 30 }, (_, i) => `${i % 7};${i % 3 === 0 ? 'NA' : i * 1.5};${i % 2 ? 'a' : 'b'}`).join('\n');
    const t = parseCsvText(`x;y;g\n${rows}`, 't');
    expect(t.columns.map((c) => c.kind)).toEqual(['numeric', 'numeric', 'categorical']);
    expect(t.columns[1].missing).toBe(10);
  });
  it('flags identifier and constant columns', () => {
    const rows = Array.from({ length: 30 }, (_, i) => `id${i},1,${i}`).join('\n');
    const t = parseCsvText(`name,const,v\n${rows}`, 't');
    expect(t.columns[0].warning).toMatch(/identifier/); expect(t.columns[1].warning).toMatch(/Constant/);
  });
});

describe('playground training on real sample data', () => {
  const iris = load('iris'), heart = load('heart_cleveland');
  const f = (t: typeof iris, target: string) => t.columns.map((c) => c.name).filter((n) => n !== target);
  const cases: [AlgoId, number][] = [['logistic-regression', 0.85], ['decision-tree', 0.85], ['random-forest', 0.85], ['svm', 0.85], ['knn', 0.85]];
  for (const [algo, min] of cases) {
    it(`${algo} on iris reaches > ${min} test accuracy`, () => {
      const r = runModel({ ...base, table: iris, algo, target: 'species', features: f(iris, 'species'), task: 'classification' });
      expect(r.metrics.accuracy).toBeGreaterThan(min); expect(r.nTrain + r.nTest).toBe(150); expect(r.confusion!.length).toBe(3);
    });
  }
  it('binary run returns AUC, ROC and handles missing values (heart)', () => {
    expect(inferTask(heart, 'target').task).toBe('classification');
    const r = runModel({ ...base, table: heart, algo: 'logistic-regression', target: 'target', features: f(heart, 'target'), task: 'classification' });
    expect(r.metrics.roc_auc).toBeGreaterThan(0.8); expect(r.roc!.length).toBeGreaterThan(5); expect(r.prepNotes.join(' ')).toMatch(/median/);
  });
  it('linear regression on a numeric target', () => {
    const wine = load('wine');
    const r = runModel({ ...base, table: wine, algo: 'linear-regression', target: 'alcohol', features: f(wine, 'alcohol').filter((n) => n !== 'target'), task: 'regression' });
    expect(r.metrics.r2).toBeGreaterThan(0.3); expect(r.scatter!.length).toBe(r.nTest);
  });
  it('k-means finds 3 groups in iris with sane silhouette', () => {
    const r = runModel({ ...base, table: iris, algo: 'k-means', target: null, features: f(iris, 'species').filter((n) => n !== 'species'), task: 'classification', params: { ...DEFAULT_PARAMS, clusters: 3 } });
    expect(r.cluster!.sizes.reduce((a, b) => a + b, 0)).toBe(150); expect(r.metrics.silhouette).toBeGreaterThan(0.3);
  });
  it('reports clear errors for invalid setups', () => {
    expect(() => runModel({ ...base, table: iris, algo: 'linear-regression', target: 'species', features: ['sepal_length_cm'], task: 'classification' })).toThrow(/cannot be used/);
    expect(() => runModel({ ...base, table: iris, algo: 'knn', target: 'species', features: [], task: 'classification' })).toThrow(/at least one/i);
  });
  it('is deterministic for a given seed', () => {
    const a = runModel({ ...base, table: iris, algo: 'random-forest', target: 'species', features: f(iris, 'species'), task: 'classification' });
    const b = runModel({ ...base, table: iris, algo: 'random-forest', target: 'species', features: f(iris, 'species'), task: 'classification' });
    expect(a.metrics).toEqual(b.metrics);
  });
});

import { scoreRecord } from '../src/lib/pipeline/score';
describe('scoring a new record with a trained playground model', () => {
  const iris = load('iris'); const feats = iris.columns.map((c) => c.name).filter((n) => n !== 'species');
  const rec = (i: number) => Object.fromEntries(iris.columns.map((c, j) => [c.name, iris.rows[i][j]]));
  for (const algo of ['logistic-regression', 'decision-tree', 'random-forest', 'svm', 'knn'] as AlgoId[]) {
    it(`${algo}: probabilities sum to 1 and typical setosa / virginica rows are labelled sensibly`, () => {
      const r = runModel({ ...base, table: iris, algo, target: 'species', features: feats, task: 'classification' });
      const a = scoreRecord(r, rec(0)), b = scoreRecord(r, rec(149));
      expect(a.probabilities!.reduce((s, o) => s + o.p, 0)).toBeCloseTo(1, 9);
      expect(a.label).toBe('setosa'); expect(b.label).toBe('virginica');
    });
  }
  it('regression and clustering scorers return values', () => {
    const wine = load('wine'); const fw = wine.columns.map((c) => c.name).filter((n) => n !== 'alcohol' && n !== 'target');
    const rr = runModel({ ...base, table: wine, algo: 'linear-regression', target: 'alcohol', features: fw, task: 'regression' });
    expect(typeof scoreRecord(rr, Object.fromEntries(wine.columns.map((c, j) => [c.name, wine.rows[0][j]]))).label).toBe('number');
    const km = runModel({ ...base, table: iris, algo: 'k-means', target: null, features: feats, task: 'classification', params: { ...DEFAULT_PARAMS, clusters: 3 } });
    expect(String(scoreRecord(km, rec(0)).label)).toMatch(/Cluster/);
  });
});
