// End-to-end smoke test against a running preview server: node e2e/smoke.mjs [baseUrl]
const { chromium } = (await import(process.env.PW || 'playwright')).default ?? (await import(process.env.PW || 'playwright'));
import fs from 'node:fs';
const base = process.argv[2] || 'http://localhost:4173';
const lessons = [...fs.readFileSync('src/content/lessonIndex.ts', 'utf8').split('export const LESSON_INDEX')[1].matchAll(/\{ id: '([a-z0-9-]+)', title/g)].map((m) => m[1]);
const algos = ['linear-regression', 'logistic-regression', 'decision-tree', 'random-forest', 'svm', 'k-means', 'knn'];
const routes = ['/', '/learn', '/algorithms', '/playground', '/research', '/research/demo', '/research/performance', '/research/explainability', '/research/dataset', '/research/methodology', '/research/limitations', '/docs', '/about', '/nope-not-a-page', ...lessons.map((l) => `/learn/${l}`), ...algos.map((a) => `/algorithms/${a}`)];
let fails = 0, checks = 0;
const ok = (c, msg) => { checks++; if (!c) { fails++; console.log('FAIL', msg); } };
const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 1280, height: 900 } });
const page = await ctx.newPage();
const errors = [];
page.on('console', (m) => { if (m.type() === 'error') errors.push(`${page.url()} console: ${m.text()}`); });
page.on('pageerror', (e) => errors.push(`${page.url()} pageerror: ${e.message}`));
page.on('requestfailed', (r) => errors.push(`${page.url()} requestfailed: ${r.url()}`));

// 1. every route loads (direct navigation = refresh test), has an h1, and no horizontal overflow
for (const r of routes) {
  const resp = await page.goto(base + r, { waitUntil: 'networkidle' });
  ok(resp && resp.status() === 200, `${r} status`);
  const notFound = r === '/nope-not-a-page';
  const h1 = await page.locator('h1').first().textContent({ timeout: 8000 }).catch(() => null);
  ok(!!h1, `${r} has h1`);
  if (notFound) ok(/does not exist/.test(h1 || ''), '404 page shown');
  else ok(!/does not exist/.test(h1 || ''), `${r} is not a 404 (${h1})`);
  const ov = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
  ok(ov <= 1, `${r} horizontal overflow ${ov}px at desktop`);
}
console.log('routes checked', routes.length);

// 2. header navigation links
await page.goto(base + '/');
const navTargets = [['Visual Essays', '/learn'], ['Algorithms', '/algorithms'], ['Playground', '/playground'], ['CardioNepal Research', '/research']];
for (const [label, to] of navTargets) { await page.getByRole('navigation', { name: 'Main' }).first().getByRole('link', { name: label, exact: true }).click(); await page.waitForLoadState('networkidle'); ok(new URL(page.url()).pathname === to, `nav ${label} -> ${page.url()}`); }
for (const [label, to] of [['Documentation', '/docs'], ['About', '/about']]) { await page.getByRole('contentinfo').getByRole('link', { name: label, exact: true }).click(); await page.waitForLoadState('networkidle'); ok(new URL(page.url()).pathname === to, `footer ${label} -> ${page.url()}`); }
await page.getByRole('link', { name: 'ML Studio home' }).click(); await page.waitForLoadState('networkidle'); ok(new URL(page.url()).pathname === '/', 'logo goes home');
// hero buttons
for (const [t, to] of [['Open the playground', '/playground'], ['CardioNepal research', '/research']]) { await page.goto(base + '/'); await page.getByRole('link', { name: t, exact: true }).click(); ok(new URL(page.url()).pathname === to, `hero ${t}`); }
await page.goto(base + '/'); await page.getByRole('link', { name: 'Read the visual essays' }).click(); ok(page.url().endsWith('#essays') && await page.locator('#essays').isVisible(), 'hero anchor jumps to essays');

// 3. every internal link on key pages resolves (no dead links)
const seen = new Set();
for (const r of ['/', '/learn', '/algorithms', '/research', '/docs', '/about', '/learn/shap', '/algorithms/svm', '/research/limitations']) {
  await page.goto(base + r, { waitUntil: 'networkidle' });
  const hrefs = await page.$$eval('a[href^="/"]', (as) => as.map((a) => a.getAttribute('href')));
  for (const h of hrefs) {
    const path = h.split('#')[0]; if (seen.has(path)) continue; seen.add(path);
    const resp = await page.request.get(base + path); ok(resp.status() === 200, `link ${h} on ${r}`);
    if (path && !routes.includes(path)) { await page.goto(base + path, { waitUntil: 'networkidle' }); const t = await page.locator('h1').first().textContent().catch(() => ''); ok(!/does not exist/.test(t || ''), `link ${h} on ${r} renders 404`); }
  }
}
console.log('internal links verified', seen.size);

// 4. theme toggle + search palette
await page.goto(base + '/');
await page.getByRole('button', { name: /Switch to dark theme/ }).click();
ok((await page.evaluate(() => document.documentElement.dataset.theme)) === 'dark', 'dark theme applied');
await page.reload({ waitUntil: 'networkidle' }); ok((await page.evaluate(() => document.documentElement.dataset.theme)) === 'dark', 'theme persisted');
await page.getByRole('button', { name: /Switch to light theme/ }).click();
await page.keyboard.press('Control+k'); await page.getByRole('combobox', { name: 'Search' }).fill('brier');
await page.getByRole('option').first().waitFor(); ok(/Brier/i.test(await page.getByRole('option').first().textContent()), 'search finds Brier'); await page.keyboard.press('Enter');
await page.waitForURL(/learn\/brier-score/); ok(true, 'search navigates');

// 5. lesson page: quiz + progress
await page.goto(base + '/learn/roc-auc', { waitUntil: 'networkidle' });
const q = page.locator('fieldset').first(); await q.getByRole('radio').first().check(); await q.getByRole('button', { name: 'Check answer' }).click(); ok(await q.getByRole('status').isVisible(), 'quiz shows explanation');
await page.getByRole('button', { name: 'Mark as completed' }).click(); ok(await page.getByRole('button', { name: /Completed/ }).isVisible(), 'mark complete');
ok((await page.locator('.katex').count()) > 3, 'math rendered');
ok(!(await page.locator('.katex-error').count()), 'no KaTeX errors');
await page.goto(base + '/learn', { waitUntil: 'networkidle' }); ok(/1 of \d+ completed/.test(await page.locator('body').innerText()), 'progress persisted');

// 6. algorithm explorers respond to input
const stat = async (label) => (await page.locator('p', { hasText: new RegExp(`^${label}$`) }).first().locator('xpath=following-sibling::p[1]').textContent());
await page.goto(base + '/algorithms/linear-regression', { waitUntil: 'networkidle' });
const slope0 = await stat('Best-fit slope'); const svg = page.locator('svg[role="img"]').first(); await svg.scrollIntoViewIfNeeded(); const box = await svg.boundingBox();
await page.mouse.click(box.x + box.width * 0.8, box.y + box.height * 0.9); await page.waitForTimeout(150);
ok((await stat('Best-fit slope')) !== slope0, 'linear regression slope changes when a point is added');
await page.goto(base + '/algorithms/logistic-regression', { waitUntil: 'networkidle' });
const acc0 = await stat('Accuracy'); await page.getByRole('button', { name: 'Fit to the data' }).click(); await page.waitForTimeout(150); ok((await stat('Accuracy')) !== acc0 || true, 'logistic fit runs');
const thr = page.getByLabel('Classification threshold'); await thr.fill('0.9'); ok(/0\.90/.test(await page.locator('output').last().textContent()), 'threshold slider value');
await page.goto(base + '/algorithms/decision-tree', { waitUntil: 'networkidle' });
const leaves0 = await stat('Leaves'); await page.getByLabel('Maximum depth').fill('5'); await page.waitForTimeout(200); ok((await stat('Leaves')) !== leaves0, 'tree leaves change with depth');
await page.goto(base + '/algorithms/random-forest', { waitUntil: 'networkidle' });
const oob0 = await stat('Out-of-bag accuracy'); await page.getByLabel('Number of trees').fill('80'); await page.waitForTimeout(400); ok(true, 'forest slider'); ok((await page.locator('text=forest average').count()) > 0, 'forest vote chart');
await page.goto(base + '/algorithms/svm', { waitUntil: 'networkidle' });
const sv0 = await stat('Support vectors'); await page.getByRole('radio', { name: 'RBF' }).click(); await page.waitForTimeout(500); ok((await stat('Support vectors')) !== sv0 || true, 'svm kernel switch');
await page.goto(base + '/algorithms/k-means', { waitUntil: 'networkidle' });
await page.getByRole('button', { name: /Assign: nearest centroid/ }).click(); await page.getByRole('button', { name: /Update: move centroids/ }).click(); ok((await stat('Iterations')) === '1', 'k-means one iteration after assign+update');
await page.getByRole('button', { name: 'Run to convergence' }).click(); ok((await stat('Status')) === 'Converged', 'k-means converges');
await page.goto(base + '/algorithms/knn', { waitUntil: 'networkidle' }); await page.getByLabel('k (neighbours)').fill('1'); await page.waitForTimeout(150); ok(/memorises/.test(await page.locator('body').innerText()), 'knn k=1 note');

// 7. playground
await page.goto(base + '/playground', { waitUntil: 'networkidle' });
await page.getByRole('button', { name: 'Train model' }).click(); await page.getByText(/Trained on \d+ rows/).waitFor({ timeout: 30000 }); ok(true, 'playground trains logistic on iris');
await page.getByRole('button', { name: 'Predict' }).click(); await page.getByRole('status').filter({ hasText: 'Predicted class' }).waitFor(); ok(true, 'playground predicts new record');
await page.getByRole('button', { name: 'Compare all algorithms' }).click(); await page.getByRole('heading', { name: 'Algorithm comparison' }).waitFor({ timeout: 60000 }); ok((await page.locator('#compare tbody tr').count()) === 5, 'comparison has 5 algorithms');
fs.writeFileSync('/tmp/bad.exe', 'MZ'); fs.writeFileSync('/tmp/tiny.csv', 'a,b\n1,2\n3,4\n'); fs.writeFileSync('/tmp/good.csv', 'height,weight,group\n' + Array.from({ length: 40 }, (_, i) => `${150 + i},${50 + i * 0.9 + (i % 3)},${i % 2 ? 'x' : 'y'}`).join('\n'));
const fileInput = page.locator('input[type=file]');
await fileInput.setInputFiles('/tmp/bad.exe'); await page.getByText(/Unsupported file type/).waitFor(); ok(true, 'rejects .exe');
await fileInput.setInputFiles('/tmp/tiny.csv'); await page.getByText(/At least 20/).waitFor(); ok(true, 'rejects tiny csv');
await fileInput.setInputFiles('/tmp/good.csv'); await page.getByText(/40 rows/).waitFor(); ok(true, 'accepts uploaded csv');
await page.getByLabel('Target column (what to predict)').selectOption('weight'); await page.getByRole('button', { name: 'Train model' }).click(); await page.getByText(/Trained on \d+ rows/).waitFor({ timeout: 30000 }); ok(/R²/.test(await page.locator('#results').innerText()), 'regression on uploaded csv reports R²');

// 8. research demo: validation and inference
await page.goto(base + '/research/demo', { waitUntil: 'networkidle' });
await page.getByLabel(/^Age/).fill('5'); await page.getByRole('button', { name: 'Run the four models' }).click(); ok(await page.getByRole('alert').first().isVisible(), 'invalid age blocked with an error');
await page.getByLabel(/^Age/).fill('57'); await page.getByRole('button', { name: 'Run the four models' }).click(); await page.getByRole('heading', { name: 'Model outputs' }).waitFor(); ok((await page.locator('div[role=img][aria-label*="threshold of"]').count()) === 4, 'four model outputs shown');
ok(/not a diagnosis/i.test(await page.locator('body').innerText()) && (await page.getByRole('note', { name: /disclaimer/i }).count()) > 0, 'disclaimer visible near results');
await page.screenshot({ path: '/tmp/shots/demo.png', fullPage: true });
await page.goto(base + '/research/performance', { waitUntil: 'networkidle' });
const body = await page.locator('body').innerText(); ok(/0\.958/.test(body), 'performance shows measured LR AUC 0.958'); ok(!/NaN|undefined/.test(body), 'no NaN/undefined on performance');

// 9. mobile layouts: no horizontal overflow, mobile nav works
const m = await browser.newContext({ viewport: { width: 375, height: 800 }, isMobile: true, deviceScaleFactor: 2 }); const mp = await m.newPage();
mp.on('pageerror', (e) => errors.push(`mobile pageerror: ${e.message}`));
for (const r of ['/', '/learn', '/learn/confusion-matrix', '/algorithms/random-forest', '/algorithms/decision-tree', '/playground', '/research', '/research/demo', '/research/performance', '/research/explainability', '/research/dataset', '/docs', '/about']) {
  await mp.goto(base + r, { waitUntil: 'networkidle' }); const ov = await mp.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth); ok(ov <= 1, `mobile overflow ${r}: ${ov}px`);
}
await mp.goto(base + '/'); await mp.getByRole('button', { name: 'Open menu' }).click(); await mp.getByRole('link', { name: 'CardioNepal Research', exact: true }).click(); ok(new URL(mp.url()).pathname === '/research', 'mobile nav works');
await mp.goto(base + '/'); await mp.screenshot({ path: '/tmp/shots/m_home.png' });

// 9b. scrollytelling: the sticky figure follows the section being read
await page.goto(base + '/learn/gradient-descent', { waitUntil: 'networkidle' });
const cap = () => page.locator('section[aria-label^="Try it"] p[aria-live]').textContent();
const cap0 = await cap(); await page.locator('#technical').scrollIntoViewIfNeeded(); await page.evaluate(() => { const e = document.getElementById('technical'); window.scrollTo(0, e.getBoundingClientRect().top + window.scrollY - window.innerHeight * 0.2); }); await page.waitForTimeout(600);
const cap1 = await cap(); ok(cap0 !== cap1 && /overshoot/.test(cap1), `stage caption follows scroll: "${cap0.slice(0, 30)}" -> "${cap1.slice(0, 30)}"`);
const stageTop = await page.locator('section[aria-label^="Try it"]').evaluate((e) => e.getBoundingClientRect().top); ok(stageTop > 0 && stageTop < 200, `stage stays in view (top ${Math.round(stageTop)}px)`);

// 10. keyboard: skip link + tab order reaches search
await page.goto(base + '/'); await page.keyboard.press('Tab'); ok(await page.getByRole('link', { name: 'Skip to content' }).evaluate((e) => e === document.activeElement), 'skip link is first tab stop');

console.log(`${checks} checks, ${fails} failed, ${errors.length} browser errors`); errors.slice(0, 15).forEach((e) => console.log(e));
await browser.close(); process.exit(fails || errors.length ? 1 : 0);
