import { useEffect, useState } from 'react';
export interface ThemeColors { classes: string[]; ink: string; muted: string; line: string; surface: string; accent: string; brand: string }
const rgb = (name: string) => `rgb(${getComputedStyle(document.documentElement).getPropertyValue(name).trim().replace(/ /g, ',')})`;
const read = (): ThemeColors => ({ classes: ['--c0', '--c1', '--c2', '--c3'].map(rgb), ink: rgb('--ink'), muted: rgb('--muted'), line: rgb('--line'), surface: rgb('--surface'), accent: rgb('--accent'), brand: rgb('--brand') });
/** Chart colours resolved from the CSS tokens; re-read when the theme switches. */
export function useThemeColors(): ThemeColors {
  const [c, setC] = useState<ThemeColors>(read);
  useEffect(() => { const mo = new MutationObserver(() => setC(read())); mo.observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] }); return () => mo.disconnect(); }, []);
  return c;
}
