import { useEffect } from 'react';
export function useTitle(t?: string) { useEffect(() => { document.title = t ? `${t} | ML Studio` : 'ML Studio'; }, [t]); }
