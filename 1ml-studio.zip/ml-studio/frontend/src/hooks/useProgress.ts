import { useCallback, useEffect, useState } from 'react';
/** Learning progress lives only in this browser (localStorage). There are no accounts and nothing is sent to a server. */
interface Progress { completed: string[]; bookmarks: string[]; last?: string }
const KEY = 'mls-progress-v1';
const read = (): Progress => { try { const v = JSON.parse(localStorage.getItem(KEY) || 'null'); if (v && Array.isArray(v.completed) && Array.isArray(v.bookmarks)) return v; } catch { /* ignore */ } return { completed: [], bookmarks: [] }; };
const listeners = new Set<() => void>();
let state: Progress = read();
function write(p: Progress) { state = p; try { localStorage.setItem(KEY, JSON.stringify(p)); } catch { /* storage unavailable: progress is kept for this tab only */ } listeners.forEach((l) => l()); }
export function useProgress() {
  const [p, setP] = useState<Progress>(state);
  useEffect(() => { const l = () => setP(state); listeners.add(l); l(); return () => { listeners.delete(l); }; }, []);
  const toggleComplete = useCallback((id: string) => write({ ...state, completed: state.completed.includes(id) ? state.completed.filter((x) => x !== id) : [...state.completed, id] }), []);
  const toggleBookmark = useCallback((id: string) => write({ ...state, bookmarks: state.bookmarks.includes(id) ? state.bookmarks.filter((x) => x !== id) : [...state.bookmarks, id] }), []);
  const visit = useCallback((id: string) => { if (state.last !== id) write({ ...state, last: id }); }, []);
  const reset = useCallback(() => write({ completed: [], bookmarks: [] }), []);
  return { ...p, toggleComplete, toggleBookmark, visit, reset };
}
