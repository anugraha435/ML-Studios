import { useEffect, useState } from 'react';

/**
 * Reports which element (by id) is currently at the reading line, roughly the upper-middle of the viewport.
 * Only active on wide screens, where the stage is sticky beside the text; on narrow screens it returns the first id.
 */
export function useActiveStep(ids: string[], enabled = true): string {
  const [active, setActive] = useState(ids[0] ?? '');
  const key = ids.join('|');
  useEffect(() => {
    setActive(ids[0] ?? '');
    if (!enabled || typeof IntersectionObserver === 'undefined' || !window.matchMedia('(min-width: 1024px)').matches) return;
    const els = ids.map((i) => document.getElementById(i)).filter((e): e is HTMLElement => !!e);
    // The observer only signals that some step has crossed the reading band; the answer is then computed from
    // positions: the last step whose top edge has passed the reading line (35% down the viewport).
    const pick = () => {
      const line = window.innerHeight * 0.35; let cur = els[0]?.id ?? '';
      for (const e of els) if (e.getBoundingClientRect().top <= line) cur = e.id;
      setActive(cur);
    };
    const io = new IntersectionObserver(pick, { rootMargin: '-30% 0px -60% 0px', threshold: [0, 1] });
    pick();
    els.forEach((e) => io.observe(e));
    return () => io.disconnect();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, enabled]);
  return active;
}
