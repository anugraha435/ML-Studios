/** Optional deployment settings, read from environment variables at build time. See .env.example. */
export const REPO_URL: string = (import.meta.env.VITE_REPO_URL as string | undefined) || '';
export const API_URL: string = ((import.meta.env.VITE_API_URL as string | undefined) || '').replace(/\/$/, '');
