import type { Lesson } from '../types';

export const supervisedLessons: Lesson[] = [
  {
    id: 'linear-regression',
    title: 'Linear regression',
    category: 'supervised',
    algorithmId: 'linear-regression',
    summary: 'Linear regression predicts a number as a weighted sum of input features, with weights chosen to minimise squared error on training data.',
    readingMinutes: 7,
    intro:
      'Linear regression is the oldest and most widely used way to predict a number from other numbers. It fits a straight line (or, with several inputs, a flat plane) through the data so that the line passes as close as possible to the observed outcomes.\n\nAfter this lesson you will know what the fitted weights mean, how they are computed in closed form, which assumptions the method relies on, and how to read a score such as R-squared without over-trusting it.',
    simple:
      'Picture a scatter of points showing house size on the horizontal axis and price on the vertical axis. You lay a ruler across the cloud and slide and tilt it until it sits as close to all the points as you can manage. That ruler is the model.\n\nTo predict the price of a new house, you find its size on the horizontal axis, go up to the ruler and read off the height. The tilt of the ruler tells you how much the price rises for each extra square metre, and where it crosses the vertical axis tells you the predicted price of a house of size zero, which is just a anchoring constant.\n\n"As close as possible" has a precise meaning: for each point, measure the vertical gap to the ruler, square it, and add up the squares. The best ruler makes that total smallest.',
    technical:
      'The model is $\\hat{y} = w^\\top x + b$ with a weight vector $w$ and intercept $b$. Training minimises the sum of squared residuals, which is the maximum likelihood estimate if the errors are independent Gaussian noise with constant variance. Appending a constant 1 to each row of the design matrix $X$ absorbs the intercept, and the minimiser then has a closed form, the normal equation.\n\nSolving it directly costs about $O(nd^2 + d^3)$ for $n$ rows and $d$ features, so for very wide or very large data one uses gradient descent or stochastic variants instead. Numerically, QR or SVD decompositions are preferred to explicitly inverting $X^\\top X$, which becomes unstable when features are highly correlated (multicollinearity).\n\nThe classical assumptions are: the relationship is linear in the parameters, errors have zero mean, constant variance and are independent, and the features are not perfectly collinear. Violations do not stop the method from running; they make coefficient estimates, confidence intervals and extrapolations unreliable. Outliers have outsized influence because errors are squared.\n\nThe main hyperparameters appear only in regularised variants: ridge adds $\\lambda\\lVert w\\rVert_2^2$ and lasso adds $\\lambda\\lVert w\\rVert_1$, both shrinking weights to reduce variance. Feature scaling does not change the unregularised fit but matters for regularised ones. Polynomial or interaction features let the model bend while staying linear in its parameters.',
    math: [
      {
        label: 'Model and squared-error objective',
        tex: String.raw`\hat{y}_i = w^\top x_i + b, \qquad J(w,b) = \sum_{i=1}^{n}\big(y_i - \hat{y}_i\big)^2`,
        note: 'Each residual $y_i - \\hat y_i$ is the vertical gap between the observation and the prediction. Training chooses $w$ and $b$ to make $J$ as small as possible.'
      },
      {
        label: 'Normal equation',
        tex: String.raw`\hat{\beta} = \left(X^\top X\right)^{-1} X^\top y`,
        note: 'Here $X$ is the $n \\times (d+1)$ design matrix with a leading column of ones and $\\beta$ stacks the intercept and weights. It exists when $X^\\top X$ is invertible.'
      },
      {
        label: 'Coefficient of determination',
        tex: String.raw`R^2 = 1 - \frac{\sum_i (y_i - \hat{y}_i)^2}{\sum_i (y_i - \bar{y})^2}`,
        note: 'The share of the variation in $y$ explained by the model, compared with always predicting the mean $\\bar y$. Measured on training data it can only rise as features are added.'
      }
    ],
    example: {
      title: 'Fitting a line to four points',
      body:
        'Take four points $(x, y)$: (1, 2), (2, 3), (3, 5), (4, 6). The means are $\\bar{x} = 2.5$ and $\\bar{y} = 4$.\n\nFor one feature the least-squares slope is $\\sum (x-\\bar x)(y-\\bar y) / \\sum (x-\\bar x)^2$. The numerator is $(-1.5)(-2) + (-0.5)(-1) + (0.5)(1) + (1.5)(2) = 7$ and the denominator is $2.25 + 0.25 + 0.25 + 2.25 = 5$, so the slope is $1.4$. The intercept is $4 - 1.4 \\times 2.5 = 0.5$.\n\nThe fitted line is $\\hat{y} = 0.5 + 1.4x$, giving predictions 1.9, 3.3, 4.7 and 6.1. The residuals are 0.1, -0.3, 0.3 and -0.1, so the squared error is $0.01 + 0.09 + 0.09 + 0.01 = 0.2$. The total variation around the mean is $4 + 1 + 1 + 4 = 10$, so $R^2 = 1 - 0.2/10 = 0.98$.\n\nFor a new input $x = 5$ the model predicts $0.5 + 7 = 7.5$. That lies just outside the observed range, so it is an extrapolation and deserves caution.'
    },
    pros: [
      'Fast to train and to evaluate, even on large tables.',
      'Coefficients are easy to read: each says how the prediction changes per unit of a feature, holding the others fixed.',
      'Has a closed-form solution and a well-developed theory for confidence intervals and tests.',
      'Makes a strong, simple baseline against which more complex models can be compared.'
    ],
    cons: [
      'Cannot capture curved or interacting effects unless you add those terms yourself.',
      'Sensitive to outliers because errors are squared.',
      'Correlated features make individual coefficients unstable and hard to interpret.',
      'Extrapolates a straight line far beyond the data, which is often unrealistic.'
    ],
    applications: [
      'Estimating house prices from area, location and age.',
      'Forecasting sales from advertising spend and seasonality.',
      'Modelling how a dose or exposure relates to a measured outcome in a study.',
      'Calibrating sensors by relating raw readings to known reference values.'
    ],
    quiz: [
      {
        question: 'What does ordinary least squares minimise?',
        options: [
          'The sum of absolute residuals',
          'The sum of squared residuals',
          'The largest single residual',
          'The number of points the line misses'
        ],
        answerIndex: 1,
        explanation: 'Least squares minimises the sum of squared vertical gaps. Minimising absolute residuals is a different method (least absolute deviations), and minimising the largest residual is minimax regression.'
      },
      {
        question: 'A model has R-squared of 0.98 on its training data. What is the safest conclusion?',
        options: [
          'It will predict new data with 98% accuracy.',
          'The relationship must be causal.',
          'It explains most of the variation in the training data, but new data are needed to judge generalisation.',
          'The assumptions of linear regression are certainly satisfied.'
        ],
        answerIndex: 2,
        explanation: 'R-squared describes fit to the data it was computed on. It is not an accuracy percentage, says nothing about causation, and a high value can coexist with violated assumptions.'
      },
      {
        question: 'Two features are almost perfectly correlated. What is the most likely effect on the fitted coefficients?',
        options: [
          'They become unstable and can change a lot with small changes in the data.',
          'They are forced to equal zero.',
          'The model can no longer make any prediction.',
          'The residuals become negative.'
        ],
        answerIndex: 0,
        explanation: 'With near-collinearity, many weight combinations fit almost equally well, so individual coefficients swing widely even though predictions may stay stable.'
      },
      {
        question: 'Which change lets linear regression fit a curved relationship?',
        options: [
          'Using more training rows with the same features',
          'Adding polynomial terms such as x squared as extra features',
          'Removing the intercept',
          'Using a smaller test set'
        ],
        answerIndex: 1,
        explanation: 'The model only needs to be linear in its parameters. Adding $x^2$ as a feature lets the fitted curve bend while still using the same fitting procedure.'
      }
    ],
    related: ['logistic-regression', 'classification-vs-regression', 'gradient-descent', 'regularization'],
    keywords: ['regression', 'least squares', 'normal equation', 'residual', 'R-squared', 'ridge', 'lasso']
  },

  {
    id: 'logistic-regression',
    title: 'Logistic regression',
    category: 'supervised',
    algorithmId: 'logistic-regression',
    summary: 'Logistic regression turns a weighted sum of features into a probability between 0 and 1 and is trained by minimising log-loss.',
    readingMinutes: 7,
    intro:
      'Despite the name, logistic regression is a classification method. It answers questions with two outcomes, such as whether a customer will cancel a subscription, by producing a probability rather than a bare yes or no.\n\nAfter this lesson you will understand how the sigmoid function converts a score into a probability, why the loss function is log-loss instead of squared error, and how to read a coefficient as a change in log-odds.',
    simple:
      'Suppose you want to predict whether a student passes an exam from the hours they studied. A straight line is a poor fit because it would predict "130% chance" for heavy studiers and negative chances for others. Probabilities must stay between 0 and 1.\n\nLogistic regression first computes a plain score, the same kind of weighted sum a line would give. It then squeezes that score through an S-shaped curve. Very low scores become probabilities near 0, very high scores become probabilities near 1, and a score of zero becomes exactly one half.\n\nTo get a final decision you pick a cut-off, often 0.5, and say "pass" when the probability is above it. The cut-off can be moved when one kind of mistake is more costly than the other.',
    technical:
      'The model assumes the log-odds of the positive class are linear in the features: $\\log\\frac{p}{1-p} = w^\\top x + b$. Inverting gives $p = \\sigma(w^\\top x + b)$ with the sigmoid $\\sigma$. Under a Bernoulli model for the labels, maximum likelihood estimation is equivalent to minimising the average negative log-likelihood, called log-loss or binary cross-entropy.\n\nUnlike linear regression there is no closed-form solution. The log-loss is convex in the parameters, so gradient descent, Newton-type methods such as iteratively reweighted least squares, or quasi-Newton solvers such as L-BFGS reach the global optimum. Each iteration costs about $O(nd)$.\n\nAssumptions include a linear decision boundary in the chosen features, independent observations, and no perfect separation (if one feature perfectly separates the classes, the unregularised weights grow without bound). Features should be scaled when regularisation or gradient-based solvers are used.\n\nThe key hyperparameters are the regularisation type and strength (L2 is the common default, L1 gives sparse weights) and the decision threshold. For more than two classes, the softmax generalisation produces one probability per class. Predicted probabilities are often reasonably calibrated, which makes the model attractive when the probability itself will be used.',
    math: [
      {
        label: 'Sigmoid function',
        tex: String.raw`\sigma(z) = \frac{1}{1+e^{-z}}, \qquad p = \sigma\!\left(w^\top x + b\right)`,
        note: 'The score $z = w^\\top x + b$ can be any real number; $\\sigma(z)$ maps it to the interval from 0 to 1, with $\\sigma(0) = 0.5$.'
      },
      {
        label: 'Log-odds form',
        tex: String.raw`\log\frac{p}{1-p} = w^\top x + b`,
        note: 'Increasing feature $x_j$ by one unit adds $w_j$ to the log-odds, which multiplies the odds by $e^{w_j}$.'
      },
      {
        label: 'Log-loss (binary cross-entropy)',
        tex: String.raw`J(w,b) = -\frac{1}{n}\sum_{i=1}^{n}\Big[\, y_i \log p_i + (1-y_i)\log(1-p_i) \Big]`,
        note: 'With labels $y_i \\in \\{0,1\\}$, a confident wrong prediction is punished heavily because $\\log$ of a tiny number is very negative.'
      }
    ],
    example: {
      title: 'Predicting an exam pass from study hours',
      body:
        'Suppose training produced $w = 0.5$ per hour and $b = -3$. For a student who studied 8 hours the score is $z = -3 + 0.5 \\times 8 = 1$.\n\nThe probability of passing is $\\sigma(1) = 1/(1+e^{-1}) = 0.7311$. At 6 hours the score is 0 and the probability is exactly 0.5; at 4 hours the score is $-1$ and the probability falls to $0.2689$. Each extra hour multiplies the odds by $e^{0.5} \\approx 1.65$.\n\nNow the loss. If the 8-hour student did pass ($y = 1$), the log-loss for that row is $-\\ln(0.7311) = 0.3133$. If they failed ($y = 0$), it is $-\\ln(1 - 0.7311) = -\\ln(0.2689) = 1.3133$. The wrong outcome costs more than four times as much, which pushes training to fix confident mistakes.'
    },
    pros: [
      'Outputs probabilities, not just labels, so thresholds can be tuned to the costs of errors.',
      'Coefficients can be read as odds ratios, which helps explain results to non-specialists.',
      'Training is a convex problem, so the optimum is found reliably.',
      'Fast, stable and a strong baseline, particularly with many features and limited data.'
    ],
    cons: [
      'The decision boundary is linear in the features unless you engineer nonlinear terms.',
      'Can fail to converge or give huge weights when classes are perfectly separable, unless regularised.',
      'Sensitive to correlated features, which blur the meaning of individual coefficients.',
      'Needs care with imbalanced classes, where a default 0.5 threshold can ignore the rare class.'
    ],
    applications: [
      'Estimating the probability that a customer will cancel a service.',
      'Scoring the likelihood of loan default as one input to a credit decision.',
      'Producing a risk score from routine measurements that a clinician can weigh as decision support.',
      'Classifying messages as spam or not spam.'
    ],
    quiz: [
      {
        question: 'What probability does a logistic regression model output when the score $w^\\top x + b$ equals 0?',
        options: ['0', '0.5', '1', 'It depends on the training labels only'],
        answerIndex: 1,
        explanation: 'The sigmoid of zero is $1/(1+e^{0}) = 0.5$. A score of zero sits exactly on the decision boundary for a 0.5 threshold.'
      },
      {
        question: 'Why is log-loss preferred over squared error for training this model?',
        options: [
          'It is derived from the Bernoulli likelihood and gives a convex problem in the weights.',
          'It always gives a closed-form solution.',
          'It ignores confident mistakes.',
          'It only works for three or more classes.'
        ],
        answerIndex: 0,
        explanation: 'Log-loss is the negative log-likelihood under Bernoulli labels and is convex in the parameters. There is no closed-form solution, and confident mistakes are penalised heavily, not ignored.'
      },
      {
        question: 'A coefficient is 0.5. How does a one-unit increase in that feature change the odds of the positive class?',
        options: [
          'They increase by 0.5 percentage points.',
          'They are multiplied by about 1.65.',
          'They are multiplied by 0.5.',
          'They do not change.'
        ],
        answerIndex: 1,
        explanation: 'The coefficient is a change in log-odds, so the odds are multiplied by $e^{0.5} \\approx 1.65$. It is not a change in probability, which depends on where you start.'
      },
      {
        question: 'Missing a true positive is much more costly than a false alarm. What is a sensible adjustment?',
        options: [
          'Raise the threshold above 0.5',
          'Lower the threshold below 0.5',
          'Switch to squared error',
          'Remove the intercept'
        ],
        answerIndex: 1,
        explanation: 'Lowering the threshold labels more cases as positive, which catches more true positives at the price of more false alarms.'
      }
    ],
    related: ['linear-regression', 'classification-vs-regression', 'loss-functions', 'probability-calibration'],
    keywords: ['sigmoid', 'log-loss', 'cross-entropy', 'odds', 'classification', 'threshold']
  },

  {
    id: 'decision-trees',
    title: 'Decision trees',
    category: 'supervised',
    algorithmId: 'decision-tree',
    summary: 'A decision tree predicts by asking a sequence of yes or no questions about features, choosing each question to make the resulting groups purer.',
    readingMinutes: 7,
    intro:
      'A decision tree is a flowchart learned from data. Each internal node asks a question about one feature, each branch is an answer, and each leaf gives a prediction. Because the path to a prediction can be read aloud, trees are among the easiest models to explain.\n\nAfter this lesson you will know how a tree chooses its questions using impurity measures, why an unrestricted tree memorises its training data, and which settings control its size.',
    simple:
      'Think of the game of twenty questions. To identify an animal you ask "does it live in water?" first because that splits the possibilities well, then follow with narrower questions. A decision tree plays this game automatically.\n\nGiven a table of labelled examples, it tries every possible question, such as "is age at most 40?", and keeps the one that sorts the examples into the tidiest piles, where each pile is mostly one class. Then it repeats inside each pile.\n\nIt stops when a pile is pure, too small, or the tree has reached a depth limit. A new example simply walks down the questions and receives the majority label of the pile where it lands.',
    technical:
      'Training is greedy recursive partitioning. At a node with sample set $S$, the algorithm considers each feature and each candidate threshold (for numeric features, midpoints between sorted values), computes the weighted impurity of the two child sets, and picks the split with the largest impurity decrease. This choice is locally optimal; finding the globally optimal tree is NP-hard, so no backtracking is done.\n\nCommon impurity measures for classification are Gini impurity and Shannon entropy, and the decrease in entropy is called information gain. For regression, variance (squared error) of the target within a node is used and a leaf predicts the node mean. Sorting makes the cost of finding the best split about $O(dn\\log n)$ per level.\n\nTrees make few distributional assumptions and need no feature scaling, and they handle mixed feature types and interactions naturally. However they produce piecewise-constant, axis-aligned boundaries, and they have high variance: small changes in the data can change the top split and therefore the whole tree.\n\nKey hyperparameters are maximum depth, minimum samples per leaf or per split, minimum impurity decrease, and a cost-complexity pruning parameter. An unconstrained tree can reach zero training error by isolating every example, which is overfitting; limiting size or pruning trades a little bias for much lower variance.',
    math: [
      {
        label: 'Gini impurity',
        tex: String.raw`G(S) = 1 - \sum_{k=1}^{K} p_k^2`,
        note: '$p_k$ is the fraction of examples in node $S$ that belong to class $k$. It is 0 for a pure node and largest when classes are evenly mixed.'
      },
      {
        label: 'Entropy',
        tex: String.raw`H(S) = -\sum_{k=1}^{K} p_k \log_2 p_k`,
        note: 'Measured in bits. A 50/50 two-class node has entropy 1; a pure node has entropy 0.'
      },
      {
        label: 'Information gain of a split',
        tex: String.raw`\text{IG}(S, A) = H(S) - \sum_{v \in \{L,R\}} \frac{|S_v|}{|S|}\, H(S_v)`,
        note: 'The parent entropy minus the size-weighted entropy of the children $S_L$ and $S_R$ created by split $A$. The same form works with Gini in place of $H$.'
      }
    ],
    example: {
      title: 'Scoring one split on ten examples',
      body:
        'A node holds 10 examples: 6 positive and 4 negative. Its Gini impurity is $1 - 0.6^2 - 0.4^2 = 0.48$, and its entropy is $-(0.6\\log_2 0.6 + 0.4\\log_2 0.4) = 0.971$ bits.\n\nCandidate split: a question that sends 5 examples left (4 positive, 1 negative) and 5 right (2 positive, 3 negative).\n\nGini of the left child: $1 - 0.8^2 - 0.2^2 = 0.32$. Gini of the right child: $1 - 0.4^2 - 0.6^2 = 0.48$. The weighted average is $0.5 \\times 0.32 + 0.5 \\times 0.48 = 0.40$, so the Gini decrease is $0.48 - 0.40 = 0.08$.\n\nWith entropy, the left child has $H = 0.722$ and the right has $H = 0.971$, giving a weighted $0.846$ and an information gain of $0.971 - 0.846 = 0.125$ bits. The tree compares this value with every other candidate split and keeps the largest.'
    },
    pros: [
      'The decision path is readable, so individual predictions can be explained step by step.',
      'No feature scaling is needed, and numeric and categorical features can be mixed.',
      'Captures nonlinear effects and feature interactions without manual engineering.',
      'Fast to train and very fast to predict.'
    ],
    cons: [
      'Unconstrained trees overfit by memorising the training set.',
      'High variance: a small change in data can produce a quite different tree.',
      'Axis-aligned splits approximate diagonal boundaries poorly.',
      'Predictions are piecewise constant and cannot extrapolate beyond the training range.',
      'Splits on features with many distinct values can be favoured by chance.'
    ],
    applications: [
      'Rule-like triage guidance, for example a clinical checklist developed as decision support and reviewed by clinicians.',
      'Customer segmentation and churn rules that business teams can inspect.',
      'Credit or eligibility screening where each decision must be justified.',
      'The building block inside random forests and gradient boosting.'
    ],
    quiz: [
      {
        question: 'How does a decision tree choose a split at a node?',
        options: [
          'It picks a random feature and threshold.',
          'It tries candidate splits and keeps the one with the largest impurity decrease.',
          'It splits at the median of the first feature.',
          'It keeps the split that creates the biggest child node.'
        ],
        answerIndex: 1,
        explanation: 'Greedy trees evaluate candidate splits and take the one that most reduces impurity (Gini or entropy). Random splits appear in some ensembles, not in the standard algorithm.'
      },
      {
        question: 'A tree reaches 100% training accuracy but only 70% on validation data. What is the most likely reason?',
        options: [
          'Underfitting, because the tree is too shallow',
          'Overfitting, because the tree grew until it isolated individual examples',
          'The impurity measure was wrong',
          'Too few features were scaled'
        ],
        answerIndex: 1,
        explanation: 'A large gap between training and validation scores signals overfitting. Limiting depth or leaf size, or pruning, usually helps. Trees do not need scaling.'
      },
      {
        question: 'A node has 5 positive and 5 negative examples. What is its Gini impurity?',
        options: ['0', '0.25', '0.5', '1'],
        answerIndex: 2,
        explanation: 'Gini $= 1 - 0.5^2 - 0.5^2 = 0.5$, the maximum for two classes. Zero would mean the node is pure.'
      },
      {
        question: 'Which statement about trees is true?',
        options: [
          'They require standardised features.',
          'They can extrapolate a trend far outside the training range.',
          'Their predictions are constant within each leaf region.',
          'They always find the globally optimal tree.'
        ],
        answerIndex: 2,
        explanation: 'Each leaf outputs one value or class for its whole region, so a tree cannot continue a trend beyond the data. Greedy training does not guarantee a globally optimal tree.'
      }
    ],
    related: ['random-forest', 'ensemble-learning', 'overfitting-underfitting', 'model-interpretability'],
    keywords: ['gini', 'entropy', 'information gain', 'pruning', 'CART', 'split', 'leaf']
  },

  {
    id: 'random-forest',
    title: 'Random forest',
    category: 'supervised',
    algorithmId: 'random-forest',
    summary: 'A random forest averages many decision trees trained on resampled data and random feature subsets, trading some readability for much lower variance.',
    readingMinutes: 7,
    intro:
      'A single decision tree is easy to read but unstable. A random forest keeps the flexibility of trees and tames the instability by training many of them and combining their votes.\n\nAfter this lesson you will understand bootstrap aggregation, why random feature selection makes the trees more diverse, how out-of-bag samples give a free error estimate, and what is lost compared with a single tree.',
    simple:
      'Imagine asking one person to guess the weight of an ox at a fair. They may be far off. Ask two hundred people and average their guesses, and the errors tend to cancel, provided the guessers did not all copy one another.\n\nA random forest builds many trees and treats each as a guesser. To keep the guessers from copying one another, each tree sees a slightly different random sample of the training rows, and at each question it may only consider a random handful of features.\n\nFor a new example, every tree votes and the most common answer wins. For a number, the trees\' predictions are averaged. No single tree needs to be great; the crowd is steadier than any member.',
    technical:
      'Random forests combine bagging with random feature subsampling. For each of $B$ trees, a bootstrap sample of size $n$ is drawn with replacement from the training set, and a tree is grown deep, usually without pruning. At every split only $m$ of the $d$ features, chosen at random, are candidates. Typical defaults are $m \\approx \\sqrt{d}$ for classification and about $d/3$ for regression.\n\nAveraging reduces variance. If each tree has variance $\\sigma^2$ and pairwise correlation $\\rho$, the ensemble variance is $\\rho\\sigma^2 + \\frac{1-\\rho}{B}\\sigma^2$. Adding trees shrinks only the second term, so the floor is set by the correlation; restricting features per split lowers $\\rho$. Bias stays about that of a deep tree.\n\nEach bootstrap sample leaves out roughly 36.8% of the rows. These out-of-bag rows can be passed through the trees that did not see them, giving an internal error estimate without a separate validation set. Aggregated impurity decrease or permutation of features gives importance scores, although impurity-based scores can favour high-cardinality features.\n\nTraining cost is about $B$ times that of one tree, and trees can be grown in parallel. Prediction is also $B$ times slower. Key hyperparameters are the number of trees (more is rarely harmful beyond cost), $m$, maximum depth and minimum leaf size. Forests are fairly robust to defaults, but like trees they cannot extrapolate beyond the target range seen in training.',
    math: [
      {
        label: 'Bootstrap aggregation (bagging)',
        tex: String.raw`\hat{f}_{\text{bag}}(x) = \frac{1}{B}\sum_{b=1}^{B} \hat{f}_b(x)`,
        note: 'Each $\\hat f_b$ is a tree trained on its own bootstrap sample. For classification, replace the average by a majority vote.'
      },
      {
        label: 'Variance of an average of correlated trees',
        tex: String.raw`\operatorname{Var}\big(\hat{f}_{\text{bag}}\big) = \rho\,\sigma^2 + \frac{1-\rho}{B}\,\sigma^2`,
        note: 'With $B$ large the second term vanishes, leaving $\\rho\\sigma^2$. Less correlated trees (smaller $\\rho$) give a lower floor.'
      },
      {
        label: 'Fraction of rows left out of a bootstrap sample',
        tex: String.raw`\left(1 - \frac{1}{n}\right)^{n} \;\xrightarrow{\;n\to\infty\;}\; e^{-1} \approx 0.368`,
        note: 'The chance that one particular row is never drawn in $n$ draws with replacement. These rows form the out-of-bag set for that tree.'
      }
    ],
    example: {
      title: 'Bootstrap sampling and a vote of seven trees',
      body:
        'With $n = 10$ training rows, the probability that a given row is missing from one bootstrap sample is $(1 - 1/10)^{10} = 0.3487$, so about 3.5 rows are out-of-bag for each tree. For $n = 100$ it is $0.366$, already close to the limit $e^{-1} = 0.368$.\n\nVariance effect: if each tree has variance 1 and pairwise correlation 0.3, averaging 100 trees gives $0.3 + 0.7/100 = 0.307$. Averaging only 10 gives $0.3 + 0.7/10 = 0.37$. Beyond about 100 trees the gain is tiny, because the correlation term dominates.\n\nVoting: seven trees classify a new customer, with five saying "will cancel" and two saying "will stay". The forest predicts "will cancel", and the vote share $5/7 = 0.714$ can be reported as a rough score, although it is not guaranteed to be a calibrated probability.'
    },
    pros: [
      'Usually far more accurate and stable than a single tree.',
      'Works well with little tuning and handles mixed feature types without scaling.',
      'Captures nonlinear effects and interactions automatically.',
      'Out-of-bag error gives a built-in performance estimate.',
      'Trees train independently, so training parallelises easily.'
    ],
    cons: [
      'Less interpretable than one tree, since the prediction comes from hundreds of paths.',
      'Larger memory use and slower prediction than a single model.',
      'Cannot extrapolate outside the range of target values seen in training.',
      'Impurity-based importance can mislead with correlated or high-cardinality features.'
    ],
    applications: [
      'Predicting equipment failure from sensor logs.',
      'Credit and fraud scoring on tabular data.',
      'Ranking patients or cases by a risk score as decision support, with clinicians making the decisions.',
      'Estimating crop yield or land cover from satellite features.'
    ],
    quiz: [
      {
        question: 'Why does each tree in a random forest use a bootstrap sample?',
        options: [
          'To make every tree see exactly the same data',
          'To make the trees differ from one another so that averaging reduces variance',
          'To remove outliers from the data',
          'To reduce the number of features'
        ],
        answerIndex: 1,
        explanation: 'Different resampled data make the trees differ. Averaging diverse, individually high-variance trees reduces the variance of the ensemble.'
      },
      {
        question: 'What is the purpose of considering only a random subset of features at each split?',
        options: [
          'To speed up prediction only',
          'To lower the correlation between trees',
          'To guarantee each feature is used once',
          'To make the forest interpretable'
        ],
        answerIndex: 1,
        explanation: 'If one feature is very strong, every unrestricted tree would split on it first and the trees would look alike. Restricting candidates decorrelates them, lowering $\\rho$.'
      },
      {
        question: 'Roughly what fraction of training rows is out-of-bag for a single tree when $n$ is large?',
        options: ['About 10%', 'About 25%', 'About 37%', 'About 63%'],
        answerIndex: 2,
        explanation: 'The probability of never being drawn is $(1-1/n)^n \\approx e^{-1} = 0.368$. About 63% of distinct rows appear in the sample.'
      },
      {
        question: 'Adding more trees to a forest is most likely to cause which effect?',
        options: [
          'Overfitting that grows steadily',
          'Lower bias at every step',
          'Variance falling toward a floor, with higher compute cost',
          'Perfect extrapolation'
        ],
        answerIndex: 2,
        explanation: 'More trees shrink the term $(1-\\rho)\\sigma^2/B$, but the $\\rho\\sigma^2$ floor remains. Extra trees cost time and memory and do not usually cause overfitting.'
      }
    ],
    related: ['decision-trees', 'ensemble-learning', 'bias-variance-tradeoff', 'feature-importance'],
    keywords: ['bagging', 'bootstrap', 'ensemble', 'out-of-bag', 'variance', 'feature importance']
  },

  {
    id: 'support-vector-machines',
    title: 'Support vector machines',
    category: 'supervised',
    algorithmId: 'svm',
    summary: 'A support vector machine finds the boundary that separates classes with the widest possible margin, and kernels let that boundary curve.',
    readingMinutes: 7,
    intro:
      'Many boundaries can separate two groups of points. A support vector machine, or SVM, picks the one that stays as far as possible from the nearest points of both classes. That wide cushion tends to help on data the model has not seen.\n\nAfter this lesson you will understand margins, support vectors, the hinge loss that handles overlapping classes, and how the kernel trick produces nonlinear boundaries without building new features by hand.',
    simple:
      'Imagine red and blue marbles scattered on a table and a straight stick that must separate them. Many stick positions work, but some almost touch a marble. The SVM chooses the position where the empty strip around the stick is as wide as possible, like building the widest possible road between two towns.\n\nOnly the marbles right at the edge of that road matter. They are the support vectors. If you moved or removed any marble farther away, the road would not change.\n\nWhen the colours overlap and no straight road works, the SVM allows a few marbles to sit on the wrong side but charges a penalty for each. When even that is not enough, a kernel lets the road bend by comparing points through a similarity score instead of straight-line position.',
    technical:
      'For labels $y_i \\in \\{-1,+1\\}$ the linear classifier is $f(x) = w^\\top x + b$. For separable data the hard-margin SVM minimises $\\tfrac12\\lVert w\\rVert^2$ subject to $y_i f(x_i) \\ge 1$; the margin width is $2/\\lVert w\\rVert$. For overlapping data, the soft-margin form adds slack variables, equivalent to minimising the hinge loss plus an L2 penalty on $w$.\n\nThe problem is convex quadratic. In its dual form, the solution is a weighted sum over support vectors only, and the data enter solely through inner products $x_i^\\top x_j$. Replacing these by a kernel $k(x_i, x_j)$ corresponds to an inner product in a high-dimensional feature space, which is the kernel trick. Common kernels are linear, polynomial and the radial basis function (RBF).\n\nKernel SVM training typically scales between $O(n^2)$ and $O(n^3)$ in the number of samples, so it becomes expensive beyond tens of thousands of rows; linear SVMs trained by stochastic methods scale much better. Prediction costs one kernel evaluation per support vector.\n\nThe main hyperparameters are the penalty $C$ (large $C$ punishes violations hard and risks overfitting; small $C$ widens the margin and tolerates errors), the kernel and its parameters such as the RBF width $\\gamma$ (large $\\gamma$ gives wiggly boundaries). Features must be scaled, since distances and dot products are scale-sensitive. Standard SVMs output a signed distance, not a probability; probabilities need an extra calibration step.',
    math: [
      {
        label: 'Margin maximisation',
        tex: String.raw`\min_{w,b}\ \tfrac{1}{2}\lVert w\rVert^{2} \quad \text{subject to} \quad y_i\,(w^\top x_i + b) \ge 1 \ \ \forall i`,
        note: 'The distance between the two margin lines is $2/\\lVert w\\rVert$, so shrinking $\\lVert w\\rVert$ widens the margin.'
      },
      {
        label: 'Soft-margin objective with hinge loss',
        tex: String.raw`\min_{w,b}\ \tfrac{1}{2}\lVert w\rVert^{2} + C\sum_{i=1}^{n}\max\!\big(0,\ 1 - y_i\,(w^\top x_i + b)\big)`,
        note: 'The hinge term is zero for points correctly classified outside the margin and grows linearly for points inside it or on the wrong side. $C$ balances margin width against violations.'
      },
      {
        label: 'RBF kernel',
        tex: String.raw`k(x, z) = \exp\!\big(-\gamma\,\lVert x - z\rVert^{2}\big)`,
        note: 'A similarity between 0 and 1 that falls as points move apart. A larger $\\gamma$ makes each point influence only its close neighbours.'
      }
    ],
    example: {
      title: 'Margin, hinge loss and a kernel value by hand',
      body:
        'Take $w = (1, 1)$ and $b = -3$, so $f(x) = x_1 + x_2 - 3$. The margin width is $2/\\lVert w\\rVert = 2/\\sqrt{2} = 1.414$.\n\nPoint $(3, 3)$ with label $+1$: $f = 3$, so $y f = 3 \\ge 1$ and the hinge loss is $\\max(0, 1-3) = 0$. It is safely outside the margin.\n\nPoint $(2, 1.5)$ with label $+1$: $f = 0.5$, correct side but inside the margin, so the hinge loss is $1 - 0.5 = 0.5$.\n\nPoint $(1.5, 1)$ with label $+1$: $f = -0.5$, wrong side, so the hinge loss is $1 - (-0.5) = 1.5$.\n\nFor the RBF kernel with $\\gamma = 0.5$, the points $(0,0)$ and $(1,1)$ have squared distance 2, so $k = e^{-0.5 \\times 2} = e^{-1} = 0.368$. Doubling the distance in each coordinate to $(2,2)$ gives squared distance 8 and $k = e^{-4} = 0.018$, showing how quickly similarity fades.'
    },
    pros: [
      'Maximising the margin gives a principled guard against overfitting, especially with many features.',
      'Kernels allow flexible nonlinear boundaries from the same convex training problem.',
      'The final model depends only on the support vectors, so it can be compact.',
      'Effective when the number of features is large relative to the number of rows.'
    ],
    cons: [
      'Training becomes slow and memory-hungry for very large datasets with nonlinear kernels.',
      'Needs feature scaling and careful tuning of $C$ and kernel parameters.',
      'Does not give probabilities directly.',
      'Kernel models are hard to interpret compared with linear models or trees.'
    ],
    applications: [
      'Text classification, where linear SVMs on sparse word features work well.',
      'Classifying biological sequences or gene-expression profiles with few samples and many features.',
      'Image classification on hand-crafted features.',
      'Detecting anomalies with one-class SVMs.'
    ],
    quiz: [
      {
        question: 'What are support vectors?',
        options: [
          'All the training points',
          'The training points closest to the boundary that determine its position',
          'The points with the largest feature values',
          'The test points the model got wrong'
        ],
        answerIndex: 1,
        explanation: 'The boundary is defined by points on or inside the margin. Removing other points leaves the solution unchanged.'
      },
      {
        question: 'You increase $C$ a great deal. What is the most likely effect?',
        options: [
          'A wider margin with more tolerated errors',
          'A narrower margin that fits training points more tightly and may overfit',
          'The kernel changes from RBF to linear',
          'Probabilities become calibrated'
        ],
        answerIndex: 1,
        explanation: 'A large $C$ makes margin violations expensive, so the model bends to classify training points correctly, raising overfitting risk.'
      },
      {
        question: 'A point with label +1 has $f(x) = 0.5$. What is its hinge loss?',
        options: ['0', '0.5', '1.5', '2'],
        answerIndex: 1,
        explanation: 'Hinge loss is $\\max(0, 1 - y f) = 1 - 0.5 = 0.5$. The point is on the correct side but inside the margin.'
      },
      {
        question: 'What does the kernel trick avoid?',
        options: [
          'Using labels during training',
          'Computing explicit coordinates in a very high-dimensional feature space',
          'Choosing a value for $C$',
          'Scaling the features'
        ],
        answerIndex: 1,
        explanation: 'The kernel returns the inner product in the feature space directly, so the mapping never has to be computed. Scaling and tuning $C$ are still needed.'
      }
    ],
    related: ['logistic-regression', 'regularization', 'loss-functions', 'k-nearest-neighbors'],
    keywords: ['margin', 'hinge loss', 'kernel', 'RBF', 'support vectors', 'soft margin']
  },

  {
    id: 'k-nearest-neighbors',
    title: 'K-nearest neighbors',
    category: 'supervised',
    algorithmId: 'knn',
    summary: 'K-nearest neighbors predicts for a new point by looking at the k most similar training points and taking their majority label or average.',
    readingMinutes: 6,
    intro:
      'K-nearest neighbors, or k-NN, is the most direct way to learn from examples: to judge a new case, find the training cases that look most like it and copy their answers. There is no fitted formula at all.\n\nAfter this lesson you will know how distance defines similarity, how the choice of k changes the prediction, why feature scaling is essential, and why the method struggles when there are many features.',
    simple:
      'Suppose you move to a new neighbourhood and want to know whether a house is likely to be expensive. You look at the three or five closest similar houses that sold recently and see what they went for. If most of them were expensive, you guess the same.\n\nThat is k-NN. "Closest" is measured by a distance between the features, and k is how many neighbours get a vote. With k equal to 1 you trust only the single nearest example, which is sensitive to oddities. With a larger k you trust a wider crowd, which is steadier but can blur real local differences.\n\nA practical warning: if one feature is measured in thousands and another in fractions, the big one decides almost everything, so features are first brought to a comparable scale.',
    technical:
      'K-NN is a non-parametric, instance-based method. Training only stores the data (and possibly builds an index); all work happens at prediction time. For a query $x$, compute distances to all training points, take the $k$ nearest, and predict the majority class (classification) or the mean of their targets (regression). Votes may be weighted by inverse distance so that closer neighbours count more.\n\nA brute-force query costs $O(nd)$, which is expensive for large $n$. Space-partitioning structures such as k-d trees and ball trees help in low dimensions, and approximate nearest-neighbour indices are used at scale. Memory use is the whole training set.\n\nThe main hyperparameters are $k$, the distance metric (Euclidean, Manhattan, more generally Minkowski, or cosine), and the weighting scheme. Small $k$ gives low bias and high variance with jagged boundaries; large $k$ gives smoother boundaries and higher bias. $k$ is chosen by cross-validation, and an odd $k$ avoids ties in binary problems.\n\nThe method assumes that nearby points in feature space have similar targets and that the distance reflects genuine similarity. Features must be scaled, and irrelevant features add noise to distances. In high dimensions distances between points concentrate, so the nearest and farthest neighbours become hard to distinguish (the curse of dimensionality), which degrades accuracy unless features are selected or reduced first.',
    math: [
      {
        label: 'Minkowski distance',
        tex: String.raw`d_p(x, z) = \left(\sum_{j=1}^{d} \lvert x_j - z_j \rvert^{p}\right)^{1/p}`,
        note: 'With $p = 2$ this is Euclidean distance (straight line); with $p = 1$ it is Manhattan distance (sum of coordinate differences).'
      },
      {
        label: 'Classification by majority vote',
        tex: String.raw`\hat{y}(x) = \arg\max_{c}\ \sum_{i \in \mathcal{N}_k(x)} \mathbb{1}\,[\,y_i = c\,]`,
        note: '$\\mathcal{N}_k(x)$ is the set of the $k$ training points closest to $x$. The predicted class is the one with the most votes among them.'
      },
      {
        label: 'Distance-weighted regression',
        tex: String.raw`\hat{y}(x) = \frac{\sum_{i \in \mathcal{N}_k(x)} w_i\, y_i}{\sum_{i \in \mathcal{N}_k(x)} w_i}, \qquad w_i = \frac{1}{d(x, x_i)}`,
        note: 'A weighted average of neighbour targets in which nearer neighbours get larger weights.'
      }
    ],
    example: {
      title: 'Classifying one point with k = 3 and k = 5',
      body:
        'Five training points in two features: A(1,2) red, B(2,1) red, C(4,4) blue, D(5,3) blue, E(3,1) red. The query is $q = (3,3)$.\n\nEuclidean distances: to A, $\\sqrt{4+1} = 2.236$; to B, $\\sqrt{1+4} = 2.236$; to C, $\\sqrt{1+1} = 1.414$; to D, $\\sqrt{4+0} = 2$; to E, $\\sqrt{0+4} = 2$.\n\nSorted: C (1.414), D (2), E (2), then A and B (2.236).\n\nWith $k = 3$ the neighbours are C, D and E: two blue and one red, so the prediction is blue. With $k = 5$ all points vote: three red and two blue, so the prediction flips to red. The answer depends on k, which is why k is tuned on validation data rather than fixed by habit.'
    },
    pros: [
      'Very simple to understand and implement, with no training phase.',
      'Makes no assumption about the shape of the decision boundary.',
      'Adapts immediately when new labelled examples are added.',
      'Works for both classification and regression.'
    ],
    cons: [
      'Prediction is slow and memory-heavy on large datasets, since the whole training set is kept.',
      'Very sensitive to feature scaling and to irrelevant features.',
      'Accuracy deteriorates in high dimensions.',
      'Handles class imbalance poorly, because majority classes dominate the vote.'
    ],
    applications: [
      'Recommending items based on what similar users liked.',
      'Finding similar documents, images or products via a nearest-neighbour search.',
      'Filling in missing values from similar records.',
      'Retrieving previously seen similar cases to give clinicians context alongside a model output, as decision support.'
    ],
    quiz: [
      {
        question: 'When does a k-NN model do most of its computation?',
        options: [
          'During training, when it fits weights',
          'At prediction time, when distances to stored examples are computed',
          'Only when k is changed',
          'It never computes distances'
        ],
        answerIndex: 1,
        explanation: 'K-NN is a lazy learner: training just stores data, and each query requires distance calculations to the stored points.'
      },
      {
        question: 'Why should features be scaled before using k-NN?',
        options: [
          'Because k-NN cannot read negative numbers',
          'Because a feature with a large numeric range would dominate the distance',
          'Because scaling reduces the number of neighbours',
          'Because scaling increases k automatically'
        ],
        answerIndex: 1,
        explanation: 'Distances add up raw coordinate differences, so a feature measured in thousands swamps one measured in fractions unless both are rescaled.'
      },
      {
        question: 'Moving from k = 1 to a much larger k typically does what?',
        options: [
          'Lowers bias and raises variance',
          'Raises bias and lowers variance, giving a smoother boundary',
          'Leaves the boundary unchanged',
          'Guarantees higher test accuracy'
        ],
        answerIndex: 1,
        explanation: 'Averaging over more neighbours smooths the boundary and reduces variance, at the cost of blurring local structure. Test accuracy may rise or fall.'
      },
      {
        question: 'Using the example points, what is the Manhattan distance from (3,3) to C(4,4)?',
        options: ['1', '1.414', '2', '4'],
        answerIndex: 2,
        explanation: 'Manhattan distance adds the coordinate differences: $|3-4| + |3-4| = 2$. The value 1.414 is the Euclidean distance.'
      }
    ],
    related: ['support-vector-machines', 'dimensionality-reduction', 'bias-variance-tradeoff', 'k-means-clustering'],
    keywords: ['nearest neighbour', 'distance', 'lazy learning', 'curse of dimensionality', 'Euclidean', 'Manhattan']
  },

  {
    id: 'naive-bayes',
    title: 'Naive Bayes',
    category: 'supervised',
    summary: 'Naive Bayes classifies by applying Bayes rule and assuming features are independent given the class, which makes it fast and surprisingly effective.',
    readingMinutes: 6,
    intro:
      'Naive Bayes is a family of probabilistic classifiers built on one idea: use Bayes rule to turn "how likely is this evidence given the class" into "how likely is the class given this evidence". A deliberately simple independence assumption makes the arithmetic trivial.\n\nAfter this lesson you will be able to compute a posterior probability by hand, explain why the model is called naive, and say why it still works well for tasks such as text classification.',
    simple:
      'Suppose you sort your email. You know that 40% of your mail is spam. You also know that the word "free" appears in half of spam but only one in twenty normal emails, and the word "meeting" appears in one in ten spam emails but three in ten normal ones.\n\nFor a new email containing both words, you start from the base rate of spam, then multiply in how typical each word is for spam, and do the same for normal mail. Whichever total is bigger wins, and the two totals can be scaled to give a probability.\n\nThe "naive" part is that you treat each word as if it carried independent evidence, even though words clearly go together. That is not strictly true, but the shortcut keeps the method fast, and the ranking of classes is often still right.',
    technical:
      'Naive Bayes is a generative classifier. By Bayes rule the posterior is $P(c \\mid x) \\propto P(c)\\,P(x \\mid c)$. Modelling the full joint $P(x \\mid c)$ needs exponentially many parameters, so the conditional independence assumption $P(x \\mid c) = \\prod_j P(x_j \\mid c)$ is imposed, reducing it to one small distribution per feature and class.\n\nThe feature likelihood depends on the variant: Gaussian for continuous features (a mean and variance per class and feature), multinomial for word counts, and Bernoulli for binary presence. Training is counting: priors are class frequencies and likelihoods are per-class frequency estimates. This takes a single pass over the data, $O(nd)$ time, and prediction is $O(dK)$ for $K$ classes.\n\nIf a feature value never occurs with a class in training, its estimated probability is zero and wipes out the whole product. Laplace (additive) smoothing with parameter $\\alpha$ fixes this. In practice, one sums log-probabilities to avoid numerical underflow.\n\nThe independence assumption is usually violated, and correlated features are counted several times, which pushes posteriors towards 0 or 1. Class probabilities are therefore often poorly calibrated, even when the predicted class ranking is good. The hyperparameters are the smoothing $\\alpha$, class priors (which can be set manually) and, for Gaussian variants, a variance floor. The model has low variance and high bias, so it performs well on small datasets and high-dimensional sparse data.',
    math: [
      {
        label: 'Bayes rule',
        tex: String.raw`P(c \mid x) = \frac{P(x \mid c)\,P(c)}{P(x)}`,
        note: '$P(c)$ is the prior, $P(x \\mid c)$ the likelihood of the evidence under class $c$, and $P(x)$ a normalising constant that is the same for all classes.'
      },
      {
        label: 'Naive independence assumption',
        tex: String.raw`P(c \mid x_1,\dots,x_d) \;\propto\; P(c)\prod_{j=1}^{d} P(x_j \mid c), \qquad \hat{c} = \arg\max_c \Big[\log P(c) + \sum_{j} \log P(x_j \mid c)\Big]`,
        note: 'Features are treated as independent given the class. Working in log space avoids multiplying many tiny numbers.'
      },
      {
        label: 'Laplace smoothing',
        tex: String.raw`P(x_j = v \mid c) = \frac{n_{c,v} + \alpha}{n_c + \alpha\, V}`,
        note: '$n_{c,v}$ counts examples of class $c$ with value $v$, $n_c$ counts examples of class $c$, and $V$ is the number of possible values. With $\\alpha = 1$ no probability is ever exactly zero.'
      }
    ],
    example: {
      title: 'Is this email spam?',
      body:
        'Priors: $P(\\text{spam}) = 0.4$ and $P(\\text{ham}) = 0.6$. Word likelihoods: $P(\\text{free} \\mid \\text{spam}) = 0.5$, $P(\\text{free} \\mid \\text{ham}) = 0.05$, $P(\\text{meeting} \\mid \\text{spam}) = 0.1$, $P(\\text{meeting} \\mid \\text{ham}) = 0.3$.\n\nThe email contains both words. Unnormalised scores: spam $= 0.4 \\times 0.5 \\times 0.1 = 0.020$ and ham $= 0.6 \\times 0.05 \\times 0.3 = 0.009$.\n\nThe normaliser is $0.020 + 0.009 = 0.029$, so $P(\\text{spam} \\mid x) = 0.020/0.029 = 0.690$ and $P(\\text{ham} \\mid x) = 0.310$.\n\nSmoothing: if a word appeared in 0 of 20 spam emails, the raw estimate would be 0. With $\\alpha = 1$ and two outcomes (present or absent) it becomes $(0+1)/(20+2) = 0.045$, so one unseen word no longer vetoes the class.'
    },
    pros: [
      'Extremely fast to train and to predict, and it scales to many features.',
      'Works with small training sets, because it estimates few parameters.',
      'Handles high-dimensional sparse data such as word counts well.',
      'Simple, easy to implement and easy to update with new counts.'
    ],
    cons: [
      'The independence assumption is rarely true, so correlated features are double-counted.',
      'Predicted probabilities tend to be extreme and poorly calibrated.',
      'A feature value unseen for a class zeroes out the probability unless smoothing is used.',
      'Cannot learn interactions between features.'
    ],
    applications: [
      'Spam filtering and other text categorisation.',
      'Sentiment analysis as a quick baseline.',
      'Sorting support tickets into topics.',
      'A fast first-pass model in decision-support tools, where results are always reviewed by a person.'
    ],
    quiz: [
      {
        question: 'What does the naive assumption state?',
        options: [
          'All classes are equally likely.',
          'Features are conditionally independent given the class.',
          'Features are independent of the class.',
          'Every feature is normally distributed.'
        ],
        answerIndex: 1,
        explanation: 'Features are assumed independent given the class, not independent of it; otherwise they would carry no information. Normality is only assumed in the Gaussian variant.'
      },
      {
        question: 'A word never appears in the spam training emails. Without smoothing, what happens when a new email contains it?',
        options: [
          'The spam score becomes zero.',
          'The ham score becomes zero.',
          'The word is ignored automatically.',
          'The prior changes.'
        ],
        answerIndex: 0,
        explanation: 'The zero likelihood multiplies the whole product, so the spam score is zero regardless of other evidence. Laplace smoothing prevents this.'
      },
      {
        question: 'In the example, spam score 0.020 and ham score 0.009. What is the posterior probability of spam?',
        options: ['0.020', '0.310', '0.690', '0.690 only if the prior is 0.5'],
        answerIndex: 2,
        explanation: 'Normalise: $0.020/(0.020+0.009) = 0.690$. The prior is already included in the scores.'
      },
      {
        question: 'Why do implementations sum log-probabilities instead of multiplying probabilities?',
        options: [
          'To make the features independent',
          'To avoid numerical underflow from many small numbers',
          'To increase the probabilities',
          'To remove the need for priors'
        ],
        answerIndex: 1,
        explanation: 'Products of hundreds of small probabilities underflow to zero in floating point. Logs turn the product into a sum and keep the same class ranking.'
      }
    ],
    related: ['logistic-regression', 'classification-vs-regression', 'probability-calibration', 'supervised-learning'],
    keywords: ['Bayes rule', 'posterior', 'prior', 'likelihood', 'Laplace smoothing', 'text classification']
  },

  {
    id: 'classification-vs-regression',
    title: 'Classification vs regression',
    category: 'supervised',
    summary: 'Classification predicts a category and regression predicts a number; the choice decides the model, the loss function and the way you evaluate results.',
    readingMinutes: 6,
    intro:
      'Every supervised learning problem begins with one question: is the thing you want to predict a category or a quantity? Whether a loan will be repaid is a category. How much a house will sell for is a quantity. The answer steers almost every later decision.\n\nAfter this lesson you will be able to classify a prediction task correctly, see how the same algorithms appear in both forms, choose suitable metrics, and spot cases where turning one kind of task into the other helps or hurts.',
    simple:
      'Think of a doctor\'s office scale and a sorting hat. The scale returns a number, such as 72.4 kilograms, and being off by 0.1 is a smaller mistake than being off by 5. That is regression.\n\nThe sorting hat returns a label such as "red house" or "blue house". It is either right or wrong, and there is no sensible notion of being slightly red. That is classification.\n\nOften you can phrase a problem either way. Predicting a delivery time in minutes is regression. Predicting "late" or "on time" is classification. Choosing the framing depends on what decision will follow the prediction. If only the decision matters, a label may be enough; if the size of the value matters, keep the number.',
    technical:
      'In classification the target $y$ takes values in a finite set of classes, and the model estimates either a label or class probabilities $P(y = c \\mid x)$. In regression $y \\in \\mathbb{R}$ (or $\\mathbb{R}^m$) and the model estimates a conditional mean or other summary of $y \\mid x$. The distinction is about the target, not the features, which may be of either kind.\n\nLoss functions follow from the target. Regression commonly uses squared error (optimal for the conditional mean) or absolute error (optimal for the median). Classification uses log-loss on probabilities, hinge loss for margin classifiers, or the 0-1 loss for the final decision, which is not differentiable and so is replaced by a surrogate during training.\n\nMetrics differ accordingly. Regression: mean absolute error (MAE), root mean squared error (RMSE), $R^2$. Classification: accuracy, precision, recall, F1, ROC-AUC, and probability-quality measures such as the Brier score. Accuracy is misleading on imbalanced classes, and RMSE punishes large errors more than MAE does.\n\nMany algorithms have both variants: trees predict a class by majority or a number by leaf mean; k-NN votes or averages; SVMs have a support vector regression form; neural networks change only the output layer and loss. Logistic regression is regression in name only, since it models a class probability.\n\nConverting between them has costs. Binning a continuous target into classes discards information, and the chosen cut-off creates sharp, arbitrary boundaries. Using regression scores for classification, by thresholding, is common but loses calibration unless checked. Ordinal targets, such as ratings from 1 to 5, sit between the two and can be handled either way or with dedicated ordinal methods.',
    math: [
      {
        label: 'Typical regression loss: mean squared error',
        tex: String.raw`\text{MSE} = \frac{1}{n}\sum_{i=1}^{n}\big(y_i - \hat{y}_i\big)^2, \qquad \text{RMSE} = \sqrt{\text{MSE}}`,
        note: 'RMSE is in the same units as the target, which makes it easy to interpret.'
      },
      {
        label: 'Mean absolute error',
        tex: String.raw`\text{MAE} = \frac{1}{n}\sum_{i=1}^{n}\lvert y_i - \hat{y}_i \rvert`,
        note: 'Treats all errors in proportion to their size, so it is less affected by a few large errors than RMSE.'
      },
      {
        label: 'Typical classification loss and accuracy',
        tex: String.raw`\text{Accuracy} = \frac{1}{n}\sum_{i=1}^{n}\mathbb{1}\,[\hat{y}_i = y_i], \qquad L_{\text{log}} = -\frac{1}{n}\sum_{i=1}^{n}\sum_{c} \mathbb{1}[y_i = c]\,\log \hat{p}_{i,c}`,
        note: 'Accuracy counts exact matches. Log-loss scores the predicted probabilities and is what many classifiers actually minimise during training.'
      }
    ],
    example: {
      title: 'One set of predictions, scored two ways',
      body:
        'A model predicts house prices in thousands for three houses. Actual prices are 200, 250 and 310; predictions are 210, 240 and 290.\n\nRegression view: the errors are 10, 10 and 20. MAE $= (10 + 10 + 20)/3 = 13.33$. MSE $= (100 + 100 + 400)/3 = 200$, so RMSE $= \\sqrt{200} = 14.14$. RMSE is larger than MAE because the 20 error counts more heavily when squared.\n\nClassification view: define "expensive" as a price above 300. The actual labels are no, no, yes. The predictions of 210, 240 and 290 all fall below 300, so the predicted labels are no, no, no. Accuracy is $2/3 = 0.67$, and the one expensive house is missed, so recall for the "expensive" class is 0.\n\nThe same predictions look fairly good as numbers (about 14 thousand off) and mixed as labels. The metric must match the question that the decision-maker actually asks.'
    },
    pros: [
      'Framing a task correctly points you to the right family of models and metrics.',
      'Classification outputs map directly onto decisions, such as approve or decline.',
      'Regression keeps the full information in a numeric target and the size of each error.',
      'Many algorithms support both, so skills and tools transfer.'
    ],
    cons: [
      'Binning a number into classes throws away information and creates arbitrary cut-offs.',
      'Using the wrong metric, such as accuracy on rare events, gives a falsely comforting picture.',
      'Regression models can predict impossible values, such as negative counts, unless constrained.',
      'Ordinal targets do not fit neatly in either category.'
    ],
    applications: [
      'Regression: forecasting energy demand or estimating delivery times.',
      'Classification: flagging fraudulent transactions or sorting images by content.',
      'Regression: estimating a continuous lab quantity from other measurements, supporting a clinician\'s review.',
      'Classification: routing support tickets to the right team.'
    ],
    quiz: [
      {
        question: 'Which task is a regression problem?',
        options: [
          'Deciding whether a photo shows a cat or a dog',
          'Predicting tomorrow\'s peak electricity demand in megawatts',
          'Labelling emails as spam or not spam',
          'Assigning a customer to one of four plans'
        ],
        answerIndex: 1,
        explanation: 'A demand in megawatts is a continuous quantity. The other three predict categories.'
      },
      {
        question: 'A rare event occurs in 2% of cases. A model that always predicts "no event" has what accuracy?',
        options: ['2%', '50%', '98%', '100%'],
        answerIndex: 2,
        explanation: 'It is right in the 98% of cases with no event and wrong in the rest. This shows why accuracy can mislead on imbalanced data; recall for the rare class would be 0.'
      },
      {
        question: 'Errors of 10, 10 and 20 give MAE 13.33. Why is RMSE (14.14) larger?',
        options: [
          'RMSE averages in a different unit',
          'Squaring gives the largest error more weight before averaging',
          'RMSE ignores small errors',
          'RMSE divides by n minus one'
        ],
        answerIndex: 1,
        explanation: 'Squaring magnifies the 20 error: $(100+100+400)/3 = 200$, whose root is 14.14. RMSE is never smaller than MAE.'
      },
      {
        question: 'Which statement about logistic regression is correct?',
        options: [
          'It is a regression method that predicts any real number.',
          'It is a classification method that models class probability.',
          'It can only be used on categorical features.',
          'It minimises mean squared error by default.'
        ],
        answerIndex: 1,
        explanation: 'Despite the name, logistic regression predicts a class probability through the sigmoid and is trained with log-loss.'
      }
    ],
    related: ['linear-regression', 'logistic-regression', 'supervised-learning', 'loss-functions', 'accuracy'],
    keywords: ['classification', 'regression', 'target', 'MAE', 'RMSE', 'accuracy', 'ordinal']
  }
];
