import type { Lesson } from '../types';

/*
 * Shared worked example for the metric lessons: a screening model is run on 200 people, 50 of whom
 * truly have the condition. TP = 40, FN = 10, FP = 15, TN = 135.
 */
export const evaluationLessons: Lesson[] = [
  {
    id: 'train-test-split',
    title: 'Train/test split',
    category: 'evaluation',
    summary: 'Holding back a portion of the data, never used for fitting, gives an honest estimate of how a model performs on new cases.',
    readingMinutes: 6,
    intro:
      'A model is fitted to data, so its score on that same data is flattering. A flexible model can memorise its training rows and still fail on the next patient or the next customer. To judge a model fairly you need cases it has never seen.\n\nThe train/test split is the simplest way to get them. You set aside a fraction of the rows before any fitting begins, train on the rest, and score the model once on the held-back part. After this lesson you will know how to split, what can go wrong, and how much trust a single test score deserves.',
    simple:
      'Think of a teacher preparing an exam. If the exam questions are the same ones used in class, a high mark only shows that students remembered the answers. A fair exam uses new questions on the same material.\n\nThe test set is that fair exam. The training set is the practice material. The one rule is that the test questions must stay sealed until the model has finished studying. Looking at them early, even to tune a setting, turns them into practice material and the exam stops being fair.',
    technical:
      'Given $n$ labelled rows, a random subset of size about $(1-q)n$ is used for training and the remaining $qn$ rows form the test set, with $q$ commonly between 0.1 and 0.3. For classification with a rare class, use a **stratified** split so each part keeps roughly the same class proportions. For data with time order or repeated measurements of the same person, split by time or by person; a random split would put near-copies of a case on both sides and inflate the score.\n\nThe test score is an estimate with its own uncertainty. For an error rate $p$ measured on $m$ independent test cases, the standard error is about $\\sqrt{p(1-p)/m}$, so small test sets give noisy estimates. Any step that learns from data, such as scaling, imputing or selecting features, must be fitted on the training part only. Fitting it on all rows leaks information from the test set. If you also need to tune hyperparameters, add a validation set or use cross-validation, and touch the test set once at the end.',
    math: [
      {
        label: 'Split sizes',
        tex: String.raw`n_{\text{train}} = \lfloor (1-q)\,n \rfloor, \qquad n_{\text{test}} = n - n_{\text{train}}`,
        note: '$n$ is the number of rows and $q$ is the test fraction, for example $q = 0.2$.'
      },
      {
        label: 'Standard error of a test error rate',
        tex: String.raw`\operatorname{SE}(\hat p) \;\approx\; \sqrt{\frac{\hat p\,(1-\hat p)}{m}}`,
        note: '$\\hat p$ is the observed error rate on $m$ test cases. Quadrupling the test size roughly halves the standard error.'
      }
    ],
    example: {
      title: 'An 80/20 stratified split of 1000 rows',
      body:
        'A dataset has 1000 rows and 100 positives (10%). With $q = 0.2$ and stratification, the training set gets 800 rows with 80 positives and the test set gets 200 rows with 20 positives.\n\nSuppose the model makes 25 errors on the test set. The error rate is $25/200 = 0.125$. The standard error is $\\sqrt{0.125 \\times 0.875 / 200} \\approx 0.023$, so a rough range for the true error rate is 0.125 plus or minus 0.046 (two standard errors), about 8% to 17%. A single split cannot narrow this further; only more test data or repeated splitting can.'
    },
    pros: [
      'Very simple and fast: the model is trained once.',
      'Gives an estimate on cases the model never saw, which exposes memorisation.',
      'Easy to explain to non-specialists and to document for review.',
      'Works with any model and any metric.'
    ],
    cons: [
      'The estimate depends on which rows landed in the test set and can be noisy on small data.',
      'Holding data back means the final model learns from fewer rows.',
      'Leakage, such as scaling on all rows or splitting one patient across both sides, quietly inflates the score.',
      'Reusing the test set to compare many models makes it an optimistic estimate too.'
    ],
    applications: [
      'A first honest benchmark for any supervised model.',
      'Final reporting once all tuning is finished.',
      'Time-ordered forecasting, using the latest period as the test set.',
      'Patient-level splits for clinical prediction models, so no person appears on both sides.'
    ],
    quiz: [
      {
        question: 'Why must the test set stay unused during model fitting and tuning?',
        options: [
          'It would make training slower.',
          'Any decision informed by it makes the final score optimistic.',
          'The model needs a different file format for testing.',
          'Test rows have no labels.'
        ],
        answerIndex: 1,
        explanation: 'If choices are guided by test performance, the test set has effectively been trained on, and its score no longer estimates performance on new data.'
      },
      {
        question: 'You standardise every feature using the mean and standard deviation of the whole dataset, then split. What is the problem?',
        options: [
          'Nothing; standardisation has no parameters.',
          'The model will need more features.',
          'Test-set information leaked into preprocessing.',
          'Standardisation only works on the test set.'
        ],
        answerIndex: 2,
        explanation: 'The mean and standard deviation are learned from data. They should be computed on the training part and then applied unchanged to the test part.'
      },
      {
        question: 'A dataset has several rows per patient. Which split is most appropriate?',
        options: [
          'A random split of individual rows.',
          'A split by patient, so each patient is entirely in train or test.',
          'Put all the patients with the most rows in the test set.',
          'No split is possible.'
        ],
        answerIndex: 1,
        explanation: 'Rows from one patient are correlated. Splitting by row puts near-copies on both sides and inflates the score.'
      },
      {
        question: 'Which change most directly reduces the noise in a test error estimate?',
        options: ['Shuffling the rows again', 'Using a larger test set', 'Choosing a smaller model', 'Training for more iterations'],
        answerIndex: 1,
        explanation: 'The standard error shrinks with the square root of the number of test cases. The other changes do not reduce the sampling noise of the estimate.'
      }
    ],
    related: ['train-validation-test', 'cross-validation', 'generalization'],
    keywords: ['holdout', 'test set', 'stratified split', 'data leakage', 'generalisation']
  },
  {
    id: 'cross-validation',
    title: 'Cross-validation',
    category: 'evaluation',
    summary: 'Cross-validation repeats train and test across several folds so every row is used for evaluation once, giving a steadier estimate than one split.',
    readingMinutes: 6,
    intro:
      'A single train/test split gives one score, and that score depends on luck: an unusually easy or hard test set shifts it. On small datasets the effect can be large, and setting aside a big test set leaves little to train on.\n\nCross-validation addresses both problems by rotating which rows are held out. After this lesson you will be able to describe k-fold cross-validation, read its mean and spread, and avoid the common mistakes that make its numbers too optimistic.',
    simple:
      'Imagine five friends tasting a recipe. Instead of one friend judging it, you let each friend taste in turn while the other four help you adjust it. At the end you have five opinions rather than one, and every friend has been the judge exactly once.\n\nIn k-fold cross-validation the data is cut into k equal parts called folds. Each fold takes one turn as the exam while the other folds are used for training. You then look at all the scores together: their average tells you the typical performance and their spread tells you how stable it is.',
    technical:
      'In k-fold cross-validation the rows are partitioned into $k$ folds. For each fold $j$, a fresh model is trained on the other $k-1$ folds and scored on fold $j$. The estimate is the mean of the $k$ scores, and the spread across folds, such as the sample standard deviation, indicates stability. Typical choices are $k=5$ or $k=10$. Larger $k$ trains on more data per round and has less bias, at the cost of more fitting. Leave-one-out is the extreme case $k=n$.\n\nUse stratified folds for imbalanced classes and grouped folds when rows share a patient or other group. All preprocessing must sit inside each training round, which a pipeline object handles. Fold scores are not independent because the training sets overlap, so the standard deviation across folds understates the true uncertainty. If cross-validation is used to choose hyperparameters, the resulting score is optimistic; for an unbiased figure use nested cross-validation or a final untouched test set.',
    math: [
      {
        label: 'Cross-validated estimate',
        tex: String.raw`\widehat{\text{CV}} \;=\; \frac{1}{k}\sum_{j=1}^{k} s_j`,
        note: '$s_j$ is the score on fold $j$ from a model trained on the other folds.'
      },
      {
        label: 'Spread across folds',
        tex: String.raw`\hat\sigma \;=\; \sqrt{\frac{1}{k-1}\sum_{j=1}^{k}\big(s_j-\widehat{\text{CV}}\big)^2}`,
        note: 'A sample standard deviation of the fold scores. Treat it as a rough guide, because folds share training data.'
      }
    ],
    example: {
      title: 'Five-fold cross-validation on 100 rows',
      body:
        'With 100 rows and $k = 5$, each fold has 20 rows. The model gets 16, 17, 15, 18 and 16 of 20 correct in the five rounds, so the fold accuracies are 0.80, 0.85, 0.75, 0.90 and 0.80.\n\nThe mean is $(0.80 + 0.85 + 0.75 + 0.90 + 0.80)/5 = 0.82$, which equals 82 correct out of 100 because the folds are equal in size. The sample standard deviation is about 0.057. You would report roughly 0.82 with a spread of about 0.06 across folds, and each row was used for testing exactly once.'
    },
    pros: [
      'Uses every row for both training and evaluation, which suits small datasets.',
      'Averages away the luck of a single split.',
      'The spread across folds shows how sensitive the result is to the data.',
      'The same procedure works for model comparison and hyperparameter search.'
    ],
    cons: [
      'Costs about k times the computation of a single fit.',
      'Fold scores overlap in training data, so the spread understates uncertainty.',
      'Leakage in preprocessing or grouped data still inflates results.',
      'Random folds are wrong for time series, where order must be respected.',
      'Choosing a model by its CV score makes that score optimistic.'
    ],
    applications: [
      'Comparing candidate algorithms on a modest dataset.',
      'Selecting hyperparameters such as regularisation strength.',
      'Estimating performance of clinical models with limited patient numbers, using patient-grouped folds.',
      'Checking that a result is stable before investing in a larger study.'
    ],
    quiz: [
      {
        question: 'In 5-fold cross-validation, how many times is each row used as part of a test fold?',
        options: ['Five times', 'Exactly once', 'Never, it is always training data', 'Four times'],
        answerIndex: 1,
        explanation: 'The folds partition the data, so each row sits in exactly one test fold and in the training set for the other four rounds.'
      },
      {
        question: 'Which kind of data requires a split other than random folds?',
        options: [
          'A balanced dataset with independent rows',
          'Time series, where later values must not be used to predict earlier ones',
          'A dataset with numeric features',
          'A dataset with more than 100 rows'
        ],
        answerIndex: 1,
        explanation: 'Random folds would let the model train on the future to predict the past. Use forward-chaining splits that respect time order.'
      },
      {
        question: 'You tune hyperparameters using the CV score and then report that same CV score as final performance. What is the issue?',
        options: [
          'The score is likely optimistic because the same folds guided the choice.',
          'The score is pessimistic because the folds are too small.',
          'There is no issue.',
          'CV cannot be used with hyperparameters.'
        ],
        answerIndex: 0,
        explanation: 'Selecting the best of many configurations on the same folds picks up some luck. Nested cross-validation or an untouched test set gives an unbiased estimate.'
      },
      {
        question: 'Why does the standard deviation of fold scores understate real uncertainty?',
        options: [
          'Folds are always identical.',
          'Training sets overlap heavily, so scores are correlated.',
          'The standard deviation ignores the mean.',
          'Fold scores are always integers.'
        ],
        answerIndex: 1,
        explanation: 'Because any two rounds share most of their training rows, the scores are not independent, and the naive spread is too small.'
      }
    ],
    related: ['train-test-split', 'hyperparameter-optimization', 'overfitting-underfitting'],
    keywords: ['k-fold', 'stratified', 'leave-one-out', 'nested cross-validation', 'model selection']
  },
  {
    id: 'confusion-matrix',
    title: 'Confusion matrix',
    category: 'evaluation',
    summary: 'A confusion matrix counts how many cases of each true class were predicted as each class, and is the source of most classification metrics.',
    readingMinutes: 6,
    intro:
      'A single number such as accuracy hides which kind of mistake a classifier makes. Missing a case that is present and raising a false alarm are different errors with different costs, and one score cannot tell them apart.\n\nThe confusion matrix lays the outcomes out in a small table. This lesson introduces its four cells and the example used throughout the evaluation lessons: a screening model run on 200 people, 50 of whom truly have the condition.',
    simple:
      'Picture a smoke alarm. There are four things that can happen in any given hour. There is a fire and the alarm rings: a true positive. There is no fire and it stays quiet: a true negative. It rings with no fire: a false positive, the annoying burnt-toast alarm. There is a fire and it stays silent: a false negative, the dangerous one.\n\nA confusion matrix is simply the tally of those four outcomes over many hours. Once you have the tally, you can ask which mistakes you can live with.',
    technical:
      'For a binary classifier with a positive and a negative class, the matrix has rows for the true class and columns for the predicted class. The cells are **TP** (true positive: positive predicted positive), **FN** (false negative: positive predicted negative), **FP** (false positive: negative predicted positive) and **TN** (true negative: negative predicted negative). Row sums give the true class counts, so $P = TP + FN$ and $N = FP + TN$, and the grand total is the number of cases.\n\nA probabilistic model produces scores, and the matrix depends on a decision threshold, commonly 0.5 but not necessarily right. Changing the threshold moves cases between cells: a lower threshold converts FN into TP and TN into FP. For more than two classes the matrix is $K \\times K$ and the diagonal holds correct predictions. Report counts, not only percentages, since the class mix and sample size matter. Always note whether rows or columns are the true classes, because both layouts are in use.',
    math: [
      {
        label: 'Cell relations',
        tex: String.raw`P = TP + FN, \qquad N = FP + TN, \qquad n = TP + FN + FP + TN`,
        note: '$P$ is the number of actual positives, $N$ the number of actual negatives and $n$ the total number of cases.'
      }
    ],
    example: {
      title: 'The screening model on 200 people',
      body:
        'Of 200 people, 50 truly have the condition and 150 do not. The model flags 55 people and clears 145. Its matrix is:\n\n- True positives (condition present, flagged): 40\n- False negatives (condition present, not flagged): 10\n- False positives (no condition, flagged): 15\n- True negatives (no condition, not flagged): 135\n\nCheck the totals: $40 + 10 = 50$ actual positives, $15 + 135 = 150$ actual negatives, $40 + 15 = 55$ flagged and $10 + 135 = 145$ cleared, giving 200 in all. Every metric in the following lessons is computed from these four numbers. The model is a decision-support aid; the 10 missed people are exactly the ones a clinician would still want to catch by other means.'
    },
    pros: [
      'Shows the type of error, not just how many errors there are.',
      'Is the single source for accuracy, precision, recall, specificity and F1.',
      'Extends naturally to many classes and reveals which classes get confused.',
      'Easy to read and to audit.'
    ],
    cons: [
      'Depends on one chosen threshold, so it hides behaviour at other thresholds.',
      'Counts alone do not show how costly each error is.',
      'Different layouts (true classes in rows or columns) cause misreading.',
      'On a very large number of classes it becomes hard to read.'
    ],
    applications: [
      'Comparing screening models by missed cases and false alarms.',
      'Diagnosing which categories an image classifier mixes up.',
      'Reviewing a fraud detector by how many genuine payments it blocks.',
      'Choosing a threshold by seeing how cells shift.'
    ],
    quiz: [
      {
        question: 'A person has the condition but the model clears them. Which cell does this fall in?',
        options: ['True positive', 'False positive', 'True negative', 'False negative'],
        answerIndex: 3,
        explanation: 'The case is actually positive and was predicted negative, so it is a false negative.'
      },
      {
        question: 'In the worked example, how many people were flagged by the model?',
        options: ['50', '55', '145', '175'],
        answerIndex: 1,
        explanation: 'Flagged means predicted positive: TP + FP = 40 + 15 = 55. The number 50 is the count of actual positives.'
      },
      {
        question: 'What happens to the matrix if you lower the decision threshold?',
        options: [
          'Nothing changes.',
          'More cases are predicted positive, so FN usually falls and FP usually rises.',
          'More cases are predicted negative, so FP rises.',
          'The total number of cases changes.'
        ],
        answerIndex: 1,
        explanation: 'A lower threshold flags more cases. Some become true positives, but some negatives become false positives. The total number of cases is fixed.'
      },
      {
        question: 'What is the sum of the four cells?',
        options: ['The number of positives', 'The number of predicted positives', 'The total number of cases', 'Always 1'],
        answerIndex: 2,
        explanation: 'Every case lands in exactly one cell, so the cells add up to the total.'
      }
    ],
    related: ['accuracy', 'precision', 'recall'],
    keywords: ['TP', 'FP', 'FN', 'TN', 'threshold', 'classification errors']
  },
  {
    id: 'accuracy',
    title: 'Accuracy',
    category: 'evaluation',
    summary: 'Accuracy is the fraction of all predictions that are correct, and it can look excellent while a model misses almost every rare case.',
    readingMinutes: 6,
    intro:
      'Accuracy is the first metric most people reach for because it answers a plain question: how often is the model right? It is easy to compute and easy to explain.\n\nIt is also easy to misuse. When one class is much rarer than the other, a model can score high accuracy while being useless for the rare class, which is often the one that matters. This lesson shows how accuracy is computed, when it is informative and why it should rarely be the only number you report.',
    simple:
      'Suppose a teacher marks 100 true/false questions and a student gets 90 right. The accuracy is 90 percent. That is a fair summary when the questions are balanced and every wrong answer costs the same.\n\nNow imagine a test where 99 of the 100 answers are false. A student who writes false on everything gets 99 percent without knowing anything. Accuracy rewards the habit of guessing the common answer, which is why it can mislead on rare-event problems.',
    technical:
      'Accuracy is the proportion of correct predictions: $(TP + TN)/n$. It equals one minus the error rate. It treats all errors as equally costly and is dominated by the larger class. The relevant yardstick is the **majority-class baseline**, the accuracy of always predicting the most common class, which equals $\\max(P, N)/n$. A model is only interesting if it beats this baseline in a way that matters.\n\nThis is the **accuracy paradox**: with 1% prevalence a model that never predicts the condition is 99% accurate and has zero recall. Better summaries on imbalanced data include recall, precision, specificity, balanced accuracy (the mean of recall and specificity), F1, and threshold-free measures such as ROC-AUC or PR-AUC. Accuracy also depends on the threshold and on the class mix of the evaluation set, so it does not transfer to a population with a different prevalence.',
    math: [
      {
        label: 'Accuracy',
        tex: String.raw`\text{accuracy} \;=\; \frac{TP + TN}{TP + TN + FP + FN}`,
        note: 'The share of all cases on the diagonal of the confusion matrix.'
      },
      {
        label: 'Balanced accuracy',
        tex: String.raw`\text{balanced accuracy} \;=\; \frac{1}{2}\left(\frac{TP}{TP+FN} + \frac{TN}{TN+FP}\right)`,
        note: 'The average of recall and specificity, so each class counts equally regardless of its size.'
      }
    ],
    example: {
      title: 'Accuracy versus a model that never flags anyone',
      body:
        'For the screening model, $TP = 40$, $TN = 135$, $FP = 15$, $FN = 10$ and $n = 200$. Accuracy is $(40 + 135)/200 = 175/200 = 0.875$.\n\nNow consider a lazy model that predicts negative for everyone. It gets all 150 negatives right and all 50 positives wrong, so its accuracy is $150/200 = 0.75$, with recall 0. The real model only gains 12.5 points over this baseline.\n\nBalanced accuracy tells the story better: recall is $40/50 = 0.80$ and specificity is $135/150 = 0.90$, so balanced accuracy is 0.85, while the lazy model scores $(0 + 1)/2 = 0.50$.'
    },
    pros: [
      'Simple to compute and to explain.',
      'Meaningful when classes are balanced and errors cost about the same.',
      'A single number that is convenient for quick comparisons.',
      'Directly related to the 0-1 loss.'
    ],
    cons: [
      'Misleading on imbalanced data, as the accuracy paradox shows.',
      'Hides the split between false alarms and missed cases.',
      'Depends on the threshold and on the prevalence of the test set.',
      'Gives no information about the quality of predicted probabilities.'
    ],
    applications: [
      'Quick sanity checks on balanced classification tasks.',
      'Benchmark comparisons where classes are roughly equal, such as digit recognition.',
      'Reporting together with the majority-class baseline.',
      'Monitoring a deployed model for a sudden drop, alongside class-specific metrics.'
    ],
    quiz: [
      {
        question: 'In a dataset where 1% of cases are positive, a model predicts negative for every case. What is its accuracy and recall?',
        options: ['99% accuracy, 0% recall', '50% accuracy, 0% recall', '99% accuracy, 99% recall', '1% accuracy, 100% recall'],
        answerIndex: 0,
        explanation: 'It is right on the 99% that are negative and wrong on every positive, so recall is zero. This is the accuracy paradox.'
      },
      {
        question: 'The screening example has TP=40, TN=135, FP=15 and FN=10. What is the accuracy?',
        options: ['0.800', '0.900', '0.875', '0.727'],
        answerIndex: 2,
        explanation: '(40 + 135)/200 = 0.875. The value 0.80 is recall, 0.90 is specificity and 0.727 is precision.'
      },
      {
        question: 'Which baseline should you compare accuracy against on imbalanced data?',
        options: [
          'A coin flip at 50%',
          'The accuracy of always predicting the majority class',
          'Zero',
          'The training accuracy'
        ],
        answerIndex: 1,
        explanation: 'The majority-class baseline shows what accuracy is achievable without learning anything. A coin flip is the wrong reference when classes are unequal.'
      }
    ],
    related: ['confusion-matrix', 'recall', 'f1-score'],
    keywords: ['accuracy paradox', 'class imbalance', 'baseline', 'balanced accuracy', 'error rate']
  },
  {
    id: 'precision',
    title: 'Precision',
    category: 'evaluation',
    summary: 'Precision is the fraction of flagged cases that are truly positive: when the model raises an alert, how often is it right?',
    readingMinutes: 5,
    intro:
      'When a model flags a case, someone has to act on it: review a transaction, call a patient back, remove a post. Each false alert costs time and attention, and too many of them make people stop trusting the system.\n\nPrecision measures how trustworthy the alerts are. This lesson defines it, shows how it depends on how common the positive class is, and explains why it is usually paired with recall.',
    simple:
      'Imagine a metal detector on a beach. Each time it beeps you dig. Precision is the share of beeps that turn up something worth finding. If you dig 55 holes and 40 contain something, the detector is right 40 out of 55 times.\n\nA detector that rarely beeps but is nearly always right has high precision. It might still miss most of the treasure, which is why precision on its own never tells the whole story.',
    technical:
      'Precision, also called positive predictive value, is $TP/(TP + FP)$, the probability that a case is truly positive given that it was predicted positive. It conditions on the predicted class, so it depends on the **prevalence** of the positive class in the population, not only on how well the model separates classes. A model with a fixed recall and false-positive rate will have lower precision when positives become rarer, because the many negatives generate more false alarms in absolute terms.\n\nPrecision is undefined when nothing is predicted positive. It trades off against recall as the threshold changes: raising the threshold usually removes borderline predictions, which tends to improve precision and reduce recall, though precision is not guaranteed to be monotone. Because of the prevalence dependence, a precision measured on a test set built with a different positive rate from the deployment population can be badly misleading.',
    math: [
      {
        label: 'Precision (positive predictive value)',
        tex: String.raw`\text{precision} \;=\; \frac{TP}{TP + FP}`,
        note: 'The denominator is the number of cases the model flagged as positive.'
      },
      {
        label: 'Precision from recall, false-positive rate and prevalence',
        tex: String.raw`\text{precision} \;=\; \frac{\text{TPR}\cdot \pi}{\text{TPR}\cdot \pi + \text{FPR}\cdot (1-\pi)}`,
        note: '$\\pi$ is the prevalence of positives. TPR is recall and FPR is the false-positive rate.'
      }
    ],
    example: {
      title: 'Precision of the screening model, and what happens at low prevalence',
      body:
        'The model flags $40 + 15 = 55$ people, and 40 of them truly have the condition. Precision is $40/55 \\approx 0.727$: about 73% of alerts are correct and 27% are false alarms.\n\nThe model has recall 0.80 and false-positive rate $15/150 = 0.10$. Prevalence in the sample is 0.25. Now apply the same model to a population where prevalence is 0.02. Precision becomes $0.8 \\times 0.02/(0.8 \\times 0.02 + 0.10 \\times 0.98) = 0.016/0.114 \\approx 0.14$. The model itself did not change, yet only about one alert in seven is now correct.'
    },
    pros: [
      'Directly measures the cost of false alarms.',
      'Easy to interpret as how often an alert is right.',
      'Pairs naturally with recall to describe the trade-off.',
      'Relevant to workload: it tells you how many reviews are wasted.'
    ],
    cons: [
      'Ignores positives the model missed, so it can be gamed by flagging very few cases.',
      'Depends strongly on prevalence, which may differ between test data and deployment.',
      'Undefined when no case is flagged.',
      'Changes with the threshold, so a single value hides the trade-off.'
    ],
    applications: [
      'Spam filtering, where blocking genuine email is costly.',
      'Prioritising which transactions fraud analysts review.',
      'Deciding how many follow-up tests a screening programme will trigger.',
      'Search and retrieval, where users want relevant results at the top.'
    ],
    quiz: [
      {
        question: 'A model flags 55 cases and 40 are truly positive. What is the precision?',
        options: ['0.80', '0.875', '0.727', '0.90'],
        answerIndex: 2,
        explanation: '40/55 is about 0.727. The value 0.80 is recall because it divides by the 50 actual positives.'
      },
      {
        question: 'The same model is deployed in a population where positives are much rarer. What usually happens to precision?',
        options: ['It rises.', 'It falls.', 'It is unchanged.', 'It becomes equal to recall.'],
        answerIndex: 1,
        explanation: 'Negatives vastly outnumber positives, so the same false-positive rate creates many more false alarms relative to true hits.'
      },
      {
        question: 'Which statement about precision is correct?',
        options: [
          'It uses the number of false negatives.',
          'It uses true negatives.',
          'It is the share of predicted positives that are correct.',
          'It is the share of actual positives that are found.'
        ],
        answerIndex: 2,
        explanation: 'Precision is TP/(TP + FP). It ignores TN and FN. The last option describes recall.'
      }
    ],
    related: ['recall', 'f1-score', 'precision-recall-curve'],
    keywords: ['positive predictive value', 'false alarms', 'prevalence', 'PPV']
  },
  {
    id: 'recall',
    title: 'Recall (sensitivity)',
    category: 'evaluation',
    summary: 'Recall is the fraction of truly positive cases that the model finds, which matters most when missing a case is costly.',
    readingMinutes: 6,
    intro:
      'Some errors are much worse than others. A screening test that misses a person who has a treatable condition lets the problem go unnoticed, while a false alarm usually leads to a further check. In such settings the question to ask is how many of the real cases the model catches.\n\nThat quantity is recall, also called sensitivity or the true-positive rate. This lesson defines it, explains why it is the headline metric for screening, and shows the price paid for pushing it up.',
    simple:
      'Imagine a net cast over a lake to catch every fish of a certain species. Recall is the share of those fish that end up in the net. A wide net with small holes catches nearly all of them, and also a lot of other things you did not want.\n\nWhen the job is to find every case, such as finding everyone who needs a follow-up scan, a wide net is sensible. You accept extra false alarms to avoid leaving real cases behind, then rely on a second, more careful step to sort them out.',
    technical:
      'Recall is $TP/(TP + FN) = TP/P$, the probability that a positive case is predicted positive. It depends only on the positive row of the confusion matrix, so it is not affected by prevalence and cannot be inflated by predicting few negatives. It is maximised trivially by predicting positive for everyone, which is why it must be read next to precision or specificity.\n\nFor screening, a first-stage test is typically tuned for high recall, accepting lower precision, since positives are followed up with a more specific test. Choosing the threshold means picking the operating point on the recall/false-positive trade-off. In a clinical setting this is a decision about harms and benefits, including the burden of follow-up for false alarms, and should involve domain experts. Report recall with an uncertainty interval, since it rests on the number of positives only: with 50 positives, one extra miss moves recall by two points.',
    math: [
      {
        label: 'Recall (sensitivity, true-positive rate)',
        tex: String.raw`\text{recall} \;=\; \frac{TP}{TP + FN}`,
        note: 'The denominator is the number of actual positives.'
      },
      {
        label: 'Miss rate',
        tex: String.raw`\text{miss rate} \;=\; \frac{FN}{TP + FN} \;=\; 1 - \text{recall}`,
        note: 'The share of true positives that the model fails to flag.'
      }
    ],
    example: {
      title: 'Recall at two thresholds',
      body:
        'At its default threshold the model finds 40 of the 50 people with the condition, so recall is $40/50 = 0.80$ and the miss rate is 0.20.\n\nSuppose the threshold is lowered and the model now finds 46 of the 50, with 10 more false alarms, so FP rises from 15 to 25. Recall is $46/50 = 0.92$. Precision falls from $40/55 \\approx 0.727$ to $46/71 \\approx 0.648$, since $46 + 25 = 71$ people are now flagged.\n\nWhether this is worthwhile depends on the setting: six more people found against ten more false alarms. In a first-stage screen that feeds a confirmatory test, many programmes would accept it. This is a prompt for clinical judgement, not a rule.'
    },
    pros: [
      'Directly measures how many real cases are caught.',
      'Not affected by how common the positive class is.',
      'Aligns with screening goals where misses are costly.',
      'Easy to explain as the share of cases found.'
    ],
    cons: [
      'Trivially 100% if everything is flagged, so it ignores false alarms.',
      'Has high variance when positives are few.',
      'Gives no information about how reliable a positive prediction is.',
      'Raising it usually lowers precision and specificity.'
    ],
    applications: [
      'Screening tests designed to miss as few true cases as possible, followed by confirmation.',
      'Safety monitoring where an undetected event is costly.',
      'Fraud detection where missed fraud has a direct financial loss.',
      'Search for relevant documents in legal review.'
    ],
    quiz: [
      {
        question: 'Recall in the worked example is 0.80. What does this mean?',
        options: [
          '80% of flagged people have the condition.',
          '80% of all predictions are correct.',
          '80% of people without the condition are cleared.',
          '80% of people with the condition are flagged.'
        ],
        answerIndex: 3,
        explanation: 'Recall is TP/(TP + FN) = 40/50. The first option describes precision, the second accuracy and the third specificity.'
      },
      {
        question: 'Why is recall the usual headline metric for a first-stage screening test?',
        options: [
          'Missed cases cannot be recovered later, while false alarms can be resolved by follow-up.',
          'It is the only metric that uses all four cells.',
          'It is always higher than precision.',
          'It ignores the positive class.'
        ],
        answerIndex: 0,
        explanation: 'A missed case may never get a second look, whereas a false alarm triggers a confirmatory step. Recall also does not use all four cells and is not always above precision.'
      },
      {
        question: 'A model flags every case as positive. What are its recall and precision?',
        options: ['Recall 1, precision equal to prevalence', 'Recall 0, precision 1', 'Recall 1, precision 1', 'Recall 0.5, precision 0.5'],
        answerIndex: 0,
        explanation: 'Every positive is found, so recall is 1. Of the flagged cases only the positive share is correct, which is the prevalence.'
      },
      {
        question: 'What is the miss rate if recall is 0.92?',
        options: ['0.92', '0.08', '0.46', '0.18'],
        answerIndex: 1,
        explanation: 'Miss rate = 1 - recall = 0.08.'
      }
    ],
    related: ['specificity', 'precision', 'roc-curve'],
    keywords: ['sensitivity', 'true-positive rate', 'screening', 'miss rate']
  },
  {
    id: 'specificity',
    title: 'Specificity',
    category: 'evaluation',
    summary: 'Specificity is the fraction of truly negative cases that the model correctly clears, the mirror image of recall.',
    readingMinutes: 5,
    intro:
      'Recall tells you how many real cases are found. It says nothing about the people who do not have the condition and are wrongly flagged. Those false alarms cause worry, extra tests and wasted resources.\n\nSpecificity describes how well the model leaves healthy cases alone. This lesson defines it, links it to the false-positive rate and explains why it is reported together with sensitivity.',
    simple:
      'Back to the smoke alarm. Recall asks how often it rings when there is a fire. Specificity asks how often it stays quiet when there is no fire. A very sensitive alarm that goes off whenever you make toast has poor specificity.\n\nA good test has both properties: it rings for real fires and stays silent otherwise. In practice there is a trade-off, and moving the threshold buys one at the expense of the other.',
    technical:
      'Specificity, or true-negative rate, is $TN/(TN + FP) = TN/N$. It is the negative-class counterpart of recall and does not depend on prevalence. Its complement is the **false-positive rate**, $FPR = FP/(FP + TN) = 1 - \\text{specificity}$, which is the x-axis of the ROC curve.\n\nSensitivity and specificity are properties of the test at a threshold; predictive values, such as precision and the negative predictive value, also depend on prevalence. That distinction matters when a model validated on a balanced sample is applied to a low-prevalence population: sensitivity and specificity carry over, but precision does not. Specificity is high when the model flags few negatives, so it is easy to obtain by flagging almost nothing. It is therefore interpreted next to recall, for instance through balanced accuracy or the ROC curve.',
    math: [
      {
        label: 'Specificity (true-negative rate)',
        tex: String.raw`\text{specificity} \;=\; \frac{TN}{TN + FP}`,
        note: 'The denominator is the number of actual negatives.'
      },
      {
        label: 'False-positive rate',
        tex: String.raw`\text{FPR} \;=\; \frac{FP}{FP + TN} \;=\; 1 - \text{specificity}`,
        note: 'The share of negatives that are wrongly flagged.'
      }
    ],
    example: {
      title: 'Specificity of the screening model',
      body:
        'Among the 150 people without the condition, the model clears 135 and flags 15. Specificity is $135/150 = 0.90$ and the false-positive rate is $15/150 = 0.10$.\n\nAt the lower threshold from the recall lesson, false positives rise to 25 and true negatives fall to 125, so specificity becomes $125/150 \\approx 0.833$. Recall rose from 0.80 to 0.92 and specificity fell from 0.90 to 0.833. Both numbers are needed to see the trade-off, which is exactly what the ROC curve plots.'
    },
    pros: [
      'Measures the avoidance of false alarms among those without the condition.',
      'Independent of prevalence, so it transfers across populations.',
      'Together with recall it fully describes the test at a threshold.',
      'Directly gives the false-positive rate used in ROC analysis.'
    ],
    cons: [
      'Easy to maximise by flagging almost nothing.',
      'Does not tell you how reliable a positive alert is, which needs prevalence.',
      'Can be overlooked when a team focuses on recall alone.',
      'Different thresholds give different values, so a single number is incomplete.'
    ],
    applications: [
      'Confirmatory tests where false positives lead to invasive follow-up.',
      'Reporting diagnostic accuracy studies with sensitivity and specificity pairs.',
      'Choosing a threshold that keeps the false-alarm burden manageable.',
      'Plotting ROC curves, where FPR is on the horizontal axis.'
    ],
    quiz: [
      {
        question: 'In the worked example, what is the specificity?',
        options: ['0.80', '0.727', '0.875', '0.90'],
        answerIndex: 3,
        explanation: 'TN/(TN + FP) = 135/150 = 0.90.'
      },
      {
        question: 'If specificity is 0.90, what is the false-positive rate?',
        options: ['0.10', '0.90', '0.20', '0.50'],
        answerIndex: 0,
        explanation: 'FPR = 1 - specificity = 0.10.'
      },
      {
        question: 'Which of these metrics is NOT affected by prevalence?',
        options: ['Precision', 'Negative predictive value', 'Specificity', 'Accuracy'],
        answerIndex: 2,
        explanation: 'Specificity conditions on the true class, so it does not depend on how common that class is. Precision, NPV and accuracy mix both classes.'
      },
      {
        question: 'A model never flags any case. Which metric looks perfect?',
        options: ['Recall', 'Specificity', 'Precision', 'F1 score'],
        answerIndex: 1,
        explanation: 'With no flags there are no false positives, so specificity is 1, while recall is 0.'
      }
    ],
    related: ['recall', 'roc-curve', 'confusion-matrix'],
    keywords: ['true-negative rate', 'false-positive rate', 'sensitivity', 'diagnostic accuracy']
  },
  {
    id: 'f1-score',
    title: 'F1 score',
    category: 'evaluation',
    summary: 'The F1 score is the harmonic mean of precision and recall, a single number that is low unless both are reasonably high.',
    readingMinutes: 5,
    intro:
      'Precision and recall pull in different directions, so comparing two models can be awkward when one wins on precision and the other on recall. People often want one number that combines both.\n\nThe F1 score does this with the harmonic mean. This lesson shows how it is computed, why the harmonic mean is used instead of the ordinary average, and the limits of any single-number summary.',
    simple:
      'Suppose a student has two grades, 100 in one subject and 10 in another. The ordinary average is 55, which sounds respectable. The harmonic mean is much harsher and gives about 18, because it is pulled down by the weak grade.\n\nF1 treats precision and recall like those two grades. A model cannot hide a very poor recall behind an excellent precision or the other way round. To get a high F1, both numbers must be decent.',
    technical:
      'F1 is the harmonic mean of precision $P$ and recall $R$: $F_1 = 2PR/(P + R)$. In terms of counts it equals $2TP/(2TP + FP + FN)$. It ignores true negatives entirely, so it is suited to problems where the positive class is the focus and negatives are abundant, but it cannot reward a model for correctly clearing negatives.\n\nThe general $F_\\beta$ score weights recall $\\beta$ times as much as precision: $F_\\beta = (1+\\beta^2)PR/(\\beta^2 P + R)$. With $\\beta = 2$ recall counts more, which suits screening, and $\\beta = 0.5$ favours precision. Caveats: F1 depends on the threshold; it is asymmetric between the classes, so swapping which class is called positive changes it; and it gives no credit for calibrated probabilities. When misclassification costs are known, minimise expected cost rather than a generic F-score.',
    math: [
      {
        label: 'F1 score',
        tex: String.raw`F_1 \;=\; \frac{2\,P\,R}{P + R} \;=\; \frac{2\,TP}{2\,TP + FP + FN}`,
        note: '$P$ is precision and $R$ is recall. The count form shows that true negatives play no part.'
      },
      {
        label: 'F-beta score',
        tex: String.raw`F_\beta \;=\; \frac{(1+\beta^{2})\,P\,R}{\beta^{2}P + R}`,
        note: 'Values of $\\beta$ above 1 weight recall more; values below 1 weight precision more.'
      }
    ],
    example: {
      title: 'F1 of the screening model',
      body:
        'Precision is $40/55 \\approx 0.7273$ and recall is $40/50 = 0.80$. Then $F_1 = 2 \\times 0.7273 \\times 0.80/(0.7273 + 0.80) = 1.1636/1.5273 \\approx 0.762$.\n\nThe count form agrees: $2 \\times 40/(2 \\times 40 + 15 + 10) = 80/105 \\approx 0.762$. The arithmetic mean of precision and recall would be 0.764, only slightly higher here because the two values are close.\n\nWith $\\beta = 2$ the score is $5 \\times 40/(5 \\times 40 + 4 \\times 10 + 15) = 200/255 \\approx 0.784$, higher because recall (0.80) is the stronger of the two and now counts more.'
    },
    pros: [
      'Combines precision and recall into a single number.',
      'The harmonic mean punishes a model that is poor on either.',
      'Suitable for imbalanced problems where accuracy fails.',
      'F-beta lets you tilt the balance towards recall or precision.'
    ],
    cons: [
      'Ignores true negatives, so it says nothing about the negative class.',
      'Depends on the threshold and on which class is called positive.',
      'Hides which of precision or recall is weak.',
      'Treats a false positive and a false negative as equally costly in F1, which is rarely true in practice.'
    ],
    applications: [
      'Comparing classifiers for rare-event detection.',
      'Evaluating information extraction and named-entity recognition.',
      'Selecting a threshold that balances alerts and misses.',
      'Leaderboards for imbalanced benchmarks.'
    ],
    quiz: [
      {
        question: 'A model has precision 1.0 and recall 0.1. Roughly what is its F1?',
        options: ['0.55', '0.18', '0.90', '0.05'],
        answerIndex: 1,
        explanation: '2 x 1.0 x 0.1/(1.0 + 0.1) is about 0.18. The arithmetic mean 0.55 would hide the weak recall.'
      },
      {
        question: 'Which cell of the confusion matrix does F1 ignore?',
        options: ['True positives', 'False positives', 'False negatives', 'True negatives'],
        answerIndex: 3,
        explanation: 'F1 = 2TP/(2TP + FP + FN) has no TN term.'
      },
      {
        question: 'You care about recall more than precision. Which score fits better?',
        options: ['F0.5', 'F2', 'Accuracy', 'Specificity'],
        answerIndex: 1,
        explanation: 'F-beta with beta above 1 puts more weight on recall, so F2 is the natural choice.'
      },
      {
        question: 'In the worked example, F1 is about 0.762. Which pair of values gives this?',
        options: [
          'Precision 0.727 and recall 0.80',
          'Precision 0.80 and recall 0.90',
          'Precision 0.875 and recall 0.727',
          'Precision 0.90 and recall 0.80'
        ],
        answerIndex: 0,
        explanation: 'F1 uses precision 40/55 and recall 40/50. Other pairs give different values.'
      }
    ],
    related: ['precision', 'recall', 'precision-recall-curve'],
    keywords: ['harmonic mean', 'F-beta', 'precision', 'recall', 'imbalanced data']
  },
  {
    id: 'roc-curve',
    title: 'ROC curve',
    category: 'evaluation',
    summary: 'The ROC curve plots recall against the false-positive rate across every possible threshold, showing how a model trades misses for false alarms.',
    readingMinutes: 6,
    intro:
      'A confusion matrix describes one threshold. But the threshold is a choice that can be changed after the model is trained, so a fair view of a classifier should cover all of them.\n\nThe receiver operating characteristic, or ROC, curve does this. It shows how recall and the false-positive rate move together as the threshold sweeps from strict to lenient. After this lesson you will be able to build a ROC curve by hand and read it.',
    simple:
      'Imagine a dial on a smoke alarm that sets its sensitivity. At the lowest setting it never rings: no false alarms, but no detection either. At the highest it rings constantly: it detects every fire and also every piece of burnt toast.\n\nThe ROC curve records every dial position. The horizontal axis is how many false alarms you get, the vertical axis is how many real fires you detect. A good alarm climbs steeply: it detects most fires before it starts crying wolf. A useless one runs along the diagonal.',
    technical:
      'Rank cases by model score. For each possible threshold $t$, compute the true-positive rate $TPR(t)$ (recall) and the false-positive rate $FPR(t)$, and plot $TPR$ against $FPR$. The curve starts at $(0, 0)$, where nothing is flagged, and ends at $(1, 1)$, where everything is flagged. A random scorer follows the diagonal and a perfect one passes through $(0, 1)$. Each point corresponds to a confusion matrix, so choosing an operating point is choosing a threshold.\n\nBecause TPR and FPR each condition on the true class, the ROC curve does not depend on prevalence. That is an advantage for comparing models but a limitation when positives are rare: a small FPR can still mean many false alarms compared with true hits, and the curve will not show that. It also uses only the ranking of scores, so it says nothing about whether the probabilities are calibrated. Curves can cross, in which case no model is better at every threshold.',
    math: [
      {
        label: 'Coordinates of a ROC point',
        tex: String.raw`\text{TPR}(t)=\frac{TP(t)}{P},\qquad \text{FPR}(t)=\frac{FP(t)}{N}`,
        note: '$P$ and $N$ are the numbers of positives and negatives; $TP(t)$ and $FP(t)$ count cases with score at least $t$.'
      }
    ],
    example: {
      title: 'Building a ROC curve from eight scored cases',
      body:
        'Four positives have scores 0.9, 0.8, 0.6, 0.4 and four negatives have scores 0.7, 0.5, 0.3, 0.2. Lower the threshold step by step and record (FPR, TPR):\n\n- Above 0.9: (0, 0)\n- 0.9: one positive caught, no false positives: (0, 0.25)\n- 0.8: (0, 0.50)\n- 0.7: a negative enters: (0.25, 0.50)\n- 0.6: (0.25, 0.75)\n- 0.5: (0.50, 0.75)\n- 0.4: (0.50, 1.00)\n- 0.3: (0.75, 1.00)\n- 0.2: (1.00, 1.00)\n\nThe curve climbs to 50% recall before any false alarm, which is encouraging. A threshold of 0.6 gives recall 0.75 at a false-positive rate of 0.25. The same eight cases are used again in the next lessons.'
    },
    pros: [
      'Shows performance at every threshold in one picture.',
      'Independent of prevalence, so models are comparable across datasets with different class mixes.',
      'Helps choose an operating point that matches the costs of each error.',
      'Easy to compare visually, and it reduces to a single number via the area under it.'
    ],
    cons: [
      'Can look optimistic when positives are rare, because FPR hides large numbers of false alarms.',
      'Ignores calibration; only the ranking matters.',
      'Does not display the thresholds themselves unless they are annotated.',
      'Curves from small samples are jagged and uncertain.'
    ],
    applications: [
      'Comparing diagnostic scoring models across thresholds.',
      'Choosing a threshold that achieves a required recall.',
      'Credit scoring and fraud model evaluation.',
      'Assessing a biomarker as a screening candidate.'
    ],
    quiz: [
      {
        question: 'What do the axes of a ROC curve show?',
        options: [
          'Precision on the vertical axis, recall on the horizontal axis',
          'Recall on the vertical axis, false-positive rate on the horizontal axis',
          'Accuracy against threshold',
          'Specificity against precision'
        ],
        answerIndex: 1,
        explanation: 'ROC plots TPR (recall) against FPR. Precision against recall is the precision-recall curve.'
      },
      {
        question: 'A model whose ROC curve follows the diagonal from (0,0) to (1,1) is behaving like what?',
        options: ['A perfect classifier', 'A classifier that is always wrong', 'Random guessing', 'A model with 100% precision'],
        answerIndex: 2,
        explanation: 'Along the diagonal recall equals the false-positive rate, which is what random scores produce.'
      },
      {
        question: 'Moving along the curve towards the top right, what happens?',
        options: [
          'The threshold rises and fewer cases are flagged.',
          'The threshold falls, recall rises and so does the false-positive rate.',
          'Recall falls.',
          'The false-positive rate falls.'
        ],
        answerIndex: 1,
        explanation: 'Lowering the threshold flags more cases, which raises both rates. At (1,1) everything is flagged.'
      },
      {
        question: 'Why can a ROC curve look good for a very rare disease even when many alerts are false?',
        options: [
          'It uses accuracy.',
          'The false-positive rate divides by the large number of negatives, so many false alarms still give a small rate.',
          'It is calibrated.',
          'It ignores recall.'
        ],
        answerIndex: 1,
        explanation: 'A tiny FPR applied to a huge negative population can still outnumber the true positives. Precision-recall curves expose this.'
      }
    ],
    related: ['roc-auc', 'recall', 'specificity'],
    keywords: ['receiver operating characteristic', 'threshold', 'true-positive rate', 'false-positive rate']
  },
  {
    id: 'roc-auc',
    title: 'ROC-AUC',
    category: 'evaluation',
    summary: 'ROC-AUC is the area under the ROC curve, equal to the probability that a random positive receives a higher score than a random negative.',
    readingMinutes: 6,
    intro:
      'A ROC curve is informative but awkward to compare when you have many models. The area under it, ROC-AUC, condenses the curve into one number between 0 and 1 that summarises how well the model ranks positives above negatives.\n\nThere is an exact probabilistic meaning behind the area. This lesson explains it, shows how to compute it by counting pairs, and discusses when the number is and is not the right summary.',
    simple:
      'Pick one person with the condition and one person without it, both at random. Ask the model to score each. ROC-AUC is the chance that the person with the condition gets the higher score.\n\nIf the model scores people at random, that chance is 50 percent, an AUC of 0.5. If it always ranks the person with the condition higher, the chance is 100 percent. Notice what this does not say: it does not say how large the scores are, only how they are ordered.',
    technical:
      'ROC-AUC equals the probability that a randomly chosen positive has a higher score than a randomly chosen negative, with ties counted as one half. This is the Mann-Whitney U statistic divided by $PN$. It can be computed by counting concordant pairs among all $P \\times N$ positive-negative pairs, without drawing the curve.\n\nValues: 0.5 means no ranking ability, 1 means perfect separation, and values below 0.5 mean the ranking is reversed. Properties: it is threshold-free, independent of prevalence and invariant to any monotone transformation of the scores, so it cannot detect poor calibration. It averages over all operating points, including ones nobody would use, such as very high false-positive rates. When positives are rare, or when the region of interest is a low false-positive range, PR-AUC or a partial AUC may be more informative. Report a confidence interval, since AUC estimated from few positives is uncertain.',
    math: [
      {
        label: 'AUC as a pairwise probability',
        tex: String.raw`\text{AUC} \;=\; \Pr\big(s(X^{+}) > s(X^{-})\big) + \tfrac{1}{2}\Pr\big(s(X^{+}) = s(X^{-})\big)`,
        note: '$s$ is the model score, $X^{+}$ a random positive and $X^{-}$ a random negative.'
      },
      {
        label: 'Counting estimate',
        tex: String.raw`\widehat{\text{AUC}} \;=\; \frac{1}{P\,N}\sum_{i\in\text{pos}}\sum_{j\in\text{neg}} \Big(\mathbf{1}[s_i > s_j] + \tfrac{1}{2}\mathbf{1}[s_i = s_j]\Big)`,
        note: 'Sum over all positive-negative pairs, scoring 1 when the positive is ranked higher.'
      }
    ],
    example: {
      title: 'Computing AUC for the eight scored cases',
      body:
        'Positives have scores 0.9, 0.8, 0.6, 0.4 and negatives have scores 0.7, 0.5, 0.3, 0.2, giving $4 \\times 4 = 16$ pairs. Count the negatives each positive beats:\n\n- 0.9 beats all 4 negatives.\n- 0.8 beats all 4.\n- 0.6 beats 0.5, 0.3 and 0.2, which is 3.\n- 0.4 beats 0.3 and 0.2, which is 2.\n\nThat is $4 + 4 + 3 + 2 = 13$ winning pairs out of 16, so AUC is $13/16 = 0.8125$. The trapezoid area under the ROC points from the previous lesson gives the same value: $0.125 + 0.1875 + 0.25 + 0.25 = 0.8125$. A randomly chosen positive outranks a randomly chosen negative about 81% of the time.'
    },
    pros: [
      'Threshold-free summary of ranking quality.',
      'Has a clear probabilistic interpretation.',
      'Independent of prevalence, so it compares across datasets.',
      'Unchanged by monotone rescaling of scores.'
    ],
    cons: [
      'Blind to calibration: well-ranked but badly scaled probabilities still score highly.',
      'Can look reassuring when positives are rare and precision is poor.',
      'Averages over operating points that may be irrelevant in practice.',
      'Two models with different curve shapes can share the same AUC.'
    ],
    applications: [
      'Ranking candidate models during development.',
      'Reporting the discrimination of clinical risk scores, alongside calibration.',
      'Credit risk scorecards.',
      'Evaluating biomarkers for their ability to separate groups.'
    ],
    quiz: [
      {
        question: 'What does an AUC of 0.8125 mean?',
        options: [
          'The model is correct 81.25% of the time.',
          'A random positive outranks a random negative with probability 0.8125.',
          'Precision is 0.8125 at every threshold.',
          '81.25% of positives are found.'
        ],
        answerIndex: 1,
        explanation: 'AUC is a pairwise ranking probability, not accuracy or recall.'
      },
      {
        question: 'A model has AUC 0.5. How does it rank cases?',
        options: ['Perfectly', 'Perfectly reversed', 'No better than chance', 'Always puts positives first by a small margin'],
        answerIndex: 2,
        explanation: 'An AUC of 0.5 corresponds to random ordering of positives and negatives.'
      },
      {
        question: 'You multiply every score by 0.5. What happens to AUC?',
        options: ['It halves.', 'It doubles.', 'It is unchanged.', 'It becomes 0.5.'],
        answerIndex: 2,
        explanation: 'AUC depends only on ranking, and a monotone transformation does not change the ranking.'
      },
      {
        question: 'Which weakness of AUC is real?',
        options: [
          'It cannot be computed without a threshold.',
          'It does not tell you whether predicted probabilities are accurate.',
          'It is affected by the number of features.',
          'It only works for regression.'
        ],
        answerIndex: 1,
        explanation: 'AUC uses only the ordering of scores, so it says nothing about calibration.'
      }
    ],
    related: ['roc-curve', 'pr-auc', 'probability-calibration'],
    keywords: ['AUC', 'Mann-Whitney', 'discrimination', 'ranking', 'area under the curve']
  },
  {
    id: 'precision-recall-curve',
    title: 'Precision-recall curve',
    category: 'evaluation',
    summary: 'The precision-recall curve plots precision against recall over all thresholds and is the more revealing view when positives are rare.',
    readingMinutes: 6,
    intro:
      'ROC curves use the false-positive rate, which divides by the number of negatives. When negatives vastly outnumber positives, even a small rate can mean a flood of false alarms, and the ROC curve hides this.\n\nThe precision-recall curve keeps the focus on the positive class. It shows how the reliability of alerts changes as you try to find more of the real cases. This lesson explains how to build and read it.',
    simple:
      'Think of a search engine returning results ranked from most to least likely relevant. At the top of the list, almost everything is relevant, so precision is high but you have found only a few of the relevant items. As you read further down, you find more of them but you also wade through junk.\n\nThe precision-recall curve is that story drawn as a picture: as you read deeper, recall climbs and precision usually sags.',
    technical:
      'Sort cases by score and lower the threshold step by step. At each threshold compute recall $TP/P$ and precision $TP/(TP+FP)$ and plot precision against recall. The curve starts near the top left with precision close to 1 at tiny recall, though it can start low if the highest-scoring case is a negative. It ends at recall 1, where precision equals the prevalence because everything is flagged. A no-skill classifier gives a horizontal line at the prevalence, so the reference line depends on the dataset.\n\nPrecision is not monotone in recall, so the curve is sawtooth shaped, and linear interpolation between points is misleading; step-wise or interpolated-envelope conventions exist and give slightly different areas. Since both axes ignore true negatives, the curve is unaffected by how many easy negatives you add, but it does depend on prevalence, so curves from datasets with different positive rates are not directly comparable. Annotate the thresholds so a reader can choose a point.',
    math: [
      {
        label: 'Points on the curve',
        tex: String.raw`\text{recall}(t)=\frac{TP(t)}{P},\qquad \text{precision}(t)=\frac{TP(t)}{TP(t)+FP(t)}`,
        note: 'Computed for each threshold $t$; the no-skill baseline for precision is the prevalence $P/(P+N)$.'
      }
    ],
    example: {
      title: 'Precision-recall points for the eight scored cases',
      body:
        'Using the same cases as the ROC lesson (positives 0.9, 0.8, 0.6, 0.4; negatives 0.7, 0.5, 0.3, 0.2), lower the threshold and record (recall, precision):\n\n- 0.9: 1 TP, 0 FP gives recall 0.25, precision 1.00\n- 0.8: 2 TP, 0 FP gives recall 0.50, precision 1.00\n- 0.7: 2 TP, 1 FP gives recall 0.50, precision 0.667\n- 0.6: 3 TP, 1 FP gives recall 0.75, precision 0.75\n- 0.5: 3 TP, 2 FP gives recall 0.75, precision 0.60\n- 0.4: 4 TP, 2 FP gives recall 1.00, precision 0.667\n- 0.3: 4 TP, 3 FP gives recall 1.00, precision 0.571\n- 0.2: 4 TP, 4 FP gives recall 1.00, precision 0.50\n\nThe last point equals the prevalence, 4 of 8 or 0.50. The sawtooth is visible: precision falls from 0.75 to 0.60 and then rises to 0.667.'
    },
    pros: [
      'Focuses on the positive class, where the interest usually lies.',
      'Exposes poor precision on rare-event problems that ROC curves hide.',
      'Directly shows the trade-off between alert quality and coverage.',
      'Does not reward the model for clearing easy negatives.'
    ],
    cons: [
      'Depends on prevalence, so curves from different datasets are hard to compare.',
      'Sawtooth shape and noisy at small sample sizes.',
      'Interpolating linearly between points can be misleading.',
      'The no-skill reference is not fixed, which confuses readers used to the ROC diagonal.'
    ],
    applications: [
      'Fraud and anomaly detection with a tiny positive rate.',
      'Information retrieval and ranking systems.',
      'Screening models where the follow-up workload depends on precision.',
      'Choosing a threshold for a required level of alert quality.'
    ],
    quiz: [
      {
        question: 'What does a no-skill classifier look like on a precision-recall plot?',
        options: [
          'A diagonal from (0,0) to (1,1)',
          'A horizontal line at the prevalence',
          'A vertical line at recall 0.5',
          'A point at (1,1)'
        ],
        answerIndex: 1,
        explanation: 'A random scorer has precision equal to the share of positives at every recall level.'
      },
      {
        question: 'At recall 1.0 (everything flagged), what is the precision?',
        options: ['1.0', '0.0', 'The prevalence of positives', 'The specificity'],
        answerIndex: 2,
        explanation: 'If all cases are flagged, the share of flags that are correct is simply the positive rate.'
      },
      {
        question: 'Why is the precision-recall curve preferred over ROC for very rare positives?',
        options: [
          'It ignores false positives.',
          'It makes models look better.',
          'It reflects the number of false alarms relative to true hits, which FPR dilutes.',
          'It does not need scores.'
        ],
        answerIndex: 2,
        explanation: 'Precision uses false positives against true positives directly, while FPR spreads them over many negatives.'
      }
    ],
    related: ['pr-auc', 'precision', 'roc-curve'],
    keywords: ['precision-recall', 'rare events', 'threshold', 'sawtooth', 'imbalanced data']
  },
  {
    id: 'pr-auc',
    title: 'PR-AUC',
    category: 'evaluation',
    summary: 'PR-AUC summarises the precision-recall curve in one number, usually computed as average precision, and is sensitive to how rare positives are.',
    readingMinutes: 5,
    intro:
      'The precision-recall curve is a good picture, but ranking models still needs one number. PR-AUC provides it by summarising how well precision holds up as recall increases.\n\nUnlike ROC-AUC, its value depends strongly on how common the positive class is, so it must be read against a baseline. This lesson explains how to compute it, how to interpret it and why the common implementations differ slightly.',
    simple:
      'Go back to reading a ranked list of search results. A good ranking puts the relevant items near the top. PR-AUC rewards that: it averages the precision you had at each point where you found another relevant item.\n\nA score of 0.85 sounds high, but if only 1 percent of items are relevant, a random list would score about 0.01, and a score of 0.85 would be remarkable. If half of the items are relevant, a random list already scores 0.5. That is why the baseline matters.',
    technical:
      'PR-AUC is the area under the precision-recall curve. The most common estimator is **average precision**, $AP = \\sum_k (R_k - R_{k-1})P_k$, where $P_k$ and $R_k$ are precision and recall at the $k$th threshold. It weights each precision value by the increase in recall at that threshold. Using the trapezoid rule on the PR points gives a different, usually slightly optimistic value because precision is not linear between points, so state which estimator is used.\n\nThe no-skill baseline equals the prevalence, so PR-AUC is not comparable across datasets with different positive rates. It ignores true negatives, which makes it sensitive to the positive class only. It is typically more informative than ROC-AUC under strong imbalance, but it is also noisier when there are few positives, so confidence intervals (by bootstrap, for example) are advisable. Like ROC-AUC, it is a ranking measure and says nothing about calibration.',
    math: [
      {
        label: 'Average precision',
        tex: String.raw`\text{AP} \;=\; \sum_{k=1}^{K} \big(R_k - R_{k-1}\big)\, P_k`,
        note: 'Thresholds are taken in decreasing score order; $R_0 = 0$. Each precision $P_k$ is weighted by the extra recall gained at step $k$.'
      }
    ],
    example: {
      title: 'Average precision for the eight scored cases',
      body:
        'The recall steps occur only where a positive is added: at scores 0.9, 0.8, 0.6 and 0.4. Each adds 0.25 to recall. The precision at those points is 1.00, 1.00, 0.75 and 0.667.\n\n$AP = 0.25 \\times 1.00 + 0.25 \\times 1.00 + 0.25 \\times 0.75 + 0.25 \\times 0.667 = 0.25 + 0.25 + 0.1875 + 0.1667 \\approx 0.854$.\n\nThe baseline here is the prevalence, 0.50, so 0.854 is a clear improvement. Contrast this with the ROC-AUC of 0.8125 on the same cases. The two numbers answer different questions and need not agree. If these cases were drawn from a population with 2% positives, a PR-AUC of 0.854 would be far more striking than the same figure at 50%, which is exactly why the baseline must always be stated.'
    },
    pros: [
      'Focuses on positive-class performance and is sensitive to false alarms.',
      'More informative than ROC-AUC when positives are rare.',
      'Average precision has a clear definition as a recall-weighted mean of precision.',
      'Threshold-free summary suitable for model comparison on the same data.'
    ],
    cons: [
      'Depends on prevalence, so values cannot be compared across datasets without the baseline.',
      'Different estimators (average precision versus trapezoid) give different numbers.',
      'Noisy with few positives.',
      'Says nothing about calibration or about the negative class.'
    ],
    applications: [
      'Model selection in fraud, anomaly and rare-disease detection.',
      'Ranking quality in retrieval and recommendation.',
      'Reporting alongside ROC-AUC in imbalanced benchmark studies.',
      'Tracking model quality over time on a fixed evaluation set.'
    ],
    quiz: [
      {
        question: 'What is the PR-AUC baseline of a random classifier?',
        options: ['0.5 always', '0', 'The prevalence of the positive class', '1'],
        answerIndex: 2,
        explanation: 'A random ranking gives precision equal to the positive rate at every recall level.'
      },
      {
        question: 'A dataset has 1% positives and a model has PR-AUC 0.30. How is this best described?',
        options: [
          'Poor, because it is below 0.5.',
          'Much better than the 0.01 baseline, though far from perfect.',
          'Identical to random.',
          'Impossible.'
        ],
        answerIndex: 1,
        explanation: 'The reference is the prevalence of 0.01, so 0.30 is a large improvement even though it looks low in isolation.'
      },
      {
        question: 'Why can two libraries report different PR-AUC values for the same scores?',
        options: [
          'Scores are random.',
          'One may use average precision and the other a trapezoid rule.',
          'PR-AUC is only defined for regression.',
          'One uses accuracy.'
        ],
        answerIndex: 1,
        explanation: 'Interpolation choices change the area, so always state the estimator.'
      }
    ],
    related: ['precision-recall-curve', 'roc-auc', 'f1-score'],
    keywords: ['average precision', 'AP', 'area under precision-recall', 'imbalanced data']
  },
  {
    id: 'brier-score',
    title: 'Brier score',
    category: 'evaluation',
    summary: 'The Brier score is the mean squared error between predicted probabilities and the 0-or-1 outcomes, rewarding both sharpness and honesty.',
    readingMinutes: 5,
    intro:
      'Many models output a probability, such as a 30 percent risk of an event. Thresholded metrics throw that number away. Ranking metrics such as AUC keep only its order. Neither checks whether 30 percent really means about 3 in 10.\n\nThe Brier score evaluates the probabilities themselves. It is just the mean squared error applied to probabilities, which makes it simple to compute and to reason about. This lesson shows how, and how to judge a value against a sensible baseline.',
    simple:
      'Suppose a forecaster says there is a 90 percent chance of rain and it rains. That was a good forecast. If it does not rain, the forecaster was confidently wrong. The Brier score measures this: take the gap between the stated chance and what happened (1 if it rained, 0 if not), square it and average over all forecasts.\n\nA perfect forecaster scores 0. Constantly saying 50 percent scores 0.25. Lower is better, and big confident mistakes are punished hardest because of the squaring.',
    technical:
      'For $n$ cases with predicted probabilities $p_i$ and binary outcomes $y_i \\in \\{0, 1\\}$, the Brier score is $\\frac{1}{n}\\sum (p_i - y_i)^2$. It is a **strictly proper scoring rule**: its expected value is minimised only by reporting the true probability, so a model has no incentive to exaggerate or hedge. It ranges from 0 to 1, with 0 best.\n\nThe score mixes two ideas, calibration (do predicted risks match observed frequencies) and refinement or sharpness (do the predictions separate cases), through its Murphy decomposition. Interpretation needs a reference. A model that always predicts the prevalence $\\bar y$ scores $\\bar y(1-\\bar y)$, and the Brier skill score $1 - \\text{BS}/\\text{BS}_{ref}$ expresses improvement over it. Values are not comparable across datasets with different prevalence. Log loss is another proper rule that punishes confident errors more severely.',
    math: [
      {
        label: 'Brier score',
        tex: String.raw`\text{BS} \;=\; \frac{1}{n}\sum_{i=1}^{n}\big(p_i - y_i\big)^2`,
        note: '$p_i$ is the predicted probability of the positive class and $y_i$ is the outcome, 1 or 0.'
      },
      {
        label: 'Brier skill score',
        tex: String.raw`\text{BSS} \;=\; 1 - \frac{\text{BS}}{\bar y\,(1-\bar y)}`,
        note: 'Compares against always predicting the prevalence $\\bar y$. Positive values mean the model beats that baseline.'
      }
    ],
    example: {
      title: 'Brier score of five risk predictions',
      body:
        'Five patients have predicted risks 0.9, 0.8, 0.3, 0.6, 0.1 and outcomes 1, 1, 0, 0, 0. The squared errors are $(0.9 - 1)^2 = 0.01$, $(0.8 - 1)^2 = 0.04$, $(0.3 - 0)^2 = 0.09$, $(0.6 - 0)^2 = 0.36$ and $(0.1 - 0)^2 = 0.01$.\n\nTheir sum is 0.51, so the Brier score is $0.51/5 = 0.102$. The biggest contribution, 0.36, comes from the confident 0.6 on a patient who did not have the event.\n\nPrevalence is 2 of 5, or 0.4. Always predicting 0.4 gives $(0.6^2 \\times 2 + 0.4^2 \\times 3)/5 = 0.24$, so the Brier skill score is $1 - 0.102/0.24 \\approx 0.575$.'
    },
    pros: [
      'Evaluates the probabilities themselves, not just the ranking or a threshold.',
      'Strictly proper, so honest probabilities score best.',
      'Simple and bounded between 0 and 1.',
      'Can be decomposed into calibration and refinement parts.'
    ],
    cons: [
      'Hard to interpret alone; it needs a prevalence-based baseline.',
      'Not comparable across datasets with different class rates.',
      'Dominated by the majority class when events are rare.',
      'A single number cannot show where the model is miscalibrated.'
    ],
    applications: [
      'Evaluating clinical risk prediction models together with a calibration plot.',
      'Weather and sports forecasting verification.',
      'Comparing probabilistic classifiers before and after recalibration.',
      'Monitoring the quality of predicted probabilities in deployed systems.'
    ],
    quiz: [
      {
        question: 'A forecaster always predicts 0.5 for a binary event. What is the Brier score?',
        options: ['0', '0.25', '0.5', '1'],
        answerIndex: 1,
        explanation: 'Every squared error is (0.5)^2 = 0.25, regardless of the outcome.'
      },
      {
        question: 'Which description of the Brier score is accurate?',
        options: [
          'The area under the ROC curve.',
          'The mean squared error between predicted probabilities and 0 or 1 outcomes.',
          'The fraction of probabilities above 0.5.',
          'The harmonic mean of precision and recall.'
        ],
        answerIndex: 1,
        explanation: 'It is mean squared error applied to probabilities. Lower is better.'
      },
      {
        question: 'Why is it called a proper scoring rule?',
        options: [
          'It ranges from 0 to 1.',
          'It is minimised in expectation by reporting the true probabilities.',
          'It ignores the outcome.',
          'It only works for balanced data.'
        ],
        answerIndex: 1,
        explanation: 'Properness means honesty is the best strategy: any other reported probability has a worse expected score.'
      },
      {
        question: 'The worked example gives BS = 0.102 versus 0.24 for the prevalence baseline. What does this show?',
        options: [
          'The model is worse than the baseline.',
          'The model beats the baseline.',
          'The model is perfectly calibrated.',
          'The result is invalid.'
        ],
        answerIndex: 1,
        explanation: 'A lower score than the baseline means skill. It says nothing about perfect calibration on its own.'
      }
    ],
    related: ['probability-calibration', 'roc-auc', 'loss-functions'],
    keywords: ['proper scoring rule', 'mean squared error', 'probabilistic forecast', 'skill score']
  },
  {
    id: 'probability-calibration',
    title: 'Probability calibration',
    category: 'evaluation',
    summary: 'A model is calibrated when its predicted probabilities match observed frequencies; calibration slope and intercept summarise how it deviates.',
    readingMinutes: 7,
    intro:
      'If a model says a patient has a 20 percent risk, that statement should hold up: among many patients given 20 percent, about one in five should have the outcome. A model can rank patients well and still be badly off in this sense, typically by being overconfident.\n\nProbability calibration checks and repairs that match. It matters whenever the number itself drives a decision, for instance a treatment threshold set at a given risk. This lesson explains calibration plots, the calibration slope and intercept, and recalibration.',
    simple:
      'A weather service says there is a 70 percent chance of rain on 100 different days. If it actually rained on about 70 of those days, the service is well calibrated. If it rained on only 45 of them, its forecasts were too confident.\n\nCalibration does not ask whether the forecast ranked rainy days above dry ones. It asks whether the stated percentages mean what they say. A forecaster can be good at ranking and poor at calibration, and the reverse.',
    technical:
      'A model is calibrated if $\\Pr(Y = 1 \\mid \\hat p = p) = p$ for all $p$. A **calibration plot** bins predictions and compares the mean predicted probability with the observed event rate in each bin; smoothing is preferable to coarse binning. The **expected calibration error** averages the absolute gaps across bins.\n\nThe calibration intercept and slope come from a logistic regression of the outcome on the logit of the prediction, $\\text{logit}\\Pr(Y=1) = a + b\\,\\text{logit}(\\hat p)$. Perfect calibration has $a = 0$ and $b = 1$. A slope below 1 means predictions are too extreme (typical of overfitted models); a slope above 1 means they are too modest. A negative intercept indicates overall overestimation of risk. Calibration should be assessed on data not used for fitting and in the target population, since prevalence shifts change it.\n\nRecalibration methods include Platt scaling (a logistic fit on scores, which is this slope-and-intercept correction) and isotonic regression, which is more flexible but needs more data. Recalibration fixes the mapping from scores to probabilities; it does not improve ranking.',
    math: [
      {
        label: 'Calibration model',
        tex: String.raw`\operatorname{logit}\,\Pr(Y=1) \;=\; a \;+\; b\,\operatorname{logit}(\hat p), \qquad \operatorname{logit}(p)=\ln\frac{p}{1-p}`,
        note: 'Perfect calibration has intercept $a = 0$ and slope $b = 1$. A slope below 1 signals overconfident predictions.'
      },
      {
        label: 'Expected calibration error (binned)',
        tex: String.raw`\text{ECE} \;=\; \sum_{m=1}^{M} \frac{n_m}{n}\,\big|\,\bar o_m - \bar p_m\,\big|`,
        note: 'Over $M$ bins, $n_m$ is the bin size, $\\bar o_m$ the observed event rate and $\\bar p_m$ the mean predicted probability.'
      }
    ],
    example: {
      title: 'Reading a three-bin calibration table',
      body:
        'Three equal-sized bins of 100 patients each have mean predicted risks 0.20, 0.50 and 0.80 and observed event rates 0.15, 0.40 and 0.60. The model overestimates risk in every bin, and the error grows with the prediction.\n\nThe ECE is $(0.05 + 0.10 + 0.20)/3 \\approx 0.117$. Fitting a line through the logits of these three points by least squares gives a slope of about 0.77 and an intercept of about -0.58. A slope below 1 confirms overconfidence and a negative intercept confirms overall overestimation. (A proper logistic regression on patient-level data would be used in practice; this is an illustration.)\n\nPlatt-style recalibration would map a prediction of 0.80 to a probability near 0.60, consistent with what was observed.'
    },
    pros: [
      'Makes predicted risks trustworthy for decisions that depend on the actual probability.',
      'Calibration slope and intercept give a compact, interpretable diagnosis.',
      'Recalibration is cheap and does not need retraining the model.',
      'Reveals dataset shift, as calibration often degrades first when the population changes.'
    ],
    cons: [
      'Needs a reasonably large sample, especially for events that are rare.',
      'Binned plots are sensitive to the number of bins.',
      'Good calibration does not imply good discrimination, so it must be reported with AUC.',
      'Calibration in one population does not carry over to another with a different prevalence.',
      'Recalibrating on the test set uses up that set.'
    ],
    applications: [
      'Clinical risk models with treatment thresholds based on absolute risk.',
      'Credit scoring, where probabilities set prices and limits.',
      'Insurance and actuarial pricing.',
      'Auditing probabilities from neural networks, which are often overconfident.'
    ],
    quiz: [
      {
        question: 'A calibration slope of 0.77 most likely indicates what?',
        options: [
          'Predictions are too modest.',
          'Predictions are too extreme or overconfident.',
          'Perfect calibration.',
          'The model has no discrimination.'
        ],
        answerIndex: 1,
        explanation: 'A slope below 1 means observed risk varies less than the predictions suggest, which is overconfidence. Perfect calibration has a slope of 1.'
      },
      {
        question: 'A model has an excellent AUC. Does it follow that its probabilities are well calibrated?',
        options: [
          'Yes, AUC measures calibration.',
          'Yes, but only on balanced data.',
          'No, AUC depends only on ranking and not on the scale of probabilities.',
          'No, because AUC cannot be above 0.9.'
        ],
        answerIndex: 2,
        explanation: 'Any monotone transformation of scores leaves AUC unchanged but can wreck calibration.'
      },
      {
        question: 'In the worked example, bins with predicted 0.80 and observed 0.60 suggest what?',
        options: [
          'The model underestimates risk.',
          'The model overestimates risk.',
          'The bin is empty.',
          'The model is calibrated.'
        ],
        answerIndex: 1,
        explanation: 'Predicted risk exceeds the observed event rate, so risk is overestimated in that bin.'
      },
      {
        question: 'Which statement about recalibration is true?',
        options: [
          'It improves the ranking of cases.',
          'It changes how scores map to probabilities and leaves the ranking as it is for a monotone mapping.',
          'It always increases AUC.',
          'It requires retraining the original model.'
        ],
        answerIndex: 1,
        explanation: 'Platt scaling and isotonic regression apply a monotone mapping to scores, so the ordering and AUC stay the same while the probabilities change.'
      }
    ],
    related: ['brier-score', 'roc-auc', 'logistic-regression'],
    keywords: ['calibration slope', 'calibration intercept', 'Platt scaling', 'isotonic regression', 'reliability diagram']
  }
];
