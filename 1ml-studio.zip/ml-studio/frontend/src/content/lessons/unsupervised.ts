import type { Lesson } from '../types';

export const unsupervisedLessons: Lesson[] = [
  {
    id: 'k-means-clustering',
    title: 'K-means clustering',
    category: 'unsupervised',
    algorithmId: 'k-means',
    summary: 'K-means splits unlabelled data into k groups by repeatedly assigning points to the nearest centre and moving each centre to the mean of its group.',
    readingMinutes: 7,
    intro:
      'Often you have a pile of measurements and no labels at all: customers described by their purchases, patients described by lab values, pixels described by colour. K-means is the most widely used way to ask whether such data falls into a small number of compact groups.\n\nAfter this lesson you will be able to run the algorithm by hand, state the objective it minimises, explain why the result depends on the starting centres, and say when its assumptions make it a poor choice.',
    simple:
      'Picture a new town with 100 houses and a plan to open 3 post offices. You drop 3 flags on the map at random. Every house walks to its nearest flag. Then each flag is moved to the middle of the houses that chose it. Some houses now find a different flag closer, so they switch. You repeat until nobody switches.\n\nThe flags are the **centroids**, the groups of houses are the **clusters**, and you chose the number of flags (k) before starting. Nothing tells the algorithm what the groups mean; it only finds a tidy split by distance.\n\nBecause the first flags were placed at random, a different start can end in a different, sometimes worse, layout. That is why people run it several times and keep the best.',
    technical:
      'Given points $x_1,\\dots,x_n \\in \\mathbb{R}^d$ and a chosen $k$, k-means seeks centroids $\\mu_1,\\dots,\\mu_k$ and an assignment of every point to one cluster that minimise the within-cluster sum of squared Euclidean distances (inertia). The standard method, Lloyd\'s algorithm, alternates two steps: assign each point to its nearest centroid, then recompute each centroid as the mean of its assigned points. Each step cannot increase the objective, and there are finitely many assignments, so the procedure terminates, but only at a local minimum. The global problem is NP-hard.\n\nEach iteration costs $O(nkd)$. Initialisation matters: k-means++ picks the first centre uniformly and later centres with probability proportional to squared distance from the nearest chosen centre, which tends to give better and more stable solutions than uniform random starts. In practice one runs several initialisations and keeps the lowest objective.\n\nThe objective implicitly assumes clusters that are roughly spherical, similar in spread and similar in size, because the mean and squared distance favour that shape. Features must be on comparable scales, so standardise first. Outliers pull means and can capture a centroid. The value of $k$ is not learned; it is chosen with a diagnostic such as the elbow plot or the silhouette score (see the clustering evaluation lesson).',
    math: [
      {
        label: 'K-means objective (inertia)',
        tex: String.raw`J \;=\; \sum_{j=1}^{k}\;\sum_{x_i \in C_j}\; \lVert x_i - \mu_j \rVert^{2}`,
        note: '$C_j$ is the set of points assigned to cluster $j$ and $\\mu_j$ is its centroid. Lloyd\'s algorithm lowers $J$ at every step.'
      },
      {
        label: 'Assignment step',
        tex: String.raw`c_i \;=\; \arg\min_{j \in \{1,\dots,k\}} \lVert x_i - \mu_j \rVert^{2}`,
        note: 'Each point $x_i$ joins the cluster whose centroid is closest.'
      },
      {
        label: 'Update step',
        tex: String.raw`\mu_j \;=\; \frac{1}{\lvert C_j \rvert}\sum_{x_i \in C_j} x_i`,
        note: 'The mean is the point that minimises the sum of squared distances to the cluster members, which is why the update never hurts $J$.'
      }
    ],
    example: {
      title: 'Clustering six numbers into two groups',
      body:
        'Take the one-dimensional points 1, 2, 4, 9, 11, 12 and start with centroids at 1 and 2.\n\n**Iteration 1.** Point 1 is closest to centroid 1, and every other point is closest to centroid 2. The clusters are {1} and {2, 4, 9, 11, 12}. New centroids: 1 and (2+4+9+11+12)/5 = 7.6.\n\n**Iteration 2.** Point 2 is 1 away from centroid 1 and 5.6 from 7.6, so it joins the first cluster. Point 4 is 3 away from 1 and 3.6 from 7.6, so it joins the first cluster as well. Points 9, 11 and 12 stay with 7.6. Clusters: {1, 2, 4} and {9, 11, 12}. New centroids: 7/3 = 2.33 and 32/3 = 10.67.\n\n**Iteration 3.** No point changes cluster, so the algorithm stops. The final inertia is (1.33² + 0.33² + 1.67²) + (1.67² + 0.33² + 1.33²) = 9.33.'
    },
    pros: [
      'Simple to implement and explain, with a clear objective.',
      'Scales to large datasets because each iteration is linear in the number of points.',
      'Produces centroids that can be inspected as typical members of each group.',
      'Works well when clusters really are compact and similar in size.'
    ],
    cons: [
      'The number of clusters must be chosen in advance.',
      'Converges only to a local minimum that depends on the initial centres.',
      'Struggles with elongated, curved or very unequal clusters.',
      'Sensitive to outliers and to the scale of each feature.'
    ],
    applications: [
      'Grouping customers by behaviour to design different outreach.',
      'Colour quantisation, which reduces an image to a small palette.',
      'Summarising patients with similar lab profiles to support exploratory research, not to label individuals.',
      'Creating initial groups of documents or sensor readings for further analysis.'
    ],
    quiz: [
      {
        question: 'What does the update step of k-means do?',
        options: [
          'Moves each centroid to the mean of the points assigned to it.',
          'Reassigns each point to a random cluster.',
          'Adds a new centroid where the error is largest.',
          'Moves each point to the nearest centroid.'
        ],
        answerIndex: 0,
        explanation: 'The update step recomputes centroids as means. Moving points to the nearest centroid is the assignment step, which is a different half of the loop.'
      },
      {
        question: 'Two runs of k-means on the same data end with different clusters. What is the most likely reason?',
        options: [
          'The algorithm is not deterministic by definition.',
          'Different initial centroids led to different local minima.',
          'The data changed between runs.',
          'K-means can only find one solution if k is even.'
        ],
        answerIndex: 1,
        explanation: 'The objective has many local minima and Lloyd\'s algorithm stops at whichever one the starting centres lead to. Running several initialisations and keeping the lowest inertia is the standard remedy.'
      },
      {
        question: 'Which dataset is k-means least suited to?',
        options: [
          'Three round blobs of similar size.',
          'Customer records standardised to similar scales.',
          'Two concentric rings of points.',
          'Pixels from a photograph.'
        ],
        answerIndex: 2,
        explanation: 'Concentric rings share the same centre, so no assignment by distance to a mean can separate them. K-means prefers compact, roughly spherical clusters.'
      },
      {
        question: 'Why should features usually be standardised before k-means?',
        options: [
          'So that all clusters end up the same size.',
          'Because the algorithm cannot handle negative values.',
          'So that the number of clusters is chosen automatically.',
          'Because distances are dominated by features with large numeric ranges.'
        ],
        answerIndex: 3,
        explanation: 'Euclidean distance adds squared differences, so a feature measured in thousands swamps one measured in fractions. Standardising gives each feature comparable influence.'
      }
    ],
    related: ['unsupervised-learning', 'hierarchical-clustering', 'clustering-evaluation', 'k-nearest-neighbors'],
    keywords: ['clustering', 'centroid', 'inertia', 'Lloyd algorithm', 'k-means++', 'elbow method']
  },
  {
    id: 'hierarchical-clustering',
    title: 'Hierarchical clustering',
    category: 'unsupervised',
    summary: 'Hierarchical clustering builds a tree of nested groups by repeatedly merging the two closest clusters, so you can cut the tree at any level.',
    readingMinutes: 7,
    intro:
      'K-means forces you to choose the number of clusters before you look. Hierarchical clustering instead produces the whole family of answers at once: one cluster per point at the bottom, a single cluster containing everything at the top, and every level of grouping in between.\n\nAfter this lesson you will be able to carry out agglomerative clustering on a small distance matrix, explain how single, complete and average linkage differ, and read a dendrogram.',
    simple:
      'Think of a family tree drawn in reverse. Start with every person alone. The two people who live closest together become a pair. Then the next closest pair or the next person to join a pair, and so on, until the whole village is one group.\n\nThe record of the order of joining, drawn as an upside-down tree, is a **dendrogram**. The height at which two branches meet tells you how far apart those groups were when they joined. To get, say, 3 groups, you cut the tree with a horizontal line at the level where 3 branches remain.\n\nThe one thing you must decide is how to measure the distance between two groups that each contain several people: nearest members, farthest members, or the average. That rule is called the **linkage**.',
    technical:
      'Agglomerative clustering starts with $n$ singleton clusters and a pairwise distance matrix. At each step it merges the two clusters with the smallest inter-cluster distance, and updates the distances to the new cluster. After $n-1$ merges there is a single cluster. The sequence of merges and the distances at which they happen define the dendrogram. Divisive methods work top-down but are used less often.\n\nThe linkage defines the inter-cluster distance. Single linkage uses the minimum pairwise distance and tends to chain together through intermediate points, which can find elongated shapes but is sensitive to noise. Complete linkage uses the maximum and favours compact clusters of similar diameter. Average linkage uses the mean of pairwise distances and is a compromise. Ward linkage merges the pair whose union gives the smallest increase in within-cluster sum of squares and behaves like a hierarchical analogue of k-means.\n\nThe naive algorithm needs $O(n^2)$ memory for the distance matrix and about $O(n^3)$ time; better data structures bring many linkages to $O(n^2 \\log n)$. This limits it to thousands, not millions, of points. Merges are greedy and never undone, so an early poor merge is permanent. The distance metric and the feature scaling affect the tree as much as the linkage does.',
    math: [
      {
        label: 'Single linkage',
        tex: String.raw`d_{\text{single}}(A,B) \;=\; \min_{a \in A,\; b \in B} d(a,b)`,
        note: 'The distance between two clusters is the distance between their two closest members.'
      },
      {
        label: 'Complete linkage',
        tex: String.raw`d_{\text{complete}}(A,B) \;=\; \max_{a \in A,\; b \in B} d(a,b)`,
        note: 'The distance is that of the two farthest members, which discourages long, thin clusters.'
      },
      {
        label: 'Average linkage',
        tex: String.raw`d_{\text{avg}}(A,B) \;=\; \frac{1}{\lvert A\rvert\,\lvert B\rvert}\sum_{a \in A}\sum_{b \in B} d(a,b)`,
        note: 'The mean of all cross-cluster pairwise distances.'
      },
      {
        label: 'Ward criterion',
        tex: String.raw`\Delta(A,B) \;=\; \frac{\lvert A\rvert\,\lvert B\rvert}{\lvert A\rvert+\lvert B\rvert}\,\lVert \mu_A - \mu_B \rVert^{2}`,
        note: 'The increase in total within-cluster variance caused by merging $A$ and $B$, where $\\mu_A$ and $\\mu_B$ are the cluster means.'
      }
    ],
    example: {
      title: 'Five points on a line, two linkages',
      body:
        'Points: 1, 2, 6, 8, 15. Pairwise distances: |1-2| = 1, |6-8| = 2, |2-6| = 4, |1-6| = 5, |8-15| = 7, |6-15| = 9, |2-8| = 6, |1-8| = 7, |2-15| = 13, |1-15| = 14.\n\n**Step 1.** The smallest distance is 1, so merge {1} and {2} at height 1. **Step 2.** The next smallest is 2, so merge {6} and {8} at height 2.\n\n**Step 3, single linkage.** The distance between {1,2} and {6,8} is min(5, 7, 4, 6) = 4. The distance from {6,8} to {15} is 7. Merge {1,2} and {6,8} at height 4. **Step 4.** {15} joins at height min(7, 9, 13, 14) = 7.\n\n**Step 3, complete linkage.** The distance between {1,2} and {6,8} is max(5, 7, 4, 6) = 7, and from {6,8} to {15} it is max(7, 9) = 9. The merge still happens at height 7, but the final merge of {15} is at height 14, the largest distance to point 1. Both linkages give the same grouping here, but the heights differ, which changes where you would cut the tree.'
    },
    pros: [
      'No need to fix the number of clusters before running; cut the tree afterwards.',
      'The dendrogram shows structure at several scales at once.',
      'Works with any distance or similarity measure, not just Euclidean distance.',
      'Deterministic: the same data and settings always give the same tree.'
    ],
    cons: [
      'Memory and time grow quickly with the number of points, so it does not suit very large datasets.',
      'Merges are greedy and cannot be undone.',
      'Results depend strongly on the linkage and the distance metric.',
      'Single linkage can chain unrelated groups through a few stray points.'
    ],
    applications: [
      'Organising gene-expression profiles into groups of similar behaviour as an exploratory step for researchers.',
      'Building taxonomies of documents or products.',
      'Grouping survey respondents with similar answer patterns.',
      'Producing a quick overview of a small dataset before choosing k for k-means.'
    ],
    quiz: [
      {
        question: 'In agglomerative clustering, what happens at each step?',
        options: [
          'The largest cluster is split in two.',
          'Every point is reassigned to the nearest centroid.',
          'The two closest clusters are merged.',
          'The point farthest from all others is removed.'
        ],
        answerIndex: 2,
        explanation: 'Agglomerative methods work bottom-up, merging the closest pair each time. Splitting is the divisive approach and reassignment to centroids is k-means.'
      },
      {
        question: 'Which linkage uses the distance between the two closest members of two clusters?',
        options: ['Single linkage', 'Complete linkage', 'Average linkage', 'Ward linkage'],
        answerIndex: 0,
        explanation: 'Single linkage takes the minimum pairwise distance. Complete linkage uses the maximum, which is why it avoids chaining.'
      },
      {
        question: 'What does the height at which two branches join in a dendrogram represent?',
        options: [
          'The number of points in the merged cluster.',
          'The inter-cluster distance at the moment of the merge.',
          'The order in which the points were collected.',
          'The probability that the clusters are real.'
        ],
        answerIndex: 1,
        explanation: 'Heights record the linkage distance of each merge. They are not probabilities, and cluster size is not shown by height.'
      },
      {
        question: 'Why is hierarchical clustering hard to apply to millions of points?',
        options: [
          'It can only handle categorical data.',
          'It requires labels.',
          'It needs the number of clusters to be known.',
          'It stores and updates a pairwise distance matrix that grows with the square of the number of points.'
        ],
        answerIndex: 3,
        explanation: 'The distance matrix has about $n^2/2$ entries, so memory and time grow rapidly. It needs neither labels nor a fixed number of clusters.'
      }
    ],
    related: ['k-means-clustering', 'clustering-evaluation', 'unsupervised-learning', 'dimensionality-reduction'],
    keywords: ['dendrogram', 'linkage', 'agglomerative', 'single linkage', 'complete linkage', 'Ward']
  },
  {
    id: 'principal-component-analysis',
    title: 'Principal component analysis',
    category: 'unsupervised',
    summary: 'Principal component analysis rotates data onto new perpendicular axes ordered by how much variance they capture, so a few axes can summarise many variables.',
    readingMinutes: 8,
    intro:
      'When a dataset has dozens of correlated variables, much of that information is repeated. Principal component analysis (PCA) finds a small number of new variables, each a weighted combination of the originals, that keep as much of the variation as possible.\n\nAfter this lesson you will be able to compute the principal components of a small dataset from its covariance matrix, interpret the eigenvalues as variance, and explain what is lost when you keep only the leading components.',
    simple:
      'Imagine a cloud of points shaped like a long, thin cigar floating in a room. To describe where a point is, the most useful ruler lies along the length of the cigar, because that is where points differ the most. A second ruler across its width adds a little more detail, and a third adds almost nothing.\n\nPCA finds those rulers. They are always perpendicular to each other, and they are ordered from most to least spread. If you keep only the first ruler, you replace each 3D point by a single number, its position along the cigar, and you lose only the small wobble across it.\n\nNote that PCA looks only at spread in the inputs. It does not know about any label, so the direction of most variation is not guaranteed to be the most useful for a prediction.',
    technical:
      'Centre the data matrix $X \\in \\mathbb{R}^{n\\times d}$ by subtracting each column mean, and form the sample covariance matrix $S = \\frac{1}{n-1}X^{\\top}X$. Because $S$ is symmetric and positive semi-definite, it has an eigen-decomposition with real non-negative eigenvalues $\\lambda_1 \\ge \\dots \\ge \\lambda_d$ and orthonormal eigenvectors $v_1,\\dots,v_d$. The eigenvectors are the principal axes, and $\\lambda_j$ is the variance of the data projected onto $v_j$. The first component is the unit direction that maximises projected variance; each later one maximises it subject to being orthogonal to the earlier ones.\n\nProjecting onto the first $m$ components gives scores $Z = X V_m$ and a reconstruction $\\hat X = Z V_m^{\\top}$ that minimises the squared reconstruction error among all rank-$m$ linear approximations. The fraction of variance retained is $\\sum_{j\\le m}\\lambda_j / \\sum_j \\lambda_j$. Equivalent and numerically preferred is the singular value decomposition of the centred matrix, where squared singular values divided by $n-1$ give the eigenvalues.\n\nPCA is linear, so it cannot unfold curved structure. It is sensitive to feature scale, so variables with different units are usually standardised first, which makes PCA operate on the correlation matrix. Components are defined up to a sign flip, and their meaning can be hard to interpret because each mixes all the original variables.',
    math: [
      {
        label: 'Sample covariance of centred data',
        tex: String.raw`S \;=\; \frac{1}{n-1}\,X^{\top}X`,
        note: '$X$ has one row per observation and its columns have mean zero. Entry $S_{jk}$ is the covariance of features $j$ and $k$.'
      },
      {
        label: 'Eigen-decomposition',
        tex: String.raw`S\,v_j \;=\; \lambda_j\, v_j, \qquad v_j^{\top}v_k = 0 \;\; (j \ne k)`,
        note: 'Each unit eigenvector $v_j$ is a principal axis and its eigenvalue $\\lambda_j$ is the variance along that axis.'
      },
      {
        label: 'Explained variance ratio',
        tex: String.raw`\text{EVR}_m \;=\; \frac{\sum_{j=1}^{m}\lambda_j}{\sum_{j=1}^{d}\lambda_j}`,
        note: 'The share of total variance kept when the first $m$ components are used.'
      },
      {
        label: 'Projection',
        tex: String.raw`z_i \;=\; V_m^{\top}\,(x_i - \bar{x})`,
        note: 'The scores $z_i$ are the coordinates of observation $i$ in the new, lower-dimensional space.'
      }
    ],
    example: {
      title: 'PCA on five points in two dimensions',
      body:
        'Data (x, y): (2,1), (3,3), (4,3), (5,5), (6,4). The means are 4 and 3.2, so the centred points are (-2,-2.2), (-1,-0.2), (0,-0.2), (1,1.8), (2,0.8).\n\nThe sample covariance matrix has variance of x equal to 2.5, variance of y equal to 2.2 and covariance 2.0, so S = [[2.5, 2.0], [2.0, 2.2]].\n\nIts eigenvalues are 4.356 and 0.344. The total variance is 4.7, so the first component keeps 4.356 / 4.7 = 92.7% of it. The first eigenvector is approximately (0.733, 0.680), a diagonal direction as expected from the positive covariance.\n\nProjecting the centred points onto it gives scores of about -2.96, -0.87, -0.14, 1.96 and 2.01. Five two-dimensional points are now summarised by five numbers while keeping most of the spread.'
    },
    pros: [
      'Removes redundancy between correlated variables.',
      'Gives a ranked, quantified account of how much variance each direction carries.',
      'Fast, deterministic and based on well-understood linear algebra.',
      'Useful for visualisation, noise reduction and as a preprocessing step.'
    ],
    cons: [
      'Only captures linear structure.',
      'Sensitive to feature scaling and to outliers.',
      'Components mix all inputs and can be hard to explain.',
      'High variance does not guarantee relevance to a prediction target.'
    ],
    applications: [
      'Plotting high-dimensional data in two dimensions to look for structure.',
      'Compressing images or sensor signals while keeping most of the variation.',
      'Reducing correlated lab measurements before fitting a model, with the loss of interpretability noted.',
      'Removing noise from measurements by discarding low-variance directions.'
    ],
    quiz: [
      {
        question: 'What does an eigenvalue of the covariance matrix represent in PCA?',
        options: [
          'The variance of the data along the corresponding principal axis.',
          'The mean of the data along that axis.',
          'The number of points on that axis.',
          'The correlation between the axis and the label.'
        ],
        answerIndex: 0,
        explanation: 'Each eigenvalue is the variance of the projection onto its eigenvector. PCA ignores labels entirely.'
      },
      {
        question: 'Why is standardising features often done before PCA?',
        options: [
          'PCA requires every feature to be binary.',
          'Features with large units would otherwise dominate the leading components.',
          'Standardising makes the components non-orthogonal.',
          'It increases the number of components available.'
        ],
        answerIndex: 1,
        explanation: 'Variance depends on units, so a variable measured in large numbers would dominate. Standardising puts all variables on the same footing. Components stay orthogonal either way.'
      },
      {
        question: 'The first two components of a dataset have eigenvalues 6 and 2, and the total variance is 10. What share is kept by the first two?',
        options: ['60%', '20%', '100%', '80%'],
        answerIndex: 3,
        explanation: '(6 + 2) / 10 = 0.8, so 80% of the variance is retained. 60% is the share of the first component alone.'
      },
      {
        question: 'Which statement about principal components is correct?',
        options: [
          'They are chosen to best separate the classes.',
          'They can be any unit-length directions, not necessarily perpendicular.',
          'They are mutually orthogonal and ordered by explained variance.',
          'They always correspond to one original feature each.'
        ],
        answerIndex: 2,
        explanation: 'Principal axes are orthonormal eigenvectors ordered by eigenvalue. Class separation is the goal of supervised methods such as linear discriminant analysis.'
      }
    ],
    related: ['dimensionality-reduction', 'feature-selection', 'k-means-clustering', 'unsupervised-learning'],
    keywords: ['PCA', 'covariance matrix', 'eigenvalue', 'eigenvector', 'explained variance', 'SVD']
  },
  {
    id: 'dimensionality-reduction',
    title: 'Dimensionality reduction',
    category: 'unsupervised',
    summary: 'Dimensionality reduction represents data with fewer variables while keeping the structure that matters, to ease visualisation, storage and learning.',
    readingMinutes: 7,
    intro:
      'Real datasets can have hundreds or thousands of columns. Many are redundant, some are noise, and the rest make models slower, harder to visualise and easier to overfit. Dimensionality reduction maps each example to a shorter description.\n\nAfter this lesson you will be able to separate feature selection from feature extraction, choose a number of PCA components using explained variance, and describe when non-linear methods are worth using instead.',
    simple:
      'A map of the Earth is a flat sheet, yet it lets you find cities. Going from the 3D globe to the 2D page loses something, such as true areas near the poles, but keeps what you need to navigate. Different map projections keep different things.\n\nDimensionality reduction does the same for data with many columns. You squash it to a few coordinates so you can plot it or feed it to a simpler model, and you accept that some detail is lost. The skill is in choosing what to preserve: overall spread, local neighbourhoods, or distances.\n\nThere are two broad ways to shrink a table. You can **drop** columns you do not need, or you can **blend** columns into a few new ones.',
    technical:
      'Reduction methods fall into two families. Feature selection keeps a subset of the original variables, so the result stays interpretable. Feature extraction builds new variables, $z = g(x)$ with $z \\in \\mathbb{R}^m$ and $m < d$, as in PCA (linear, preserves variance), classical multidimensional scaling (preserves pairwise distances), and non-linear manifold methods such as Isomap, t-SNE and UMAP, which preserve neighbourhood structure. Autoencoders learn $g$ as the encoder of a neural network trained to reconstruct its input through a narrow layer.\n\nThe motivation is partly the curse of dimensionality: as $d$ grows, volume increases so fast that data become sparse, and distances between points concentrate, which weakens methods based on neighbourhoods. If the data lie near a low-dimensional manifold, a good embedding can recover usable coordinates.\n\nChoosing $m$ for PCA is commonly done by cumulative explained variance, a scree plot elbow, or by cross-validating a downstream task. Caveats matter: t-SNE and UMAP plots are useful for exploration but cluster sizes, gaps and distances between clusters in them should not be over-read, and results depend on hyperparameters and random seeds. Any reduction must be fitted on training data only and then applied unchanged to validation and test data, otherwise information leaks.',
    math: [
      {
        label: 'Reconstruction error of a linear reduction',
        tex: String.raw`E \;=\; \frac{1}{n}\sum_{i=1}^{n}\lVert x_i - V_m V_m^{\top}x_i \rVert^{2}`,
        note: '$V_m$ holds $m$ orthonormal columns. PCA chooses the $V_m$ that minimises $E$ for centred data.'
      },
      {
        label: 'Cumulative explained variance',
        tex: String.raw`\text{EVR}(m) \;=\; \frac{\sum_{j=1}^{m}\lambda_j}{\sum_{j=1}^{d}\lambda_j}`,
        note: 'Pick the smallest $m$ for which this passes a chosen threshold, for example 0.90.'
      },
      {
        label: 'Distance preservation (stress)',
        tex: String.raw`\text{Stress} \;=\; \sum_{i<j}\big(d_{ij} - \lVert z_i - z_j \rVert\big)^{2}`,
        note: '$d_{ij}$ is the original distance between examples $i$ and $j$ and $z_i$ is the low-dimensional point. Multidimensional scaling looks for $z$ that makes this small.'
      }
    ],
    example: {
      title: 'Choosing how many components to keep',
      body:
        'Suppose a PCA of six standardised measurements gives eigenvalues 4.0, 2.0, 1.0, 0.5, 0.3 and 0.2. Their sum is 8.0, which equals the number of variables only if the data were standardised; here we simply use the sum.\n\nThe explained variance ratios are 4.0/8 = 0.500, 2.0/8 = 0.250, 1.0/8 = 0.125, 0.5/8 = 0.0625, 0.3/8 = 0.0375 and 0.2/8 = 0.025.\n\nThe cumulative values are 0.500, 0.750, 0.875, 0.9375, 0.975 and 1.000. To keep at least 90% of the variance we need 4 components, because 3 give only 87.5%. We therefore replace six columns by four, losing 6.25% of the variance.\n\nIn practice you would then check that a model trained on the four scores performs about as well on validation data as one trained on all six.'
    },
    pros: [
      'Makes high-dimensional data plottable and easier to explore.',
      'Reduces storage, computation and often noise.',
      'Can lessen overfitting when there are many more features than examples.',
      'Handles correlated variables by combining them.'
    ],
    cons: [
      'Always discards some information, and what is discarded may matter for the task.',
      'New features can be harder to interpret than the original ones.',
      'Non-linear embeddings depend on settings and can mislead if over-interpreted.',
      'Must be fitted on training data only, which is easy to get wrong.'
    ],
    applications: [
      'Two-dimensional plots of high-dimensional data to look for groups or outliers.',
      'Compressing image or audio features before storage or search.',
      'Reducing many correlated sensor channels before building a forecasting model.',
      'Exploring single-cell or lab-panel data as a hypothesis-generating step for researchers.'
    ],
    quiz: [
      {
        question: 'What is the difference between feature selection and feature extraction?',
        options: [
          'Selection creates new variables; extraction deletes rows.',
          'Selection keeps a subset of the original variables; extraction builds new ones from them.',
          'They are two names for the same procedure.',
          'Extraction requires labels; selection never does.'
        ],
        answerIndex: 1,
        explanation: 'Selection retains original columns, which keeps them interpretable. Extraction, such as PCA, constructs new variables from combinations of the originals.'
      },
      {
        question: 'Cumulative explained variance for components 1 to 4 is 0.62, 0.81, 0.89 and 0.93. What is the smallest number of components that retains at least 90%?',
        options: ['3', '2', '5', '4'],
        answerIndex: 3,
        explanation: 'With 3 components only 89% is kept, which is below 90%. Four components reach 93%.'
      },
      {
        question: 'Why must a dimensionality reduction be fitted on the training set only?',
        options: [
          'Fitting on all data lets information from the test set influence the transformation, which makes evaluation optimistic.',
          'Test data cannot be numeric.',
          'PCA cannot run on more than one dataset.',
          'The training set always has more columns.'
        ],
        answerIndex: 0,
        explanation: 'If the transformation sees test data, the evaluation is no longer a fair test of unseen data. Fit on training data, then apply the fitted transformation to the others.'
      },
      {
        question: 'Which caution applies to t-SNE or UMAP plots?',
        options: [
          'They always preserve global distances exactly.',
          'They are linear and therefore easy to interpret.',
          'The sizes of clusters and gaps between them should not be read as exact quantities.',
          'They cannot be used with more than two features.'
        ],
        answerIndex: 2,
        explanation: 'These methods focus on preserving local neighbourhoods, so global layout, cluster size and between-cluster distance can be distorted and depend on settings.'
      }
    ],
    related: ['principal-component-analysis', 'feature-selection', 'unsupervised-learning', 'regularization'],
    keywords: ['curse of dimensionality', 'feature extraction', 'manifold', 't-SNE', 'UMAP', 'autoencoder']
  },
  {
    id: 'clustering-evaluation',
    title: 'Clustering evaluation',
    category: 'unsupervised',
    summary: 'Clustering evaluation judges how compact and well separated clusters are, using internal scores such as silhouette or external scores when reference labels exist.',
    readingMinutes: 7,
    intro:
      'With no labels there is no accuracy to report, yet every clustering algorithm will return groups, even from random noise. You need ways to judge whether the groups are meaningful, and to compare different values of k or different algorithms.\n\nAfter this lesson you will be able to compute a silhouette value by hand, name the difference between internal and external measures, and explain why a good score is evidence and not proof.',
    simple:
      'Suppose you sort a classroom into teams. A good split has two features: people on the same team sit close together, and people on different teams sit far apart. If someone is nearer to the other team than their own, they probably belong elsewhere.\n\nClustering scores formalise this. For each point you compare how close it is to its own group with how close it is to the nearest other group. A score near 1 means it clearly belongs, near 0 means it sits on the border, and below 0 means it may be in the wrong group.\n\nIf you also happen to know the true groups, say from an expert, you can instead measure how well the clusters match them. But beware: a pretty score does not mean the groups are useful. That judgement needs a person who knows the domain.',
    technical:
      'Internal measures use only the data and the partition. The silhouette of point $i$ compares $a(i)$, its mean distance to other points in its own cluster, with $b(i)$, the lowest mean distance to the points of any other cluster. It lies in $[-1,1]$, and the mean silhouette over the dataset can be compared across values of $k$. The Davies-Bouldin index averages, for each cluster, its worst ratio of within-cluster scatter to between-centroid separation (lower is better). The Calinski-Harabasz index is a ratio of between-cluster to within-cluster dispersion (higher is better). Inertia always falls as $k$ rises, so it needs an elbow judgement and cannot be used alone.\n\nExternal measures compare to a reference partition. The adjusted Rand index counts pairs of points that are grouped together or apart in both partitions and corrects for chance, so that random labelling scores near 0 and identical partitions score 1. Normalised mutual information measures shared information between two labelings. These require ground truth, which in truly unsupervised work is rarely available.\n\nCaveats: each internal index embeds an assumption about what a cluster is, usually compact and convex, so density-based clusters of arbitrary shape can score poorly although they are correct. Stability is another check: re-cluster on bootstrap resamples and see whether the groups reappear. Finally, cluster tendency should be checked, since data with no structure can still produce moderate scores.',
    math: [
      {
        label: 'Silhouette of one point',
        tex: String.raw`s(i) \;=\; \frac{b(i) - a(i)}{\max\{a(i),\, b(i)\}}`,
        note: '$a(i)$ is the mean distance from point $i$ to the other members of its own cluster; $b(i)$ is the smallest mean distance from $i$ to the members of any other cluster.'
      },
      {
        label: 'Mean silhouette',
        tex: String.raw`\bar{s} \;=\; \frac{1}{n}\sum_{i=1}^{n} s(i)`,
        note: 'Values near 1 indicate compact, well-separated clusters. Compare $\\bar{s}$ across candidate values of $k$.'
      },
      {
        label: 'Calinski-Harabasz index',
        tex: String.raw`\text{CH} \;=\; \frac{\operatorname{tr}(B_k)/(k-1)}{\operatorname{tr}(W_k)/(n-k)}`,
        note: '$B_k$ is the between-cluster scatter matrix and $W_k$ the within-cluster scatter matrix. Higher values mean tighter, better-separated clusters.'
      },
      {
        label: 'Adjusted Rand index',
        tex: String.raw`\text{ARI} \;=\; \frac{\text{RI} - \mathbb{E}[\text{RI}]}{\max(\text{RI}) - \mathbb{E}[\text{RI}]}`,
        note: 'RI is the fraction of point pairs on which two partitions agree. Subtracting its expected value under random labelling makes the index near 0 for chance agreement.'
      }
    ],
    example: {
      title: 'Silhouette for six points in two clusters',
      body:
        'Points on a line: 1, 2, 3 in cluster A and 8, 9, 12 in cluster B.\n\nFor the point 1: its mean distance to the other members of A is (1+2)/2 = 1.5, so a = 1.5. Its mean distance to B is (7+8+11)/3 = 8.67, so b = 8.67. Then s = (8.67 - 1.5) / 8.67 = 0.827.\n\nFor the point 2: a = (1+1)/2 = 1.0, b = (6+7+10)/3 = 7.67, s = 0.870. For the point 3: a = 1.5, b = (5+6+9)/3 = 6.67, s = 0.775.\n\nFor the point 8: a = (1+4)/2 = 2.5, b = (7+6+5)/3 = 6.0, s = 0.583. For the point 9: a = (1+3)/2 = 2.0, b = 7.0, s = 0.714. For the point 12: a = (4+3)/2 = 3.5, b = 10.0, s = 0.650.\n\nThe mean silhouette is about 0.737. The weakest points are the ones in B, which is spread out the most, and 12 is the most isolated. A value this high suggests a clear two-group structure, but it should be backed up by domain knowledge.'
    },
    pros: [
      'Gives a number to compare different values of k or different algorithms.',
      'Silhouette values for individual points highlight those that sit on cluster borders.',
      'External indices let you test a method against a known reference partition.',
      'Stability checks reveal fragile clusterings without needing labels.'
    ],
    cons: [
      'Internal indices assume a notion of cluster shape and may penalise valid non-convex clusters.',
      'Different indices can disagree on the best k.',
      'External indices need ground-truth labels, which are usually absent.',
      'A good score does not show that clusters are meaningful or useful.'
    ],
    applications: [
      'Choosing the number of clusters for k-means by comparing mean silhouette across k.',
      'Comparing hierarchical and k-means results on the same dataset.',
      'Flagging borderline customers or samples that fit their assigned group poorly.',
      'Checking a clustering of patient subtypes against expert groupings in research, never as a diagnosis.'
    ],
    quiz: [
      {
        question: 'A point has silhouette close to -0.4. What does this suggest?',
        options: [
          'It is at the centre of a very tight cluster.',
          'It may have been assigned to the wrong cluster.',
          'It is an exact duplicate of another point.',
          'The clustering has exactly the right k.'
        ],
        answerIndex: 1,
        explanation: 'A negative silhouette means the point is on average closer to another cluster than to its own, so the assignment is questionable.'
      },
      {
        question: 'Why is inertia (within-cluster sum of squares) alone a poor way to choose k?',
        options: [
          'It cannot be computed for k above 2.',
          'It requires labels.',
          'It always decreases as k increases, reaching zero when each point has its own cluster.',
          'It is always the same for every k.'
        ],
        answerIndex: 2,
        explanation: 'More clusters can only reduce within-cluster scatter, so the lowest inertia always favours the largest k. That is why an elbow or a penalised index is needed.'
      },
      {
        question: 'Which measure compares a clustering with a known reference partition?',
        options: [
          'Mean silhouette',
          'Davies-Bouldin index',
          'Inertia',
          'Adjusted Rand index'
        ],
        answerIndex: 3,
        explanation: 'The adjusted Rand index is external, using ground-truth groupings. The others use only the data and the cluster assignments.'
      },
      {
        question: 'For a point, a(i) = 2 and b(i) = 8. What is its silhouette?',
        options: ['0.75', '0.25', '-0.75', '4'],
        answerIndex: 0,
        explanation: '(8 - 2) / max(2, 8) = 6/8 = 0.75. The value must lie between -1 and 1, so 4 is impossible.'
      }
    ],
    related: ['k-means-clustering', 'hierarchical-clustering', 'unsupervised-learning', 'dimensionality-reduction'],
    keywords: ['silhouette', 'Davies-Bouldin', 'Calinski-Harabasz', 'adjusted Rand index', 'cluster validity', 'stability']
  }
];
