import type { Lesson } from '../types';

export const foundationsLessons: Lesson[] = [
  {
    id: 'what-is-ml',
    title: 'What is machine learning?',
    category: 'foundations',
    summary: 'Machine learning builds programs that improve at a task by finding patterns in examples instead of following hand-written rules.',
    readingMinutes: 6,
    intro:
      'Most software is a list of rules written by a person: if the order total is above 50, ship for free. Machine learning turns this around. You give the computer examples of inputs together with the outcomes you want, and it works out the rules itself.\n\nAfter this lesson you will be able to say what it means for a program to learn, name the three ingredients every learning system has, and recognise when a problem is a good fit for learning from data.',
    simple:
      'Imagine teaching a child to tell ripe mangoes from unripe ones. You do not hand over a rulebook. You hold up many mangoes, say ripe or not ripe, and let the child notice the pattern: colour, smell, softness. After enough examples the child can judge a mango they have never seen.\n\nMachine learning works the same way. The "mangoes" are rows in a table, the "noticing" is a mathematical search for a rule that matches the labelled examples, and the test of success is how well the rule does on new rows it was not shown.\n\nThree things are always present: **data** (the examples), a **model** (a flexible formula or procedure with adjustable settings), and a **score** that says how wrong the model currently is. Learning is the process of adjusting the settings to make the score better.',
    technical:
      'A frequently quoted definition says a program learns from experience $E$ with respect to a task $T$ and a performance measure $P$ if its performance at $T$, as measured by $P$, improves with $E$. In supervised learning, $E$ is a set of input-output pairs $(x_i, y_i)$, $T$ is predicting $y$ for a new $x$, and $P$ is a loss averaged over data.\n\nA model is a function $f_\\theta$ with parameters $\\theta$. Training chooses $\\theta$ by minimising the average loss on the training data, usually with an iterative optimiser. The real goal is different, though: low error on data the model has not seen. The gap between training error and error on new data is the central difficulty of the field, and most of the techniques in later lessons (validation, regularisation, cross-validation) exist to manage it.\n\nTwo assumptions sit underneath almost everything. First, the future data resemble the training data (they come from the same distribution). Second, the inputs actually contain information about the target. When either fails, for example when a hospital model is moved to a different population, performance can drop sharply without any warning from the training score.',
    math: [
      {
        label: 'Learning as minimising average loss',
        tex: String.raw`\hat{\theta} \;=\; \arg\min_{\theta}\; \frac{1}{n}\sum_{i=1}^{n} L\big(f_{\theta}(x_i),\, y_i\big)`,
        note: 'The training set has $n$ examples. $L$ measures how far a prediction $f_\\theta(x_i)$ is from the true value $y_i$. The chosen parameters $\\hat\\theta$ make the average loss smallest.'
      },
      {
        label: 'What we actually care about',
        tex: String.raw`R(f) \;=\; \mathbb{E}_{(x,y)}\big[\, L\big(f(x),\, y\big) \,\big]`,
        note: 'The risk $R(f)$ is the expected loss on new data drawn from the same source. We cannot compute it exactly, so we estimate it with data held back from training.'
      }
    ],
    example: {
      title: 'Learning a spam rule from six emails',
      body:
        'Suppose each email has one feature: the number of exclamation marks. Six labelled emails give counts 0, 1, 0, 5, 7, 6, with labels not spam, not spam, not spam, spam, spam, spam.\n\nA model that says "spam if the count is above a threshold" has one adjustable setting, the threshold. Try 0.5: the email with 1 exclamation mark is wrongly flagged, giving 1 error out of 6. Try 3: every email is classified correctly, 0 errors. Choosing the threshold with the lowest error is training.\n\nThis tiny model will still fail on new data, for example a calm phishing email with no exclamation marks. That is why we test on emails the model has never seen.'
    },
    pros: [
      'Handles problems where the rules are too many or too subtle to write by hand, such as recognising speech or handwriting.',
      'Adapts when retrained on fresh data, without rewriting the program.',
      'Can find patterns in many variables at once that a person would miss.'
    ],
    cons: [
      'Needs enough representative, correctly labelled data, which is often expensive to collect.',
      'Can learn shortcuts or biases that are present in the data and report them with confidence.',
      'Good performance on past data does not guarantee good performance in a new setting.',
      'Many models are hard to inspect, which makes mistakes hard to diagnose.'
    ],
    applications: [
      'Filtering spam and detecting fraudulent card payments.',
      'Estimating whether a medical image or a set of test results suggests disease, as decision support for clinicians.',
      'Recommending products, music or articles.',
      'Forecasting demand, energy use or equipment failure.'
    ],
    quiz: [
      {
        question: 'Which description best matches machine learning?',
        options: [
          'A person writes every rule the program will follow.',
          'A program adjusts its own settings so that it makes fewer errors on example data.',
          'A program stores every example and replays them exactly.',
          'A database query that returns matching rows.'
        ],
        answerIndex: 1,
        explanation: 'Learning means adjusting parameters to improve a performance measure using examples. Hand-written rules are ordinary programming, and replaying stored examples is memorisation.'
      },
      {
        question: 'A model reaches 99% accuracy on its training data. What can you conclude about new data?',
        options: [
          'It will also reach about 99%.',
          'It will reach at least 90%.',
          'Nothing yet; you must measure on data it did not train on.',
          'The model is guaranteed to be overfitted.'
        ],
        answerIndex: 2,
        explanation: 'Training accuracy can be high because the model memorised the examples. Only a held-out evaluation estimates performance on new data. A high training score is not proof of overfitting either, so the last option is also wrong.'
      },
      {
        question: 'Which is NOT one of the three ingredients named in this lesson?',
        options: ['Data', 'A model with adjustable settings', 'A score that measures error', 'A guarantee of correctness'],
        answerIndex: 3,
        explanation: 'Learning systems have data, a model and a score. They come with no guarantee of correctness; that is why evaluation matters.'
      }
    ],
    related: ['ai-vs-ml-vs-dl', 'types-of-ml', 'generalization'],
    keywords: ['learning from data', 'model', 'loss', 'training', 'prediction']
  },
  {
    id: 'ai-vs-ml-vs-dl',
    title: 'AI vs machine learning vs deep learning',
    category: 'foundations',
    summary: 'Artificial intelligence is the broad goal, machine learning is the data-driven way of reaching it, and deep learning is machine learning with many-layered neural networks.',
    readingMinutes: 5,
    intro:
      'The three terms are often used as if they meant the same thing, which makes news articles and job descriptions confusing. They are nested: each one is a subset of the one before it. Knowing which is which helps you judge what a product claims to do.\n\nAfter this lesson you will be able to place a given system in the right layer, explain what makes deep learning different from other machine learning, and say when a simpler method is the better choice.',
    simple:
      'Think of transport. "Vehicles" is the broad idea, "cars" is one family of vehicles, and "electric cars" is one kind of car. Artificial intelligence (AI) is the broad idea: any technique that lets a computer do something that normally needs human judgement. Machine learning (ML) is one family inside it, where the computer learns the behaviour from examples. Deep learning (DL) is one kind of ML, built from neural networks with many stacked layers.\n\nNot all AI learns. A chess program that searches moves using rules written by programmers is AI but not ML. A spam filter trained on labelled emails is ML. A system that reads handwriting using a network with many layers is deep learning.\n\nThe layers are not ranked by quality. A short, simple model often beats a deep network when you have a small table of data.',
    technical:
      'AI covers symbolic methods (logic, search, planning, expert systems) and statistical methods. ML is the subfield in which behaviour is estimated from data by optimising parameters against a loss. DL is the subfield of ML that uses neural networks with several layers of learned transformations, so that the model builds its own intermediate representations of the input.\n\nThe practical distinction is where the features come from. In classical ML on tabular data, a person usually designs the features (ratios, counts, encodings) and a model such as a linear model or a tree ensemble uses them. In deep learning on images, audio or text, the early layers learn useful features directly from raw pixels, waveforms or tokens. This is powerful, but it generally requires more data and more computation, and the resulting models are harder to interpret.\n\nA layer maps an input vector to an output vector through a weight matrix, a bias and a non-linear activation. Stacking layers lets the network represent more complex functions. Model size is commonly measured by the number of trainable parameters, which grows quickly with width and depth.',
    math: [
      {
        label: 'One fully connected layer',
        tex: String.raw`\mathbf{h} \;=\; \sigma\big(W\mathbf{x} + \mathbf{b}\big)`,
        note: 'The input $\\mathbf{x}$ is multiplied by a weight matrix $W$, a bias $\\mathbf{b}$ is added, and a non-linear function $\\sigma$ is applied. Deep learning stacks many such layers.'
      },
      {
        label: 'Trainable parameters in a layer',
        tex: String.raw`P \;=\; (n_{\text{in}} + 1)\, n_{\text{out}}`,
        note: 'A layer with $n_{\\text{in}}$ inputs and $n_{\\text{out}}$ outputs has $n_{\\text{in}} n_{\\text{out}}$ weights plus $n_{\\text{out}}$ biases.'
      }
    ],
    example: {
      title: 'Counting parameters: linear model vs small network',
      body:
        'Take 3 input features and one output. A linear model has 3 weights and 1 bias, so 4 parameters.\n\nNow add a hidden layer of 4 units. The first layer has $(3+1)\\times 4 = 16$ parameters. The output layer has $(4+1)\\times 1 = 5$. The total is $16 + 5 = 21$ parameters, more than five times as many as the linear model, even for this tiny network.\n\nReal deep networks have many layers and wide layers, so counts reach millions or more. More parameters give more flexibility, and also more need for data and for checking against overfitting.'
    },
    pros: [
      'The nested view gives a clear vocabulary for comparing systems.',
      'Deep learning can learn features directly from raw images, sound and text.',
      'Classical ML remains effective and cheap on small tabular datasets.',
      'Rule-based AI is predictable and easy to audit where rules are well understood.'
    ],
    cons: [
      'Marketing often labels any software "AI", which hides how it actually works.',
      'Deep learning usually needs large datasets and substantial computing resources.',
      'Deeper models are harder to explain than a linear model or a small tree.',
      'Choosing the most complex layer by default can waste effort and reduce reliability.'
    ],
    applications: [
      'Rule-based AI: route planning and game-playing programs that search through possible moves.',
      'Classical ML: predicting customer churn from a table of account features.',
      'Deep learning: recognising objects in photographs or transcribing speech.',
      'Deep learning: translating text between languages.'
    ],
    quiz: [
      {
        question: 'Which statement about the three terms is correct?',
        options: [
          'Deep learning contains machine learning, which contains AI.',
          'Machine learning is one approach within AI, and deep learning is one approach within machine learning.',
          'AI and deep learning are separate fields that do not overlap.',
          'Machine learning is the same thing as deep learning.'
        ],
        answerIndex: 1,
        explanation: 'The sets are nested: deep learning is inside machine learning, which is inside AI. The first option reverses the nesting.'
      },
      {
        question: 'A chess engine follows hand-written evaluation rules and searches moves. How is it best described?',
        options: ['Deep learning', 'AI but not necessarily machine learning', 'Unsupervised learning', 'Not AI at all'],
        answerIndex: 1,
        explanation: 'It performs a task requiring judgement, so it counts as AI, but its behaviour is not estimated from data, so it need not be ML.'
      },
      {
        question: 'A network has 5 inputs and one layer of 3 units. How many parameters does that layer have?',
        options: ['15', '18', '8', '24'],
        answerIndex: 1,
        explanation: 'Use $(n_{in}+1)\\times n_{out} = (5+1)\\times 3 = 18$. The value 15 forgets the biases.'
      }
    ],
    related: ['what-is-ml', 'types-of-ml', 'training-and-prediction'],
    keywords: ['artificial intelligence', 'deep learning', 'neural network', 'layers', 'parameters']
  },
  {
    id: 'types-of-ml',
    title: 'Types of machine learning',
    category: 'foundations',
    summary: 'Machine learning problems are grouped by the feedback available: labelled answers (supervised), no answers (unsupervised), or rewards from actions (reinforcement).',
    readingMinutes: 5,
    intro:
      'Before choosing an algorithm you need to know what kind of feedback your data provides. Do you have the correct answer for each example, none at all, or only a score that arrives after a sequence of decisions? The answer decides which family of methods applies.\n\nAfter this lesson you will be able to name the three main types, match a real task to its type, and recognise common mixed settings such as semi-supervised learning.',
    simple:
      'Picture three ways of learning to cook. In the first, a teacher tastes each dish and tells you the right seasoning: that is **supervised learning**, because every example comes with an answer. In the second, you get a box of unlabelled ingredients and sort them into groups that seem alike: that is **unsupervised learning**, because nobody gives answers. In the third, you cook meals for guests, and they only tell you afterwards how much they enjoyed it: that is **reinforcement learning**, because you learn from rewards for your actions.\n\nIn between there are mixtures. If only a small share of your examples carry answers, you can still use the rest to understand the shape of the data. This is called semi-supervised learning.',
    technical:
      'In supervised learning the data are pairs $(x_i, y_i)$ and the goal is a function that predicts $y$ from $x$. Tasks are regression when $y$ is numeric and classification when $y$ is a category. In unsupervised learning only inputs $x_i$ are available, and the goal is structure: clusters, low-dimensional representations, densities or anomalies. In reinforcement learning an agent interacts with an environment, choosing actions and receiving rewards, and seeks a policy that maximises expected cumulative reward. Here the data depend on the agent\'s own choices, which sets it apart from the other two.\n\nHybrid settings are common. Semi-supervised learning uses a few labelled and many unlabelled examples. Self-supervised learning builds labels from the data itself, for example by hiding a word and predicting it. The choice among types is driven by what supervision exists and how expensive it is to obtain.',
    math: [
      {
        label: 'Supervised objective',
        tex: String.raw`\min_{\theta}\; \frac{1}{n}\sum_{i=1}^{n} L\big(f_\theta(x_i),\, y_i\big)`,
        note: 'Labels $y_i$ are available, so the loss $L$ compares predictions directly with the correct answers.'
      },
      {
        label: 'Unsupervised objective (clustering example)',
        tex: String.raw`\min_{C}\; \sum_{k=1}^{K}\sum_{x_i \in C_k} \lVert x_i - \mu_k \rVert^2`,
        note: 'No labels appear. The objective measures how tightly points sit around the centre $\\mu_k$ of the cluster $C_k$ they were assigned to.'
      },
      {
        label: 'Reinforcement objective',
        tex: String.raw`\max_{\pi}\; \mathbb{E}\Big[\sum_{t=0}^{\infty} \gamma^{t} r_t\Big]`,
        note: 'The policy $\\pi$ is chosen to maximise the expected discounted sum of rewards $r_t$, with discount $\\gamma$ between 0 and 1.'
      }
    ],
    example: {
      title: 'Matching tasks to types',
      body:
        'A company has 1000 customer emails and wants to sort them by topic. Only 200 are labelled with a topic, which is 20% of the data.\n\n- Train a classifier on the 200 labelled emails: supervised.\n- Group all 1000 emails by similarity, without using labels, and read the groups: unsupervised.\n- Use the 200 labels to guide a model that also studies the other 800 emails: semi-supervised.\n\nA fourth task, a robot learning to balance a pole by trying moves and receiving a score, has no table of right answers at all, so it belongs to reinforcement learning.'
    },
    pros: [
      'The taxonomy narrows the choice of algorithm quickly.',
      'Supervised methods give measurable accuracy against known answers.',
      'Unsupervised methods work when labels do not exist.',
      'Reinforcement learning handles sequences of decisions that supervised learning cannot express.'
    ],
    cons: [
      'Real problems often straddle categories, so the boundaries are blurry.',
      'Supervised learning depends on labels, which can be slow or costly to produce.',
      'Unsupervised results are harder to judge because there is no ground truth.',
      'Reinforcement learning often needs many trials and a well-designed reward.'
    ],
    applications: [
      'Supervised: predicting loan repayment from past applications.',
      'Unsupervised: grouping shoppers with similar purchase habits.',
      'Reinforcement: tuning the control policy of a simulated robot.',
      'Semi-supervised: classifying documents when only a few are labelled.'
    ],
    quiz: [
      {
        question: 'What mainly separates supervised from unsupervised learning?',
        options: [
          'Supervised learning uses larger datasets.',
          'Supervised learning uses labelled answers for each example.',
          'Unsupervised learning needs a human to watch training.',
          'Unsupervised learning cannot use numbers.'
        ],
        answerIndex: 1,
        explanation: 'The difference is the presence of target labels, not the size of the data or any human supervision during training.'
      },
      {
        question: 'A program learns to play a game by receiving a score after each match. Which type is this?',
        options: ['Supervised', 'Unsupervised', 'Reinforcement', 'Semi-supervised'],
        answerIndex: 2,
        explanation: 'Feedback arrives as rewards for actions rather than as correct answers per example.'
      },
      {
        question: 'Of 500 records, 50 are labelled. What fraction is labelled?',
        options: ['5%', '10%', '25%', '50%'],
        answerIndex: 1,
        explanation: '$50 / 500 = 0.10$, so 10%. Using the unlabelled rest as well would be semi-supervised learning.'
      }
    ],
    related: ['supervised-learning', 'unsupervised-learning', 'reinforcement-learning'],
    keywords: ['supervised', 'unsupervised', 'reinforcement', 'semi-supervised', 'self-supervised', 'labels']
  },
  {
    id: 'supervised-learning',
    title: 'Supervised learning',
    category: 'foundations',
    summary: 'Supervised learning fits a model to labelled examples so that it can predict the label for new inputs, either a number (regression) or a category (classification).',
    readingMinutes: 6,
    intro:
      'Supervised learning is the most widely used kind of machine learning. Whenever you have past cases where the outcome is known, and you want to predict the outcome for a new case, you are in supervised territory.\n\nAfter this lesson you will be able to distinguish regression from classification, describe the training loop in terms of a loss, and compute a simple loss by hand.',
    simple:
      'Imagine a student working through practice questions with an answer key. After each attempt they compare their answer with the key, see how far off they were, and adjust their method. After many questions they can handle new questions that were not in the practice set.\n\nIn supervised learning the practice questions are the training examples, the answer key is the set of labels, and the "how far off" is the loss. If the answer is a number, such as a house price, the task is **regression**. If the answer is a category, such as spam or not spam, the task is **classification**.\n\nThe key promise is only about new questions of the same kind. A student drilled on arithmetic is not ready for chemistry.',
    technical:
      'Given training data $\\{(x_i, y_i)\\}_{i=1}^{n}$ drawn from an unknown joint distribution, we search a hypothesis class $\\mathcal{F}$ (for example linear functions or trees of limited depth) for $f$ that minimises the empirical risk, often with a penalty on complexity. Typical losses are squared error for regression and cross-entropy for classification.\n\nThe procedure is: choose a model family, choose a loss, fit parameters on training data, tune settings called hyperparameters on a validation set, and report performance on a separate test set. Algorithms differ in their inductive bias, meaning the kinds of functions they find easy to represent. A linear model assumes a roughly linear relationship, while a decision tree splits the input space into regions.\n\nTwo practical issues dominate. Label quality: noise or bias in the labels becomes noise or bias in the model. Distribution shift: if the inputs seen after deployment differ from those in training, the estimated error no longer applies.',
    math: [
      {
        label: 'Mean squared error (regression)',
        tex: String.raw`\text{MSE} \;=\; \frac{1}{n}\sum_{i=1}^{n}\big(\hat{y}_i - y_i\big)^2`,
        note: 'Each prediction $\\hat y_i$ is compared with the true value $y_i$. Squaring penalises large errors more than small ones.'
      },
      {
        label: 'Cross-entropy (binary classification)',
        tex: String.raw`L \;=\; -\frac{1}{n}\sum_{i=1}^{n}\Big[\,y_i \log \hat{p}_i + (1-y_i)\log(1-\hat{p}_i)\Big]`,
        note: 'Here $y_i$ is 0 or 1 and $\\hat p_i$ is the predicted probability of class 1. Confident wrong predictions are penalised heavily.'
      }
    ],
    example: {
      title: 'Comparing two price models by MSE',
      body:
        'Three homes have sizes 50, 80 and 100 square metres and prices 150, 230 and 290 (in thousands).\n\nModel A predicts price = 3 x size: 150, 240, 300. The errors are 0, 10, 10, so MSE is $(0 + 100 + 100)/3 = 66.67$.\n\nModel B predicts price = 2.9 x size: 145, 232, 290. The errors are -5, 2, 0, so MSE is $(25 + 4 + 0)/3 = 9.67$.\n\nModel B has the lower loss on these three homes, so training would prefer it. Whether it is better on unseen homes still has to be checked on held-out data.'
    },
    pros: [
      'Performance can be measured directly against known answers.',
      'A mature toolbox exists, from linear models to tree ensembles and neural networks.',
      'Works well when historical outcomes are available and conditions are stable.',
      'Many methods are fast to train and easy to deploy.'
    ],
    cons: [
      'Requires labels, which may be costly, slow or subjective.',
      'Learns whatever patterns the labels contain, including bias and mistakes.',
      'Predictions can degrade when new data differ from training data.',
      'Finding a pattern is not the same as finding a cause.'
    ],
    applications: [
      'Predicting house prices from size, location and age (regression).',
      'Filtering spam email (classification).',
      'Flagging scans for a clinician to review, as decision support rather than a diagnosis.',
      'Estimating the chance that a card payment is fraudulent.',
      'Forecasting energy demand from weather and calendar features.'
    ],
    quiz: [
      {
        question: 'Predicting the temperature in degrees tomorrow is which task?',
        options: ['Classification', 'Clustering', 'Regression', 'Reinforcement learning'],
        answerIndex: 2,
        explanation: 'The target is a continuous number, so this is regression.'
      },
      {
        question: 'Predictions are 4 and 8, true values are 5 and 6. What is the MSE?',
        options: ['2.5', '1.5', '5', '2'],
        answerIndex: 0,
        explanation: 'Errors are -1 and 2. Squares are 1 and 4. The mean is $5/2 = 2.5$.'
      },
      {
        question: 'Why can a supervised model be unreliable after deployment even if its test score was good?',
        options: [
          'Test scores are always random.',
          'Real inputs may differ from the data it was trained and tested on.',
          'Models forget their parameters over time.',
          'Labels are removed after training.'
        ],
        answerIndex: 1,
        explanation: 'Test performance only describes data similar to the test set. Distribution shift can make real-world performance worse.'
      },
      {
        question: 'Which is a classification task?',
        options: ['Estimating rainfall in millimetres', 'Deciding whether an image shows a cat or a dog', 'Predicting a stock price', 'Forecasting sales next month'],
        answerIndex: 1,
        explanation: 'The target is a category. The others have numeric targets.'
      }
    ],
    related: ['types-of-ml', 'datasets-features-labels', 'train-validation-test', 'linear-regression'],
    keywords: ['supervised', 'regression', 'classification', 'labels', 'loss', 'mean squared error']
  },
  {
    id: 'unsupervised-learning',
    title: 'Unsupervised learning',
    category: 'foundations',
    summary: 'Unsupervised learning looks for structure in data that has no labels, such as groups of similar items, compact representations or unusual cases.',
    readingMinutes: 5,
    intro:
      'Labels are expensive, and many datasets simply do not have them. Unsupervised learning asks a different question: without being told the answer, what patterns are in the data?\n\nAfter this lesson you will know the main tasks (clustering, dimensionality reduction, anomaly detection), understand why results are harder to judge, and be able to carry out one step of k-means by hand.',
    simple:
      'Imagine being handed a drawer of mixed buttons and asked to tidy it. Nobody tells you the categories. You start putting similar buttons together by size, colour and number of holes, and piles appear. You have discovered structure without answers.\n\nThat is clustering, the best-known unsupervised task. Another is compressing a lot of measurements into a few summary numbers while keeping what matters, much like describing a person by height and build instead of listing fifty measurements. A third is spotting the button that does not fit any pile.\n\nBecause there is no answer key, the result is a suggestion. Two reasonable people could sort the buttons differently, and each sorting could be useful.',
    technical:
      'The data are $\\{x_i\\}_{i=1}^{n}$ with no targets. Major tasks include clustering (k-means, hierarchical, density-based), dimensionality reduction (principal component analysis, which finds directions of maximal variance, and nonlinear embeddings), density estimation, and anomaly detection.\n\nK-means alternates two steps. Assignment: give each point to its nearest centroid. Update: move each centroid to the mean of its assigned points. Each step cannot increase the within-cluster sum of squares, so the procedure converges, but only to a local optimum that depends on initialisation, and the number of clusters $K$ must be chosen in advance.\n\nEvaluation is the central difficulty. Internal measures such as the silhouette score describe cohesion and separation but not usefulness. External checks, such as whether discovered groups agree with a known grouping or help a downstream task, are often more convincing. Results are also sensitive to feature scaling, since distance-based methods treat a large-valued feature as more important.',
    math: [
      {
        label: 'K-means objective',
        tex: String.raw`J \;=\; \sum_{k=1}^{K}\sum_{x_i \in C_k} \lVert x_i - \mu_k \rVert^{2}`,
        note: 'The sum of squared distances from each point to the centroid $\\mu_k$ of its cluster $C_k$. K-means tries to make $J$ small.'
      },
      {
        label: 'Centroid update',
        tex: String.raw`\mu_k \;=\; \frac{1}{|C_k|}\sum_{x_i \in C_k} x_i`,
        note: 'After assignment, each centroid becomes the mean of the $|C_k|$ points in its cluster.'
      }
    ],
    example: {
      title: 'One k-means iteration in one dimension',
      body:
        'Points: 1, 2, 9, 10. Choose $K = 2$ with starting centroids 1 and 10.\n\nAssignment: 1 is closest to 1, and 2 is closest to 1 (distance 1 against 8). 9 is closest to 10 (distance 1 against 8), and 10 is closest to 10. Clusters are {1, 2} and {9, 10}.\n\nUpdate: the new centroids are $(1+2)/2 = 1.5$ and $(9+10)/2 = 9.5$.\n\nObjective: each point sits 0.5 from its centroid, so $J = 4 \\times 0.5^2 = 1.0$. Another assignment step changes nothing, so the algorithm has converged.'
    },
    pros: [
      'Needs no labels, so it can be applied to raw data at once.',
      'Reveals structure that may not have been anticipated.',
      'Dimensionality reduction helps visualise and compress data.',
      'Anomaly detection can highlight unusual cases for people to examine.'
    ],
    cons: [
      'There is no single right answer to check against.',
      'Results depend on choices such as the number of clusters, the distance and the scaling of features.',
      'Discovered groups may be mathematically tidy but not meaningful.',
      'Some methods, like k-means, assume roughly round clusters of similar size.'
    ],
    applications: [
      'Segmenting customers into groups with similar behaviour.',
      'Compressing high-dimensional data for plotting and exploration.',
      'Flagging unusual network activity for security analysts to review.',
      'Grouping news articles by topic.'
    ],
    quiz: [
      {
        question: 'What is the defining feature of unsupervised learning?',
        options: [
          'It uses neural networks.',
          'The training data have no target labels.',
          'It never uses a loss or objective.',
          'It only works on images.'
        ],
        answerIndex: 1,
        explanation: 'Only inputs are given. Unsupervised methods still optimise objectives, such as the k-means sum of squared distances.'
      },
      {
        question: 'In k-means, what does the update step do?',
        options: [
          'Moves each centroid to the mean of the points assigned to it.',
          'Deletes the points farthest from the centroid.',
          'Chooses a new value of K.',
          'Assigns each point a label from the user.'
        ],
        answerIndex: 0,
        explanation: 'Assignment and update alternate. The update step recomputes each centroid as the mean of its cluster.'
      },
      {
        question: 'Points 2 and 4 form one cluster with centroid 3. What is their contribution to $J$?',
        options: ['1', '2', '4', '0'],
        answerIndex: 1,
        explanation: 'Each point is 1 away, so $1^2 + 1^2 = 2$.'
      }
    ],
    related: ['types-of-ml', 'k-means-clustering', 'datasets-features-labels'],
    keywords: ['clustering', 'k-means', 'dimensionality reduction', 'anomaly detection', 'unlabelled data']
  },
  {
    id: 'reinforcement-learning',
    title: 'Reinforcement learning',
    category: 'foundations',
    summary: 'Reinforcement learning trains an agent to choose actions in an environment by trial and error, using reward signals to improve its decisions over time.',
    readingMinutes: 6,
    intro:
      'Some problems are not about predicting an answer but about making a sequence of decisions, where each choice changes what happens next. Driving, playing a game and managing inventory all fit. Reinforcement learning (RL) is the branch of machine learning built for these problems.\n\nAfter this lesson you will know the parts of an RL setup, understand the idea of discounted return, and be able to do one value update by hand.',
    simple:
      'Think of training a dog. You do not show the dog a labelled example of the perfect sit. The dog tries things, and a treat follows some of them. Over many tries the dog learns which actions in which situations lead to treats.\n\nIn RL the learner is the **agent**, the world it acts in is the **environment**, what it observes is the **state**, what it does is an **action**, and the treat is the **reward**. The agent is not told which action was right. It only sees the reward, which may arrive long after the action that caused it, so it has to work out which earlier choices deserve credit.\n\nThe agent also faces a trade-off. It can repeat what has worked (exploit) or try something new that might work better (explore).',
    technical:
      'The standard formalism is a Markov decision process: states $s$, actions $a$, transition probabilities, a reward function and a discount factor $\\gamma \\in [0,1)$. A policy $\\pi(a\\mid s)$ gives the probability of each action in each state. The return is the discounted sum of future rewards, and the goal is a policy that maximises its expected value.\n\nValue-based methods estimate the action-value function $Q(s,a)$, the expected return after taking $a$ in $s$ and following the policy afterwards. Q-learning updates this estimate toward a bootstrapped target built from the observed reward and the best estimated value of the next state. Policy-gradient methods instead adjust the policy parameters directly. Deep reinforcement learning uses neural networks to approximate $Q$ or $\\pi$ in large state spaces.\n\nDifficulties include sparse or delayed rewards, high sample requirements, instability during training, and reward misspecification, where the agent finds a way to score highly without doing what the designer meant. Exploration in the real world can also be unsafe, so many applications train in simulation.',
    math: [
      {
        label: 'Discounted return',
        tex: String.raw`G_t \;=\; \sum_{k=0}^{\infty} \gamma^{k}\, r_{t+k+1}`,
        note: 'Future rewards $r$ are weighted by powers of the discount $\\gamma$, so near-term rewards count more than distant ones.'
      },
      {
        label: 'Q-learning update',
        tex: String.raw`Q(s,a) \;\leftarrow\; Q(s,a) + \alpha\Big[\, r + \gamma \max_{a\prime} Q(s\prime, a\prime) - Q(s,a) \Big]`,
        note: 'The learning rate $\\alpha$ controls the step size. The bracket is the gap between the target and the current estimate.'
      }
    ],
    example: {
      title: 'Return and one Q-learning update',
      body:
        'Return: with $\\gamma = 0.9$ an agent receives rewards 1, 0, 2 on consecutive steps. The discounted return is $1 + 0.9 \\times 0 + 0.9^2 \\times 2 = 1 + 0 + 1.62 = 2.62$.\n\nUpdate: suppose $Q(s,a) = 0.5$, the agent receives $r = 1$, and the best value in the next state is 2. With $\\alpha = 0.1$ and $\\gamma = 0.9$ the target is $1 + 0.9 \\times 2 = 2.8$. The gap is $2.8 - 0.5 = 2.3$. The new estimate is $0.5 + 0.1 \\times 2.3 = 0.73$.'
    },
    pros: [
      'Handles sequential decisions where actions affect future situations.',
      'Needs only a reward signal, not a correct action for every state.',
      'Can discover strategies that were not designed in advance.',
      'Works well in simulated settings where trials are cheap.'
    ],
    cons: [
      'Often needs a very large number of interactions to learn.',
      'Results depend heavily on how the reward is designed.',
      'Training can be unstable and hard to reproduce.',
      'Trial and error is unsafe or costly in many real settings.'
    ],
    applications: [
      'Game-playing agents.',
      'Control of robots and other machines, usually first trained in simulation.',
      'Adjusting recommendations or ad choices over many rounds.',
      'Scheduling and resource allocation, such as cooling control in a data centre.'
    ],
    quiz: [
      {
        question: 'What feedback does a reinforcement learning agent receive?',
        options: [
          'The correct action for every state.',
          'A reward signal that evaluates what happened.',
          'A list of clusters.',
          'Nothing; it learns without feedback.'
        ],
        answerIndex: 1,
        explanation: 'The agent gets rewards, not correct actions. That is the difference from supervised learning.'
      },
      {
        question: 'With $\\gamma = 0.5$ and rewards 4, 4, 4, what is the discounted return?',
        options: ['12', '7', '8', '6'],
        answerIndex: 1,
        explanation: '$4 + 0.5\\times 4 + 0.25 \\times 4 = 4 + 2 + 1 = 7$.'
      },
      {
        question: 'What does the exploration versus exploitation trade-off describe?',
        options: [
          'Choosing between training and testing data.',
          'Choosing between trying new actions and repeating actions that have worked.',
          'Choosing between regression and classification.',
          'Choosing between CPU and GPU.'
        ],
        answerIndex: 1,
        explanation: 'Too little exploration can miss better options, and too much wastes effort on poor ones.'
      }
    ],
    related: ['types-of-ml', 'supervised-learning', 'generalization'],
    keywords: ['agent', 'environment', 'reward', 'policy', 'Q-learning', 'exploration']
  },
  {
    id: 'datasets-features-labels',
    title: 'Datasets, features, labels and targets',
    category: 'foundations',
    summary: 'A dataset is a table in which each row is an example, the columns that describe it are features, and the column to be predicted is the label or target.',
    readingMinutes: 5,
    intro:
      'Every machine learning project starts with data, and the vocabulary around it appears in every tool and paper. Confusion about what a feature is, or which column is the target, causes real mistakes, including leaking the answer into the inputs.\n\nAfter this lesson you will be able to describe a dataset as a matrix, tell features from labels, and explain why some features must be encoded or rescaled.',
    simple:
      'Think of a spreadsheet of homes for sale. Each **row** is one home. Most columns describe the home: floor area, number of bedrooms, neighbourhood. Those descriptive columns are the **features**, the things the model is allowed to look at. One more column holds the sale price, which is what we want to predict. That is the **label**, also called the **target**.\n\nA new home arrives with its features filled in and the price missing. The model reads the features and fills in a guess for the price.\n\nModels work with numbers, so a column such as neighbourhood must be turned into numbers first. And a column such as floor area may need rescaling so that it does not overwhelm a column like bedrooms simply because its numbers are bigger.',
    technical:
      'A dataset of $n$ examples with $d$ features is usually written as a design matrix $X \\in \\mathbb{R}^{n\\times d}$, with a target vector $y \\in \\mathbb{R}^{n}$ (or class indices). Row $x_i$ is the feature vector of example $i$. In unsupervised learning there is only $X$.\n\nFeature types need different handling. Numeric features may be standardised to zero mean and unit variance, which matters for distance-based and gradient-based methods. Categorical features are encoded, commonly with one-hot encoding, which creates one binary column per category. Missing values need an explicit policy such as imputation, with an indicator that the value was missing.\n\nTwo pitfalls recur. Target leakage occurs when a feature contains information that would not be available at prediction time, such as a field recorded after the outcome. It inflates evaluation scores and fails in use. Preprocessing statistics, such as the mean used for standardising, must be computed on training data only and then applied to the other sets. Finally, examples should be representative and, where they are related (several records from one person), kept together when splitting.',
    math: [
      {
        label: 'Design matrix and target',
        tex: String.raw`X \in \mathbb{R}^{n \times d}, \qquad y \in \mathbb{R}^{n}`,
        note: '$n$ is the number of examples (rows) and $d$ the number of features (columns). Entry $y_i$ is the label of row $x_i$.'
      },
      {
        label: 'Standardisation',
        tex: String.raw`z \;=\; \frac{x - \mu}{\sigma}`,
        note: 'Subtract the feature mean $\\mu$ and divide by its standard deviation $\\sigma$, both computed on the training set.'
      }
    ],
    example: {
      title: 'Shape of a small housing dataset',
      body:
        'Four homes have features area, bedrooms and neighbourhood (A, B or C), and a target price.\n\nOne-hot encoding turns neighbourhood into 3 binary columns. With area and bedrooms that gives $d = 2 + 3 = 5$ feature columns, so $X$ is $4 \\times 5$ and $y$ has length 4.\n\nStandardising area: the values 50, 80, 100, 70 have mean $300/4 = 75$. Deviations are -25, 5, 25, -5, with squares 625, 25, 625, 25, which sum to 1300. The variance is $1300/4 = 325$ and the standard deviation is about 18.03. The standardised values are about -1.39, 0.28, 1.39 and -0.28.'
    },
    pros: [
      'The table view gives a common structure for nearly all methods.',
      'Good features can matter more than the choice of algorithm.',
      'Encoding and scaling are simple steps that often improve results.',
      'Clear definitions make it easier to spot leakage and mislabeled columns.'
    ],
    cons: [
      'Building and cleaning a dataset is often the most time-consuming part of a project.',
      'Labels may be noisy, subjective or biased.',
      'Leakage can make a model look excellent while it is useless in practice.',
      'One-hot encoding of categories with many values creates very wide tables.'
    ],
    applications: [
      'Housing price models built from property attributes.',
      'Customer records with account features and a churn label.',
      'Tabular clinical measurements prepared for risk models used as decision support.',
      'Sensor logs turned into feature tables for fault prediction.'
    ],
    quiz: [
      {
        question: 'In a table of loan applications, which column is most likely the label?',
        options: ['Applicant income', 'Loan amount requested', 'Whether the loan was repaid', 'Applicant age'],
        answerIndex: 2,
        explanation: 'Repayment is the outcome we want to predict. The other columns describe the application.'
      },
      {
        question: 'A dataset has 200 rows and 6 numeric features. What is the shape of $X$?',
        options: ['6 x 200', '200 x 6', '200 x 1', '1200 x 1'],
        answerIndex: 1,
        explanation: 'Rows are examples and columns are features, so $X$ is $n \\times d = 200 \\times 6$.'
      },
      {
        question: 'Which is an example of target leakage?',
        options: [
          'Using floor area to predict price.',
          'Using a field filled in after the sale to predict the sale price.',
          'Standardising features.',
          'Dropping rows with missing values.'
        ],
        answerIndex: 1,
        explanation: 'A field recorded after the outcome is not available at prediction time, so it gives away the answer.'
      },
      {
        question: 'A colour column has 4 categories. How many columns does one-hot encoding create?',
        options: ['1', '3', '4', '16'],
        answerIndex: 2,
        explanation: 'One-hot encoding makes one binary column per category.'
      }
    ],
    related: ['supervised-learning', 'train-validation-test', 'generalization'],
    keywords: ['features', 'labels', 'target', 'design matrix', 'one-hot encoding', 'standardisation', 'leakage']
  },
  {
    id: 'train-validation-test',
    title: 'Training, validation and testing',
    category: 'foundations',
    summary: 'Data is split into a training set to fit the model, a validation set to choose settings, and a test set used once to estimate performance on new data.',
    readingMinutes: 5,
    intro:
      'A model that is graded on the examples it studied will almost always look good. To learn how it will behave on new cases, we must hold some data back. The way we hold data back is one of the most important habits in machine learning.\n\nAfter this lesson you will know what each of the three sets is for, why the test set must be used sparingly, and how cross-validation uses data more efficiently.',
    simple:
      'Consider a student preparing for an exam. The textbook exercises are the **training set**: they study from them. A mock exam taken along the way is the **validation set**: it shows which study method works and what to change. The real exam is the **test set**: a single, final check on questions the student has never seen.\n\nIf the student saw the real exam questions beforehand, the grade would say nothing about their ability. In the same way, if we tune a model by repeatedly looking at the test set, the test score stops being an honest estimate, because we have quietly adapted the model to it.\n\nSo the rule is simple: train on one part, tune on another, and look at the last part once at the end.',
    technical:
      'The training set is used to fit parameters. The validation set is used to select hyperparameters (such as tree depth or regularisation strength) and to compare model families. The test set provides an approximately unbiased estimate of generalisation error, valid only if it played no part in any decision. Each time a choice is made based on test performance, the estimate becomes optimistic.\n\nCommon splits are 60/20/20 to 80/10/10, depending on dataset size. Splits should be random for independent examples, stratified to preserve class proportions when classes are imbalanced, grouped when several rows come from the same entity, and chronological for time series so that the model is never trained on the future.\n\nWhen data are scarce, $k$-fold cross-validation divides the data into $k$ parts, trains on $k-1$ and validates on the remaining one, rotating through all choices. The mean of the $k$ scores estimates performance and their spread indicates variability. A final model is then refit on all non-test data. Preprocessing such as scaling must be fitted inside each training fold to avoid leakage.',
    math: [
      {
        label: 'Cross-validation estimate',
        tex: String.raw`\text{CV}_k \;=\; \frac{1}{k}\sum_{j=1}^{k} \text{score}_j`,
        note: 'The model is trained $k$ times, each time scoring on the fold $j$ that was held out. The average is the estimate.'
      },
      {
        label: 'Generalisation gap',
        tex: String.raw`\text{gap} \;=\; \text{error}_{\text{test}} - \text{error}_{\text{train}}`,
        note: 'A large positive gap suggests the model fits the training data better than it fits new data.'
      }
    ],
    example: {
      title: 'A 70/15/15 split and model choice',
      body:
        'From 1000 rows, a 70/15/15 split gives 700 training, 150 validation and 150 test rows.\n\nThree candidate models are trained on the 700 rows. On the validation set they get 123, 129 and 126 correct out of 150, which is 82%, 86% and 84%. The second model is chosen.\n\nOnly now is the test set used. The chosen model gets 126 of 150 correct, an accuracy of 84%. This is slightly lower than its validation score of 86%, which is normal: the model was selected for scoring well on validation, so that figure was a little optimistic.\n\nFor 5-fold cross-validation on the same 1000 rows, each fold holds out 200 rows and trains on 800.'
    },
    pros: [
      'Gives an honest estimate of how the model will perform on new data.',
      'Separates model fitting from model selection.',
      'Cross-validation makes good use of small datasets.',
      'Helps detect overfitting early.'
    ],
    cons: [
      'Splitting reduces the amount of data available for training.',
      'A small test set gives a noisy estimate.',
      'Easy to leak information through preprocessing or repeated test-set use.',
      'Cross-validation multiplies training time by roughly $k$.'
    ],
    applications: [
      'Choosing the regularisation strength of a regression model.',
      'Comparing a tree ensemble with a linear model on the same data.',
      'Reporting final performance of a risk model before it is used as decision support.',
      'Time-ordered splits for demand forecasting.'
    ],
    quiz: [
      {
        question: 'What is the validation set mainly used for?',
        options: ['Fitting the parameters', 'Choosing hyperparameters and comparing models', 'Reporting final performance after every change', 'Replacing the training set'],
        answerIndex: 1,
        explanation: 'Validation guides choices. The test set is reserved for the final estimate.'
      },
      {
        question: 'Why should the test set be used only once at the end?',
        options: [
          'It is too large to use more than once.',
          'Repeated use to make decisions makes its score optimistic.',
          'Models cannot be evaluated twice.',
          'It contains the labels of the training set.'
        ],
        answerIndex: 1,
        explanation: 'Each decision based on the test score tailors the model to that set, so the final number no longer reflects unseen data.'
      },
      {
        question: 'In 10-fold cross-validation on 500 rows, how many rows are in each validation fold?',
        options: ['10', '50', '450', '100'],
        answerIndex: 1,
        explanation: '$500 / 10 = 50$ rows per fold, with 450 used for training in each round.'
      },
      {
        question: 'For daily sales data, which split is most appropriate?',
        options: ['Random shuffle', 'Train on earlier dates, test on later dates', 'Train on later dates, test on earlier dates', 'Use the same rows for both'],
        answerIndex: 1,
        explanation: 'Time series should respect order so that the model is never trained on information from the future.'
      }
    ],
    related: ['generalization', 'datasets-features-labels', 'training-and-prediction'],
    keywords: ['train test split', 'validation set', 'test set', 'cross-validation', 'hyperparameters', 'leakage']
  },
  {
    id: 'training-and-prediction',
    title: 'Model training and prediction',
    category: 'foundations',
    summary: 'Training adjusts a model\'s parameters to reduce a loss on training data; prediction then applies the fixed, trained model to new inputs.',
    readingMinutes: 6,
    intro:
      'Machine learning has two phases that are easy to blur together. In training the model is adjusted using known examples. In prediction, sometimes called inference, the finished model is applied to new inputs and nothing is adjusted.\n\nAfter this lesson you will understand the training loop, the role of the loss and the learning rate, and be able to carry out one gradient descent step by hand.',
    simple:
      'Imagine tuning a radio by turning a dial. You listen, decide whether the sound is clearer or worse, and turn the dial a little in the direction that helps. Repeat until the sound is as clear as you can get it. Then you stop turning and just listen.\n\nTraining is the turning. The dial is a parameter, the "how clear is it" is the loss, and the size of each turn is the learning rate. Turn too far and you overshoot the best spot. Turn too little and it takes forever.\n\nPrediction is the listening. The settings are frozen, a new input goes in, and an output comes out. It is much quicker than training because no searching is needed.',
    technical:
      'Training solves $\\min_\\theta \\; \\frac{1}{n}\\sum_i L(f_\\theta(x_i), y_i)$. For differentiable models the standard tool is gradient descent: compute the gradient of the loss with respect to the parameters and move against it. In practice, stochastic or mini-batch gradient descent estimates the gradient from a small random subset of examples at each step, which is cheaper and often generalises well. One pass over the data is an epoch. Some models, such as ordinary least squares, have a closed-form solution, and trees are built by greedy splitting instead.\n\nThe learning rate $\\eta$ is a hyperparameter. If it is too large the loss can oscillate or diverge, and if it is too small progress is slow. Training is typically stopped when the validation loss stops improving, which is a simple guard against overfitting. For non-convex models such as neural networks, gradient descent finds a local solution that depends on initialisation and data order.\n\nPrediction is a forward computation with fixed parameters $\\hat\\theta$. Its cost depends on model size, not on the size of the training set, with the notable exception of methods such as k-nearest neighbours that store the training data and consult it at prediction time. Inputs at prediction time must be preprocessed exactly as in training.',
    math: [
      {
        label: 'Gradient descent update',
        tex: String.raw`\theta \;\leftarrow\; \theta - \eta\, \nabla_{\theta} J(\theta)`,
        note: '$J$ is the loss, $\\nabla_\\theta J$ its gradient and $\\eta$ the learning rate. Each step moves the parameters in the direction that lowers the loss fastest locally.'
      },
      {
        label: 'Gradient for a one-weight linear model',
        tex: String.raw`\frac{\partial J}{\partial w} \;=\; \frac{2}{n}\sum_{i=1}^{n} x_i\,(w x_i - y_i)`,
        note: 'For the model $\\hat y = wx$ with mean squared error $J$. Residuals are weighted by the inputs.'
      }
    ],
    example: {
      title: 'One gradient descent step',
      body:
        'Model $\\hat y = wx$ with data $(1,2)$, $(2,4)$, $(3,6)$. Start at $w = 0$, with $\\eta = 0.05$.\n\nResiduals $wx - y$ are -2, -4, -6. Multiplying by $x$ gives -2, -8, -18, which sum to -28. The gradient is $\\frac{2}{3}\\times(-28) = -18.67$. The starting loss is $(4+16+36)/3 = 18.67$.\n\nUpdate: $w = 0 - 0.05 \\times (-18.67) = 0.933$. The new residuals are -1.067, -2.133, -3.2, with squares 1.138, 4.551, 10.24. The new loss is $15.929/3 = 5.31$, a large drop.\n\nPrediction with the current model for $x = 4$ is $0.933 \\times 4 = 3.73$. More steps move $w$ toward 2, where the loss is zero.'
    },
    pros: [
      'Gradient-based training is a general recipe that works for many model types.',
      'Mini-batch updates scale to very large datasets.',
      'Prediction is usually fast, so trained models can be used in real time.',
      'Monitoring the loss gives a visible signal of progress.'
    ],
    cons: [
      'Results depend on the learning rate and other hyperparameters that need tuning.',
      'Non-convex problems can end in poor local solutions.',
      'Training large models can take substantial time and computing power.',
      'A model whose preprocessing at prediction time differs from training will give wrong outputs.'
    ],
    applications: [
      'Fitting a regression model to forecast demand, then serving forecasts daily.',
      'Training an image classifier offline and running it on a phone.',
      'Retraining a fraud model periodically on new transactions.',
      'Scoring incoming records with a trained risk model as decision support for staff.'
    ],
    quiz: [
      {
        question: 'During prediction, what happens to the model parameters?',
        options: ['They are updated after every input.', 'They stay fixed.', 'They are reset to zero.', 'They are replaced by the labels.'],
        answerIndex: 1,
        explanation: 'Prediction applies the trained model as it is. Updating parameters is part of training.'
      },
      {
        question: 'What is a likely effect of a learning rate that is far too large?',
        options: ['Training is guaranteed to be faster and better.', 'The loss may oscillate or diverge.', 'The model needs no data.', 'Overfitting becomes impossible.'],
        answerIndex: 1,
        explanation: 'Large steps can overshoot the minimum repeatedly, so the loss may bounce or grow.'
      },
      {
        question: 'With $w = 1$, gradient $= -4$ and $\\eta = 0.1$, what is the new $w$?',
        options: ['0.6', '1.4', '0.9', '5'],
        answerIndex: 1,
        explanation: '$w \\leftarrow 1 - 0.1\\times(-4) = 1.4$.'
      }
    ],
    related: ['supervised-learning', 'train-validation-test', 'generalization', 'linear-regression'],
    keywords: ['gradient descent', 'learning rate', 'loss', 'epoch', 'inference', 'parameters']
  },
  {
    id: 'generalization',
    title: 'Generalization',
    category: 'foundations',
    summary: 'Generalization is a model\'s ability to perform well on new data it has not seen, which depends on balancing flexibility against the risk of memorising noise.',
    readingMinutes: 6,
    intro:
      'The purpose of a model is to work on tomorrow\'s data, not to repeat yesterday\'s. Generalization is the name for that ability, and almost every practical decision in machine learning, from model size to regularisation, is about getting it.\n\nAfter this lesson you will be able to describe underfitting and overfitting, explain the bias-variance trade-off, and read a gap between training and test error.',
    simple:
      'Two students prepare for a maths exam. One memorises the exact worked solutions in the textbook. The other learns the methods behind them. On questions from the textbook, both score well. On new questions, the first student struggles, while the second does fine. The first has **overfit**: they learned the specifics, including accidents, rather than the pattern.\n\nA third student who only read the chapter titles knows too little to solve anything. That is **underfitting**: the model is too simple to capture the pattern, so it does poorly everywhere.\n\nGood generalization sits between the two. The model is flexible enough to capture the real pattern and constrained enough to ignore the noise.',
    technical:
      'Generalization error is the expected loss on new data from the same distribution. Training error tends to fall as model capacity grows, while test error typically falls and then rises, forming a U shape. Underfitting (high bias) occurs when the model class cannot represent the true relationship. Overfitting (high variance) occurs when the model fits fluctuations specific to the training sample, so a different sample would have produced a very different model.\n\nFor squared error, expected prediction error at a point decomposes into squared bias, variance and irreducible noise. Reducing bias by increasing complexity tends to increase variance, and the best capacity balances the two. More training data lowers variance and so reduces overfitting. Regularisation, early stopping, simpler models, data augmentation and ensembling are standard remedies. Learning curves, which plot training and validation error against training set size, help diagnose which problem is present: a large persistent gap suggests variance, while both errors being high suggests bias.\n\nGeneralization also fails under distribution shift, where new data differ systematically from training data. A low held-out error then does not transfer to the deployed setting.',
    math: [
      {
        label: 'Bias-variance decomposition (squared error)',
        tex: String.raw`\mathbb{E}\big[(y - \hat f(x))^2\big] \;=\; \text{Bias}^2 + \text{Variance} + \sigma^2`,
        note: 'Bias is the systematic error of the average model, variance is how much the fitted model changes between training samples, and $\\sigma^2$ is noise that no model can remove.'
      },
      {
        label: 'Generalisation gap',
        tex: String.raw`\text{gap} \;=\; \text{error}_{\text{test}} - \text{error}_{\text{train}}`,
        note: 'A large gap with low training error is the typical signature of overfitting.'
      }
    ],
    example: {
      title: 'Two models and the decomposition',
      body:
        'Suppose the noise level is $\\sigma^2 = 0.2$.\n\nA simple model has $\\text{Bias}^2 = 0.5$ and variance $0.3$. Expected error is $0.5 + 0.3 + 0.2 = 1.0$.\n\nA very flexible model has $\\text{Bias}^2 = 0.1$ and variance $0.9$. Expected error is $0.1 + 0.9 + 0.2 = 1.2$.\n\nThe flexible model has less bias but more total error. Now suppose its training error is 0.05 and test error is 1.2. The gap is $1.2 - 0.05 = 1.15$, which signals overfitting. These numbers are chosen for illustration, not measured from a real dataset.'
    },
    pros: [
      'Gives a clear target: performance on new data, not on training data.',
      'The bias-variance view explains why more complex is not always better.',
      'Remedies such as regularisation and more data are well understood.',
      'Learning curves offer a practical way to diagnose problems.'
    ],
    cons: [
      'True generalization error can only be estimated, never observed exactly.',
      'Held-out estimates are unreliable if the deployed data shift.',
      'Flexible models need care, and there is rarely a universal best setting.',
      'More data helps variance but cannot fix a model that is too simple.'
    ],
    applications: [
      'Choosing the depth of a decision tree using validation error.',
      'Setting regularisation strength in a regression model.',
      'Deciding whether collecting more data is worth the cost, using learning curves.',
      'Checking that a risk model used as decision support still performs on a new hospital population before relying on it.'
    ],
    quiz: [
      {
        question: 'Training error is very low and test error is much higher. What is the most likely issue?',
        options: ['Underfitting', 'Overfitting', 'Too much test data', 'Irreducible noise only'],
        answerIndex: 1,
        explanation: 'A large gap with a low training error suggests the model fit quirks of the training sample.'
      },
      {
        question: 'Both training and test error are high and close together. What does this suggest?',
        options: ['High variance', 'Perfect generalization', 'High bias, so the model is too simple', 'Data leakage'],
        answerIndex: 2,
        explanation: 'The model fails to capture the pattern even on data it has seen, which is underfitting.'
      },
      {
        question: 'Bias squared is 0.4, variance is 0.25 and noise is 0.1. What is the expected squared error?',
        options: ['0.65', '0.75', '0.5', '0.9'],
        answerIndex: 1,
        explanation: '$0.4 + 0.25 + 0.1 = 0.75$. The option 0.65 leaves out the noise.'
      },
      {
        question: 'Which step generally helps reduce overfitting?',
        options: ['Training for much longer on the same data without checks', 'Adding regularisation or collecting more data', 'Evaluating on the training set only', 'Removing the validation set'],
        answerIndex: 1,
        explanation: 'Regularisation constrains the model and more data lowers variance. The other options hide or worsen the problem.'
      }
    ],
    related: ['train-validation-test', 'training-and-prediction', 'what-is-ml'],
    keywords: ['overfitting', 'underfitting', 'bias-variance', 'regularisation', 'generalisation gap', 'learning curve']
  }
];
