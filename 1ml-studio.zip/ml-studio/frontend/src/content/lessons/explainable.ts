import type { Lesson } from '../types';

/*
 * Explainable machine learning lessons. All numbers in the worked examples are small constructed
 * illustrations, not results from real studies. The Shapley example uses the value function
 * v(empty)=10, v(A)=14, v(B)=12, v(C)=11, v(AB)=18, v(AC)=15, v(BC)=13, v(ABC)=20.
 */
export const explainableLessons: Lesson[] = [
  {
    id: 'model-interpretability',
    title: 'Model interpretability',
    category: 'explainable',
    summary: 'Interpretability is about understanding why a model makes its predictions, either by using a readable model or by explaining a complex one afterwards.',
    readingMinutes: 6,
    intro:
      'A model that scores well is not automatically a model you can rely on. People who use or review its output often need to know which inputs drove a prediction, whether the reasoning is sensible, and where it is likely to fail. Without that, errors are hard to spot and hard to correct.\n\nInterpretability is the broad name for answering those questions. After this lesson you will know the difference between models that are readable by design and explanations added after training, what an explanation can legitimately claim, and why an explanation of a model is not an explanation of the world.',
    simple:
      'Imagine two advisers. One hands you a short checklist: add 3 points for this, subtract 2 for that, and recommend when the total passes 10. The other gives a recommendation from a vast private calculation and cannot say how. You can check the first adviser line by line. The second may be more accurate, but you have to trust it or test it from the outside.\n\nInterpretable models are like the checklist, for example a small decision tree or a linear model. Complex models such as boosted trees and neural networks are like the second adviser, so we use extra tools to ask what the answer depended on. Those tools tell you what the model used. They do not tell you what causes the outcome in the real world.',
    technical:
      'Two routes are usually distinguished. **Intrinsic interpretability** restricts the model class so its structure can be read: sparse linear models, short rule lists, shallow trees, additive models. **Post-hoc explanation** keeps the flexible model and analyses its behaviour with a separate method, such as permutation importance, partial dependence, local surrogate models or Shapley values. Explanations can be **global** (how the model behaves across the data) or **local** (why this one prediction).\n\nAn explanation has to be judged on **fidelity** (does it describe what the model really does), **stability** (do small input changes leave it roughly unchanged) and **usefulness** to the reader. An accurate model with a faithful explanation can still rest on a spurious pattern in the training data, and the explanation will then faithfully report that pattern. Correlated features make attributions ambiguous, because credit can be split between them in several defensible ways. Above all, a feature being important to the model is a statement about the fitted function, not a causal claim: changing that feature in the real world need not change the outcome.',
    math: [
      {
        label: 'A linear model as an intrinsic explanation',
        tex: String.raw`\hat y = b_0 + \sum_{j=1}^{p} w_j x_j`,
        note: 'Each term $w_j x_j$ is that feature\'s contribution to this prediction, so the model can be read directly. The reading holds only within the fitted model.'
      }
    ],
    example: {
      title: 'Reading a linear rent model',
      body:
        'A fitted model predicts monthly rent as $200 + 150 \\times \\text{bedrooms} + 2 \\times \\text{area} - 30 \\times \\text{km to centre}$. For a flat with 2 bedrooms, 60 square metres and 4 km from the centre, the terms are 300, 120 and -120.\n\nThe prediction is $200 + 300 + 120 - 120 = 500$. You can say which inputs pushed the figure up (bedrooms, area) and which pulled it down (distance). You cannot conclude that adding a bedroom to this flat would raise its rent by 150. The coefficient describes the pattern across the training flats, where bigger flats tend to have more bedrooms and cost more.'
    },
    pros: [
      'Lets reviewers check that predictions rest on sensible inputs.',
      'Helps find data problems, such as an identifier that leaks the label.',
      'Supports debugging: wrong predictions can be traced to the inputs behind them.',
      'Readable models are easier to document and audit.'
    ],
    cons: [
      'Readable models can be less accurate than flexible ones on complex data.',
      'Post-hoc explanations are approximations and can be unstable.',
      'Explanations are easy to over-read as causal statements.',
      'Correlated features make the split of credit ambiguous.'
    ],
    applications: [
      'Model review before deployment.',
      'Detecting leakage and shortcut features.',
      'Explaining a prediction to a person affected by it.',
      'Regulated settings where decisions must be documented.'
    ],
    quiz: [
      {
        question: 'Which is an example of an intrinsically interpretable model?',
        options: ['A large neural network', 'A small linear model with few features', 'A boosted ensemble of 500 trees', 'Any model plus a chart'],
        answerIndex: 1,
        explanation: 'Its structure can be read directly. The other options need post-hoc tools to understand.'
      },
      {
        question: 'A feature has a large coefficient in a fitted model. What can you conclude?',
        options: [
          'Changing that feature in the real world will change the outcome.',
          'The model relies on it, within the patterns of the training data.',
          'The feature causes the outcome.',
          'The model is accurate.'
        ],
        answerIndex: 1,
        explanation: 'Coefficients describe the fitted function. Causal conclusions need a different design, such as an experiment or explicit causal assumptions.'
      },
      {
        question: 'What does fidelity mean for an explanation?',
        options: ['It is short.', 'It describes what the model actually does.', 'It uses plain language.', 'It matches the data labels.'],
        answerIndex: 1,
        explanation: 'A faithful explanation reflects the model, even if the model itself is wrong.'
      },
      {
        question: 'Why can an explanation reveal a model that is accurate but unreliable?',
        options: [
          'It shows the model uses a spurious feature.',
          'It increases accuracy.',
          'It removes noise from labels.',
          'It makes the model slower.'
        ],
        answerIndex: 0,
        explanation: 'High accuracy on a test set drawn from the same source can hide reliance on a shortcut, which an explanation can expose.'
      }
    ],
    related: ['feature-importance', 'shap', 'linear-regression'],
    keywords: ['interpretability', 'explainability', 'post-hoc', 'intrinsic', 'fidelity', 'causation']
  },
  {
    id: 'feature-importance',
    title: 'Feature importance',
    category: 'explainable',
    summary: 'Feature importance scores rank inputs by how much a model relies on them, but impurity, permutation and SHAP importance measure different things.',
    readingMinutes: 7,
    intro:
      'After fitting a model, one of the first questions is which inputs matter. Several methods give a ranking, and they often disagree. That is not a bug: each one measures something different, and choosing the wrong one can mislead.\n\nThis lesson compares three common measures: impurity importance for tree models, permutation importance, and SHAP-based importance. You will learn what each measures, when it misleads, and why none of them is a statement about causes.',
    simple:
      'Suppose a team wins matches and you want to know who matters. One way is to count how often each player is involved in goals, which is cheap but biased towards players who take many shots. Another way is to bench each player in turn and see how much the results get worse. That is closer to a fair test of reliance on that player.\n\nImpurity importance is the counting approach, built into trees during training. Permutation importance is the bench test: scramble one column and watch the score drop. SHAP importance averages how much each feature moves individual predictions. All three describe what the model uses, not what causes the outcome.',
    technical:
      '**Impurity importance** (mean decrease in impurity) sums, over every split on a feature in every tree, the weighted reduction in Gini impurity or variance. It is computed on training data, so it reflects fitting as well as signal, and it favours features with many distinct values or many possible split points, which a tree can use to fit noise.\n\n**Permutation importance** is model-agnostic. Score the fitted model on held-out data, shuffle one feature column to break its link with the target, score again, and take the drop. Repeating the shuffle gives a spread. It measures reliance on the feature for predictive accuracy, uses held-out data if you choose, and depends on the metric. With strongly correlated features it can understate importance, because the model can fall back on the correlated partner, and shuffled rows may be unrealistic combinations.\n\n**SHAP importance** is the mean absolute Shapley value of a feature across rows. It measures how far the feature moves predictions on average, not how much accuracy depends on it. A feature can have large SHAP importance yet produce little accuracy loss if the other features are redundant. The three rankings answer different questions, so compare them rather than expecting agreement.',
    math: [
      {
        label: 'Gini impurity',
        tex: String.raw`G = 1 - \sum_{k} p_k^2`,
        note: '$p_k$ is the share of class $k$ in a node. Impurity importance adds up the weighted decrease in $G$ caused by splits on a feature.'
      },
      {
        label: 'Permutation importance',
        tex: String.raw`I_j = s - s_{\pi(j)}`,
        note: '$s$ is the model score on held-out data and $s_{\\pi(j)}$ is the score after shuffling feature $j$. A large positive $I_j$ means the model relies on it.'
      }
    ],
    example: {
      title: 'A split and a shuffle with real numbers',
      body:
        'Impurity: a node holds 10 positives and 10 negatives, so $G = 1 - 0.5^2 - 0.5^2 = 0.5$. A split sends 9 positives and 1 negative left, and 1 positive and 9 negatives right. Each child has $G = 1 - 0.9^2 - 0.1^2 = 0.18$. The weighted child impurity is $0.18$, so the decrease is $0.5 - 0.18 = 0.32$.\n\nPermutation: on 200 held-out rows the model gets 180 right, accuracy 0.90. Shuffling feature A leaves 150 right (0.75), a drop of 0.15. Shuffling B leaves 174 right (0.87), a drop of 0.03. Shuffling C leaves 180 right, a drop of 0. The model leans heavily on A, a little on B and not at all on C. This says nothing about whether A causes the outcome.'
    },
    pros: [
      'Impurity importance is free with tree ensembles and instant to compute.',
      'Permutation importance works with any model and any metric.',
      'Permutation on held-out data reflects reliance that generalises.',
      'SHAP importance is consistent with per-prediction explanations.'
    ],
    cons: [
      'Impurity importance is computed on training data and favours high-cardinality features.',
      'Permutation importance can mislead when features are strongly correlated.',
      'Rankings from different methods can disagree.',
      'None of them establishes causation.'
    ],
    applications: [
      'Screening features before simplifying a model.',
      'Spotting a leaking or suspicious input.',
      'Reporting which inputs a model depends on.',
      'Sanity checks after retraining on new data.'
    ],
    quiz: [
      {
        question: 'Which importance measure is computed from the training process of a tree ensemble?',
        options: ['Impurity importance', 'Permutation importance on a test set', 'SHAP interaction values', 'Partial dependence'],
        answerIndex: 0,
        explanation: 'Impurity importance sums split gains during training. Permutation importance can be computed afterwards on any data.'
      },
      {
        question: 'Shuffling feature C leaves accuracy unchanged. What is the best reading?',
        options: [
          'C is causally irrelevant.',
          'The model does not rely on C for accuracy on this data.',
          'C has a negative effect.',
          'The test set is too large.'
        ],
        answerIndex: 1,
        explanation: 'It says only that this model does not need C here. A correlated feature might be carrying the same information.'
      },
      {
        question: 'Why can SHAP importance and permutation importance rank features differently?',
        options: [
          'One of them is wrong.',
          'SHAP measures average movement of predictions, permutation measures loss of score.',
          'SHAP ignores the model.',
          'Permutation uses the labels twice.'
        ],
        answerIndex: 1,
        explanation: 'They answer different questions, so different rankings are expected.'
      },
      {
        question: 'Why does impurity importance favour features with many distinct values?',
        options: [
          'They are always more predictive.',
          'They offer many split points, which a tree can use to fit noise.',
          'Trees cannot split binary features.',
          'They are scaled larger.'
        ],
        answerIndex: 1,
        explanation: 'More candidate splits give more chances of a spurious impurity decrease on training data.'
      }
    ],
    related: ['shap', 'global-explanations', 'random-forest', 'feature-selection'],
    keywords: ['feature importance', 'impurity', 'permutation importance', 'mean decrease in impurity', 'correlated features']
  },
  {
    id: 'shap',
    title: 'SHAP',
    category: 'explainable',
    summary: 'SHAP splits a prediction into one contribution per feature using Shapley values from game theory, so the contributions add up to the prediction.',
    readingMinutes: 7,
    intro:
      'SHAP (SHapley Additive exPlanations) answers a precise question: starting from the average prediction, how much of the gap to this particular prediction should be credited to each feature? It borrows the Shapley value from cooperative game theory, which divides a shared payoff fairly among players.\n\nAfter this lesson you will be able to write the Shapley formula, compute it by hand for three features, check the additivity property, and say what the numbers do and do not mean.',
    simple:
      'Three colleagues finish a project that earns a bonus, and you want to split it fairly. Each person joins the team at a different moment, so the extra value they add depends on who is already there. A fair method averages each person\'s added value over every possible order of arrival.\n\nSHAP treats features as the colleagues and the prediction as the bonus. A feature\'s SHAP value is its average added contribution across all orders in which features could be revealed to the model. Add the contributions to the average prediction and you get exactly this prediction. As always, the result describes the model, not the world.',
    technical:
      'Let $F$ be the set of features and $v(S)$ the expected model output when only the features in $S$ are known and the rest are averaged out over a background dataset. The Shapley value of feature $i$ is the weighted average of its marginal contribution $v(S \\cup \\{i\\}) - v(S)$ over all subsets $S$ not containing $i$. It is the only attribution satisfying efficiency, symmetry, dummy and linearity.\n\n**Efficiency** gives the additivity property: the base value $v(\\emptyset)$, which is the average prediction, plus the sum of contributions equals the prediction. Exact computation needs $2^{|F|}$ evaluations, so practical tools use model-specific algorithms (TreeSHAP is exact and fast for tree ensembles) or sampling approximations. For tree models contributions are often in log-odds units, not probability.\n\nCaveats: results depend on the background data and on how missing features are simulated. With correlated features, the interventional approach can evaluate unrealistic inputs. Interactions are shared between the features involved. Large SHAP values mean the model used the feature, and they are not evidence that the feature causes the outcome.',
    math: [
      {
        label: 'Shapley value',
        tex: String.raw`\phi_i = \sum_{S \subseteq F \setminus \{i\}} \frac{|S|!\,(|F|-|S|-1)!}{|F|!}\,\bigl[v(S\cup\{i\}) - v(S)\bigr]`,
        note: '$\\phi_i$ is the contribution of feature $i$, $F$ the set of all features, and $v(S)$ the model output with only the features in $S$ known.'
      },
      {
        label: 'Additivity (efficiency)',
        tex: String.raw`f(x) = \phi_0 + \sum_{i=1}^{|F|} \phi_i, \qquad \phi_0 = v(\emptyset)`,
        note: '$\\phi_0$ is the base value, the average prediction. The contributions fill the gap between it and the prediction $f(x)$.'
      }
    ],
    example: {
      title: 'Three features, computed by hand',
      body:
        'Take features A, B and C with outputs $v(\\emptyset)=10$, $v(A)=14$, $v(B)=12$, $v(C)=11$, $v(AB)=18$, $v(AC)=15$, $v(BC)=13$, $v(ABC)=20$.\n\nFor feature A the subsets of the other features are {}, {B}, {C}, {B,C} with weights 1/3, 1/6, 1/6, 1/3 and marginal gains 4, 6, 4, 7. So $\\phi_A = 4/3 + 6/6 + 4/6 + 7/3 = 5.33$. In the same way $\\phi_B = 3.33$ and $\\phi_C = 1.33$.\n\nCheck additivity: $10 + 5.33 + 3.33 + 1.33 = 20 = v(ABC)$. The prediction of 20 is 10 above the base value, and the three contributions split that gap of 10.'
    },
    pros: [
      'Contributions add up exactly to the prediction minus the base value.',
      'Rests on a clear set of fairness axioms.',
      'The same values support local and global views.',
      'TreeSHAP computes exact values quickly for tree ensembles.'
    ],
    cons: [
      'Exact computation grows exponentially with the number of features.',
      'Values depend on the choice of background data.',
      'Correlated features can produce unrealistic evaluations or shared credit.',
      'Easily misread as causal effects, which they are not.'
    ],
    applications: [
      'Explaining individual predictions of gradient boosted trees.',
      'Ranking features by mean absolute contribution.',
      'Checking a model for reliance on suspicious inputs.',
      'Comparing how a model treats different groups of cases.'
    ],
    quiz: [
      {
        question: 'What does additivity say about SHAP values?',
        options: [
          'Contributions are always positive.',
          'Base value plus the sum of contributions equals the prediction.',
          'Features are independent.',
          'The model is linear.'
        ],
        answerIndex: 1,
        explanation: 'This is the efficiency property of Shapley values.'
      },
      {
        question: 'In the example, which feature gets the largest share of the 10-point gap?',
        options: ['A', 'B', 'C', 'All equal'],
        answerIndex: 0,
        explanation: 'A has 5.33, B has 3.33 and C has 1.33, which sum to 10.'
      },
      {
        question: 'Why does exact Shapley computation become impractical?',
        options: [
          'It needs the labels.',
          'It needs about 2 to the power of the number of features evaluations.',
          'It needs a linear model.',
          'It cannot handle missing values.'
        ],
        answerIndex: 1,
        explanation: 'Every subset of features is a coalition to evaluate, which is why approximations and TreeSHAP exist.'
      },
      {
        question: 'A feature has a large SHAP value for a patient. What follows?',
        options: [
          'It causes the patient outcome.',
          'Intervening on it will change the outcome.',
          'The model used it heavily for this prediction.',
          'The feature is accurate.'
        ],
        answerIndex: 2,
        explanation: 'SHAP describes the model function, not the mechanism behind the data.'
      }
    ],
    related: ['feature-importance', 'local-explanations', 'global-explanations', 'model-interpretability'],
    keywords: ['SHAP', 'Shapley value', 'additivity', 'base value', 'TreeSHAP', 'attribution']
  },
  {
    id: 'global-explanations',
    title: 'Global explanations',
    category: 'explainable',
    summary: 'Global explanations describe how a model behaves across the whole dataset, such as which features matter most and how predictions change as a feature varies.',
    readingMinutes: 6,
    intro:
      'A global explanation summarises the overall behaviour of a model: which inputs it relies on, in which direction, and with what shape of relationship. It is the view you want when reviewing a model before use, or comparing it with domain knowledge.\n\nThis lesson covers common global tools, namely importance rankings, partial dependence plots and aggregated SHAP values, along with their limits. You will see why averaging can hide important structure.',
    simple:
      'Picture a map of a country showing the main roads. It tells you the general layout but not the best route for a particular trip. A global explanation is that map: it shows the main patterns in how the model turns inputs into outputs.\n\nThe risk of any summary is what it leaves out. If a feature raises predictions for some people and lowers them for others, a plain average can show nothing at all. Good global views show the spread as well as the average, and they still describe the model, not the real-world causes.',
    technical:
      'Common global tools are: **feature importance** (permutation, impurity or mean absolute SHAP); **partial dependence plots** (PDP), which average the prediction over the data while setting one feature to a grid of values; **individual conditional expectation** (ICE) curves, which show the same curve per row; and **SHAP summary plots**, which show every row\'s contribution for each feature. A **global surrogate** is a simple interpretable model fitted to the predictions of the complex one, with its fidelity measured by agreement on held-out data.\n\nPDPs assume the varied feature can be set independently of the others; with correlated features they average over unrealistic combinations. Averaging also hides heterogeneity, which ICE curves and SHAP scatter plots reveal. Mean absolute SHAP importance is the average magnitude of the contributions and loses direction, whereas the signed mean can cancel to zero. All global summaries are computed on a chosen dataset, so they change if that dataset does not match deployment.',
    math: [
      {
        label: 'Mean absolute SHAP importance',
        tex: String.raw`G_j = \frac{1}{n}\sum_{r=1}^{n} \bigl|\phi_j^{(r)}\bigr|`,
        note: '$\\phi_j^{(r)}$ is the SHAP value of feature $j$ for row $r$ and $n$ is the number of rows.'
      },
      {
        label: 'Partial dependence',
        tex: String.raw`\mathrm{PD}_j(z) = \frac{1}{n}\sum_{r=1}^{n} f\bigl(z,\, x_{-j}^{(r)}\bigr)`,
        note: 'The prediction is averaged over the data with feature $j$ forced to the value $z$ and the other features left as observed.'
      }
    ],
    example: {
      title: 'Why the average of signed values can mislead',
      body:
        'Four rows have SHAP values for three features. Feature A: +5, -3, +4, -2. Feature B: +1, +1, -2, 0. Feature C: +0.5, -0.5, +0.5, -0.5.\n\nMean absolute values are A: $(5+3+4+2)/4 = 3.5$, B: $(1+1+2+0)/4 = 1.0$, C: $0.5$. So the ranking is A, B, C. The signed means are A: $+1.0$, B: $0$, C: $0$. Feature B looks irrelevant on the signed mean even though it moves three of four predictions, and feature A moves predictions strongly in both directions. The absolute version shows size of use, the signed one a net direction, and the row-level spread shows that A behaves differently for different rows.'
    },
    pros: [
      'Gives a compact overview for model review.',
      'Can be compared with domain knowledge to find implausible behaviour.',
      'Row-level plots reveal heterogeneity that averages hide.',
      'Surrogate models give a readable approximation of the whole model.'
    ],
    cons: [
      'Averages can hide subgroups where behaviour differs.',
      'Partial dependence can use unrealistic feature combinations.',
      'Results depend on the dataset used to compute them.',
      'Summaries describe model use, not causes.'
    ],
    applications: [
      'Pre-deployment model review.',
      'Checking that monotone relationships match expectations.',
      'Comparing candidate models by what they rely on.',
      'Documenting a model for auditors.'
    ],
    quiz: [
      {
        question: 'Which global tool averages predictions while one feature is fixed to a grid of values?',
        options: ['Partial dependence plot', 'Confusion matrix', 'Learning curve', 'ROC curve'],
        answerIndex: 0,
        explanation: 'Partial dependence averages the model output over the data for each value of the chosen feature.'
      },
      {
        question: 'Why can the signed mean of SHAP values for a feature be near zero when the feature matters?',
        options: [
          'SHAP values are random.',
          'Positive and negative contributions can cancel.',
          'The feature is unused.',
          'Averages are always zero.'
        ],
        answerIndex: 1,
        explanation: 'A feature can raise some predictions and lower others. Mean absolute SHAP captures the size of use.'
      },
      {
        question: 'What is the main risk of a partial dependence plot with strongly correlated features?',
        options: [
          'It cannot be drawn.',
          'It averages over combinations that rarely occur.',
          'It changes the model.',
          'It needs labels.'
        ],
        answerIndex: 1,
        explanation: 'Forcing one feature to a value while keeping the others can create unrealistic inputs.'
      }
    ],
    related: ['feature-importance', 'shap', 'local-explanations', 'model-interpretability'],
    keywords: ['global explanation', 'partial dependence', 'ICE', 'SHAP summary', 'surrogate model']
  },
  {
    id: 'local-explanations',
    title: 'Local explanations',
    category: 'explainable',
    summary: 'A local explanation says why a model made one specific prediction, by showing how much each feature pushed it above or below the average.',
    readingMinutes: 6,
    intro:
      'A person who receives a model output, such as a risk score, usually wants to know about their own case: what pushed it up, and what pulled it down. A global summary cannot answer that, because the model may behave differently from one case to the next.\n\nLocal explanations focus on a single prediction. After this lesson you will be able to read a SHAP waterfall-style breakdown, check that it adds up, and describe what it can and cannot support.',
    simple:
      'Think of a bill at a restaurant. There is a standard cover charge, and then each item you ordered adds or subtracts something. The total is the standard charge plus every line. A local explanation is that itemised bill for one prediction.\n\nStarting from the average prediction, each feature adds or subtracts an amount, and the final figure is the model output for this case. The explanation tells you what the model responded to. It does not say what you could change to alter your real outcome, because the model reflects patterns in past data and not a mechanism.',
    technical:
      'Popular local methods are **SHAP**, **LIME** and **counterfactual explanations**. SHAP gives additive contributions $\\phi_i$ with $f(x) = \\phi_0 + \\sum_i \\phi_i$. LIME fits a simple weighted linear model to the black-box predictions on perturbed copies of the instance, so its coefficients describe the model near that point; results depend on the perturbation scheme and the neighbourhood width and can vary between runs. A counterfactual is a nearby input that would change the prediction, such as the smallest edit to cross a decision threshold.\n\nSeveral cautions apply. Contributions are relative to a baseline, so changing the background data changes them. The units matter: contributions for classifiers are often in log-odds, which add up on that scale and not in probability. Contributions for correlated features can shift between them. A counterfactual is a statement about the model, and acting on it need not change the real outcome, because the features may be markers of an underlying cause. Local explanations of individual predictions can also look convincing for wrong predictions, so they should accompany, not replace, performance checks.',
    math: [
      {
        label: 'Additive local explanation',
        tex: String.raw`f(x) = \phi_0 + \sum_{i=1}^{p} \phi_i(x)`,
        note: '$\\phi_0$ is the average prediction and $\\phi_i(x)$ the contribution of feature $i$ for this input $x$.'
      },
      {
        label: 'Local surrogate (LIME-style objective)',
        tex: String.raw`\hat g = \arg\min_{g \in G}\; \sum_{z} \pi_x(z)\,\bigl(f(z) - g(z)\bigr)^2 + \Omega(g)`,
        note: '$g$ is a simple model fitted on perturbed points $z$, weighted by closeness $\\pi_x(z)$ to $x$, and $\\Omega$ penalises complexity.'
      }
    ],
    example: {
      title: 'An itemised risk score',
      body:
        'A model gives an average predicted risk of 0.12. For one person the contributions, in probability units for simplicity, are +0.20 for feature A, +0.11 for feature B and -0.04 for feature C.\n\nThe prediction is $0.12 + 0.20 + 0.11 - 0.04 = 0.39$. A is the largest push upward, B adds a smaller push, and C lowers the score slightly. This reads as: relative to the average case, the model scored this person higher mainly because of A. It does not say that changing A would lower this person\'s true risk. It also does not say the prediction is correct; that must be checked separately.'
    },
    pros: [
      'Answers the question the affected person actually asks about their own case.',
      'Additive breakdowns are easy to check.',
      'Helps reviewers spot predictions driven by suspicious features.',
      'Counterfactuals give a concrete picture of the decision boundary.'
    ],
    cons: [
      'Depends on the baseline and the background data.',
      'LIME results can vary with sampling and neighbourhood choices.',
      'Can make a wrong prediction look reasonable.',
      'Not evidence of what would happen if the input were changed in reality.'
    ],
    applications: [
      'Explaining a single risk score to a reviewer.',
      'Investigating individual errors.',
      'Giving reasons alongside an automated decision.',
      'Auditing unusual predictions.'
    ],
    quiz: [
      {
        question: 'A local explanation breaks down:',
        options: ['The average error over the dataset', 'One prediction into feature contributions', 'The training loss curve', 'The class balance'],
        answerIndex: 1,
        explanation: 'Local explanations concern a single instance.'
      },
      {
        question: 'Base 0.12 with contributions +0.20, +0.11 and -0.04. What is the prediction?',
        options: ['0.27', '0.35', '0.39', '0.47'],
        answerIndex: 2,
        explanation: '0.12 + 0.20 + 0.11 - 0.04 = 0.39.'
      },
      {
        question: 'Why can a counterfactual explanation mislead if treated as advice?',
        options: [
          'It is always wrong.',
          'It describes the model, and the real outcome may not respond the same way.',
          'It needs more data.',
          'It changes the labels.'
        ],
        answerIndex: 1,
        explanation: 'The features may be markers of a cause, so editing them need not change the actual outcome.'
      },
      {
        question: 'What is a known weakness of LIME?',
        options: [
          'It cannot explain trees.',
          'Explanations can depend on sampling and neighbourhood settings.',
          'It only works on images.',
          'It requires labels.'
        ],
        answerIndex: 1,
        explanation: 'Different perturbation choices can give different explanations for the same instance.'
      }
    ],
    related: ['shap', 'global-explanations', 'model-interpretability', 'explainability-in-healthcare'],
    keywords: ['local explanation', 'LIME', 'counterfactual', 'waterfall', 'single prediction', 'additivity']
  },
  {
    id: 'explainability-in-healthcare',
    title: 'Explainability in healthcare',
    category: 'explainable',
    summary: 'In healthcare, explanations help clinicians review model output as decision support, but they do not make a model safe, causal or a substitute for clinical judgement.',
    readingMinutes: 7,
    intro:
      'Healthcare is a setting where a wrong prediction can harm a person and where clinicians remain responsible for decisions. A prediction model there is best understood as decision support: it offers a second input to a qualified person, and it is not a diagnosis.\n\nExplanations can help that person judge whether to trust a given output. This lesson covers what they are good for, how they can fail, and why subgroup performance and dataset shift matter as much as any explanation.',
    simple:
      'Imagine a colleague who flags a scan as worrying and points to a region. That helps you look. But you would still examine the scan, consider the patient\'s history and decide yourself. If the colleague pointed at a label in the corner of the image instead, you would learn that the flag cannot be trusted.\n\nExplanations in healthcare play that role. They show what the model used, so a clinician can notice when it relied on something sensible or on something irrelevant. They do not show why the patient is ill, and they do not turn a prediction into a diagnosis.',
    technical:
      'Useful roles for explanations include **debugging** (finding shortcuts such as a hospital identifier, scanner type or a treatment already given that leaks the label), **sanity review** against clinical knowledge, and **communicating** a score to a reviewer. Attribution maps on images and SHAP values on tabular records both describe the fitted function. Saliency maps in particular can be unstable and do not guarantee that the model reasons as a clinician would.\n\nTwo checks matter beyond any explanation. **Subgroup performance**: overall accuracy can hide poor sensitivity in groups defined by age, sex, ethnicity, site or device, especially if they are under-represented in training data. Report metrics per subgroup and per site. **Dataset shift**: a model trained at one hospital or period can degrade when populations, equipment, coding practices or care pathways change, so deployment needs external validation and ongoing monitoring. Explanations should be re-examined after shift, since the features the model relies on may no longer carry the same meaning.\n\nFinally, associations are not causes. A feature that raises predicted risk may be a marker of treatment intensity or a data-recording habit. Acting on an explanation as if it were a causal finding can be harmful. Models intended for clinical use also fall under regulation and require validation appropriate to their intended use.',
    math: [
      {
        label: 'Sensitivity within a subgroup',
        tex: String.raw`\text{sensitivity}_g = \frac{TP_g}{TP_g + FN_g}`,
        note: '$TP_g$ and $FN_g$ count true positives and false negatives among patients in subgroup $g$. Compare it across groups, not only overall.'
      }
    ],
    example: {
      title: 'A good overall figure that hides a gap',
      body:
        'This is a constructed illustration, not real data. Among 100 patients who truly have a condition, 60 are in group X and 40 are in group Y. The model flags 54 of group X and 24 of group Y.\n\nOverall sensitivity is $(54 + 24)/100 = 0.78$. Within groups it is $54/60 = 0.90$ for X and $24/40 = 0.60$ for Y. A single headline figure of 0.78 hides that the model misses 40 percent of cases in group Y. Explanations on individual cases would not reveal this; only a per-group evaluation does. If the model was trained mostly on group X, the explanation of group Y cases may also rest on features that are less informative there.'
    },
    pros: [
      'Lets clinicians check whether output rests on plausible inputs.',
      'Can expose shortcuts such as site or device markers.',
      'Supports communication of a score to colleagues and reviewers.',
      'Encourages per-subgroup evaluation and monitoring.'
    ],
    cons: [
      'Explanations describe the model and not the disease or its causes.',
      'Attribution maps can be unstable and over-trusted.',
      'A convincing explanation can increase trust in a wrong prediction.',
      'Subgroup gaps and dataset shift are invisible to single-case explanations.'
    ],
    applications: [
      'Decision support alongside clinical judgement.',
      'Auditing a model for shortcuts before deployment.',
      'Reviewing performance across sites and patient groups.',
      'Monitoring a deployed model after practice changes.'
    ],
    quiz: [
      {
        question: 'How should a clinical prediction model be positioned?',
        options: ['As a replacement for clinicians', 'As decision support for a qualified person', 'As a diagnosis', 'As a causal finding'],
        answerIndex: 1,
        explanation: 'The clinician remains responsible. The model offers an input to their judgement.'
      },
      {
        question: 'Overall sensitivity is 0.78, with 0.90 in group X and 0.60 in group Y. What does this show?',
        options: [
          'The model is fair.',
          'The overall figure hides a large subgroup gap.',
          'Group Y is mislabelled.',
          'Sensitivity is meaningless.'
        ],
        answerIndex: 1,
        explanation: 'Per-group metrics are needed, since the average is dominated by the larger group.'
      },
      {
        question: 'What is dataset shift?',
        options: [
          'Moving data to another server.',
          'A change between training conditions and deployment conditions.',
          'Shuffling rows.',
          'Removing missing values.'
        ],
        answerIndex: 1,
        explanation: 'Populations, devices or practices can differ, which can degrade performance and change what features mean.'
      },
      {
        question: 'An explanation shows a scanner identifier drove a prediction. What does that suggest?',
        options: [
          'The model has found a causal factor.',
          'The model uses a shortcut and may not generalise.',
          'The scanner causes the disease.',
          'The explanation is wrong by definition.'
        ],
        answerIndex: 1,
        explanation: 'Site or device markers can correlate with the label in training data without carrying clinical meaning.'
      }
    ],
    related: ['local-explanations', 'global-explanations', 'model-interpretability', 'generalization'],
    keywords: ['healthcare', 'clinical decision support', 'subgroup performance', 'dataset shift', 'shortcut learning', 'validation']
  }
];
