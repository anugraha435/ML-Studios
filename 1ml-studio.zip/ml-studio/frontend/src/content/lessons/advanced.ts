import type { Lesson } from '../types';

export const advancedLessons: Lesson[] = [
  {
    id: 'neural-networks',
    title: 'Neural networks',
    category: 'advanced',
    summary: 'A neural network is a stack of layers that each apply a weighted sum and a nonlinear function, letting the model learn complicated input-output relationships from data.',
    readingMinutes: 7,
    intro:
      'Many problems, such as recognising an object in an image or estimating risk from dozens of measurements, depend on interactions between inputs that are hard to write down by hand. Neural networks learn those interactions by composing many simple computations, and they are the basis of modern deep learning.\n\nAfter this lesson you will be able to compute the forward pass of a small network, explain why a nonlinear activation is essential, and describe what the weights represent and how they are fitted.',
    simple:
      'Think of a committee that votes in stages. In the first stage, several members each look at the raw facts and give a score, weighting some facts more than others. In the second stage, a final member listens to those scores, again weighting some members more than others, and gives the answer.\n\nEach member is a **neuron**: it multiplies its inputs by weights, adds them up, and passes the result through a rule that decides how strongly to speak up. The weights are the only thing that changes during learning. Training nudges them until the committee answers correctly on the examples it has seen.\n\nWithout that "speak up" rule, a committee of any size would behave like a single weighted vote. The rule is what lets stages build on each other.',
    technical:
      'A feed-forward network with layers $l = 1,\\dots,L$ computes $a^{(l)} = \\sigma^{(l)}(W^{(l)} a^{(l-1)} + b^{(l)})$ with $a^{(0)} = x$. The weight matrices $W^{(l)}$ and bias vectors $b^{(l)}$ are the learnable parameters; the activation $\\sigma$ is applied element-wise. Common hidden activations are ReLU, $\\max(0,z)$, and tanh. The output activation is chosen to suit the task: identity for regression, sigmoid for binary probabilities, softmax for several classes.\n\nIf every $\\sigma$ were linear, the whole network would collapse to one linear map, so nonlinearity is what gives depth its value. The universal approximation theorem states that a network with one hidden layer and enough units can approximate any continuous function on a compact set to arbitrary accuracy; it says nothing about how many units are needed or whether training will find the weights. In practice, depth often represents structured functions more efficiently than width.\n\nParameters are fitted by minimising a loss over the training data with gradient-based methods, using backpropagation to compute gradients. The loss is non-convex, so training finds a good local solution rather than a provable global one, and results depend on initialisation, learning rate and architecture. Networks with many parameters can memorise training data, so regularisation and held-out validation are standard.',
    math: [
      {
        label: 'Single layer',
        tex: String.raw`a^{(l)} \;=\; \sigma\!\left(W^{(l)}\, a^{(l-1)} + b^{(l)}\right)`,
        note: '$W^{(l)}$ holds the weights into layer $l$, $b^{(l)}$ the biases, and $\\sigma$ the activation applied to each entry.'
      },
      {
        label: 'ReLU activation',
        tex: String.raw`\mathrm{ReLU}(z) \;=\; \max(0,\,z)`,
        note: 'Outputs zero for negative input and passes positive input unchanged. It is cheap to compute and has gradient 1 for positive $z$.'
      },
      {
        label: 'Sigmoid output',
        tex: String.raw`\sigma(z) \;=\; \frac{1}{1+e^{-z}}`,
        note: 'Squashes any real number into $(0,1)$, so the output of a binary classifier can be read as a probability.'
      }
    ],
    example: {
      title: 'Forward pass through a 2-2-1 network',
      body:
        'Input $x = (1, 2)$. Hidden weights: neuron 1 has $(0.5, -1.0)$ with bias 0.1, neuron 2 has $(0.3, 0.8)$ with bias -0.2. Output weights are $(1.0, -0.5)$ with bias 0.2.\n\n**Hidden pre-activations.** Neuron 1: 0.5(1) - 1.0(2) + 0.1 = -1.4. Neuron 2: 0.3(1) + 0.8(2) - 0.2 = 1.7.\n\n**ReLU.** Neuron 1 becomes 0 and neuron 2 stays 1.7.\n\n**Output.** z = 1.0(0) - 0.5(1.7) + 0.2 = -0.65. Sigmoid gives 1 / (1 + e^0.65) = 0.343.\n\nThe network says the positive class has probability about 0.34 for this input.'
    },
    pros: [
      'Can represent very complicated nonlinear relationships.',
      'Learns useful intermediate features instead of needing them designed by hand.',
      'Handles images, text, audio and tables with suitable architectures.',
      'Improves with more data and computation in many settings.'
    ],
    cons: [
      'Needs a lot of labelled data for good results on complex tasks.',
      'Many hyperparameters and a non-convex loss make training fiddly.',
      'Hard to interpret, which matters in regulated or clinical settings.',
      'Prone to overfitting without regularisation or enough data.'
    ],
    applications: [
      'Image classification and object detection.',
      'Speech recognition and language modelling.',
      'Risk scores from many tabular measurements, used as decision support alongside clinical judgement.',
      'Forecasting demand or sensor signals.'
    ],
    quiz: [
      {
        question: 'Why must hidden layers use a nonlinear activation?',
        options: [
          'To make the network train faster on any problem.',
          'Without it, stacked layers collapse into one linear transformation.',
          'To guarantee that the loss is convex.',
          'To keep every weight between 0 and 1.'
        ],
        answerIndex: 1,
        explanation: 'A composition of linear maps is itself linear, so depth adds nothing without nonlinearity. Nonlinear activations do not make the loss convex, and they do not bound the weights.'
      },
      {
        question: 'A neuron has weights (2, -1), bias 0.5 and ReLU activation. For input (1, 3), what is its output?',
        options: [
          '-0.5',
          '0.5',
          '0',
          '3.5'
        ],
        answerIndex: 2,
        explanation: 'The pre-activation is 2(1) - 1(3) + 0.5 = -0.5. ReLU maps negative values to 0, so the output is 0. The value -0.5 is the pre-activation, not the output.'
      },
      {
        question: 'What does the universal approximation theorem guarantee?',
        options: [
          'Gradient descent will always find the best weights.',
          'Any network will generalise to unseen data.',
          'A wide enough single hidden layer can approximate any continuous function on a bounded region.',
          'Deeper networks always need fewer parameters.'
        ],
        answerIndex: 2,
        explanation: 'The theorem is about representational capacity only. It does not promise that training will find the weights, that the network will generalise, or that depth is more efficient.'
      }
    ],
    related: ['gradient-descent', 'backpropagation', 'loss-functions', 'overfitting-underfitting'],
    keywords: ['neural network', 'neuron', 'layer', 'activation', 'ReLU', 'sigmoid', 'forward pass', 'deep learning', 'weights']
  },
  {
    id: 'gradient-descent',
    title: 'Gradient descent',
    category: 'advanced',
    summary: 'Gradient descent minimises a loss by repeatedly stepping the parameters in the direction that decreases it fastest, with the step size set by the learning rate.',
    readingMinutes: 7,
    intro:
      'Almost every model in this course is fitted by choosing parameters that make a loss as small as possible. For simple models there is a formula for the answer; for neural networks and many others there is not, so we search. Gradient descent is the basic search procedure behind most of modern machine learning.\n\nAfter this lesson you will be able to write the update rule, carry out several steps by hand, explain what goes wrong when the learning rate is too large or too small, and distinguish batch, stochastic and mini-batch versions.',
    simple:
      'Imagine standing on a hillside in thick fog, wanting to reach the valley floor. You cannot see the valley, but you can feel which way the ground slopes under your feet. So you take a step downhill, feel the slope again, and repeat.\n\nThe slope is the **gradient**, and the length of each step is the **learning rate**. Tiny steps are safe but slow. Huge steps can carry you across the valley and up the other side, so you bounce around or end up higher than where you began.\n\nIn a real problem the hillside has one direction for every parameter, perhaps millions, but the idea is the same: feel the slope, step downhill.',
    technical:
      'For a differentiable loss $L(\\theta)$, gradient descent iterates $\\theta_{t+1} = \\theta_t - \\eta \\nabla L(\\theta_t)$, where $\\eta > 0$ is the learning rate. The negative gradient is the direction of steepest local decrease. For a convex function with an $L$-Lipschitz gradient, a step size $\\eta \\le 1/L$ guarantees the loss decreases at every step and converges to the global minimum. For non-convex losses, such as those of neural networks, the method converges to a stationary point, which may be a local minimum or saddle, and in practice often works well enough.\n\nThe cost of one gradient depends on the data. Batch gradient descent uses all $n$ examples per step. Stochastic gradient descent (SGD) uses one example, and mini-batch SGD uses a small random subset, typically tens to hundreds of examples. The mini-batch gradient is an unbiased but noisy estimate of the full gradient; the noise makes each step cheaper and can help escape shallow regions, but it requires a decaying or small learning rate to settle.\n\nVariants add memory to the update. Momentum accumulates a running average of past gradients to damp oscillations in narrow valleys. Adaptive methods such as RMSProp and Adam scale each parameter\'s step by a running estimate of its gradient magnitude. Features on very different scales produce elongated loss surfaces that slow plain gradient descent, so standardising inputs is common practice. Learning-rate schedules that shrink $\\eta$ over time are widely used.',
    math: [
      {
        label: 'Update rule',
        tex: String.raw`\theta_{t+1} \;=\; \theta_t \;-\; \eta\,\nabla_{\theta} L(\theta_t)`,
        note: '$\\theta$ is the parameter vector, $\\eta$ the learning rate and $\\nabla L$ the vector of partial derivatives of the loss.'
      },
      {
        label: 'Mini-batch gradient',
        tex: String.raw`\nabla L(\theta) \;\approx\; \frac{1}{\lvert B \rvert}\sum_{i \in B} \nabla \ell_i(\theta)`,
        note: '$B$ is a randomly chosen batch of examples and $\\ell_i$ is the loss on example $i$.'
      },
      {
        label: 'Momentum',
        tex: String.raw`v_{t+1} = \beta v_t + \nabla L(\theta_t), \qquad \theta_{t+1} = \theta_t - \eta\, v_{t+1}`,
        note: '$v$ is a velocity that averages recent gradients; $\\beta$ (often 0.9) controls how long the memory lasts.'
      }
    ],
    example: {
      title: 'Minimising a one-parameter loss',
      body:
        'Let $L(w) = (w-3)^2$, whose gradient is $2(w-3)$ and whose minimum is at $w = 3$. Start at $w_0 = 0$ with learning rate 0.1.\n\n**Step 1.** Gradient = 2(0 - 3) = -6. New w = 0 - 0.1(-6) = 0.6.\n\n**Step 2.** Gradient = 2(0.6 - 3) = -4.8. New w = 0.6 + 0.48 = 1.08.\n\n**Step 3.** Gradient = 2(1.08 - 3) = -3.84. New w = 1.08 + 0.384 = 1.464.\n\nEach step closes 20 percent of the remaining distance to 3. Now try learning rate 1.1 from the same start: the iterates go 6.6, -1.32, 8.184, so each step overshoots by more than the last and the method diverges.'
    },
    pros: [
      'Needs only first derivatives, which are cheap to compute with backpropagation.',
      'Scales to huge datasets and millions of parameters through mini-batches.',
      'General purpose: works for any differentiable loss.',
      'Simple to implement and extend with momentum or adaptive step sizes.'
    ],
    cons: [
      'Sensitive to the learning rate, which often needs tuning.',
      'Can stall on plateaus and saddle points or zig-zag in narrow valleys.',
      'On non-convex losses it gives no guarantee of reaching the global minimum.',
      'Slow when features have very different scales.'
    ],
    applications: [
      'Training neural networks of every size.',
      'Fitting logistic regression and linear models on very large data.',
      'Matrix factorisation for recommendation systems.',
      'Any custom model with a differentiable objective.'
    ],
    quiz: [
      {
        question: 'In the update $\\theta \\leftarrow \\theta - \\eta \\nabla L$, what happens if $\\eta$ is far too large?',
        options: [
          'The method converges faster to the exact minimum.',
          'The gradient becomes zero.',
          'The steps can overshoot the minimum and the loss may grow.',
          'The method becomes stochastic.'
        ],
        answerIndex: 2,
        explanation: 'Large steps jump past the valley floor. In the example with learning rate 1.1 each step lands farther from the minimum than the last.'
      },
      {
        question: 'Why is mini-batch SGD popular for large datasets?',
        options: [
          'Each step is cheap and the noisy gradient still points roughly downhill on average.',
          'It always finds the global minimum.',
          'It removes the need for a learning rate.',
          'It uses second derivatives for faster convergence.'
        ],
        answerIndex: 0,
        explanation: 'The mini-batch gradient is an unbiased estimate of the full gradient at a fraction of the cost. It does not guarantee a global minimum and still needs a learning rate.'
      },
      {
        question: 'What does the momentum term do?',
        options: [
          'It increases the learning rate at every step.',
          'It averages past gradients so oscillations cancel and steady directions build speed.',
          'It selects a random subset of the data.',
          'It makes the loss function convex.'
        ],
        answerIndex: 1,
        explanation: 'Momentum keeps a running average of gradients. Components that flip sign cancel out, while consistent components accumulate.'
      },
      {
        question: 'For $L(w) = (w-3)^2$ at $w = 5$ with learning rate 0.25, what is the next value of $w$?',
        options: [
          '4.0',
          '4.5',
          '3.0',
          '5.5'
        ],
        answerIndex: 0,
        explanation: 'The gradient is 2(5 - 3) = 4, so the new w is 5 - 0.25(4) = 4.0.'
      }
    ],
    related: ['backpropagation', 'loss-functions', 'neural-networks', 'hyperparameter-optimization'],
    keywords: ['gradient descent', 'learning rate', 'SGD', 'stochastic', 'mini-batch', 'momentum', 'Adam', 'optimisation', 'convergence']
  },
  {
    id: 'backpropagation',
    title: 'Backpropagation',
    category: 'advanced',
    summary: 'Backpropagation computes the gradient of a loss with respect to every weight in a network by applying the chain rule backwards from the output to the input.',
    readingMinutes: 7,
    intro:
      'Gradient descent needs the gradient of the loss with respect to every parameter. A network can have millions of them, so computing each derivative separately would be hopelessly slow. Backpropagation is the procedure that gets all of them in roughly the cost of two passes through the network.\n\nAfter this lesson you will be able to explain the forward and backward passes, apply the chain rule to a small network by hand, and say why gradients can shrink or grow as they travel through many layers.',
    simple:
      'Suppose a relay of workers turns raw material into a product, and the final product comes out slightly wrong. To fix it, you ask the last worker how much the error depends on what they did. That worker tells the one before how much of the blame is theirs, and so on back to the start.\n\nEach worker only needs two facts: how sensitive their own output is to their own settings, and how much the error cares about their output. Multiplying those along the chain gives each worker their share of the blame, which is the gradient for their settings.\n\nThe first pass, forward, records what every worker produced. The second pass, backward, hands the blame back down the line using those records.',
    technical:
      'Backpropagation is reverse-mode automatic differentiation applied to the computation graph of a network. In the forward pass we compute and store the pre-activations $z^{(l)} = W^{(l)} a^{(l-1)} + b^{(l)}$ and activations $a^{(l)}$ for each layer and then the loss. In the backward pass we define the error signal $\\delta^{(l)} = \\partial L / \\partial z^{(l)}$. At the output layer, $\\delta^{(L)}$ comes from the loss and the output activation; for a sigmoid output with cross-entropy loss it simplifies to $a^{(L)} - y$. For earlier layers, $\\delta^{(l)} = (W^{(l+1)})^{\\top}\\delta^{(l+1)} \\odot \\sigma\'(z^{(l)})$, where $\\odot$ is the element-wise product.\n\nThe parameter gradients follow directly: $\\partial L/\\partial W^{(l)} = \\delta^{(l)} (a^{(l-1)})^{\\top}$ and $\\partial L/\\partial b^{(l)} = \\delta^{(l)}$. The total cost is proportional to that of the forward pass, which is why training large networks is feasible. The price is memory, because activations must be kept until the backward pass uses them.\n\nBecause the backward pass multiplies many Jacobian factors, gradients can shrink towards zero (vanishing) or grow without bound (exploding) in deep networks. Sigmoid and tanh have derivatives below 1, which makes vanishing likely; ReLU activations, careful weight initialisation, normalisation layers, residual connections and gradient clipping all mitigate the problem. A gradient check against finite differences is a standard way to test an implementation.',
    math: [
      {
        label: 'Chain rule for one weight',
        tex: String.raw`\frac{\partial L}{\partial w} \;=\; \frac{\partial L}{\partial a}\cdot\frac{\partial a}{\partial z}\cdot\frac{\partial z}{\partial w}`,
        note: 'The effect of a weight on the loss is the product of how the loss responds to the output $a$, how $a$ responds to $z$, and how $z$ responds to $w$.'
      },
      {
        label: 'Backward recursion',
        tex: String.raw`\delta^{(l)} \;=\; \left(W^{(l+1)}\right)^{\!\top}\delta^{(l+1)} \,\odot\, \sigma'\!\left(z^{(l)}\right)`,
        note: '$\\delta^{(l)}$ is the gradient of the loss with respect to the pre-activation of layer $l$, passed back from layer $l+1$.'
      },
      {
        label: 'Weight gradient',
        tex: String.raw`\frac{\partial L}{\partial W^{(l)}} \;=\; \delta^{(l)}\,\left(a^{(l-1)}\right)^{\!\top}`,
        note: 'Each weight\'s gradient is the error signal of the neuron it feeds times the activation it receives.'
      }
    ],
    example: {
      title: 'One backward pass through a single sigmoid neuron',
      body:
        'Input $x = 1.5$, weight $w = 0.8$, bias $b = -0.5$, target $y = 1$, loss $L = \\tfrac{1}{2}(a - y)^2$.\n\n**Forward.** z = 0.8(1.5) - 0.5 = 0.7. a = sigmoid(0.7) = 0.668. L = 0.5(0.668 - 1)^2 = 0.0550.\n\n**Backward.** dL/da = a - y = -0.332. da/dz = a(1 - a) = 0.2217. So dL/dz = -0.332 x 0.2217 = -0.0736. Then dL/dw = dL/dz x x = -0.0736 x 1.5 = -0.1104, and dL/db = -0.0736.\n\n**Update with learning rate 0.5.** w = 0.8 + 0.0552 = 0.855 and b = -0.5 + 0.0368 = -0.463. The new output is sigmoid(0.855 x 1.5 - 0.463) = 0.694 and the loss drops to 0.0468.'
    },
    pros: [
      'Computes all gradients in about the cost of two network passes.',
      'Works for any differentiable architecture, which automatic differentiation tools exploit.',
      'Exact up to floating-point error, unlike numerical differentiation.',
      'Makes training of very large networks practical.'
    ],
    cons: [
      'Stores intermediate activations, so memory use grows with depth and batch size.',
      'Gradients can vanish or explode in deep networks.',
      'Requires differentiable operations, so discrete choices need workarounds.',
      'Implementation errors are subtle, which is why gradient checking is used.'
    ],
    applications: [
      'Training feed-forward, convolutional and recurrent networks.',
      'Fine-tuning pretrained models on a new task.',
      'Computing input gradients for saliency maps and adversarial tests.',
      'Differentiable programming beyond classic neural networks.'
    ],
    quiz: [
      {
        question: 'What mathematical rule is at the heart of backpropagation?',
        options: [
          'Bayes\' rule',
          'The chain rule of calculus',
          'The central limit theorem',
          'The law of large numbers'
        ],
        answerIndex: 1,
        explanation: 'Backpropagation applies the chain rule layer by layer, reusing results from later layers to get gradients for earlier ones.'
      },
      {
        question: 'Why does backpropagation need the forward pass first?',
        options: [
          'The forward pass chooses the learning rate.',
          'The backward pass changes the weights before the forward pass reads them.',
          'The backward pass needs the stored activations and the loss value from the forward pass.',
          'The forward pass removes unused neurons.'
        ],
        answerIndex: 2,
        explanation: 'Local derivatives such as $\\sigma\'(z)$ and the weight gradient formulas use values computed in the forward pass, so they must be stored.'
      },
      {
        question: 'Which change is most likely to reduce vanishing gradients in a deep network?',
        options: [
          'Switching hidden sigmoids to ReLU and using sensible initialisation.',
          'Lowering the learning rate to 0.0001.',
          'Removing the bias terms.',
          'Using a smaller training set.'
        ],
        answerIndex: 0,
        explanation: 'Sigmoid derivatives are at most 0.25, so products over many layers shrink quickly. ReLU has derivative 1 for positive inputs. A smaller learning rate does not change the size of the gradient itself.'
      }
    ],
    related: ['neural-networks', 'gradient-descent', 'loss-functions'],
    keywords: ['backpropagation', 'chain rule', 'gradient', 'automatic differentiation', 'vanishing gradient', 'exploding gradient', 'forward pass', 'backward pass']
  },
  {
    id: 'loss-functions',
    title: 'Loss functions',
    category: 'advanced',
    summary: 'A loss function scores how wrong a prediction is, and the choice of loss decides what the model is trained to care about.',
    readingMinutes: 7,
    intro:
      'A model cannot improve unless something tells it how badly it is doing. The loss function is that score. It is the quantity that training minimises, so it quietly encodes your priorities: whether large mistakes matter much more than small ones, whether over-confident wrong answers should be punished, and whether outliers should be taken seriously.\n\nAfter this lesson you will be able to compute mean squared error, mean absolute error and cross-entropy by hand, explain how they treat errors differently, and choose a sensible loss for a regression or classification task.',
    simple:
      'Think of a teacher marking answers. One teacher subtracts a point for every unit you are off. Another squares the miss, so being off by 10 costs 100 times more than being off by 1. A third, marking a quiz where you state how sure you are, barely penalises a wrong answer you hedged on but is harsh when you were certain and wrong.\n\nEach marking scheme is a loss. A student trained under the squared scheme will work hard to avoid a few big blunders, while one trained under the absolute scheme treats all misses in proportion.\n\nThe scheme is not just a report card. It shapes what the student ends up learning.',
    technical:
      'A loss $\\ell(y, \\hat{y})$ compares a target with a prediction, and training minimises its average over the data, often plus a regulariser. For regression, squared error $(y-\\hat{y})^2$ is differentiable everywhere and minimised in expectation by the conditional mean, but it grows quadratically, so a single outlier can dominate. Absolute error is minimised by the conditional median and is more robust, at the cost of a non-smooth point at zero. The Huber loss is quadratic for small residuals and linear beyond a threshold $\\delta$, combining both behaviours.\n\nFor classification with predicted probability $p$ for the true class, cross-entropy (log loss) is $-\\log p$. It is the negative log-likelihood of a Bernoulli or categorical model, so minimising it is maximum likelihood estimation. It penalises confident mistakes heavily: the loss tends to infinity as $p \\to 0$. It is also a proper scoring rule, meaning it is minimised in expectation by reporting the true probabilities, which is why models trained with it tend to give usable probability estimates. Hinge loss, used by support vector machines, only penalises points that are misclassified or within the margin and does not produce probabilities.\n\nA loss used for training should be differentiable, or nearly so, for gradient methods. It need not equal the metric you finally care about: accuracy is not differentiable, so we train on cross-entropy and report accuracy or other metrics separately. When classes are imbalanced, class weights or a focal loss can shift the emphasis toward the rare class.',
    math: [
      {
        label: 'Mean squared error',
        tex: String.raw`\mathrm{MSE} \;=\; \frac{1}{n}\sum_{i=1}^{n}\left(y_i - \hat{y}_i\right)^{2}`,
        note: 'Averages squared residuals, so large errors dominate. Its square root, RMSE, has the same units as $y$.'
      },
      {
        label: 'Mean absolute error',
        tex: String.raw`\mathrm{MAE} \;=\; \frac{1}{n}\sum_{i=1}^{n}\left\lvert y_i - \hat{y}_i\right\rvert`,
        note: 'Treats every unit of error equally, which makes it less sensitive to outliers than MSE.'
      },
      {
        label: 'Binary cross-entropy',
        tex: String.raw`\mathcal{L} \;=\; -\frac{1}{n}\sum_{i=1}^{n}\Big[\,y_i \log p_i + (1-y_i)\log(1-p_i)\Big]`,
        note: '$y_i \\in \\{0,1\\}$ is the label and $p_i$ the predicted probability of class 1.'
      }
    ],
    example: {
      title: 'How MSE and MAE react to an outlier',
      body:
        'Five residuals (prediction errors) are 1, -2, 1, -1 and 20.\n\n**Mean absolute error.** (1 + 2 + 1 + 1 + 20) / 5 = 5.0.\n\n**Mean squared error.** (1 + 4 + 1 + 1 + 400) / 5 = 81.4.\n\nDrop the outlier and the four remaining residuals give MAE = 1.25 and MSE = 1.75. The single point multiplies MAE by 4 but MSE by about 47, so a model trained on squared error will bend itself toward that point far more.\n\n**Cross-entropy for one example whose true class is 1.** Predicting p = 0.9 costs -ln(0.9) = 0.105. Predicting 0.6 costs 0.511. Predicting 0.1 costs 2.303, and predicting 0.01 costs 4.605. Confident wrong answers are punished steeply.'
    },
    pros: [
      'Gives training a single number to minimise, which makes optimisation possible.',
      'Choosing it deliberately lets you encode which errors matter.',
      'Cross-entropy matches probabilistic modelling and yields good probability estimates.',
      'Robust variants such as MAE and Huber limit the effect of outliers.'
    ],
    cons: [
      'The training loss may not match the metric you care about.',
      'Squared error is sensitive to outliers and noisy labels.',
      'Cross-entropy can become very large on confidently wrong or mislabelled examples.',
      'Class imbalance can make an average loss reward ignoring the rare class.'
    ],
    applications: [
      'Squared or Huber loss for predicting continuous quantities such as prices.',
      'Cross-entropy for classifiers, including image and text models.',
      'Hinge loss for margin-based classifiers such as support vector machines.',
      'Weighted losses where missing a rare condition costs more than a false alarm, as decision support only.'
    ],
    quiz: [
      {
        question: 'A dataset contains a few extreme outliers you believe are measurement errors. Which loss is the most robust choice?',
        options: [
          'Mean squared error',
          'Cubed error',
          'Mean absolute error or Huber loss',
          'Squared error with a larger learning rate'
        ],
        answerIndex: 2,
        explanation: 'Absolute and Huber losses grow linearly for large residuals, so outliers have limited pull. Squared and cubed errors grow faster and magnify them.'
      },
      {
        question: 'For a positive example, which prediction gives the largest binary cross-entropy?',
        options: [
          'p = 0.9',
          'p = 0.5',
          'p = 0.7',
          'p = 0.05'
        ],
        answerIndex: 3,
        explanation: 'The loss is -ln(p), which is about 0.105, 0.693, 0.357 and 3.0 for these four options. The lowest probability on the true class is penalised most.'
      },
      {
        question: 'Why do we usually train a classifier on cross-entropy instead of accuracy?',
        options: [
          'Accuracy cannot be computed on training data.',
          'Cross-entropy is always equal to accuracy.',
          'Accuracy is only defined for regression.',
          'Accuracy is a step function with no useful gradient, while cross-entropy is smooth.'
        ],
        answerIndex: 3,
        explanation: 'Small weight changes rarely change which side of a threshold a prediction falls on, so accuracy gives gradient descent nothing to follow. Cross-entropy changes smoothly with the predicted probabilities.'
      },
      {
        question: 'Squared error is minimised, in expectation, by predicting which quantity?',
        options: [
          'The conditional median',
          'The conditional mean',
          'The conditional mode',
          'The largest observed value'
        ],
        answerIndex: 1,
        explanation: 'Minimising expected squared error gives the mean; absolute error gives the median. This is one reason the two losses behave differently with skewed data.'
      }
    ],
    related: ['gradient-descent', 'logistic-regression', 'regularization', 'neural-networks'],
    keywords: ['loss function', 'MSE', 'MAE', 'cross-entropy', 'log loss', 'Huber', 'hinge', 'objective', 'cost function']
  },
  {
    id: 'overfitting-underfitting',
    title: 'Overfitting and underfitting',
    category: 'advanced',
    summary: 'Underfitting means the model is too simple to capture the pattern; overfitting means it has also memorised noise in the training data and fails on new data.',
    readingMinutes: 7,
    intro:
      'A model that scores perfectly on its training data can still be useless. What matters is how it performs on data it has never seen. Overfitting and underfitting are the two ways this goes wrong, and recognising which one you have decides what to do next.\n\nAfter this lesson you will be able to diagnose each problem from training and validation errors, explain why model complexity and dataset size drive them, and list practical remedies.',
    simple:
      'Consider two students preparing for an exam from last year\'s paper. One barely reads it and learns only that "maths is hard"; they fail both old and new papers. That is underfitting. The other memorises every answer, including the typos in the answer key. They ace the old paper but stumble when the questions change slightly. That is overfitting.\n\nThe student you want understands the method behind the answers. They do well on the old paper and nearly as well on a new one.\n\nThe key signal is the gap: poor on both means too simple, great on practice but poor on new means too specialised.',
    technical:
      'Let the training error be measured on the data used to fit the model and the validation or test error on held-out data from the same distribution. Underfitting shows as high training error and a validation error close to it: the hypothesis class cannot represent the signal, a case of high bias. Overfitting shows as low training error and a much higher validation error: the model has fitted noise specific to the sample, a case of high variance. As complexity grows, training error falls monotonically, while validation error typically falls, reaches a minimum and then rises.\n\nComplexity can mean polynomial degree, tree depth, number of neighbours (small $k$ is complex), number of parameters or training epochs. The risk of overfitting also depends on sample size: more data supports more complex models, and an $n$ small relative to the number of features invites memorisation. Label noise and many irrelevant features make it worse.\n\nLearning curves, which plot error against training set size, help diagnose the problem. If both curves plateau high and close together, more data will not help and the model needs more capacity or better features. If a large gap remains, more data, simpler models, regularisation, early stopping, dropout, data augmentation or feature selection can help. The test set must stay untouched during these choices, or it too will be overfit; use a validation set or cross-validation for tuning.',
    math: [
      {
        label: 'Generalisation gap',
        tex: String.raw`\text{gap} \;=\; E_{\text{val}} - E_{\text{train}}`,
        note: 'A large positive gap signals overfitting. Both errors being high signals underfitting.'
      },
      {
        label: 'Training error as empirical risk',
        tex: String.raw`E_{\text{train}} \;=\; \frac{1}{n}\sum_{i=1}^{n}\ell\!\left(y_i,\, f(x_i)\right)`,
        note: 'The average loss on the $n$ fitting examples. It can always be driven toward zero by a flexible enough $f$.'
      }
    ],
    example: {
      title: 'Fitting polynomials of degree 0, 1 and 5',
      body:
        'Six training points $(x, y)$: (0, 1.0), (1, 2.9), (2, 5.2), (3, 6.8), (4, 9.1), (5, 11.0). They follow roughly $y = 2x + 1$ plus noise. Three held-out points are (0.5, 2.0), (2.5, 6.0) and (4.5, 10.0).\n\n**Degree 0 (a constant, 6.0).** Training MSE = 11.75 and test MSE = 10.67. Both are high: underfitting.\n\n**Degree 1 (y = 0.986 + 2.006x).** Training MSE = 0.017 and test MSE = 0.0001. Both are tiny: a good fit.\n\n**Degree 5.** A degree-5 polynomial passes through all six points, so training MSE is essentially 0, but test MSE is 0.108, about a thousand times worse than the line. It has bent itself to follow the noise.\n\nThe most complex model has the lowest training error and a worse test error than the simple line.'
    },
    pros: [
      'The train-versus-validation comparison is a cheap and reliable diagnostic.',
      'Each failure mode has well-known remedies.',
      'Learning curves show whether more data or a different model is the better investment.',
      'Understanding the trade-off guides model choice before any tuning begins.'
    ],
    cons: [
      'A validation set is needed, which reduces the data available for training.',
      'Repeated tuning on the same validation set can overfit it.',
      'The right level of complexity is problem-specific and must be found by experiment.',
      'Very flexible modern models can interpolate noise yet still generalise, so the picture is not always simple.'
    ],
    applications: [
      'Choosing tree depth, polynomial degree or neighbour count.',
      'Deciding when to stop training a neural network.',
      'Checking that a clinical risk model validated on one hospital also holds on another before it is used as decision support.',
      'Judging whether to collect more data or engineer better features.'
    ],
    quiz: [
      {
        question: 'A model has training accuracy 99 percent and validation accuracy 71 percent. What is the most likely issue?',
        options: [
          'Underfitting',
          'A perfect model',
          'Overfitting',
          'Too much training data'
        ],
        answerIndex: 2,
        explanation: 'A large gap between training and validation performance is the signature of overfitting. Underfitting would show poor performance on both.'
      },
      {
        question: 'Both training and validation errors are high and nearly equal. Which action is most likely to help?',
        options: [
          'Add stronger regularisation.',
          'Use a more flexible model or better features.',
          'Stop training earlier.',
          'Remove half of the training data.'
        ],
        answerIndex: 1,
        explanation: 'This pattern means the model cannot capture the signal. More capacity or more informative features is the remedy; regularisation and early stopping would reduce capacity further.'
      },
      {
        question: 'As model complexity increases, what normally happens to training error?',
        options: [
          'It falls and may reach zero.',
          'It first falls then rises.',
          'It stays constant.',
          'It always equals the validation error.'
        ],
        answerIndex: 0,
        explanation: 'A more flexible model can always fit the training data at least as well. It is the validation error that has the U shape.'
      },
      {
        question: 'Why should the final test set not be used to choose between model settings?',
        options: [
          'It is too small to evaluate any model.',
          'Repeated use leaks information about it into the choices, so the final estimate becomes optimistic.',
          'Test sets cannot be used to compute errors.',
          'It would increase the training error.'
        ],
        answerIndex: 1,
        explanation: 'Each decision made by looking at the test set fits the choices to it. A separate validation set or cross-validation keeps the test estimate honest.'
      }
    ],
    related: ['bias-variance-tradeoff', 'regularization', 'generalization', 'cross-validation'],
    keywords: ['overfitting', 'underfitting', 'generalisation gap', 'model complexity', 'learning curve', 'validation error', 'early stopping', 'memorisation']
  },
  {
    id: 'bias-variance-tradeoff',
    title: 'The bias-variance tradeoff',
    category: 'advanced',
    summary: 'Expected prediction error splits into bias, variance and irreducible noise, and making a model more flexible usually lowers bias while raising variance.',
    readingMinutes: 7,
    intro:
      'Overfitting and underfitting describe what you see in the errors. The bias-variance decomposition explains why they happen, by splitting a model\'s expected error into parts that respond differently to model complexity.\n\nAfter this lesson you will be able to define bias and variance precisely, compute them from repeated fits, state the decomposition for squared error, and use it to reason about which changes to a model are likely to help.',
    simple:
      'Picture several archers shooting at a target. One archer\'s arrows all land tightly together but off to the left: low spread, consistent miss. That is **high bias, low variance**. Another archer\'s arrows scatter widely around the bullseye: right on average, but any single shot may be far off. That is **low bias, high variance**.\n\nA simple model is like the first archer: it makes the same kind of mistake whatever data it sees. A very flexible model is like the second: it chases whatever sample it happened to get, so each training set produces a different answer.\n\nThere is also bad luck in the target itself. Even a perfect archer cannot beat wind that moves the target, which stands for noise in the data.',
    technical:
      'Suppose $y = f(x) + \\varepsilon$ with $E[\\varepsilon] = 0$ and $\\operatorname{Var}(\\varepsilon) = \\sigma^2$, and let $\\hat{f}$ be a model fitted to a random training set. For squared error at a fixed point $x$, the expected loss over training sets and noise decomposes as bias squared plus variance plus irreducible error. Bias is $E[\\hat{f}(x)] - f(x)$, the systematic difference between the average prediction and the truth. Variance is $E[(\\hat{f}(x) - E[\\hat{f}(x)])^2]$, how much the prediction changes from one training set to another.\n\nThe decomposition is exact for squared loss; for other losses there are analogues but no single clean form. Increasing flexibility, for example higher polynomial degree, deeper trees or smaller $k$ in k-nearest neighbours, typically reduces bias and increases variance. Regularisation, bagging and more data typically reduce variance, sometimes at a small cost in bias. The best generalisation is usually at an intermediate complexity where the sum is smallest, and it can never go below $\\sigma^2$.\n\nBias and variance are defined by a thought experiment over many training sets, so they cannot be read off one fit. They can be estimated by resampling, for example by bootstrapping, refitting and measuring the spread. Modern heavily over-parameterised networks sometimes show test error that falls again past the interpolation point (double descent), which shows that the classical U-shaped picture is a useful guide but not a law for every model family.',
    math: [
      {
        label: 'Bias-variance decomposition (squared error)',
        tex: String.raw`E\!\left[(y-\hat{f}(x))^{2}\right] \;=\; \underbrace{\big(E[\hat{f}(x)]-f(x)\big)^{2}}_{\text{bias}^{2}} \;+\; \underbrace{\operatorname{Var}\!\big(\hat{f}(x)\big)}_{\text{variance}} \;+\; \underbrace{\sigma^{2}}_{\text{noise}}`,
        note: 'The expectation is over training sets and noise. Only the first two terms depend on the learning method.'
      },
      {
        label: 'Bias of an estimator',
        tex: String.raw`\operatorname{Bias}\big(\hat{f}(x)\big) \;=\; E\big[\hat{f}(x)\big] - f(x)`,
        note: 'Zero bias means the predictions are correct on average across training sets.'
      }
    ],
    example: {
      title: 'Two estimators of a true value of 10',
      body:
        'The true value is 10 and there is no noise. We fit each model on five different training sets and record the prediction at one point.\n\n**Model A (simple).** Predictions: 12, 13, 11, 12, 12. Mean = 12, so bias = 2 and bias squared = 4. Variance = 0.4. Expected squared error = 4 + 0.4 = 4.4.\n\n**Model B (flexible).** Predictions: 6, 14, 9, 15, 6. Mean = 10, so bias = 0. Variance = 14.8. Expected squared error = 0 + 14.8 = 14.8.\n\nModel B is right on average yet has more than three times the error of Model A, because its predictions scatter so widely. Model A is consistently wrong yet cheaper overall. Neither is ideal; a model with, say, bias 1 and variance 2 would beat both, with error 3.'
    },
    pros: [
      'Explains why simple and complex models fail in different ways.',
      'Guides remedies: reduce variance with data, regularisation or averaging; reduce bias with capacity or features.',
      'Gives a floor on achievable error through the noise term.',
      'Connects ensemble methods and regularisation to a common idea.'
    ],
    cons: [
      'Bias and variance cannot be observed directly from a single fitted model.',
      'The clean additive form holds exactly only for squared error.',
      'The classical U-shaped curve does not describe every modern model, such as very large networks.',
      'Estimating the terms needs many refits, which can be costly.'
    ],
    applications: [
      'Choosing polynomial degree, tree depth or neighbour count.',
      'Deciding between collecting more data and building a richer model.',
      'Understanding why bagging helps high-variance learners such as deep trees.',
      'Setting expectations for the lowest error a clinical prediction model can reach given noisy measurements.'
    ],
    quiz: [
      {
        question: 'Which statement describes a high-variance model?',
        options: [
          'It gives similar predictions whatever training set it sees.',
          'Its predictions change a lot when the training sample changes.',
          'It has high error only on the training set.',
          'It cannot be improved by more data.'
        ],
        answerIndex: 1,
        explanation: 'Variance measures sensitivity to the training sample. More data usually reduces it, so the last option is wrong.'
      },
      {
        question: 'In the decomposition of squared error, which term can no model reduce?',
        options: [
          'Bias squared',
          'Variance',
          'The sum of bias and variance',
          'Irreducible noise'
        ],
        answerIndex: 3,
        explanation: 'The noise term $\\sigma^2$ comes from randomness in the target itself, so it sets a lower bound on expected error.'
      },
      {
        question: 'You increase the depth of a decision tree. What is the usual effect?',
        options: [
          'Bias falls and variance rises.',
          'Bias rises and variance falls.',
          'Both fall.',
          'Neither changes.'
        ],
        answerIndex: 0,
        explanation: 'Deeper trees fit finer structure, reducing systematic error but becoming more dependent on the particular sample.'
      },
      {
        question: 'A model has predictions 4, 6, 5, 5 for a true value of 5, with no noise. What is its bias?',
        options: [
          '1',
          '0',
          '-1',
          '5'
        ],
        answerIndex: 1,
        explanation: 'The mean prediction is 5, equal to the true value, so bias is 0. The model has nonzero variance (0.5) but no bias.'
      }
    ],
    related: ['overfitting-underfitting', 'regularization', 'ensemble-learning', 'generalization'],
    keywords: ['bias', 'variance', 'tradeoff', 'decomposition', 'irreducible error', 'model complexity', 'double descent', 'noise']
  },
  {
    id: 'regularization',
    title: 'Regularization',
    category: 'advanced',
    summary: 'Regularization adds a penalty or constraint that discourages overly complex models, trading a little bias for a larger reduction in variance.',
    readingMinutes: 7,
    intro:
      'When a flexible model has too little data, it can fit the noise. Rather than shrinking the model by hand, regularization keeps the flexibility available but makes extreme solutions costly, so the fit has to justify any complexity it uses.\n\nAfter this lesson you will be able to write the ridge and lasso objectives, explain how each shrinks coefficients, compute a ridge solution by hand, and name other forms of regularization such as early stopping and dropout.',
    simple:
      'Imagine fitting a line through scattered points while holding a rubber band that pulls every slope toward zero. The data pulls the line toward the best fit; the band pulls it toward flatness. The final line is a compromise.\n\nA weak band changes little. A strong band flattens everything. Because the band stops any single feature from being given a huge slope, the model becomes less jumpy and is less likely to chase quirks of the sample.\n\nThe strength of the band is a setting you choose. Too weak and you overfit; too strong and you underfit.',
    technical:
      'A regularised objective adds a penalty to the data loss: $J(\\theta) = L(\\theta) + \\lambda\\,\\Omega(\\theta)$, where $\\lambda \\ge 0$ sets the strength. Ridge (L2) regression uses $\\Omega = \\lVert\\theta\\rVert_2^2$ and shrinks all coefficients smoothly toward zero without making them exactly zero; for linear regression it has the closed form $\\hat{\\theta} = (X^{\\top}X + \\lambda I)^{-1}X^{\\top}y$, which is also well defined when $X^{\\top}X$ is singular. Lasso (L1) uses $\\Omega = \\lVert\\theta\\rVert_1$, which can set coefficients exactly to zero and so performs feature selection. Elastic net combines the two and handles groups of correlated features better than lasso alone.\n\nFrom a Bayesian view, L2 corresponds to a Gaussian prior on the weights and L1 to a Laplace prior, with the penalised solution being the maximum a posteriori estimate. Regularisation lowers variance at the price of some bias, so it helps most when data is limited or features are many. Penalties depend on feature scale, so inputs should be standardised, and the intercept is normally not penalised.\n\nOther techniques act as regularisers too: early stopping halts training when validation error starts to rise; dropout randomly silences units during training; weight decay in neural networks is closely related to L2; data augmentation enlarges the effective sample. The value of $\\lambda$ is a hyperparameter chosen by validation or cross-validation.',
    math: [
      {
        label: 'Regularised objective',
        tex: String.raw`J(\theta) \;=\; \underbrace{L(\theta)}_{\text{fit}} \;+\; \lambda\,\Omega(\theta)`,
        note: 'Larger $\\lambda$ puts more weight on keeping the parameters small.'
      },
      {
        label: 'Ridge (L2) and lasso (L1) penalties',
        tex: String.raw`\Omega_{\text{ridge}}(\theta)=\sum_{j}\theta_j^{2}, \qquad \Omega_{\text{lasso}}(\theta)=\sum_{j}\lvert\theta_j\rvert`,
        note: 'The L1 penalty has a corner at zero, which is why it can produce exactly zero coefficients.'
      },
      {
        label: 'Ridge in one dimension (no intercept)',
        tex: String.raw`\hat{w} \;=\; \frac{\sum_i x_i y_i}{\sum_i x_i^{2} + \lambda}`,
        note: 'With $\\lambda = 0$ this is ordinary least squares. As $\\lambda$ grows the estimate shrinks toward 0.'
      }
    ],
    example: {
      title: 'Ridge shrinkage on three points',
      body:
        'Fit $y = wx$ with data (1, 2), (2, 4), (3, 7). Here $\\sum xy = 2 + 8 + 21 = 31$ and $\\sum x^2 = 1 + 4 + 9 = 14$.\n\n**lambda = 0 (ordinary least squares).** w = 31 / 14 = 2.214.\n\n**lambda = 1.** w = 31 / 15 = 2.067.\n\n**lambda = 5.** w = 31 / 19 = 1.632.\n\n**lambda = 10.** w = 31 / 24 = 1.292.\n\nThe slope shrinks steadily as the penalty grows. In practice you would pick lambda by checking error on held-out data, since the training error alone always prefers lambda = 0.'
    },
    pros: [
      'Reduces overfitting, especially with many features or little data.',
      'Ridge keeps the problem well posed when features are highly correlated.',
      'Lasso gives sparse models that are easier to inspect.',
      'Cheap to add to almost any model that is trained by optimisation.'
    ],
    cons: [
      'Adds a hyperparameter $\\lambda$ that needs tuning.',
      'Introduces bias, so too strong a penalty causes underfitting.',
      'Requires standardised features for the penalty to be fair across variables.',
      'Lasso can pick one of several correlated features arbitrarily.'
    ],
    applications: [
      'Ridge regression on datasets with many correlated predictors.',
      'Lasso for selecting a small set of informative features, such as genes or lab values for exploratory research.',
      'Weight decay and dropout in neural networks.',
      'Early stopping when training deep models.'
    ],
    quiz: [
      {
        question: 'Which penalty can drive coefficients exactly to zero?',
        options: [
          'L2 (ridge)',
          'Weight decay with a very small value',
          'L1 (lasso)',
          'No penalty'
        ],
        answerIndex: 2,
        explanation: 'The absolute-value penalty has a corner at zero that makes exact zeros possible. The L2 penalty shrinks coefficients but rarely makes them exactly zero.'
      },
      {
        question: 'What happens to bias and variance as $\\lambda$ increases?',
        options: [
          'Bias falls and variance rises.',
          'Both rise.',
          'Both fall.',
          'Bias rises and variance falls.'
        ],
        answerIndex: 3,
        explanation: 'A stronger penalty restricts the model, giving more systematic error but less sensitivity to the sample. This is regularisation\'s trade.'
      },
      {
        question: 'Why should features be standardised before applying ridge or lasso?',
        options: [
          'The penalty acts on coefficient size, which depends on the feature\'s scale.',
          'Standardising makes the loss convex.',
          'Ridge requires all features to be binary.',
          'It removes the need to choose $\\lambda$.'
        ],
        answerIndex: 0,
        explanation: 'A feature measured in small units needs a large coefficient and would be penalised unfairly. Standardising puts all coefficients on a comparable footing.'
      }
    ],
    related: ['overfitting-underfitting', 'bias-variance-tradeoff', 'feature-selection', 'hyperparameter-optimization'],
    keywords: ['regularisation', 'ridge', 'lasso', 'L1', 'L2', 'elastic net', 'weight decay', 'dropout', 'early stopping', 'shrinkage']
  },
  {
    id: 'feature-selection',
    title: 'Feature selection',
    category: 'advanced',
    summary: 'Feature selection chooses a useful subset of the available input variables, which can make a model simpler, faster, more robust and easier to explain.',
    readingMinutes: 6,
    intro:
      'Datasets often contain far more columns than are useful. Some are irrelevant, some repeat the same information, and some are noisy. Keeping all of them can hurt a model by inviting overfitting and making it harder to interpret or deploy.\n\nAfter this lesson you will be able to describe filter, wrapper and embedded methods, compute a simple correlation filter by hand, explain why redundancy matters as well as relevance, and avoid the common leakage mistake of selecting features before splitting the data.',
    simple:
      'Packing for a trip, you could take your whole wardrobe, but a suitcase with only what you will wear is easier to carry and to find things in. Feature selection is that packing decision for a model.\n\nYou ask two questions about each item. Is it useful for this trip? And do I already have something that does the same job? Two similar jackets waste space.\n\nThere are three ways to decide: judge each item on its own merits, try different packed suitcases and see which works best, or let the packing process itself drop things you never use.',
    technical:
      'Methods fall into three families. **Filter** methods score each feature independently of any model, using correlation, mutual information, the chi-squared statistic or an ANOVA F-test, and keep the top ones. They are fast but ignore interactions and redundancy. **Wrapper** methods search over subsets by training a model on each candidate: forward selection adds the best feature at a time, backward elimination removes the worst, and recursive feature elimination repeatedly drops the least important feature. They capture interactions but cost many model fits and can overfit the validation criterion. **Embedded** methods select features as part of training, as with lasso\'s zero coefficients or the importance measures of tree ensembles.\n\nGood selection balances relevance to the target against redundancy among chosen features. Highly correlated features carry overlapping information, so keeping both adds little. Univariate scores can also miss a feature that is only useful in combination with another.\n\nSelection must be treated as part of model fitting. If you choose features using the whole dataset and then cross-validate, information from the validation folds has leaked into the choice and performance estimates become optimistic, particularly when there are many features and few samples. The selection step should be repeated inside each training fold. Feature selection is also not causal inference: a retained feature is predictive, not necessarily a cause.',
    math: [
      {
        label: 'Pearson correlation',
        tex: String.raw`r_{xy} \;=\; \frac{\sum_i (x_i-\bar{x})(y_i-\bar{y})}{\sqrt{\sum_i (x_i-\bar{x})^{2}}\;\sqrt{\sum_i (y_i-\bar{y})^{2}}}`,
        note: 'Measures linear association between a feature and the target, from -1 to 1. It misses non-linear relationships.'
      },
      {
        label: 'Mutual information',
        tex: String.raw`I(X;Y) \;=\; \sum_{x,y} p(x,y)\,\log\frac{p(x,y)}{p(x)\,p(y)}`,
        note: 'Zero when $X$ and $Y$ are independent; it also detects non-linear dependence.'
      }
    ],
    example: {
      title: 'A correlation filter with a redundant feature',
      body:
        'Five examples. Target $y$ = 1.1, 2.3, 2.9, 4.2, 4.8. Feature A = 1, 2, 3, 4, 5. Feature B = 2, 4, 6, 8, 11. Feature C = 5, 1, 4, 2, 3.\n\n**Correlation with y.** A: 0.993. B: 0.983. C: -0.395.\n\nA filter that keeps features with |r| above 0.5 retains A and B and drops C.\n\n**Redundancy check.** The correlation between A and B is 0.996, so they carry almost the same information. Keeping both adds little and can destabilise a linear model. Choosing A alone gives a smaller model with nearly the same predictive signal.\n\nThis is only a screening step: C might still help in combination with others, which a wrapper or embedded method could reveal.'
    },
    pros: [
      'Reduces overfitting by removing noisy or irrelevant inputs.',
      'Speeds up training and prediction.',
      'Gives smaller models that are easier to explain and maintain.',
      'Can cut data collection costs if some measurements are unnecessary.'
    ],
    cons: [
      'Selection done outside cross-validation leaks information and inflates scores.',
      'Filters can miss interactions and keep redundant features.',
      'Wrapper methods are expensive and can overfit.',
      'Selected features are predictive, not necessarily causal, and may change between samples.'
    ],
    applications: [
      'Choosing a short list of lab tests for a screening model, used as decision support only.',
      'Reducing thousands of gene-expression measurements to candidate markers for further study.',
      'Trimming features in a credit-risk or churn model for speed and auditability.',
      'Text classification by keeping the most informative words.'
    ],
    quiz: [
      {
        question: 'Which family of methods selects features as a by-product of training a model?',
        options: [
          'Filter methods',
          'Embedded methods',
          'Random sampling',
          'Unsupervised clustering'
        ],
        answerIndex: 1,
        explanation: 'Embedded methods such as lasso and tree-based importance choose features during fitting. Filters score features before any model is trained.'
      },
      {
        question: 'Two features each correlate 0.9 with the target and 0.98 with each other. What is the best approach?',
        options: [
          'Keep both because both are relevant.',
          'Drop both because they are correlated.',
          'Keep one, since the second adds little new information.',
          'Multiply them together to form one feature and discard the target.'
        ],
        answerIndex: 2,
        explanation: 'Relevance alone is not enough; the second feature is largely redundant. Dropping both would discard real signal.'
      },
      {
        question: 'Why is it wrong to select the top features using the full dataset and then run cross-validation?',
        options: [
          'Cross-validation cannot be used with feature selection.',
          'The chosen features have already seen the validation folds, so the estimate is optimistic.',
          'It increases the number of features.',
          'It makes the model underfit.'
        ],
        answerIndex: 1,
        explanation: 'Selection is part of the learning procedure. It must be repeated inside each training fold to avoid leakage.'
      }
    ],
    related: ['regularization', 'dimensionality-reduction', 'overfitting-underfitting', 'feature-importance'],
    keywords: ['feature selection', 'filter', 'wrapper', 'embedded', 'recursive feature elimination', 'correlation', 'mutual information', 'redundancy', 'lasso']
  },
  {
    id: 'hyperparameter-optimization',
    title: 'Hyperparameter optimization',
    category: 'advanced',
    summary: 'Hyperparameter optimization searches for the settings that are not learned from data, such as learning rate or tree depth, by comparing validation performance.',
    readingMinutes: 6,
    intro:
      'Most models have settings that training does not set for you: the learning rate, the number of trees, the strength of regularisation, the number of layers. These choices can change performance a great deal, and the right values depend on the data.\n\nAfter this lesson you will be able to tell parameters from hyperparameters, describe grid search, random search and Bayesian optimisation, calculate how many model fits a search costs, and set up the search without contaminating your final test estimate.',
    simple:
      'Baking bread, the recipe has ingredients you cannot change mid-bake, like oven temperature and baking time. The dough itself rises on its own, but you pick the temperature and time beforehand. Those pre-chosen dials are hyperparameters.\n\nTo find good dials you bake several loaves with different settings and taste each. You could try every combination on a neat table, or pick random combinations, or learn from earlier loaves which direction seems promising and try there next.\n\nOne rule matters: do the tasting with a panel that helps you adjust the recipe, and keep a different, fresh panel for the final verdict.',
    technical:
      'Parameters, such as regression coefficients or network weights, are learned by minimising the training loss. Hyperparameters are fixed before or around training and control model capacity, the optimiser or the penalty. Optimisation chooses hyperparameters $\\lambda$ to minimise an estimate of generalisation error, normally a validation score or a cross-validated score, $\\lambda^{*} = \\arg\\min_{\\lambda} \\, \\mathrm{CV}(\\lambda)$. This objective is noisy, expensive and usually not differentiable.\n\n**Grid search** evaluates every combination on a fixed grid; its cost multiplies across dimensions, and it wastes effort when only a few hyperparameters matter. **Random search** samples configurations from distributions, often on a log scale for rates and penalties. Bergstra and Bengio showed that random search tends to explore the important dimensions more efficiently than a grid of equal size when some hyperparameters matter much more than others. **Bayesian optimisation** fits a surrogate model, commonly a Gaussian process or tree-based model, of score as a function of the hyperparameters, and chooses the next trial by balancing exploitation and exploration. Early-stopping schemes such as successive halving and Hyperband drop poor configurations after a small budget.\n\nTwo cautions apply. The best cross-validated score from a large search is optimistically biased because it is the maximum over many noisy estimates, so the final generalisation estimate must come from data not used in the search, or from nested cross-validation. And every tuning decision, including preprocessing choices, counts as part of the search.',
    math: [
      {
        label: 'Search objective',
        tex: String.raw`\lambda^{*} \;=\; \arg\min_{\lambda \in \Lambda}\; \frac{1}{K}\sum_{k=1}^{K} L_{\text{val}}^{(k)}\!\big(\hat{\theta}_{\lambda}^{(k)}\big)`,
        note: '$\\Lambda$ is the search space, $K$ the number of folds, and $\\hat{\\theta}_{\\lambda}^{(k)}$ the parameters fitted on the training part of fold $k$ with hyperparameters $\\lambda$.'
      },
      {
        label: 'Chance random search hits a top fraction',
        tex: String.raw`P(\text{at least one hit}) \;=\; 1-(1-q)^{n}`,
        note: 'With $n$ independent random trials, $q$ is the fraction of the space that counts as good, for example the best 5 percent.'
      }
    ],
    example: {
      title: 'Counting the cost of a search',
      body:
        'Suppose we tune three hyperparameters: 3 values of learning rate, 4 values of depth and 5 values of regularisation strength.\n\n**Grid search.** 3 x 4 x 5 = 60 configurations. With 5-fold cross-validation each configuration needs 5 fits, so 300 fits in total.\n\n**Random search with the same 60 trials.** If the best 5 percent of the space counts as good, the chance that at least one trial lands there is 1 - 0.95^60 = 0.954. Even 14 random trials give 1 - 0.95^14 = 0.512, about an even chance.\n\nSo a modest random search has a high probability of reaching a near-best region, and the cost stays fixed however many hyperparameters we add, whereas the grid multiplies with each one.'
    },
    pros: [
      'Can improve performance substantially without changing the algorithm.',
      'Random search is simple, parallel and cost-controlled.',
      'Bayesian methods use fewer trials when each fit is expensive.',
      'Making the search explicit gives a reproducible record of how the model was tuned.'
    ],
    cons: [
      'Costly: each trial may need a full training run, often repeated across folds.',
      'Grid search scales exponentially with the number of hyperparameters.',
      'The best validation score is optimistically biased after a large search.',
      'Results depend on the chosen ranges and scales, which require judgement.'
    ],
    applications: [
      'Tuning learning rate, depth and number of trees in gradient-boosted models.',
      'Choosing the regularisation strength for ridge, lasso or logistic regression.',
      'Selecting k in k-nearest neighbours or kernel parameters in support vector machines.',
      'Configuring network architectures and training schedules.'
    ],
    quiz: [
      {
        question: 'Which of these is a hyperparameter rather than a learned parameter?',
        options: [
          'A weight in a neural network.',
          'The coefficient of a fitted linear model.',
          'The split threshold in a trained tree node.',
          'The maximum depth allowed for a tree.'
        ],
        answerIndex: 3,
        explanation: 'Depth limits are set before training. Weights, coefficients and split thresholds are all fitted from the data.'
      },
      {
        question: 'A grid search tunes 4 hyperparameters with 5 values each using 3-fold cross-validation. How many model fits does it perform?',
        options: [
          '20',
          '1875',
          '60',
          '625'
        ],
        answerIndex: 1,
        explanation: 'There are 5^4 = 625 configurations, each needing 3 fits, giving 1875. The grid grows exponentially with the number of hyperparameters.'
      },
      {
        question: 'Why is the best cross-validated score from a very large search too optimistic as a performance estimate?',
        options: [
          'Cross-validation always overestimates error.',
          'It is the maximum of many noisy estimates, so it partly reflects luck.',
          'Large searches reduce the amount of training data.',
          'Hyperparameters cannot be evaluated on validation data.'
        ],
        answerIndex: 1,
        explanation: 'Picking the best of many noisy scores selects favourable noise. An untouched test set or nested cross-validation gives an honest estimate.'
      },
      {
        question: 'What is the main idea of Bayesian optimisation?',
        options: [
          'Test every combination on a regular grid.',
          'Pick hyperparameters at random from a uniform distribution.',
          'Use gradient descent on the validation labels.',
          'Fit a surrogate model of the score and use it to choose the next trial.'
        ],
        answerIndex: 3,
        explanation: 'The surrogate summarises what past trials suggest and guides new ones toward promising or uncertain regions, which saves expensive evaluations.'
      }
    ],
    related: ['cross-validation', 'regularization', 'overfitting-underfitting', 'train-validation-test'],
    keywords: ['hyperparameter', 'grid search', 'random search', 'Bayesian optimisation', 'tuning', 'nested cross-validation', 'validation', 'search space']
  },
  {
    id: 'ensemble-learning',
    title: 'Ensemble learning',
    category: 'advanced',
    summary: 'Ensemble learning combines several models so that their individual errors partly cancel, usually giving more accurate and stable predictions than any single member.',
    readingMinutes: 7,
    intro:
      'A single model makes mistakes that come partly from the particular sample it saw and partly from its own limits. If different models make different mistakes, combining them can average those mistakes away. This idea sits behind some of the strongest methods for tabular data, including random forests and gradient boosting.\n\nAfter this lesson you will be able to explain bagging, boosting and stacking, calculate the accuracy of a majority vote, and say why diversity among members matters as much as their individual quality.',
    simple:
      'Ask one person to guess the number of sweets in a jar and the guess may be well off. Ask a hundred people and average the answers, and the errors in each direction tend to cancel, so the average is often closer than most individuals. That works only if people guess independently and their mistakes are not all the same.\n\nEnsembles do this with models. Some train many models on different random samples and let them vote. Others train models one after another, each concentrating on the examples the previous ones got wrong. Others let a final model learn how much to trust each of the others.\n\nA crowd that all copies the same neighbour gains nothing from being large, so the members must differ.',
    technical:
      '**Bagging** (bootstrap aggregating) trains each member on a bootstrap sample of the data, drawn with replacement, and averages predictions or takes a majority vote. It mainly reduces variance and suits unstable, low-bias learners such as deep decision trees. Random forests add random feature subsets at each split to further decorrelate trees. Out-of-bag examples, those left out of a member\'s sample, provide a free validation estimate.\n\n**Boosting** builds members sequentially, each focusing on what the current ensemble gets wrong. AdaBoost reweights misclassified examples; gradient boosting fits each new weak learner, usually a shallow tree, to the negative gradient of the loss, so the ensemble performs gradient descent in function space with a learning rate that shrinks each contribution. Boosting mainly reduces bias, can overfit if run for too many rounds, and is sensitive to label noise. **Stacking** trains a meta-model on the out-of-fold predictions of several different base models.\n\nFor $M$ predictors with equal variance $\\sigma^2$ and pairwise correlation $\\rho$, the variance of their average is $\\rho\\sigma^2 + \\frac{1-\\rho}{M}\\sigma^2$. Adding members shrinks only the second term, so the benefit is limited by the correlation between members. Costs include more computation, memory and latency, and reduced interpretability compared with a single small model.',
    math: [
      {
        label: 'Variance of an average of correlated predictors',
        tex: String.raw`\operatorname{Var}\!\left(\frac{1}{M}\sum_{m=1}^{M}\hat f_m\right) \;=\; \rho\,\sigma^{2} \;+\; \frac{1-\rho}{M}\,\sigma^{2}`,
        note: '$\\sigma^2$ is each member\'s variance and $\\rho$ their pairwise correlation. As $M$ grows the variance approaches $\\rho\\sigma^2$, not zero.'
      },
      {
        label: 'Majority vote of independent classifiers',
        tex: String.raw`P(\text{correct}) \;=\; \sum_{k=\lceil (M+1)/2\rceil}^{M}\binom{M}{k}\,p^{k}\,(1-p)^{M-k}`,
        note: '$M$ is odd, $p$ is each classifier\'s accuracy, and the votes are assumed independent.'
      },
      {
        label: 'Boosting update',
        tex: String.raw`F_m(x) \;=\; F_{m-1}(x) \;+\; \nu\, h_m(x)`,
        note: 'Each weak learner $h_m$ is fitted to the current residual direction, and $\\nu$ is the learning rate that shrinks its contribution.'
      }
    ],
    example: {
      title: 'Majority vote of three classifiers, each 70 percent accurate',
      body:
        'Assume the three classifiers err independently, each with accuracy $p = 0.7$. The vote is correct when at least 2 of 3 are correct.\n\n**Exactly 3 correct.** 0.7^3 = 0.343.\n\n**Exactly 2 correct.** 3 x 0.7^2 x 0.3 = 0.441.\n\n**Total.** 0.343 + 0.441 = 0.784, which beats each single member at 0.70.\n\nWith 5 voters the result is 0.837, and with 11 voters it is 0.922. These numbers rely on independence; if the voters make the same mistakes, which real models trained on the same data often do, the gain is much smaller, which is why diversity is encouraged by bootstrap sampling and random feature subsets.'
    },
    pros: [
      'Often more accurate and more stable than any single model.',
      'Bagging reduces variance and can be trained in parallel.',
      'Boosting can reach very high accuracy on tabular data.',
      'Out-of-bag estimates give a built-in validation check for bagged models.'
    ],
    cons: [
      'More computation, memory and prediction time.',
      'Harder to interpret than one tree or one linear model.',
      'Gains shrink when members make correlated errors.',
      'Boosting can overfit noisy labels and needs careful tuning.'
    ],
    applications: [
      'Random forests and gradient-boosted trees for tabular prediction.',
      'Stacked models in data science competitions.',
      'Combining several imaging or lab-based models into a more stable risk estimate, used as decision support only.',
      'Averaging forecasts from different time-series models.'
    ],
    quiz: [
      {
        question: 'Which ensemble method trains models sequentially, each focusing on the errors of earlier ones?',
        options: [
          'Bagging',
          'Boosting',
          'Random voting',
          'Bootstrap sampling without models'
        ],
        answerIndex: 1,
        explanation: 'Boosting is sequential. Bagging trains its members independently on bootstrap samples and so can run in parallel.'
      },
      {
        question: 'Three independent classifiers each have accuracy 0.8. What is the accuracy of their majority vote?',
        options: [
          '0.800',
          '0.896',
          '0.960',
          '0.512'
        ],
        answerIndex: 1,
        explanation: 'P = 0.8^3 + 3(0.8^2)(0.2) = 0.512 + 0.384 = 0.896. The value 0.512 is only the chance that all three are correct.'
      },
      {
        question: 'Why does adding more and more perfectly correlated members stop helping?',
        options: [
          'They have different training sets.',
          'The averaged variance cannot fall below $\\rho\\sigma^2$, so identical members add nothing.',
          'Ensembles can only contain ten members.',
          'The bias increases with every member.'
        ],
        answerIndex: 1,
        explanation: 'If members are identical, the average is identical to one member. Variance reduction needs members whose errors differ.'
      },
      {
        question: 'What mainly does bagging reduce?',
        options: [
          'Irreducible noise',
          'Training set size',
          'The number of features',
          'Variance'
        ],
        answerIndex: 3,
        explanation: 'Averaging many models fitted to resampled data smooths out sample-specific fluctuations, reducing variance. Noise in the target cannot be averaged away.'
      }
    ],
    related: ['random-forest', 'decision-trees', 'bias-variance-tradeoff', 'overfitting-underfitting'],
    keywords: ['ensemble', 'bagging', 'boosting', 'stacking', 'random forest', 'gradient boosting', 'majority vote', 'bootstrap', 'AdaBoost']
  }
];
