import type { CategoryInfo, LessonIndexEntry } from './types';

export const CATEGORIES: CategoryInfo[] = [
  { id: 'foundations', title: 'Machine learning foundations', blurb: 'What learning from data means, the kinds of problems it solves, and how data is organised.' },
  { id: 'supervised', title: 'Supervised learning', blurb: 'Models that learn from labelled examples: regression, classification and the classic algorithms.' },
  { id: 'unsupervised', title: 'Unsupervised learning', blurb: 'Finding structure in data that has no labels: clusters and low-dimensional views.' },
  { id: 'advanced', title: 'Advanced machine learning', blurb: 'Neural networks, optimisation and the ideas that decide whether a model generalises.' },
  { id: 'evaluation', title: 'Model evaluation', blurb: 'How to measure a model honestly: splits, metrics, curves and calibration.' },
  { id: 'explainable', title: 'Explainable machine learning', blurb: 'How to look inside predictions, and what explanations can and cannot tell you.' }
];

/** Master list: every lesson file must provide exactly these ids. Order is the reading order. */
export const LESSON_INDEX: LessonIndexEntry[] = [
  // Foundations
  { id: 'what-is-ml', title: 'What is machine learning?', category: 'foundations' },
  { id: 'ai-vs-ml-vs-dl', title: 'AI vs machine learning vs deep learning', category: 'foundations' },
  { id: 'types-of-ml', title: 'Types of machine learning', category: 'foundations' },
  { id: 'supervised-learning', title: 'Supervised learning', category: 'foundations' },
  { id: 'unsupervised-learning', title: 'Unsupervised learning', category: 'foundations' },
  { id: 'reinforcement-learning', title: 'Reinforcement learning', category: 'foundations' },
  { id: 'datasets-features-labels', title: 'Datasets, features, labels and targets', category: 'foundations' },
  { id: 'train-validation-test', title: 'Training, validation and testing', category: 'foundations' },
  { id: 'training-and-prediction', title: 'Model training and prediction', category: 'foundations' },
  { id: 'generalization', title: 'Generalization', category: 'foundations' },
  // Supervised
  { id: 'linear-regression', title: 'Linear regression', category: 'supervised', algorithmId: 'linear-regression' },
  { id: 'logistic-regression', title: 'Logistic regression', category: 'supervised', algorithmId: 'logistic-regression' },
  { id: 'decision-trees', title: 'Decision trees', category: 'supervised', algorithmId: 'decision-tree' },
  { id: 'random-forest', title: 'Random forest', category: 'supervised', algorithmId: 'random-forest' },
  { id: 'support-vector-machines', title: 'Support vector machines', category: 'supervised', algorithmId: 'svm' },
  { id: 'k-nearest-neighbors', title: 'K-nearest neighbors', category: 'supervised', algorithmId: 'knn' },
  { id: 'naive-bayes', title: 'Naive Bayes', category: 'supervised' },
  { id: 'classification-vs-regression', title: 'Classification vs regression', category: 'supervised' },
  // Unsupervised
  { id: 'k-means-clustering', title: 'K-means clustering', category: 'unsupervised', algorithmId: 'k-means' },
  { id: 'hierarchical-clustering', title: 'Hierarchical clustering', category: 'unsupervised' },
  { id: 'principal-component-analysis', title: 'Principal component analysis', category: 'unsupervised' },
  { id: 'dimensionality-reduction', title: 'Dimensionality reduction', category: 'unsupervised' },
  { id: 'clustering-evaluation', title: 'Clustering evaluation', category: 'unsupervised' },
  // Advanced
  { id: 'neural-networks', title: 'Neural networks', category: 'advanced' },
  { id: 'gradient-descent', title: 'Gradient descent', category: 'advanced' },
  { id: 'backpropagation', title: 'Backpropagation', category: 'advanced' },
  { id: 'loss-functions', title: 'Loss functions', category: 'advanced' },
  { id: 'overfitting-underfitting', title: 'Overfitting and underfitting', category: 'advanced' },
  { id: 'bias-variance-tradeoff', title: 'The bias-variance tradeoff', category: 'advanced' },
  { id: 'regularization', title: 'Regularization', category: 'advanced' },
  { id: 'feature-selection', title: 'Feature selection', category: 'advanced' },
  { id: 'hyperparameter-optimization', title: 'Hyperparameter optimization', category: 'advanced' },
  { id: 'ensemble-learning', title: 'Ensemble learning', category: 'advanced' },
  // Evaluation
  { id: 'train-test-split', title: 'Train/test split', category: 'evaluation' },
  { id: 'cross-validation', title: 'Cross-validation', category: 'evaluation' },
  { id: 'confusion-matrix', title: 'Confusion matrix', category: 'evaluation' },
  { id: 'accuracy', title: 'Accuracy', category: 'evaluation' },
  { id: 'precision', title: 'Precision', category: 'evaluation' },
  { id: 'recall', title: 'Recall (sensitivity)', category: 'evaluation' },
  { id: 'specificity', title: 'Specificity', category: 'evaluation' },
  { id: 'f1-score', title: 'F1 score', category: 'evaluation' },
  { id: 'roc-curve', title: 'ROC curve', category: 'evaluation' },
  { id: 'roc-auc', title: 'ROC-AUC', category: 'evaluation' },
  { id: 'precision-recall-curve', title: 'Precision-recall curve', category: 'evaluation' },
  { id: 'pr-auc', title: 'PR-AUC', category: 'evaluation' },
  { id: 'brier-score', title: 'Brier score', category: 'evaluation' },
  { id: 'probability-calibration', title: 'Probability calibration', category: 'evaluation' },
  // Explainable
  { id: 'model-interpretability', title: 'Model interpretability', category: 'explainable' },
  { id: 'feature-importance', title: 'Feature importance', category: 'explainable' },
  { id: 'shap', title: 'SHAP', category: 'explainable' },
  { id: 'global-explanations', title: 'Global explanations', category: 'explainable' },
  { id: 'local-explanations', title: 'Local explanations', category: 'explainable' },
  { id: 'explainability-in-healthcare', title: 'Explainability in healthcare', category: 'explainable' }
];
