import { CATEGORIES, LESSON_INDEX } from './lessonIndex';
import type { Lesson } from './types';
import { foundationsLessons } from './lessons/foundations';
import { supervisedLessons } from './lessons/supervised';
import { unsupervisedLessons } from './lessons/unsupervised';
import { advancedLessons } from './lessons/advanced';
import { evaluationLessons } from './lessons/evaluation';
import { explainableLessons } from './lessons/explainable';

const all: Lesson[] = [...foundationsLessons, ...supervisedLessons, ...unsupervisedLessons, ...advancedLessons, ...evaluationLessons, ...explainableLessons];
const byId = new Map(all.map((l) => [l.id, l]));
/** Lessons in the reading order defined by lessonIndex.ts. */
export const LESSONS: Lesson[] = LESSON_INDEX.map((e) => byId.get(e.id)).filter((l): l is Lesson => !!l);
export const getLesson = (id: string) => byId.get(id);
export { CATEGORIES, LESSON_INDEX };
export const lessonsIn = (cat: string) => LESSONS.filter((l) => l.category === cat);
