import type { CategoryId } from './types';
/**
 * Total reading time per track. Kept here so the home page does not have to load the lesson text.
 * tests/content.test.ts checks that these equal the sum of the lessons' readingMinutes.
 */
export const TRACK_MINUTES: Record<CategoryId, number> = { foundations: 55, supervised: 53, unsupervised: 36, advanced: 68, evaluation: 80, explainable: 39 };
export const TRACK_SUMMARY: Record<CategoryId, string> = {
  foundations: 'What learning from data means, the kinds of problems it solves, and how data is organised.',
  supervised: 'Models that learn from labelled examples: regression, classification and the classic algorithms.',
  unsupervised: 'Finding structure in data that has no labels: clusters and low-dimensional views.',
  advanced: 'Neural networks, optimisation and the ideas that decide whether a model generalises.',
  evaluation: 'How to measure a model honestly: splits, metrics, curves and calibration.',
  explainable: 'How to look inside predictions, and what explanations can and cannot tell you.'
};
