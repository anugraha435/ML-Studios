/**
 * Content schema for ML Studio lessons.
 *
 * Rich-text mini markup used in every string field except `title`, `summary` and `keywords`:
 *   - Paragraphs are separated by a blank line ("\n\n").
 *   - A paragraph whose lines all start with "- " is rendered as a bulleted list.
 *   - Inline: **bold**, *italic*, `code`, and $inline math$ (KaTeX, no nested dollar signs).
 *   - Display equations belong in `math` blocks, not in paragraphs.
 */
export type CategoryId = 'foundations' | 'supervised' | 'unsupervised' | 'advanced' | 'evaluation' | 'explainable';

export type AlgorithmId =
  | 'linear-regression'
  | 'logistic-regression'
  | 'decision-tree'
  | 'random-forest'
  | 'svm'
  | 'k-means'
  | 'knn';

export interface MathBlock {
  /** Short name of the equation, e.g. "Sigmoid function". */
  label: string;
  /** KaTeX source for a display equation. Use String.raw`...` so backslashes survive. */
  tex: string;
  /** One or two sentences explaining each symbol or what the equation means. Rich text allowed. */
  note?: string;
}

export interface QuizQuestion {
  question: string;
  /** 3 or 4 plausible options. */
  options: string[];
  answerIndex: number;
  /** Why the correct answer is right (and, where useful, why a tempting wrong one is wrong). */
  explanation: string;
}

export interface Lesson {
  /** kebab-case id; must match an entry in lessonIndex.ts. */
  id: string;
  title: string;
  category: CategoryId;
  /** One plain sentence (max ~28 words) used in lists and search results. */
  summary: string;
  readingMinutes: number;
  /** Why the topic matters and what the reader will understand afterwards. */
  intro: string;
  /** Plain-language explanation for a beginner, with an analogy or concrete picture. */
  simple: string;
  /** Precise explanation for a university student: definitions, procedure, assumptions, complexity or caveats. */
  technical: string;
  math?: MathBlock[];
  /** A small worked example with actual numbers that the reader can follow by hand. */
  example: { title: string; body: string };
  pros: string[];
  cons: string[];
  applications: string[];
  /** 3 or 4 knowledge-check questions. Vary the position of the correct option. */
  quiz: QuizQuestion[];
  /** Ids of related lessons (must exist in lessonIndex.ts). */
  related: string[];
  /** Links the lesson to an interactive algorithm page. */
  algorithmId?: AlgorithmId;
  keywords: string[];
}

export interface CategoryInfo {
  id: CategoryId;
  title: string;
  blurb: string;
}

export interface LessonIndexEntry {
  id: string;
  title: string;
  category: CategoryId;
  algorithmId?: AlgorithmId;
}
