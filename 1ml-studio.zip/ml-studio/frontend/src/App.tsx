import { Suspense, lazy } from 'react';
import { Route, Routes } from 'react-router-dom';
import Layout from './components/Layout';
import Home from './pages/Home';
import { Container } from './components/ui/Page';
import ErrorBoundary from './components/ErrorBoundary';

const Learn = lazy(() => import('./pages/LearnIndex'));
const LessonPage = lazy(() => import('./pages/LessonPage'));
const Algorithms = lazy(() => import('./pages/Algorithms').then((m) => ({ default: m.AlgorithmsIndex })));
const AlgorithmPage = lazy(() => import('./pages/Algorithms').then((m) => ({ default: m.AlgorithmPage })));
const Playground = lazy(() => import('./pages/Playground'));
const ResearchLayout = lazy(() => import('./pages/research/ResearchLayout'));
const ResearchOverview = lazy(() => import('./pages/research/Overview'));
const ResearchDemo = lazy(() => import('./pages/research/Demo'));
const ResearchPerformance = lazy(() => import('./pages/research/Performance'));
const ResearchExplain = lazy(() => import('./pages/research/Explain'));
const ResearchDataset = lazy(() => import('./pages/research/Dataset'));
const ResearchMethod = lazy(() => import('./pages/research/Methodology'));
const ResearchLimits = lazy(() => import('./pages/research/Limitations'));
const Docs = lazy(() => import('./pages/Docs'));
const About = lazy(() => import('./pages/About'));
const NotFound = lazy(() => import('./pages/NotFound'));

const Loading = () => (<Container className="py-24"><div role="status" aria-live="polite" className="flex items-center gap-3 text-muted"><span className="h-5 w-5 animate-spin rounded-full border-2 border-line border-t-accent" aria-hidden />Loading</div></Container>);

export default function App() {
  return (
    <ErrorBoundary>
      <Suspense fallback={<Loading />}>
        <Routes>
          <Route element={<Layout />}>
            <Route index element={<Home />} />
            <Route path="learn" element={<Learn />} />
            <Route path="learn/:id" element={<LessonPage />} />
            <Route path="algorithms" element={<Algorithms />} />
            <Route path="algorithms/:id" element={<AlgorithmPage />} />
            <Route path="playground" element={<Playground />} />
            <Route path="research" element={<ResearchLayout />}>
              <Route index element={<ResearchOverview />} />
              <Route path="demo" element={<ResearchDemo />} />
              <Route path="performance" element={<ResearchPerformance />} />
              <Route path="explainability" element={<ResearchExplain />} />
              <Route path="dataset" element={<ResearchDataset />} />
              <Route path="methodology" element={<ResearchMethod />} />
              <Route path="limitations" element={<ResearchLimits />} />
            </Route>
            <Route path="docs" element={<Docs />} />
            <Route path="about" element={<About />} />
            <Route path="*" element={<NotFound />} />
          </Route>
        </Routes>
      </Suspense>
    </ErrorBoundary>
  );
}
