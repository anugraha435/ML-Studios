import { applyPrepRecord } from '../data/preprocess';
import { fitKnn, kernelFn, knnRegress, predictLinear, argmax, argmin, type TreeNode } from '../ml/models';
import { dot, sigmoid } from '../ml/linalg';
import type { RunResult } from './run';

export interface Scored { label: string | number; probabilities?: { label: string; p: number }[]; note?: string }
const leaf = (root: TreeNode, r: number[]) => { let n = root; while (n.left && n.right) n = r[n.feature!] <= n.threshold! ? n.left : n.right; return n; };

/** Score one new record with a model returned by runModel (works across the worker boundary, which only carries plain data). */
export function scoreRecord(res: RunResult, rec: Record<string, number | string | null>): Scored {
  const { spec, kind, task, classLabels } = res.scorer; const payload: any = res.scorer.payload;
  const std = kind !== 'decision-tree' && kind !== 'random-forest';
  const x = applyPrepRecord(spec, rec, std);
  if (kind === 'k-means') { const c = payload.centroids as number[][]; const k = argmin(c.map((m) => m.reduce((s, v, j) => s + (v - x[j]) ** 2, 0))); return { label: `Cluster ${k + 1}`, note: 'Nearest centroid in standardised feature space.' }; }
  if (task === 'regression') {
    if (kind === 'linear-regression') return { label: +predictLinear(payload, [x])[0].toFixed(4) };
    return { label: +knnRegress(payload.X, payload.y, [x], payload.k)[0].toFixed(4) };
  }
  const K = classLabels!.length; let p: number[];
  if (kind === 'logistic-regression') {
    const ms = payload.model.models as { coef: number[]; intercept: number }[]; const q = ms.map((m) => sigmoid(m.intercept + dot(m.coef, x)));
    p = K === 2 ? [1 - q[0], q[0]] : (() => { const t = q.reduce((a, b) => a + b, 0) || 1; return q.map((v) => v / t); })();
  } else if (kind === 'decision-tree') { const n = leaf(payload.model.root, x); p = n.counts.map((c: number) => c / (n.n || 1)); }
  else if (kind === 'random-forest') { const acc = new Array<number>(K).fill(0); const trees = payload.model.trees as { root: TreeNode }[]; trees.forEach((t) => { const n = leaf(t.root, x); n.counts.forEach((c, i) => (acc[i] += c / (n.n || 1))); }); p = acc.map((v) => v / trees.length); }
  else if (kind === 'svm') {
    const ms = payload.model.models as { sv: number[][]; coef: number[]; rho: number; kernel: any }[];
    const dec = ms.map((m) => { const k = kernelFn(m.kernel); let s = -m.rho; m.sv.forEach((v, t) => (s += m.coef[t] * k(v, x))); return s; });
    p = K === 2 ? [1 - sigmoid(dec[0]), sigmoid(dec[0])] : (() => { const q = dec.map(sigmoid); const t = q.reduce((a, b) => a + b, 0) || 1; return q.map((v) => v / t); })();
  } else { p = fitKnn(payload.X, payload.y, payload.classes, payload.k, payload.weighted).predictProba([x])[0]; }
  return { label: classLabels![argmax(p)], probabilities: p.map((v, i) => ({ label: classLabels![i], p: v })) };
}
