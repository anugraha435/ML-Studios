import { runModel, type RunRequest } from './run';
self.onmessage = (e: MessageEvent<RunRequest | RunRequest[]>) => {
  try {
    const reqs = Array.isArray(e.data) ? e.data : [e.data];
    const out = reqs.map((r) => { try { return { ok: true as const, result: runModel(r) }; } catch (err) { return { ok: false as const, algo: r.algo, error: (err as Error).message }; } });
    (self as unknown as Worker).postMessage({ results: out });
  } catch (err) { (self as unknown as Worker).postMessage({ fatal: (err as Error).message }); }
};
