import { useCallback, useEffect, useRef } from 'react';
import type { RunRequest, RunResult } from './run';

export type Outcome = { ok: true; result: RunResult } | { ok: false; algo: string; error: string };
/** Runs training in a Web Worker so the page stays responsive. */
export function useTrainer() {
  const worker = useRef<Worker | null>(null);
  useEffect(() => () => { worker.current?.terminate(); }, []);
  return useCallback((reqs: RunRequest[], timeoutMs = 90000) => new Promise<Outcome[]>((resolve, reject) => {
    worker.current?.terminate();
    const w = new Worker(new URL('./worker.ts', import.meta.url), { type: 'module' }); worker.current = w;
    const t = setTimeout(() => { w.terminate(); reject(new Error('Training took longer than 90 seconds and was stopped. Try fewer rows, fewer trees or a simpler model.')); }, timeoutMs);
    w.onmessage = (e: MessageEvent<{ results?: Outcome[]; fatal?: string }>) => { clearTimeout(t); if (e.data.fatal) reject(new Error(e.data.fatal)); else resolve(e.data.results!); };
    w.onerror = (e) => { clearTimeout(t); reject(new Error(e.message || 'The training worker failed.')); };
    w.postMessage(reqs);
  }), []);
}
