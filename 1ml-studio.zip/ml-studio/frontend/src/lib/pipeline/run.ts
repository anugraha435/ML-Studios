import type { Table } from '../data/table';
import { applyPrep, fitPrep, inferTask, splitRows, type PrepSpec, type TaskType } from '../data/preprocess';
import { argmax, fitForest, fitKnn, fitLinear, fitLogistic, fitSvm, fitTree, kmeansFit, knnRegress, predictLinear, type Classifier, type Kernel } from '../ml/models';
import { brier, confusion, confusionMulti, f1, mae, precision, r2, recall, rmse, rocAuc, rocCurve, silhouette, specificity } from '../ml/metrics';
import { makeRng } from '../ml/rng';

export type AlgoId = 'linear-regression' | 'logistic-regression' | 'decision-tree' | 'random-forest' | 'svm' | 'knn' | 'k-means';
export interface Params {
  C: number; kernel: 'linear' | 'rbf' | 'poly'; gamma: number; degree: number;
  maxDepth: number; minSamplesSplit: number; nTrees: number; k: number; weighted: boolean; clusters: number; ridge: number; seed: number;
}
export const DEFAULT_PARAMS: Params = { C: 1, kernel: 'rbf', gamma: 0, degree: 3, maxDepth: 4, minSamplesSplit: 2, nTrees: 50, k: 5, weighted: false, clusters: 3, ridge: 0, seed: 42 };

export interface RunRequest { table: Table; algo: AlgoId; target: string | null; features: string[]; params: Params; task: TaskType; testFraction: number }
export interface RunResult {
  algo: AlgoId; task: TaskType | 'clustering'; nTrain: number; nTest: number; droppedTargetMissing: number;
  classLabels?: string[]; prepNotes: string[]; metrics: Record<string, number>;
  confusion?: number[][]; roc?: { fpr: number; tpr: number }[]; positiveClass?: string;
  testPreview: { actual: string | number; predicted: string | number; probability?: number }[];
  scatter?: { actual: number; predicted: number }[];
  importances?: { name: string; value: number; kind: string }[];
  cluster?: { assign: number[]; inertia: number; silhouette: number; sizes: number[]; iterations: number; xy: [number, number][]; centroidsXY: [number, number][]; axisNames: [string, string] };
  extra: string[]; ms: number;
  /** Everything needed to score a new record. */
  scorer: { spec: PrepSpec; classLabels?: string[]; task: TaskType | 'clustering'; kind: AlgoId; payload: unknown };
}

function resolveGamma(p: Params, d: number) { return p.gamma > 0 ? p.gamma : 1 / d; }
export function algoSupports(algo: AlgoId, task: TaskType | 'clustering'): boolean {
  if (algo === 'k-means') return task === 'clustering';
  if (algo === 'linear-regression') return task === 'regression';
  if (algo === 'logistic-regression') return task === 'classification';
  return task !== 'clustering';
}

export function runModel(req: RunRequest): RunResult {
  const t0 = performance.now();
  const { table, algo, params: p } = req;
  if (algo === 'k-means') return runKmeans(req, t0);
  if (!req.target) throw new Error('Choose a target column.');
  const tj = table.columns.findIndex((c) => c.name === req.target);
  if (tj < 0) throw new Error(`Target column "${req.target}" not found.`);
  const features = req.features.filter((f) => f !== req.target);
  if (features.length === 0) throw new Error('Select at least one input feature.');
  if (!algoSupports(algo, req.task)) throw new Error(`${algo} cannot be used for a ${req.task} target.`);

  const keep = table.rows.map((r, i) => (r[tj] === null ? -1 : i)).filter((i) => i >= 0);
  const dropped = table.rows.length - keep.length;
  let labels: string[] | undefined, y: number[];
  if (req.task === 'classification') {
    const raw = keep.map((i) => String(table.rows[i][tj]));
    labels = [...new Set(raw)].sort((a, b) => (isNaN(+a) || isNaN(+b) ? (a < b ? -1 : 1) : +a - +b));
    if (labels.length < 2) throw new Error('The target has only one class; nothing to learn.');
    if (labels.length > 12) throw new Error(`The target has ${labels.length} classes. Use at most 12, or treat the target as numeric.`);
    y = raw.map((v) => labels!.indexOf(v));
    const counts = labels.map((_, c) => y.filter((v) => v === c).length);
    if (Math.min(...counts) < 2) throw new Error('Every class needs at least 2 rows so it can appear in both the training and test sets.');
  } else y = keep.map((i) => table.rows[i][tj] as number);

  const rng = makeRng(p.seed);
  const sp = splitRows(keep.length, req.task === 'classification' ? y : null, req.testFraction, rng);
  const trRows = sp.train.map((k) => keep[k]), teRows = sp.test.map((k) => keep[k]);
  const ytr = sp.train.map((k) => y[k]), yte = sp.test.map((k) => y[k]);
  const std = algo !== 'decision-tree' && algo !== 'random-forest';
  const spec = fitPrep(table, features, trRows, std);
  const Xtr = applyPrep(spec, table, trRows, std), Xte = applyPrep(spec, table, teRows, std);
  const d = Xtr[0].length, K = labels?.length ?? 0;
  const res: RunResult = { algo, task: req.task, nTrain: trRows.length, nTest: teRows.length, droppedTargetMissing: dropped, classLabels: labels, prepNotes: spec.explanations,
    metrics: {}, testPreview: [], extra: [], ms: 0, scorer: { spec, classLabels: labels, task: req.task, kind: algo, payload: null } };
  if (dropped) res.prepNotes.unshift(`${dropped} row(s) with a missing target were removed before splitting.`);
  res.prepNotes.push(`Split: ${trRows.length} training rows and ${teRows.length} test rows (${req.task === 'classification' ? 'stratified by class' : 'random'}, seed ${p.seed}). All metrics below are measured on the test rows only.`);

  if (req.task === 'regression') {
    let pred: number[]; const imps: RunResult['importances'] = [];
    if (algo === 'linear-regression') {
      const m = fitLinear(Xtr, ytr, p.ridge); pred = predictLinear(m, Xte);
      spec.outputNames.forEach((n, i) => imps.push({ name: n, value: m.coef[i], kind: 'coefficient' }));
      res.extra.push(`Intercept ${m.intercept.toFixed(4)}.`); res.scorer.payload = m;
    } else if (algo === 'knn') { pred = knnRegress(Xtr, ytr, Xte, p.k); res.scorer.payload = { X: Xtr, y: ytr, k: p.k }; }
    else throw new Error('Regression is available for linear regression and k-nearest neighbours in this playground. Decision tree, random forest and SVM are offered for classification.');
    res.metrics = { r2: r2(yte, pred), rmse: rmse(yte, pred), mae: mae(yte, pred) };
    res.scatter = yte.map((a, i) => ({ actual: a, predicted: pred[i] }));
    res.testPreview = yte.slice(0, 15).map((a, i) => ({ actual: +a.toFixed(4), predicted: +pred[i].toFixed(4) }));
    res.importances = imps.sort((a, b) => Math.abs(b.value) - Math.abs(a.value)).slice(0, 15);
    res.ms = performance.now() - t0; return res;
  }

  let model: Classifier; let imps: RunResult['importances'];
  if (algo === 'logistic-regression') {
    const m = fitLogistic(Xtr, ytr, K, p.C); model = m;
    imps = spec.outputNames.map((n, i) => ({ name: n, value: m.models[0].coef[i], kind: K === 2 ? 'coefficient (log-odds per standard deviation)' : 'coefficient (class 0 vs rest)' }));
  } else if (algo === 'decision-tree') {
    const m = fitTree(Xtr, ytr, K, { maxDepth: p.maxDepth, minSamplesSplit: p.minSamplesSplit }); model = m;
    imps = spec.outputNames.map((n, i) => ({ name: n, value: m.importances[i], kind: 'impurity importance' }));
  } else if (algo === 'random-forest') {
    const m = fitForest(Xtr, ytr, K, { nTrees: p.nTrees, maxDepth: p.maxDepth, minSamplesSplit: p.minSamplesSplit, seed: p.seed }); model = m;
    const imp = new Array<number>(d).fill(0); m.trees.forEach((t) => t.importances.forEach((v, i) => (imp[i] += v / m.trees.length)));
    imps = spec.outputNames.map((n, i) => ({ name: n, value: imp[i], kind: 'mean impurity importance' }));
    if (m.oobScore !== null) res.extra.push(`Out-of-bag accuracy ${(m.oobScore * 100).toFixed(1)}% (computed on training rows each tree did not see).`);
  } else if (algo === 'svm') {
    const kernel: Kernel = p.kernel === 'linear' ? { type: 'linear' } : p.kernel === 'rbf' ? { type: 'rbf', gamma: resolveGamma(p, d) } : { type: 'poly', degree: p.degree, gamma: resolveGamma(p, d), coef0: 1 };
    if (trRows.length > 3000) throw new Error('SVM training is limited to 3000 training rows in the browser. Use a smaller file or another algorithm.');
    const m = fitSvm(Xtr, ytr, K, p.C, kernel); model = m;
    res.extra.push(`${m.models.map((b) => b.svIdx.length).join(' / ')} support vector(s). Scores are the SVM decision value passed through a logistic function; they are not calibrated probabilities.`);
  } else if (algo === 'knn') { model = fitKnn(Xtr, ytr, K, p.k, p.weighted); res.scorer.payload = { X: Xtr, y: ytr, k: p.k, weighted: p.weighted, classes: K, knn: true }; }
  else throw new Error(`Unknown algorithm ${algo}`);

  const proba = model.predictProba(Xte), pred = proba.map(argmax);
  res.metrics.accuracy = pred.filter((v, i) => v === yte[i]).length / yte.length;
  res.confusion = confusionMulti(yte, pred, K);
  if (K === 2) {
    const c = confusion(yte, pred); const s = proba.map((r) => r[1]);
    Object.assign(res.metrics, { precision: precision(c), recall: recall(c), specificity: specificity(c), f1: f1(c), roc_auc: rocAuc(yte, s), brier: brier(yte, s) });
    res.roc = rocCurve(yte, s); res.positiveClass = labels![1];
  } else {
    // macro-averaged one-vs-rest metrics
    let pr = 0, rc = 0, ff = 0;
    for (let c = 0; c < K; c++) { const cm = confusion(yte, pred, c); pr += precision(cm) || 0; rc += recall(cm) || 0; ff += f1(cm) || 0; }
    Object.assign(res.metrics, { macro_precision: pr / K, macro_recall: rc / K, macro_f1: ff / K });
  }
  res.testPreview = yte.slice(0, 15).map((a, i) => ({ actual: labels![a], predicted: labels![pred[i]], probability: +Math.max(...proba[i]).toFixed(4) }));
  res.importances = imps?.sort((a, b) => Math.abs(b.value) - Math.abs(a.value)).slice(0, 15);
  if (algo !== 'knn') res.scorer.payload = { model: serialise(algo, model) };
  res.ms = performance.now() - t0;
  return res;
}

/** Keep only what is needed for scoring new records (a plain closure cannot cross the worker boundary). */
function serialise(algo: AlgoId, model: Classifier): unknown {
  const m = model as any;
  if (algo === 'logistic-regression') return { models: m.models, classes: m.classes };
  if (algo === 'decision-tree') return { root: m.root, classes: m.classes };
  if (algo === 'random-forest') return { trees: m.trees.map((t: any) => ({ root: t.root })), classes: m.classes };
  if (algo === 'svm') return { models: m.models.map((b: any) => ({ sv: b.sv, coef: b.coef, rho: b.rho, kernel: b.kernel })), classes: m.classes };
  return null;
}

function runKmeans(req: RunRequest, t0: number): RunResult {
  const { table, params: p } = req;
  const features = req.features.filter((f) => f !== req.target);
  if (features.length < 1) throw new Error('Select at least one numeric feature.');
  for (const f of features) if (table.columns.find((c) => c.name === f)?.kind !== 'numeric') throw new Error(`K-means needs numeric features. "${f}" is categorical; deselect it.`);
  if (p.clusters < 2 || p.clusters > 12) throw new Error('Choose between 2 and 12 clusters.');
  const rows = table.rows.map((_, i) => i);
  const spec = fitPrep(table, features, rows, true);
  const X = applyPrep(spec, table, rows, true);
  const st = kmeansFit(X, p.clusters, p.seed);
  const sizes = new Array<number>(p.clusters).fill(0); st.assign.forEach((a) => sizes[a]++);
  const xy: [number, number][] = X.map((r) => [r[0], r[1] ?? 0]), cxy: [number, number][] = st.centroids.map((c) => [c[0], c[1] ?? 0]);
  return { algo: 'k-means', task: 'clustering', nTrain: X.length, nTest: 0, droppedTargetMissing: 0, prepNotes: [...spec.explanations, 'K-means is unsupervised: it uses all rows and no target. Scores describe cluster structure, not predictive accuracy.'],
    metrics: { inertia: st.inertia, silhouette: silhouette(X, st.assign) }, testPreview: [], extra: [`Converged after ${st.iteration} iteration(s).`],
    cluster: { assign: st.assign, inertia: st.inertia, silhouette: silhouette(X, st.assign), sizes, iterations: st.iteration, xy, centroidsXY: cxy, axisNames: [features[0], features[1] ?? '(none)'] },
    ms: performance.now() - t0, scorer: { spec, task: 'clustering', kind: 'k-means', payload: { centroids: st.centroids } } };
}

export { inferTask };
