/** Marching-squares line segments of f(x,y) = level over a rectangular domain. */
export function contourSegments(f: (x: number, y: number) => number, level: number, dom: { x: [number, number]; y: [number, number] }, res = 60): [number, number, number, number][] {
  const nx = res, ny = res, dx = (dom.x[1] - dom.x[0]) / nx, dy = (dom.y[1] - dom.y[0]) / ny;
  const v: number[][] = [];
  for (let j = 0; j <= ny; j++) { v[j] = []; for (let i = 0; i <= nx; i++) v[j][i] = f(dom.x[0] + i * dx, dom.y[0] + j * dy) - level; }
  const segs: [number, number, number, number][] = [];
  const interp = (x0: number, y0: number, v0: number, x1: number, y1: number, v1: number): [number, number] => { const t = v0 === v1 ? 0.5 : v0 / (v0 - v1); return [x0 + t * (x1 - x0), y0 + t * (y1 - y0)]; };
  for (let j = 0; j < ny; j++) for (let i = 0; i < nx; i++) {
    const x0 = dom.x[0] + i * dx, y0 = dom.y[0] + j * dy, x1 = x0 + dx, y1 = y0 + dy;
    const a = v[j][i], b = v[j][i + 1], c = v[j + 1][i + 1], d = v[j + 1][i];
    const idx = (a > 0 ? 1 : 0) | (b > 0 ? 2 : 0) | (c > 0 ? 4 : 0) | (d > 0 ? 8 : 0);
    if (idx === 0 || idx === 15) continue;
    const e = { bottom: () => interp(x0, y0, a, x1, y0, b), right: () => interp(x1, y0, b, x1, y1, c), top: () => interp(x0, y1, d, x1, y1, c), left: () => interp(x0, y0, a, x0, y1, d) };
    const push = (p: [number, number], q: [number, number]) => segs.push([p[0], p[1], q[0], q[1]]);
    switch (idx) {
      case 1: case 14: push(e.left(), e.bottom()); break;
      case 2: case 13: push(e.bottom(), e.right()); break;
      case 3: case 12: push(e.left(), e.right()); break;
      case 4: case 11: push(e.right(), e.top()); break;
      case 6: case 9: push(e.bottom(), e.top()); break;
      case 7: case 8: push(e.left(), e.top()); break;
      case 5: push(e.left(), e.top()); push(e.bottom(), e.right()); break;
      case 10: push(e.left(), e.bottom()); push(e.top(), e.right()); break;
    }
  }
  return segs;
}
