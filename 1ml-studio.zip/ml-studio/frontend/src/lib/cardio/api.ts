import type { RawRecord, ModelKey } from './inference';

/** Optional server-side inference. Set VITE_API_URL at build time (see .env.example). When unset the app uses in-browser inference only. */
export const API_URL: string = ((import.meta as any).env?.VITE_API_URL ?? '').replace(/\/$/, '');
export interface ApiPrediction { model: ModelKey; probability: number; threshold: number; classification: string; calibration: string }
export interface ApiContribution { feature: string; value: number | null; contribution: number }
export class ApiError extends Error { constructor(msg: string, public status?: number) { super(msg); } }

async function call<T>(path: string, init?: RequestInit): Promise<T> {
  if (!API_URL) throw new ApiError('No API URL is configured for this deployment.');
  const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 15000);
  try {
    const res = await fetch(`${API_URL}${path}`, { ...init, signal: ctl.signal, headers: { 'Content-Type': 'application/json' } });
    if (!res.ok) {
      let detail = `The server returned HTTP ${res.status}.`;
      try { const j = await res.json(); if (Array.isArray(j.detail)) detail = j.detail.map((d: any) => `${(d.loc ?? []).slice(1).join('.')}: ${d.msg}`).join('; '); else if (j.detail) detail = String(j.detail); } catch { /* keep default */ }
      throw new ApiError(res.status === 429 ? 'Too many requests. Wait a minute and try again.' : detail, res.status);
    }
    return (await res.json()) as T;
  } catch (e) {
    if (e instanceof ApiError) throw e;
    if ((e as Error).name === 'AbortError') throw new ApiError('The API did not answer within 15 seconds. It may be starting up; try again.');
    throw new ApiError('Could not reach the API server. Check your connection or use in-browser inference.');
  } finally { clearTimeout(t); }
}
const body = (rec: RawRecord, models?: ModelKey[]) => JSON.stringify({ features: rec, ...(models ? { models } : {}) });
export const apiHealth = () => call<{ status: string; model_loaded: boolean }>('/health');
export const apiPredict = (rec: RawRecord, models: ModelKey[] = ['lr', 'dt', 'rf', 'svm']) => call<{ predictions: ApiPrediction[]; notice: string }>('/api/v1/predict', { method: 'POST', body: body(rec, models) });
export const apiExplain = (rec: RawRecord, model: 'rf' | 'lr') => call<{ model: string; units: string; base_value: number; prediction_check: number; contributions: ApiContribution[]; notice: string }>(`/api/v1/explain/${model}`, { method: 'POST', body: body(rec) });
