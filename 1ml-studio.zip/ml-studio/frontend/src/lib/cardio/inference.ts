/**
 * Exact in-browser inference for the fitted CardioNepal scikit-learn models.
 * The fitted objects are exported to JSON by research/export_artifacts.py; this file only evaluates them
 * (imputation -> scaling -> one-hot -> classifier -> optional sigmoid calibration, averaged over CV members).
 * Parity with scikit-learn is asserted in tests/inference.parity.test.ts.
 */
export const FEATURES = ['age', 'trestbps', 'chol', 'thalach', 'oldpeak', 'ca', 'sex', 'fbs', 'exang', 'cp', 'restecg', 'slope', 'thal'] as const;
export type FeatureName = (typeof FEATURES)[number];
export type ModelKey = 'lr' | 'dt' | 'rf' | 'svm';
export type RawRecord = Record<FeatureName, number | null>;

interface Prep {
  numCols: string[]; binCols: string[]; catCols: string[];
  median: number[]; mean: number[]; scale: number[];
  catMostFrequent: number[]; categories: number[][];
}
interface TreeJson { left: number[]; right: number[]; feature: number[]; threshold: number[]; p1: number[] }
type Clf =
  | { kind: 'lr'; coef: number[]; intercept: number }
  | { kind: 'tree'; trees: TreeJson[] }
  | { kind: 'svm-rbf'; gamma: number; sv: number[][]; dual: number[]; intercept: number };
interface Member { pipeline: Prep; clf: Clf; calibration: { a: number; b: number } | null; trainMean?: number[] }
export interface ModelJson { threshold: number; calibration: 'none' | 'sigmoid'; members: Member[] }
export interface ModelBundle { features: string[]; models: Record<ModelKey, ModelJson> }

export function transform(p: Prep, rec: Record<string, number | null>): number[] {
  const out: number[] = [];
  p.numCols.forEach((c, i) => {
    const raw = rec[c];
    const v = raw == null || Number.isNaN(raw) ? p.median[i] : raw;
    out.push((v - p.mean[i]) / p.scale[i]);
  });
  p.binCols.forEach((c) => out.push(rec[c] as number));
  p.catCols.forEach((c, i) => {
    const raw = rec[c];
    const v = raw == null || Number.isNaN(raw) ? p.catMostFrequent[i] : raw;
    p.categories[i].forEach((cat) => out.push(v === cat ? 1 : 0));
  });
  return out;
}

const sigmoid = (z: number) => 1 / (1 + Math.exp(-z));

function treeProb(t: TreeJson, x: number[]): number {
  let n = 0;
  // scikit-learn trees compare float32 inputs against float64 thresholds
  while (t.left[n] !== -1) n = Math.fround(x[t.feature[n]]) <= t.threshold[n] ? t.left[n] : t.right[n];
  return t.p1[n];
}

/** Raw classifier score: probability for trees, probability for LR, decision value for SVM. */
function score(clf: Clf, x: number[]): number {
  if (clf.kind === 'lr') return sigmoid(clf.coef.reduce((s, w, i) => s + w * x[i], clf.intercept));
  if (clf.kind === 'tree') return clf.trees.reduce((s, t) => s + treeProb(t, x), 0) / clf.trees.length;
  let f = clf.intercept;
  for (let i = 0; i < clf.sv.length; i++) {
    let d2 = 0;
    const sv = clf.sv[i];
    for (let j = 0; j < sv.length; j++) d2 += (sv[j] - x[j]) ** 2;
    f += clf.dual[i] * Math.exp(-clf.gamma * d2);
  }
  return f;
}

export function predictProba(m: ModelJson, rec: Record<string, number | null>): number {
  let s = 0;
  for (const mem of m.members) {
    const raw = score(mem.clf, transform(mem.pipeline, rec));
    // scikit-learn _SigmoidCalibration: expit(-(a * score + b))
    s += mem.calibration ? sigmoid(-(mem.calibration.a * raw + mem.calibration.b)) : raw;
  }
  return s / m.members.length;
}

export function recordFromRow(row: (number | null)[]): RawRecord {
  const r = {} as RawRecord;
  FEATURES.forEach((f, i) => (r[f] = row[i]));
  return r;
}

export interface Contribution { feature: FeatureName; value: number | null; contribution: number }
/**
 * Exact linear SHAP for the logistic regression, in log-odds units: phi_j = w_j (x_j - mean_j) on the transformed
 * columns, summed back to the original 13 features. The mean is that of the background rows used for the published
 * SHAP values. base + sum(phi) equals the model's log-odds.
 */
export function explainLogistic(m: ModelJson, rec: Record<string, number | null>): { base: number; logit: number; contributions: Contribution[] } {
  const mem = m.members[0];
  if (mem.clf.kind !== 'lr' || !mem.trainMean) throw new Error('Linear SHAP needs the logistic regression with its background mean.');
  const x = transform(mem.pipeline, rec), p = mem.pipeline;
  const names: string[] = [...p.numCols, ...p.binCols, ...p.catCols.flatMap((c, i) => p.categories[i].map(() => c))];
  const phi = new Map<string, number>();
  const coef = mem.clf.coef;
  names.forEach((f, j) => phi.set(f, (phi.get(f) ?? 0) + coef[j] * (x[j] - mem.trainMean![j])));
  const base = mem.clf.intercept + coef.reduce((s, w, j) => s + w * mem.trainMean![j], 0);
  const contributions = FEATURES.map((f) => ({ feature: f, value: rec[f] ?? null, contribution: phi.get(f) ?? 0 }));
  return { base, logit: base + contributions.reduce((a, c) => a + c.contribution, 0), contributions };
}
