import { makeRng, randn } from '../ml/rng';
export interface LabeledPoint { x: number; y: number; c: number }
export type ShapeId = 'blobs' | 'moons' | 'circles' | 'xor' | 'overlap';
export const SHAPES: { id: ShapeId; label: string }[] = [
  { id: 'blobs', label: 'Two blobs' }, { id: 'overlap', label: 'Overlapping blobs' }, { id: 'moons', label: 'Two moons' }, { id: 'circles', label: 'Rings' }, { id: 'xor', label: 'XOR corners' }
];
const clamp = (v: number) => Math.min(9.8, Math.max(0.2, v));
/** Synthetic 2-D classification data in the square [0,10]^2. Generated from a seeded RNG; not real measurements. */
export function makeShape(shape: ShapeId, n = 80, seed = 1, noise = 0.6): LabeledPoint[] {
  const r = makeRng(seed), out: LabeledPoint[] = [], h = Math.floor(n / 2);
  const push = (x: number, y: number, c: number) => out.push({ x: clamp(x), y: clamp(y), c });
  for (let i = 0; i < n; i++) {
    const c = i < h ? 0 : 1;
    if (shape === 'blobs') push((c ? 7 : 3) + randn(r) * noise * 1.2, (c ? 6.5 : 3.5) + randn(r) * noise * 1.2, c);
    else if (shape === 'overlap') push((c ? 6 : 4) + randn(r) * 1.4, (c ? 5.8 : 4.2) + randn(r) * 1.4, c);
    else if (shape === 'moons') { const t = r() * Math.PI; push(c ? 5 + 2.8 * Math.cos(t) + 1.3 : 5 - 1.3 + 2.8 * Math.cos(t + Math.PI), c ? 3.6 - 2.8 * Math.sin(t) + 1.6 : 5.6 + 2.8 * Math.sin(t) - 1.6 + 0, c) ; out[out.length - 1].x = clamp(out[out.length - 1].x + randn(r) * noise * 0.5); out[out.length - 1].y = clamp(out[out.length - 1].y + randn(r) * noise * 0.5); }
    else if (shape === 'circles') { const t = r() * 2 * Math.PI, rad = c ? 3.6 : 1.5; push(5 + rad * Math.cos(t) + randn(r) * noise * 0.4, 5 + rad * Math.sin(t) + randn(r) * noise * 0.4, c); }
    else { const qx = r() < 0.5 ? 2.8 : 7.2, qy = r() < 0.5 ? 2.8 : 7.2; const cc = (qx > 5) === (qy > 5) ? 0 : 1; push(qx + randn(r) * noise, qy + randn(r) * noise, cc); }
  }
  return out;
}
export function makeBlobs(k: number, per = 25, seed = 4): { x: number; y: number }[] {
  const r = makeRng(seed), centres = [[2.5, 2.8], [7.4, 3], [5, 7.6], [8.2, 8], [1.8, 7.4], [5, 5]];
  const out: { x: number; y: number }[] = [];
  for (let c = 0; c < k; c++) for (let i = 0; i < per; i++) out.push({ x: clamp(centres[c][0] + randn(r) * 0.9), y: clamp(centres[c][1] + randn(r) * 0.9) });
  return out;
}
export function makeLine(n = 18, seed = 2): { x: number; y: number }[] {
  const r = makeRng(seed); const out: { x: number; y: number }[] = [];
  for (let i = 0; i < n; i++) { const x = 0.8 + (8.4 * i) / (n - 1) + (r() - 0.5) * 0.4; out.push({ x, y: clamp(1.6 + 0.62 * x + randn(r) * 0.8) }); }
  return out;
}
