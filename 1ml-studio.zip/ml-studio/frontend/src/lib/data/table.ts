import Papa from 'papaparse';

export type Cell = string | number | null;
export interface ColumnInfo {
  name: string; kind: 'numeric' | 'categorical'; missing: number; unique: number; sample: string[];
  /** Why the column is excluded from the default feature selection, if it is. */
  warning?: string;
}
export interface Table { columns: ColumnInfo[]; rows: Cell[][]; source: string; notes: string[] }

export const LIMITS = { maxBytes: 5 * 1024 * 1024, maxRows: 10000, maxCols: 100, minRows: 20 };
const MISSING = new Set(['', 'na', 'n/a', 'nan', 'null', 'none', '?', '-']);
export class DataError extends Error {}

export function validateFile(f: { name: string; size: number; type?: string }): void {
  if (!/\.(csv|txt)$/i.test(f.name)) throw new DataError('Unsupported file type. Upload a .csv file (comma, semicolon or tab separated).');
  if (f.type && !/(csv|text\/plain|excel|octet-stream)/i.test(f.type)) throw new DataError(`Unexpected file type "${f.type}". Upload a plain-text CSV file.`);
  if (f.size === 0) throw new DataError('The file is empty.');
  if (f.size > LIMITS.maxBytes) throw new DataError(`The file is ${(f.size / 1048576).toFixed(1)} MB. The limit is ${LIMITS.maxBytes / 1048576} MB.`);
}

export function parseCsvText(text: string, source: string): Table {
  const res = Papa.parse<string[]>(text.replace(/^﻿/, ''), { skipEmptyLines: 'greedy' });
  const fatal = res.errors.find((e) => e.type === 'Delimiter' ? false : e.code === 'TooManyFields' ? false : false);
  if (fatal) throw new DataError(fatal.message);
  const data = res.data;
  if (data.length < 2) throw new DataError('The file needs a header row and at least one data row.');
  const header = data[0].map((h) => String(h).trim());
  if (header.some((h) => h === '')) throw new DataError('Every column needs a name in the header row. Found an empty column name.');
  if (new Set(header).size !== header.length) throw new DataError('Column names must be unique. Rename the duplicated columns and upload again.');
  if (header.length < 2) throw new DataError('Found only one column. Check that the file uses commas, semicolons or tabs as separators.');
  if (header.length > LIMITS.maxCols) throw new DataError(`The file has ${header.length} columns. The limit is ${LIMITS.maxCols}.`);
  const body = data.slice(1);
  if (body.length > LIMITS.maxRows) throw new DataError(`The file has ${body.length} rows. The limit is ${LIMITS.maxRows}.`);
  if (body.length < LIMITS.minRows) throw new DataError(`The file has ${body.length} rows. At least ${LIMITS.minRows} are needed to train and test a model.`);
  const notes: string[] = [];
  const ragged = body.filter((r) => r.length !== header.length).length;
  if (ragged) notes.push(`${ragged} row(s) had a different number of fields than the header; missing fields were treated as missing values and extra fields were ignored.`);

  const raw = body.map((r) => header.map((_, j) => (r[j] ?? '').toString().trim()));
  const columns: ColumnInfo[] = header.map((name, j) => {
    const vals = raw.map((r) => r[j]);
    const present = vals.filter((v) => !MISSING.has(v.toLowerCase()));
    const numeric = present.length > 0 && present.every((v) => v !== '' && Number.isFinite(Number(v.replace(/,/g, '.') === v ? v : v)));
    const uniq = new Set(present);
    const info: ColumnInfo = { name, kind: numeric ? 'numeric' : 'categorical', missing: vals.length - present.length, unique: uniq.size, sample: [...uniq].slice(0, 4) };
    if (present.length === 0) info.warning = 'Every value is missing.';
    else if (uniq.size === 1) info.warning = 'Constant column (one distinct value) carries no information.';
    else if (!numeric && uniq.size > 20) info.warning = `Categorical with ${uniq.size} distinct values; looks like an identifier or free text.`;
    else if (numeric && uniq.size === present.length && present.length > 20 && /(^|_)id$|^id(_|$)|index/i.test(name)) info.warning = 'Looks like a row identifier.';
    return info;
  });
  const rows: Cell[][] = raw.map((r) => r.map((v, j) => (MISSING.has(v.toLowerCase()) ? null : columns[j].kind === 'numeric' ? Number(v) : v)));
  return { columns, rows, source, notes };
}

export async function readFile(f: File): Promise<Table> {
  validateFile(f);
  return parseCsvText(await f.text(), f.name);
}
