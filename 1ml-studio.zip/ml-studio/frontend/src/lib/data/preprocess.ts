import type { Cell, Table } from './table';
import { mean, std } from '../ml/linalg';

export type TaskType = 'classification' | 'regression';
export interface PrepSpec {
  features: { name: string; kind: 'numeric' | 'categorical'; fill: number | string; mean?: number; std?: number; levels?: string[] }[];
  outputNames: string[];
  explanations: string[];
}
const median = (a: number[]) => { const s = a.slice().sort((x, y) => x - y); const m = s.length >> 1; return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2; };

/** Fit the preprocessing on the TRAIN rows only (median / most-frequent imputation, standardise, one-hot). */
export function fitPrep(table: Table, featureNames: string[], trainRows: number[], standardize = true): PrepSpec {
  const explanations: string[] = [];
  const features: PrepSpec['features'] = [];
  const outputNames: string[] = [];
  for (const name of featureNames) {
    const j = table.columns.findIndex((c) => c.name === name), col = table.columns[j];
    const vals = trainRows.map((i) => table.rows[i][j]).filter((v): v is string | number => v !== null);
    if (col.kind === 'numeric') {
      const nums = vals as number[], med = nums.length ? median(nums) : 0, sd = nums.length ? std(nums) : 1;
      features.push({ name, kind: 'numeric', fill: med, mean: nums.length ? mean(nums) : 0, std: sd > 1e-12 ? sd : 1 });
      outputNames.push(name);
      if (col.missing) explanations.push(`${name}: ${col.missing} missing value(s) filled with the training-set median (${+med.toFixed(4)}).`);
    } else {
      const counts = new Map<string, number>(); (vals as string[]).forEach((v) => counts.set(v, (counts.get(v) ?? 0) + 1));
      const levels = [...counts.entries()].sort((a, b) => b[1] - a[1] || (a[0] < b[0] ? -1 : 1)).map((e) => e[0]).slice(0, 20).sort();
      const mode = [...counts.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] ?? '';
      features.push({ name, kind: 'categorical', fill: mode, levels });
      levels.forEach((l) => outputNames.push(`${name}=${l}`));
      explanations.push(`${name}: categorical with ${levels.length} level(s), one-hot encoded${col.missing ? `; missing values filled with the most frequent level ("${mode}")` : ''}. Unseen levels become all zeros.`);
    }
  }
  if (standardize) explanations.push('Numeric features are standardised (mean 0, standard deviation 1) using training-set statistics only, so no information from the test set leaks into training.');
  return { features, outputNames, explanations };
}

export function applyPrep(spec: PrepSpec, table: Table, rows: number[], standardize = true): number[][] {
  const idx = spec.features.map((f) => table.columns.findIndex((c) => c.name === f.name));
  return rows.map((i) => {
    const out: number[] = [];
    spec.features.forEach((f, k) => {
      const v: Cell = table.rows[i][idx[k]];
      if (f.kind === 'numeric') { const x = (v === null ? (f.fill as number) : (v as number)); out.push(standardize ? (x - f.mean!) / f.std! : x); }
      else { const x = v === null ? (f.fill as string) : (v as string); f.levels!.forEach((l) => out.push(x === l ? 1 : 0)); }
    });
    return out;
  });
}
export function applyPrepRecord(spec: PrepSpec, rec: Record<string, number | string | null>, standardize = true): number[] {
  const out: number[] = [];
  for (const f of spec.features) {
    const v = rec[f.name];
    if (f.kind === 'numeric') { const x = v === null || v === undefined || v === '' ? (f.fill as number) : Number(v); out.push(standardize ? (x - f.mean!) / f.std! : x); }
    else { const x = v === null || v === undefined || v === '' ? (f.fill as string) : String(v); f.levels!.forEach((l) => out.push(x === l ? 1 : 0)); }
  }
  return out;
}

/** Decide whether the target is a class label or a quantity. */
export function inferTask(table: Table, target: string): { task: TaskType; reason: string } {
  const j = table.columns.findIndex((c) => c.name === target), col = table.columns[j];
  if (col.kind === 'categorical') return { task: 'classification', reason: 'The target contains text categories.' };
  const vals = table.rows.map((r) => r[j]).filter((v): v is number => v !== null);
  const uniq = new Set(vals);
  const allInt = vals.every((v) => Number.isInteger(v));
  if (uniq.size <= 10 && allInt) return { task: 'classification', reason: `The target has only ${uniq.size} distinct whole-number values, so it is treated as class labels. Change the task if it is a count.` };
  return { task: 'regression', reason: `The target is numeric with ${uniq.size} distinct values, so it is treated as a quantity to predict.` };
}

/** Stratified (classification) or random (regression) split with a fixed seed. */
export function splitRows(n: number, labels: number[] | null, testFrac: number, rng: () => number): { train: number[]; test: number[] } {
  const train: number[] = [], test: number[] = [];
  const groups = new Map<number, number[]>();
  for (let i = 0; i < n; i++) { const k = labels ? labels[i] : 0; (groups.get(k) ?? groups.set(k, []).get(k)!).push(i); }
  for (const g of groups.values()) {
    for (let i = g.length - 1; i > 0; i--) { const j = Math.floor(rng() * (i + 1)); [g[i], g[j]] = [g[j], g[i]]; }
    const nt = g.length < 2 ? 0 : Math.max(1, Math.round(g.length * testFrac));
    test.push(...g.slice(0, nt)); train.push(...g.slice(nt));
  }
  return { train, test };
}
