import { LESSONS } from '../content';
import { ALGORITHMS } from '../data/algorithms';
import { DOC_SECTIONS } from '../data/docs';
import { plain } from '../components/RichText';

export interface SearchEntry { id: string; title: string; kind: 'Lesson' | 'Algorithm' | 'Research' | 'Documentation' | 'Page'; to: string; text: string; keywords: string }
const RESEARCH: SearchEntry[] = [
  ['Research overview', '/research', 'CardioNepal background problem statement objectives prototype architecture'],
  ['Model demonstration', '/research/demo', 'prediction form probability threshold explain inference FastAPI'],
  ['Model performance', '/research/performance', 'accuracy recall specificity precision f1 roc auc brier confusion matrix calibration curves'],
  ['Explainability (SHAP)', '/research/explainability', 'shap feature importance global local waterfall beeswarm permutation'],
  ['Research methodology', '/research/methodology', 'stratified split cross-validation threshold smote preprocessing leakage nested cv'],
  ['Dataset information', '/research/dataset', 'UCI Cleveland heart disease 303 records 13 features attributes'],
  ['Limitations and privacy', '/research/limitations', 'disclaimer not diagnosis Nepal population privacy limitations future work']
].map(([title, to, kw]) => ({ id: to, title, kind: 'Research' as const, to, text: kw, keywords: kw }));

const PAGES: SearchEntry[] = [
  ['Interactive playground', '/playground', 'upload csv train model compare algorithms sample datasets iris wine'],
  ['About ML Studio', '/about', 'about mission credits license']
].map(([title, to, kw]) => ({ id: to, title, kind: 'Page' as const, to, text: kw, keywords: kw }));

export const INDEX: SearchEntry[] = [
  ...LESSONS.map((l) => ({ id: l.id, title: l.title, kind: 'Lesson' as const, to: `/learn/${l.id}`, text: plain([l.summary, l.intro, l.simple].join(' ')), keywords: l.keywords.join(' ') })),
  ...ALGORITHMS.map((a) => ({ id: a.id, title: a.title, kind: 'Algorithm' as const, to: `/algorithms/${a.id}`, text: a.tagline + ' ' + plain(a.howItWorks.join(' ')), keywords: a.family })),
  ...RESEARCH, ...PAGES,
  ...DOC_SECTIONS.map((d) => ({ id: d.id, title: d.title, kind: 'Documentation' as const, to: `/docs#${d.id}`, text: plain(d.body.slice(0, 600)), keywords: d.title }))
];

export const SEARCH_INDEX = INDEX;
const norm = (s: string) => s.toLowerCase().normalize('NFKD').replace(/[^a-z0-9 ]+/g, ' ');
export function search(q: string, limit = 12): SearchEntry[] {
  const terms = norm(q).split(/\s+/).filter(Boolean);
  if (!terms.length) return [];
  const scored: { e: SearchEntry; s: number }[] = [];
  for (const e of INDEX) {
    const t = norm(e.title), k = norm(e.keywords), x = norm(e.text);
    let s = 0, ok = true;
    for (const term of terms) {
      let ts = 0;
      if (t === term) ts += 12; else if (t.startsWith(term)) ts += 9; else if (t.split(' ').some((w) => w.startsWith(term))) ts += 7; else if (t.includes(term)) ts += 5;
      if (k.includes(term)) ts += 3;
      if (x.includes(term)) ts += 1;
      if (ts === 0) { ok = false; break; }
      s += ts;
    }
    if (ok) scored.push({ e, s });
  }
  return scored.sort((a, b) => b.s - a.s || a.e.title.localeCompare(b.e.title)).slice(0, limit).map((o) => o.e);
}
