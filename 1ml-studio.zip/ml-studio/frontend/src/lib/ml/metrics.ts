export interface Confusion { tp: number; fp: number; tn: number; fn: number }
export function confusion(y: number[], pred: number[], positive = 1): Confusion {
  const c = { tp: 0, fp: 0, tn: 0, fn: 0 };
  y.forEach((t, i) => { const p = pred[i] === positive, a = t === positive; if (a && p) c.tp++; else if (!a && p) c.fp++; else if (!a && !p) c.tn++; else c.fn++; });
  return c;
}
const div = (a: number, b: number) => (b === 0 ? NaN : a / b);
export const accuracy = (c: Confusion) => div(c.tp + c.tn, c.tp + c.tn + c.fp + c.fn);
export const precision = (c: Confusion) => div(c.tp, c.tp + c.fp);
export const recall = (c: Confusion) => div(c.tp, c.tp + c.fn);
export const specificity = (c: Confusion) => div(c.tn, c.tn + c.fp);
export const f1 = (c: Confusion) => div(2 * c.tp, 2 * c.tp + c.fp + c.fn);
/** ROC-AUC via the rank-sum (Mann-Whitney) identity; ties get average rank. */
export function rocAuc(y: number[], score: number[]): number {
  const idx = score.map((_, i) => i).sort((a, b) => score[a] - score[b]);
  const rank = new Array<number>(score.length);
  for (let i = 0; i < idx.length;) { let j = i; while (j + 1 < idx.length && score[idx[j + 1]] === score[idx[i]]) j++; const r = (i + j) / 2 + 1; for (let k = i; k <= j; k++) rank[idx[k]] = r; i = j + 1; }
  const np = y.filter((v) => v === 1).length, nn = y.length - np;
  if (!np || !nn) return NaN;
  const sp = y.reduce((s, v, i) => s + (v === 1 ? rank[i] : 0), 0);
  return (sp - (np * (np + 1)) / 2) / (np * nn);
}
export function rocCurve(y: number[], score: number[]): { fpr: number; tpr: number }[] {
  const np = y.filter((v) => v === 1).length, nn = y.length - np;
  const order = score.map((_, i) => i).sort((a, b) => score[b] - score[a]);
  const pts = [{ fpr: 0, tpr: 0 }]; let tp = 0, fp = 0;
  for (let k = 0; k < order.length; k++) {
    if (y[order[k]] === 1) tp++; else fp++;
    if (k === order.length - 1 || score[order[k + 1]] !== score[order[k]]) pts.push({ fpr: fp / nn, tpr: tp / np });
  }
  return pts;
}
export const brier = (y: number[], p: number[]) => y.reduce((s, t, i) => s + (p[i] - t) ** 2, 0) / y.length;
export const rmse = (y: number[], p: number[]) => Math.sqrt(y.reduce((s, t, i) => s + (p[i] - t) ** 2, 0) / y.length);
export const mae = (y: number[], p: number[]) => y.reduce((s, t, i) => s + Math.abs(p[i] - t), 0) / y.length;
export function r2(y: number[], p: number[]): number {
  const m = y.reduce((a, b) => a + b, 0) / y.length;
  const ssTot = y.reduce((s, t) => s + (t - m) ** 2, 0), ssRes = y.reduce((s, t, i) => s + (t - p[i]) ** 2, 0);
  return ssTot === 0 ? NaN : 1 - ssRes / ssTot;
}
export function confusionMulti(y: number[], pred: number[], k: number): number[][] {
  const m = Array.from({ length: k }, () => new Array<number>(k).fill(0));
  y.forEach((t, i) => m[t][pred[i]]++);
  return m;
}
export function silhouette(X: number[][], assign: number[]): number {
  const k = Math.max(...assign) + 1; if (k < 2) return NaN;
  const d = (a: number[], b: number[]) => Math.hypot(...a.map((v, j) => v - b[j]));
  let tot = 0;
  for (let i = 0; i < X.length; i++) {
    const sums = new Array<number>(k).fill(0), cnt = new Array<number>(k).fill(0);
    for (let j = 0; j < X.length; j++) if (j !== i) { sums[assign[j]] += d(X[i], X[j]); cnt[assign[j]]++; }
    if (cnt[assign[i]] === 0) continue;
    const a = sums[assign[i]] / cnt[assign[i]];
    let b = Infinity; for (let c = 0; c < k; c++) if (c !== assign[i] && cnt[c]) b = Math.min(b, sums[c] / cnt[c]);
    tot += (b - a) / Math.max(a, b);
  }
  return tot / X.length;
}
