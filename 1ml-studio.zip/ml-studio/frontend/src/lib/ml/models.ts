/**
 * From-scratch implementations of the algorithms taught on ML Studio. They run in the browser on small data.
 * Conventions: X is n x d (rows are samples); classification labels are integers 0..K-1.
 */
import { dot, sigmoid, solve } from './linalg';
import { makeRng, type Rng } from './rng';

export interface Classifier {
  classes: number;
  /** Probability-like score per class (rows sum to 1). SVM scores are squashed decision values, not calibrated. */
  predictProba(X: number[][]): number[][];
}
export const argmax = (a: number[]) => a.reduce((b, v, i) => (v > a[b] ? i : b), 0);
export const predictClass = (m: Classifier, X: number[][]) => m.predictProba(X).map(argmax);

/* ------------------------------------------------------------------ linear regression */
export interface LinearModel { coef: number[]; intercept: number }
/** Ordinary least squares (ridge penalty `l2` on the slopes only) via the normal equations. */
export function fitLinear(X: number[][], y: number[], l2 = 0): LinearModel {
  const n = X.length, d = X[0].length;
  const A = Array.from({ length: d + 1 }, () => new Array<number>(d + 1).fill(0));
  const b = new Array<number>(d + 1).fill(0);
  for (let i = 0; i < n; i++) {
    const r = [1, ...X[i]];
    for (let p = 0; p <= d; p++) { b[p] += r[p] * y[i]; for (let q = 0; q <= d; q++) A[p][q] += r[p] * r[q]; }
  }
  for (let p = 1; p <= d; p++) A[p][p] += l2;
  if (l2 === 0) for (let p = 0; p <= d; p++) A[p][p] += 1e-10; // numerical guard only
  const w = solve(A, b);
  return { intercept: w[0], coef: w.slice(1) };
}
export const predictLinear = (m: LinearModel, X: number[][]) => X.map((r) => m.intercept + dot(m.coef, r));

/* ------------------------------------------------------------------ logistic regression */
export interface BinaryLogit { coef: number[]; intercept: number }
/** L2-penalised logistic regression fitted by Newton / IRLS. Penalty is (1/(2C)) * ||w||^2 on a sum-of-losses objective, as in scikit-learn. */
export function fitLogisticBinary(X: number[][], y: number[], C = 1, maxIter = 100): BinaryLogit {
  const n = X.length, d = X[0].length, lam = 1 / C;
  let w = new Array<number>(d + 1).fill(0);
  for (let it = 0; it < maxIter; it++) {
    const g = new Array<number>(d + 1).fill(0);
    const H = Array.from({ length: d + 1 }, () => new Array<number>(d + 1).fill(0));
    for (let i = 0; i < n; i++) {
      const r = [1, ...X[i]];
      const p = sigmoid(dot(w, r));
      const s = Math.max(p * (1 - p), 1e-9);
      for (let a = 0; a <= d; a++) { g[a] += (p - y[i]) * r[a]; for (let c = 0; c <= d; c++) H[a][c] += s * r[a] * r[c]; }
    }
    for (let a = 1; a <= d; a++) { g[a] += lam * w[a]; H[a][a] += lam; }
    H[0][0] += 1e-10;
    const step = solve(H, g);
    w = w.map((v, i) => v - step[i]);
    if (Math.max(...step.map(Math.abs)) < 1e-9) break;
  }
  return { intercept: w[0], coef: w.slice(1) };
}
export function fitLogistic(X: number[][], y: number[], classes: number, C = 1): Classifier & { models: BinaryLogit[] } {
  const k = classes === 2 ? 1 : classes;
  const models = Array.from({ length: k }, (_, c) => fitLogisticBinary(X, y.map((v) => (classes === 2 ? v : v === c ? 1 : 0)), C));
  return {
    classes, models,
    predictProba(Z) {
      return Z.map((r) => {
        const p = models.map((m) => sigmoid(m.intercept + dot(m.coef, r)));
        if (classes === 2) return [1 - p[0], p[0]];
        const s = p.reduce((a, b) => a + b, 0) || 1;
        return p.map((v) => v / s);
      });
    }
  };
}

/* ------------------------------------------------------------------ decision tree (CART, Gini) */
export interface TreeNode {
  id: number; depth: number; n: number; counts: number[]; gini: number;
  feature?: number; threshold?: number; left?: TreeNode; right?: TreeNode; gain?: number;
}
export interface TreeOptions { maxDepth: number; minSamplesSplit: number; maxFeatures?: number; rng?: Rng }
export const giniOf = (counts: number[]) => { const n = counts.reduce((a, b) => a + b, 0); return n ? 1 - counts.reduce((s, c) => s + (c / n) ** 2, 0) : 0; };

export function fitTree(X: number[][], y: number[], classes: number, opt: TreeOptions, rows?: number[]): Classifier & { root: TreeNode; importances: number[] } {
  const d = X[0].length;
  const idx0 = rows ?? X.map((_, i) => i);
  let nextId = 0;
  const imp = new Array<number>(d).fill(0);
  const rng = opt.rng ?? makeRng(1);
  const countOf = (idx: number[]) => { const c = new Array<number>(classes).fill(0); for (const i of idx) c[y[i]]++; return c; };

  function build(idx: number[], depth: number): TreeNode {
    const counts = countOf(idx);
    const node: TreeNode = { id: nextId++, depth, n: idx.length, counts, gini: giniOf(counts) };
    if (depth >= opt.maxDepth || idx.length < opt.minSamplesSplit || node.gini === 0) return node;
    let feats = Array.from({ length: d }, (_, i) => i);
    if (opt.maxFeatures && opt.maxFeatures < d) { for (let i = d - 1; i > 0; i--) { const j = Math.floor(rng() * (i + 1)); [feats[i], feats[j]] = [feats[j], feats[i]]; } feats = feats.slice(0, opt.maxFeatures); }
    let best = { gain: 1e-12, f: -1, t: 0 };
    for (const f of feats) {
      const order = idx.slice().sort((a, b) => X[a][f] - X[b][f]);
      const left = new Array<number>(classes).fill(0), right = counts.slice();
      for (let k = 0; k < order.length - 1; k++) {
        const c = y[order[k]]; left[c]++; right[c]--;
        const v = X[order[k]][f], nv = X[order[k + 1]][f];
        if (v === nv) continue;
        const nl = k + 1, nr = order.length - nl;
        const gain = node.gini - (nl / order.length) * giniOf(left) - (nr / order.length) * giniOf(right);
        if (gain > best.gain) best = { gain, f, t: (v + nv) / 2 };
      }
    }
    if (best.f < 0) return node;
    const L: number[] = [], R: number[] = [];
    for (const i of idx) (X[i][best.f] <= best.t ? L : R).push(i);
    node.feature = best.f; node.threshold = best.t; node.gain = best.gain;
    imp[best.f] += best.gain * idx.length;
    node.left = build(L, depth + 1); node.right = build(R, depth + 1);
    return node;
  }
  const root = build(idx0, 0);
  const tot = imp.reduce((a, b) => a + b, 0) || 1;
  const leaf = (r: number[]) => { let n = root; while (n.left && n.right) n = r[n.feature!] <= n.threshold! ? n.left : n.right; return n; };
  return {
    classes, root, importances: imp.map((v) => v / tot),
    predictProba: (Z) => Z.map((r) => { const n = leaf(r); const s = n.n || 1; return n.counts.map((c) => c / s); })
  };
}
export function treeLeafPath(root: TreeNode, r: number[]): TreeNode[] {
  const path = [root]; let n = root;
  while (n.left && n.right) { n = r[n.feature!] <= n.threshold! ? n.left : n.right; path.push(n); }
  return path;
}

/* ------------------------------------------------------------------ random forest */
export interface Forest extends Classifier { trees: ReturnType<typeof fitTree>[]; inBag: number[][]; oobScore: number | null }
export function fitForest(X: number[][], y: number[], classes: number, o: { nTrees: number; maxDepth: number; minSamplesSplit?: number; maxFeatures?: number; seed?: number }): Forest {
  const n = X.length, d = X[0].length, rng = makeRng(o.seed ?? 7);
  const mf = o.maxFeatures ?? Math.max(1, Math.round(Math.sqrt(d)));
  const trees: ReturnType<typeof fitTree>[] = [], inBag: number[][] = [];
  for (let t = 0; t < o.nTrees; t++) {
    const rows = Array.from({ length: n }, () => Math.floor(rng() * n));
    inBag.push(rows);
    trees.push(fitTree(X, y, classes, { maxDepth: o.maxDepth, minSamplesSplit: o.minSamplesSplit ?? 2, maxFeatures: mf, rng }, rows));
  }
  const avg = (Z: number[][], which?: number[]) => Z.map((r, zi) => {
    const acc = new Array<number>(classes).fill(0); let c = 0;
    trees.forEach((tr, ti) => { if (which && which[zi] !== undefined && inBag[ti].includes(which[zi])) return; const p = tr.predictProba([r])[0]; p.forEach((v, k) => (acc[k] += v)); c++; });
    return c ? acc.map((v) => v / c) : acc.map(() => 1 / classes);
  });
  let oob: number | null = null;
  if (n <= 1500) {
    const bagSets = inBag.map((b) => new Set(b));
    let ok = 0, cnt = 0;
    for (let i = 0; i < n; i++) {
      const acc = new Array<number>(classes).fill(0); let c = 0;
      trees.forEach((tr, ti) => { if (!bagSets[ti].has(i)) { tr.predictProba([X[i]])[0].forEach((v, k) => (acc[k] += v)); c++; } });
      if (c) { cnt++; if (argmax(acc) === y[i]) ok++; }
    }
    oob = cnt ? ok / cnt : null;
  }
  return { classes, trees, inBag, oobScore: oob, predictProba: (Z) => avg(Z) };
}

/* ------------------------------------------------------------------ k-nearest neighbours */
export function fitKnn(X: number[][], y: number[], classes: number, k = 5, weighted = false): Classifier {
  return {
    classes,
    predictProba(Z) {
      return Z.map((r) => {
        const d = X.map((x, i) => ({ i, d: Math.hypot(...x.map((v, j) => v - r[j])) })).sort((a, b) => a.d - b.d).slice(0, Math.min(k, X.length));
        const acc = new Array<number>(classes).fill(0);
        for (const { i, d: dist } of d) acc[y[i]] += weighted ? 1 / (dist + 1e-9) : 1;
        const s = acc.reduce((a, b) => a + b, 0) || 1;
        return acc.map((v) => v / s);
      });
    }
  };
}
export function knnRegress(X: number[][], y: number[], Z: number[][], k = 5): number[] {
  return Z.map((r) => { const d = X.map((x, i) => ({ i, d: Math.hypot(...x.map((v, j) => v - r[j])) })).sort((a, b) => a.d - b.d).slice(0, k); return d.reduce((s, o) => s + y[o.i], 0) / d.length; });
}

/* ------------------------------------------------------------------ support vector machine (SMO, libsvm-style WSS1) */
export type Kernel = { type: 'linear' } | { type: 'rbf'; gamma: number } | { type: 'poly'; degree: number; gamma: number; coef0: number };
export function kernelFn(k: Kernel) {
  if (k.type === 'linear') return (a: number[], b: number[]) => dot(a, b);
  if (k.type === 'rbf') return (a: number[], b: number[]) => { let s = 0; for (let i = 0; i < a.length; i++) s += (a[i] - b[i]) ** 2; return Math.exp(-k.gamma * s); };
  return (a: number[], b: number[]) => (k.gamma * dot(a, b) + k.coef0) ** k.degree;
}
export interface BinarySvm { sv: number[][]; svIdx: number[]; coef: number[]; rho: number; kernel: Kernel; decision(Z: number[][]): number[]; alpha: number[]; iterations: number }
/** Binary soft-margin SVM; y01 are 0/1 labels. Equivalent to scikit-learn's SVC(kernel, C, gamma). */
export function fitSvmBinary(X: number[][], y01: number[], C: number, kernel: Kernel, tol = 1e-4, maxIter = 100000): BinarySvm {
  const n = X.length, y = y01.map((v) => (v === 1 ? 1 : -1)), K = kernelFn(kernel);
  const Q: Float64Array[] = Array.from({ length: n }, () => new Float64Array(n));
  for (let i = 0; i < n; i++) for (let j = i; j < n; j++) { const v = K(X[i], X[j]); Q[i][j] = v; Q[j][i] = v; }
  const alpha = new Float64Array(n), G = new Float64Array(n).fill(-1);
  let it = 0;
  for (; it < maxIter; it++) {
    let i = -1, Gmax = -Infinity, Gmin = Infinity, j = -1;
    for (let t = 0; t < n; t++) {
      const up = (y[t] === 1 && alpha[t] < C) || (y[t] === -1 && alpha[t] > 0);
      if (up && -y[t] * G[t] > Gmax) { Gmax = -y[t] * G[t]; i = t; }
    }
    for (let t = 0; t < n; t++) {
      const low = (y[t] === 1 && alpha[t] > 0) || (y[t] === -1 && alpha[t] < C);
      if (low && -y[t] * G[t] < Gmin) { Gmin = -y[t] * G[t]; j = t; }
    }
    if (i < 0 || j < 0 || Gmax - Gmin < tol) break;
    // second-order working-set choice for j (Fan, Chen & Lin 2005)
    let bestObj = Infinity, jj = j;
    for (let t = 0; t < n; t++) {
      const low = (y[t] === 1 && alpha[t] > 0) || (y[t] === -1 && alpha[t] < C);
      if (!low) continue;
      const b = Gmax + y[t] * G[t];
      if (b > 0) { const a = Math.max(Q[i][i] + Q[t][t] - 2 * Q[i][t], 1e-12); const o = -(b * b) / a; if (o < bestObj) { bestObj = o; jj = t; } }
    }
    j = jj;
    const oldAi = alpha[i], oldAj = alpha[j];
    if (y[i] !== y[j]) {
      const quad = Math.max(Q[i][i] + Q[j][j] - 2 * Q[i][j], 1e-12);
      const delta = (-G[i] - G[j]) / quad, diff = alpha[i] - alpha[j];
      alpha[i] += delta; alpha[j] += delta;
      if (diff > 0) { if (alpha[j] < 0) { alpha[j] = 0; alpha[i] = diff; } } else if (alpha[i] < 0) { alpha[i] = 0; alpha[j] = -diff; }
      if (diff > 0) { if (alpha[i] > C) { alpha[i] = C; alpha[j] = C - diff; } } else if (alpha[j] > C) { alpha[j] = C; alpha[i] = C + diff; }
    } else {
      const quad = Math.max(Q[i][i] + Q[j][j] - 2 * Q[i][j], 1e-12);
      const delta = (G[i] - G[j]) / quad, sum = alpha[i] + alpha[j];
      alpha[i] -= delta; alpha[j] += delta;
      if (sum > C) { if (alpha[i] > C) { alpha[i] = C; alpha[j] = sum - C; } } else if (alpha[j] < 0) { alpha[j] = 0; alpha[i] = sum; }
      if (sum > C) { if (alpha[j] > C) { alpha[j] = C; alpha[i] = sum - C; } } else if (alpha[i] < 0) { alpha[i] = 0; alpha[j] = sum; }
    }
    const dAi = alpha[i] - oldAi, dAj = alpha[j] - oldAj;
    for (let t = 0; t < n; t++) G[t] += y[t] * (y[i] * Q[t][i] * dAi + y[j] * Q[t][j] * dAj);
  }
  // bias (rho) as in libsvm: mean of y*G over free vectors, else midpoint of bounds
  let ub = Infinity, lb = -Infinity, sumFree = 0, nFree = 0;
  for (let t = 0; t < n; t++) {
    const yG = y[t] * G[t];
    if (alpha[t] >= C) { if (y[t] === -1) ub = Math.min(ub, yG); else lb = Math.max(lb, yG); }
    else if (alpha[t] <= 0) { if (y[t] === 1) ub = Math.min(ub, yG); else lb = Math.max(lb, yG); }
    else { nFree++; sumFree += yG; }
  }
  const rho = nFree > 0 ? sumFree / nFree : (ub + lb) / 2;
  const svIdx = Array.from({ length: n }, (_, t) => t).filter((t) => alpha[t] > 1e-8);
  const sv = svIdx.map((t) => X[t]), coef = svIdx.map((t) => alpha[t] * y[t]);
  return { sv, svIdx, coef, rho, kernel, alpha: Array.from(alpha), iterations: it,
    decision: (Z) => Z.map((r) => { let s = -rho; for (let t = 0; t < sv.length; t++) s += coef[t] * K(sv[t], r); return s; }) };
}
export function fitSvm(X: number[][], y: number[], classes: number, C: number, kernel: Kernel): Classifier & { models: BinarySvm[] } {
  const k = classes === 2 ? 1 : classes;
  const models = Array.from({ length: k }, (_, c) => fitSvmBinary(X, y.map((v) => (classes === 2 ? v : v === c ? 1 : 0)), C, kernel));
  return {
    classes, models,
    predictProba(Z) {
      const dec = models.map((m) => m.decision(Z));
      return Z.map((_, i) => {
        if (classes === 2) { const p = sigmoid(dec[0][i]); return [1 - p, p]; }
        const s = dec.map((d) => sigmoid(d[i])); const t = s.reduce((a, b) => a + b, 0) || 1; return s.map((v) => v / t);
      });
    }
  };
}

/* ------------------------------------------------------------------ k-means */
export interface KMeansState { centroids: number[][]; assign: number[]; inertia: number; iteration: number; converged: boolean; moved: number }
export function kmeansInit(X: number[][], k: number, seed = 3, plusPlus = true): number[][] {
  const rng = makeRng(seed), c = [X[Math.floor(rng() * X.length)].slice()];
  while (c.length < k) {
    const d2 = X.map((x) => Math.min(...c.map((m) => m.reduce((s, v, j) => s + (v - x[j]) ** 2, 0))));
    if (!plusPlus) { c.push(X[Math.floor(rng() * X.length)].slice()); continue; }
    const tot = d2.reduce((a, b) => a + b, 0);
    if (tot === 0) { c.push(X[Math.floor(rng() * X.length)].slice()); continue; }
    let r = rng() * tot, pick = 0;
    for (let i = 0; i < d2.length; i++) { r -= d2[i]; if (r <= 0) { pick = i; break; } }
    c.push(X[pick].slice());
  }
  return c;
}
/** One Lloyd iteration: assignment step then update step. */
export function kmeansStep(X: number[][], prev: KMeansState): KMeansState {
  const k = prev.centroids.length, d = X[0].length;
  const assign = X.map((x) => argmin(prev.centroids.map((c) => c.reduce((s, v, j) => s + (v - x[j]) ** 2, 0))));
  const sums = Array.from({ length: k }, () => new Array<number>(d).fill(0)), cnt = new Array<number>(k).fill(0);
  assign.forEach((a, i) => { cnt[a]++; X[i].forEach((v, j) => (sums[a][j] += v)); });
  const centroids = sums.map((s, c) => (cnt[c] ? s.map((v) => v / cnt[c]) : prev.centroids[c].slice()));
  const moved = centroids.reduce((m, c, i) => Math.max(m, Math.hypot(...c.map((v, j) => v - prev.centroids[i][j]))), 0);
  const inertia = X.reduce((s, x, i) => s + centroids[assign[i]].reduce((q, v, j) => q + (v - x[j]) ** 2, 0), 0);
  const same = prev.assign.length === assign.length && assign.every((a, i) => a === prev.assign[i]);
  return { centroids, assign, inertia, iteration: prev.iteration + 1, converged: same || moved < 1e-9, moved };
}
export const argmin = (a: number[]) => a.reduce((b, v, i) => (v < a[b] ? i : b), 0);
export function kmeansFit(X: number[][], k: number, seed = 3, maxIter = 100): KMeansState {
  let s: KMeansState = { centroids: kmeansInit(X, k, seed), assign: [], inertia: Infinity, iteration: 0, converged: false, moved: Infinity };
  while (!s.converged && s.iteration < maxIter) s = kmeansStep(X, s);
  return s;
}
