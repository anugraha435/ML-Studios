import { useEffect, useMemo, useState } from 'react';
import { Slider, Stat, fmt } from '@/components/ui/Controls';
import { Badge } from '@/components/ui/Badge';
import { accuracy, f1, precision, recall, specificity } from '@/lib/ml/metrics';
import { fitLinear, predictLinear } from '@/lib/ml/models';
import { makeRng, randn } from '@/lib/ml/rng';
import { useThemeColors } from '@/hooks/useThemeColors';

/** The narrative steps of a lesson. When a visualization sits in the sticky stage, scrolling to a step applies that step's preset. */
export type Step = 'intro' | 'simple' | 'technical' | 'math' | 'example';
export interface VizProps { step?: Step; stage?: boolean }

function Wrap({ title, kind = 'simulation', caption, stage, children }: { title: string; kind?: 'simulation' | 'illustrative'; caption?: string; stage?: boolean; children: React.ReactNode }) {
  return (<section className={stage ? 'rounded-xl border border-line bg-surface p-4 sm:p-5' : 'card my-6 p-4'} aria-label={title}><div className="mb-2 flex flex-wrap items-center justify-between gap-2"><h3 className="text-base font-medium">{title}</h3><Badge kind={kind} /></div>
    {caption && <p aria-live="polite" className="mb-3 min-h-[2.6em] border-l-2 border-brand pl-3 font-serif text-[0.95rem] italic text-muted">{caption}</p>}{children}</section>);
}

const CONF: Record<Step, { c: { tp: number; fn: number; fp: number; tn: number }; note: string }> = {
  intro: { c: { tp: 40, fn: 10, fp: 15, tn: 135 }, note: 'Four counts sum up every prediction a classifier made. Here it is right 175 times out of 200.' },
  simple: { c: { tp: 40, fn: 10, fp: 15, tn: 135 }, note: 'Missed cases (false negatives) and false alarms (false positives) are different kinds of mistake.' },
  technical: { c: { tp: 49, fn: 1, fp: 60, tn: 90 }, note: 'Lower the bar for flagging and recall rises to 0.98, but precision falls to 0.45.' },
  math: { c: { tp: 40, fn: 10, fp: 15, tn: 135 }, note: 'Every metric is a ratio of these four numbers. Change one and watch which ratios move.' },
  example: { c: { tp: 0, fn: 10, fp: 0, tn: 990 }, note: 'A rare condition: predicting "no" for everyone scores 99% accuracy and finds nobody.' }
};
export function ConfusionExplorer({ step, stage }: VizProps = {}) {
  const [c, setC] = useState({ tp: 40, fn: 10, fp: 15, tn: 135 });
  useEffect(() => { if (step) setC(CONF[step].c); }, [step]);
  const set = (k: keyof typeof c) => (e: React.ChangeEvent<HTMLInputElement>) => setC({ ...c, [k]: Math.max(0, Math.min(100000, Math.floor(Number(e.target.value) || 0))) });
  const total = c.tp + c.fn + c.fp + c.tn;
  const F = ({ k, label, tone }: { k: keyof typeof c; label: string; tone: string }) => (<label className={`block rounded-md p-3 ${tone}`}><span className="text-xs">{label}</span><input type="number" min={0} className="field mt-1 w-full min-w-0 font-mono" value={c[k]} onChange={set(k)} /></label>);
  return (
    <Wrap title="Try it: change the four counts and watch every metric" kind="illustrative" stage={stage} caption={step ? CONF[step].note : undefined}>
      <div className={stage ? 'grid gap-4' : 'grid gap-4 md:grid-cols-2'}>
        <div><div className="grid grid-cols-2 gap-2"><F k="tp" label="True positives (sick, flagged)" tone="bg-accent-soft" /><F k="fn" label="False negatives (sick, missed)" tone="bg-warn-soft" /><F k="fp" label="False positives (healthy, flagged)" tone="bg-warn-soft" /><F k="tn" label="True negatives (healthy, cleared)" tone="bg-accent-soft" /></div>
          <div className="mt-3 flex flex-wrap gap-2"><button className="btn btn-secondary" onClick={() => setC({ tp: 40, fn: 10, fp: 15, tn: 135 })}>Balanced example</button><button className="btn btn-secondary" onClick={() => setC({ tp: 0, fn: 10, fp: 0, tn: 990 })}>Rare disease: predict “no” for everyone</button></div></div>
        <div className="grid grid-cols-2 gap-2"><Stat label="Accuracy" value={fmt(accuracy(c))} /><Stat label="Precision" value={fmt(precision(c))} /><Stat label="Recall (sensitivity)" value={fmt(recall(c))} /><Stat label="Specificity" value={fmt(specificity(c))} /><Stat label="F1 score" value={fmt(f1(c))} /><Stat label="Prevalence" value={fmt((c.tp + c.fn) / total)} /></div>
      </div>
      <p className="mt-2 text-sm text-muted">The second preset has 99.0% accuracy and 0 recall: the classifier never finds a single sick person. This is the accuracy paradox on imbalanced data.</p>
    </Wrap>
  );
}

const erf = (x: number) => { const t = 1 / (1 + 0.3275911 * Math.abs(x)); const y = 1 - (((((1.061405429 * t - 1.453152027) * t) + 1.421413741) * t - 0.284496736) * t + 0.254829592) * t * Math.exp(-x * x); return x >= 0 ? y : -y; };
const Phi = (z: number) => 0.5 * (1 + erf(z / Math.SQRT2));
const pdf = (x: number, m: number) => Math.exp(-0.5 * (x - m) ** 2) / Math.sqrt(2 * Math.PI);
const ROC: Record<Step, { d: number; t: number; note: string }> = {
  intro: { d: 0, t: 0, note: 'With no separation the scores carry no information: the curve is the diagonal and AUC is 0.5.' },
  simple: { d: 1.8, t: 0.9, note: 'Two groups of scores that overlap a little. The dot is one choice of threshold.' },
  technical: { d: 1.8, t: -0.6, note: 'A low threshold catches almost every positive and also flags many negatives.' },
  math: { d: 3, t: 1.5, note: 'More separation pushes the curve toward the top-left corner and AUC toward 1.' },
  example: { d: 1.8, t: 2, note: 'A strict threshold gives few false alarms and misses many true cases.' }
};
export function RocExplorer({ step, stage }: VizProps = {}) {
  const [d, setD] = useState(1.8); const [t, setT] = useState(0.9); const colors = useThemeColors();
  useEffect(() => { if (step) { setD(ROC[step].d); setT(ROC[step].t); } }, [step]);
  const tpr = 1 - Phi(t - d), fpr = 1 - Phi(t), auc = Phi(d / Math.SQRT2);
  const W = 300, H = 140, xs = (v: number) => 10 + ((v + 4) / 10) * (W - 20), ys = (v: number) => H - 12 - v * (H - 28);
  const grid = Array.from({ length: 101 }, (_, i) => -4 + (i / 100) * 10);
  const path = (m: number) => grid.map((g, i) => `${i ? 'L' : 'M'}${xs(g).toFixed(1)} ${ys(pdf(g, m) * 2.2).toFixed(1)}`).join(' ');
  const roc = grid.map((g) => ({ f: 1 - Phi(g), t: 1 - Phi(g - d) })).sort((a, b) => a.f - b.f);
  const S = 150, rx = (v: number) => 24 + v * (S - 34), ry = (v: number) => S - 22 - v * (S - 34);
  return (
    <Wrap title="Try it: slide the threshold along two score distributions" stage={stage} caption={step ? ROC[step].note : undefined}>
      <div className={stage ? 'grid gap-4 sm:grid-cols-2' : 'grid gap-4 md:grid-cols-2'}>
        <svg viewBox={`0 0 ${W} ${H}`} className="w-full" role="img" aria-label="Score distributions of negatives and positives with a threshold line">
          <path d={path(0)} fill="none" stroke={colors.classes[0]} strokeWidth={2} /><path d={path(d)} fill="none" stroke={colors.classes[1]} strokeWidth={2} />
          <line x1={xs(t)} x2={xs(t)} y1={6} y2={H - 12} stroke={colors.ink} strokeWidth={2} /><text x={xs(t) + 4} y={14} fontSize={9} fill={colors.ink}>threshold</text>
          <line x1={10} x2={W - 10} y1={H - 12} y2={H - 12} stroke={colors.line} /><text x={xs(0)} y={H - 1} fontSize={9} fill={colors.classes[0]} textAnchor="middle">negatives</text><text x={xs(d)} y={H - 1} fontSize={9} fill={colors.classes[1]} textAnchor="middle">positives</text></svg>
        <svg viewBox={`0 0 ${S} ${S}`} className="w-full max-w-[220px]" role="img" aria-label="ROC curve with the current operating point">
          <rect x={24} y={12} width={S - 34} height={S - 34} fill="none" stroke={colors.line} /><line x1={rx(0)} y1={ry(0)} x2={rx(1)} y2={ry(1)} stroke={colors.line} strokeDasharray="3 3" />
          <polyline fill="none" stroke={colors.accent} strokeWidth={2} points={roc.map((p) => `${rx(p.f)},${ry(p.t)}`).join(' ')} /><circle cx={rx(fpr)} cy={ry(tpr)} r={5} fill={colors.ink} />
          <text x={rx(0.5)} y={S - 6} fontSize={9} textAnchor="middle" fill={colors.muted}>false positive rate</text><text transform={`translate(8 ${ry(0.5)}) rotate(-90)`} fontSize={9} textAnchor="middle" fill={colors.muted}>true positive rate</text></svg>
      </div>
      <div className="mt-3 grid gap-3 sm:grid-cols-2"><Slider label="Separation between classes" value={d} min={0} max={4} step={0.1} onChange={setD} hint="0 means the scores carry no information." /><Slider label="Decision threshold" value={t} min={-3} max={5} step={0.05} onChange={setT} format={(v) => v.toFixed(2)} /></div>
      <div className="mt-3 grid grid-cols-3 gap-2"><Stat label="TPR (recall)" value={fmt(tpr)} /><Stat label="FPR" value={fmt(fpr)} /><Stat label="AUC" value={fmt(auc)} sub="area under the curve" /></div>
    </Wrap>
  );
}

const GD: Record<Step, { lr: number; steps: number; note: string }> = {
  intro: { lr: 0.05, steps: 12, note: 'A tiny learning rate: every step heads downhill, but slowly.' },
  simple: { lr: 0.3, steps: 8, note: 'A moderate rate: the steps shrink as the slope flattens and w settles near 2.' },
  technical: { lr: 0.9, steps: 14, note: 'Close to 1 the updates overshoot the minimum and bounce from side to side.' },
  math: { lr: 0.5, steps: 3, note: 'For this loss, η = 0.5 multiplies the distance by 1 − 2η = 0 and lands on the minimum at once.' },
  example: { lr: 1.1, steps: 10, note: 'Above 1 each step lands farther away than the last, and the loss grows.' }
};
export function GradientDescentViz({ step, stage }: VizProps = {}) {
  const [lr, setLr] = useState(0.3); const [steps, setSteps] = useState(8); const colors = useThemeColors();
  useEffect(() => { if (step) { setLr(GD[step].lr); setSteps(GD[step].steps); } }, [step]);
  // loss L(w) = (w - 2)^2, gradient 2(w - 2); start at w = 6. Converges for lr < 1, diverges for lr > 1.
  const path = useMemo(() => { const p = [6]; for (let i = 0; i < steps; i++) p.push(p[i] - lr * 2 * (p[i] - 2)); return p; }, [lr, steps]);
  const lim = Math.max(8, ...path.map((v) => Math.abs(v - 2) + 2)), W = 300, H = 150;
  const xs = (v: number) => 10 + ((v - (2 - lim)) / (2 * lim)) * (W - 20), L = (w: number) => (w - 2) ** 2, ymax = lim * lim, ys = (v: number) => H - 12 - Math.min(v / ymax, 1) * (H - 24);
  const curve = Array.from({ length: 81 }, (_, i) => { const w = 2 - lim + (2 * lim * i) / 80; return `${i ? 'L' : 'M'}${xs(w).toFixed(1)} ${ys(L(w)).toFixed(1)}`; }).join(' ');
  const last = path[path.length - 1];
  return (
    <Wrap title="Try it: the learning rate decides whether descent converges" stage={stage} caption={step ? GD[step].note : undefined}>
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full max-w-lg" role="img" aria-label="Loss curve with gradient descent steps"><path d={curve} fill="none" stroke={colors.ink} strokeWidth={2} />
        <polyline fill="none" stroke={colors.accent} points={path.map((w) => `${xs(w)},${ys(L(w))}`).join(' ')} />{path.map((w, i) => <circle key={i} cx={xs(w)} cy={ys(L(w))} r={i === 0 ? 5 : 3.5} fill={i === 0 ? colors.classes[2] : colors.accent} />)}</svg>
      <div className="grid gap-3 sm:grid-cols-2"><Slider label="Learning rate" value={lr} min={0.02} max={1.2} step={0.01} onChange={setLr} hint="For this loss, rates above 1.0 overshoot more each step and diverge." /><Slider label="Steps" value={steps} min={1} max={30} onChange={setSteps} /></div>
      <div className="mt-3 grid grid-cols-3 gap-2"><Stat label="Start w" value="6.00" /><Stat label={`w after ${steps} steps`} value={Math.abs(last) > 1e6 ? last.toExponential(1) : last.toFixed(4)} /><Stat label="Minimum at" value="2.00" /></div>
      <p className="mt-2 text-sm text-muted">Update rule: <code className="inline">w ← w − η · dL/dw</code> with <code className="inline">dL/dw = 2(w − 2)</code>. Each step multiplies the distance to the minimum by <code className="inline">1 − 2η</code>.</p>
    </Wrap>
  );
}

const truth = (x: number) => Math.sin(2.2 * x);
const POLY: Record<Step, { deg: number; note: string }> = {
  intro: { deg: 1, note: 'A straight line is too simple for this curve: it underfits.' },
  simple: { deg: 3, note: 'A gentle curve follows the pattern without chasing every noisy point.' },
  technical: { deg: 9, note: 'A flexible curve threads the training points, and the test error climbs: overfitting.' },
  math: { deg: 12, note: 'Still more flexibility: training error keeps falling (0.16) while test error keeps rising (0.75).' },
  example: { deg: 3, note: 'The balance point: low training error and low test error.' }
};
export function PolyFitViz({ step, stage }: VizProps = {}) {
  const [deg, setDeg] = useState(3); const colors = useThemeColors();
  useEffect(() => { if (step) setDeg(POLY[step].deg); }, [step]);
  const { train, test } = useMemo(() => { const r = makeRng(8); return { train: Array.from({ length: 14 }, () => { const x = r() * 2 - 1; return { x, y: truth(x) + randn(r) * 0.25 }; }), test: Array.from({ length: 200 }, (_, i) => { const x = -1 + (2 * i) / 199; return { x, y: truth(x) }; }) }; }, []);
  const feat = (x: number) => Array.from({ length: deg }, (_, k) => x ** (k + 1));
  const m = useMemo(() => fitLinear(train.map((p) => feat(p.x)), train.map((p) => p.y), 1e-6), [train, deg]);
  const err = (set: { x: number; y: number }[]) => Math.sqrt(set.reduce((s, p) => s + (predictLinear(m, [feat(p.x)])[0] - p.y) ** 2, 0) / set.length);
  const W = 320, H = 170, xs = (v: number) => 10 + ((v + 1) / 2) * (W - 20), ys = (v: number) => H / 2 - Math.max(-2.2, Math.min(2.2, v)) * 32;
  const curve = test.map((p, i) => `${i ? 'L' : 'M'}${xs(p.x).toFixed(1)} ${ys(predictLinear(m, [feat(p.x)])[0]).toFixed(1)}`).join(' ');
  return (
    <Wrap title="Try it: raise the polynomial degree and compare training and test error" stage={stage} caption={step ? POLY[step].note : undefined}>
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full max-w-xl" role="img" aria-label="Polynomial fit to noisy training points and the true curve">
        <path d={test.map((p, i) => `${i ? 'L' : 'M'}${xs(p.x).toFixed(1)} ${ys(p.y).toFixed(1)}`).join(' ')} fill="none" stroke={colors.muted} strokeDasharray="4 3" />
        <path d={curve} fill="none" stroke={colors.accent} strokeWidth={2.5} />{train.map((p, i) => <circle key={i} cx={xs(p.x)} cy={ys(p.y)} r={4} fill={colors.classes[2]} />)}</svg>
      <p className="text-xs text-muted">Orange: 14 noisy training points. Dashed: the true curve. Teal: the fitted polynomial. Test error is measured against the true curve at 200 points.</p>
      <Slider label="Polynomial degree" value={deg} min={1} max={12} onChange={setDeg} />
      <div className="mt-3 grid grid-cols-3 gap-2"><Stat label="Training RMSE" value={fmt(err(train))} /><Stat label="Test RMSE" value={fmt(err(test))} /><Stat label="Diagnosis" value={deg <= 1 ? 'Underfit' : deg >= 9 ? 'Overfit' : 'Reasonable'} /></div>
    </Wrap>
  );
}

export const LESSON_VIZ: Record<string, (p: VizProps) => JSX.Element> = {
  'confusion-matrix': ConfusionExplorer, accuracy: ConfusionExplorer, precision: ConfusionExplorer, recall: ConfusionExplorer, specificity: ConfusionExplorer, 'f1-score': ConfusionExplorer,
  'roc-curve': RocExplorer, 'roc-auc': RocExplorer, 'gradient-descent': GradientDescentViz, 'overfitting-underfitting': PolyFitViz, 'bias-variance-tradeoff': PolyFitViz, generalization: PolyFitViz
};
