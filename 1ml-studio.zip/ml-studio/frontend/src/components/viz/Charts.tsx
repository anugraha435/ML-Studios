import { CartesianGrid, Legend, Line, LineChart, ReferenceLine, ResponsiveContainer, Scatter, ScatterChart, Tooltip, XAxis, YAxis, Bar, BarChart, ComposedChart, Cell } from 'recharts';
import { CURVES, MODEL_KEYS, MODEL_NAMES, MODEL_SHORT, type ModelKey } from '@/data/metrics';
import { useThemeColors } from '@/hooks/useThemeColors';

const DASH: Record<ModelKey, string | undefined> = { lr: undefined, dt: '6 3', rf: '2 2', svm: '10 3 2 3' };
export const useModelColors = () => { const c = useThemeColors(); return { lr: c.classes[0], dt: c.classes[1], rf: c.classes[2], svm: c.classes[3] } as Record<ModelKey, string>; };
const axis = (c: ReturnType<typeof useThemeColors>) => ({ stroke: c.muted, tick: { fill: c.muted, fontSize: 12 } });

export function CurveChart({ kind, height = 320 }: { kind: 'roc' | 'pr'; height?: number }) {
  const c = useThemeColors(), mc = useModelColors();
  const pts = (k: ModelKey) => kind === 'roc' ? CURVES.curves[k].roc.fpr.map((x, i) => ({ x, y: CURVES.curves[k].roc.tpr[i] })) : CURVES.curves[k].pr.recall.map((x, i) => ({ x, y: CURVES.curves[k].pr.precision[i] }));
  return (
    <div role="img" aria-label={kind === 'roc' ? 'ROC curves of the four models on the test set' : 'Precision-recall curves of the four models on the test set'} style={{ height }}>
      <ResponsiveContainer><ScatterChart margin={{ top: 8, right: 16, bottom: 28, left: 8 }}>
        <CartesianGrid stroke={c.line} strokeOpacity={0.6} />
        <XAxis type="number" dataKey="x" domain={[0, 1]} {...axis(c)} label={{ value: kind === 'roc' ? 'False positive rate (1 - specificity)' : 'Recall (sensitivity)', position: 'insideBottom', offset: -16, fill: c.ink, fontSize: 12 }} />
        <YAxis type="number" dataKey="y" domain={[0, 1]} {...axis(c)} label={{ value: kind === 'roc' ? 'True positive rate (sensitivity)' : 'Precision', angle: -90, position: 'insideLeft', fill: c.ink, fontSize: 12 }} />
        {kind === 'roc' && <ReferenceLine segment={[{ x: 0, y: 0 }, { x: 1, y: 1 }]} stroke={c.muted} strokeDasharray="3 3" />}
        <Tooltip cursor={false} contentStyle={{ background: c.surface, border: `1px solid ${c.line}`, color: c.ink }} formatter={(v: number) => v.toFixed(3)} />
        <Legend verticalAlign="top" height={28} />
        {MODEL_KEYS.map((k) => <Scatter key={k} name={MODEL_NAMES[k]} data={pts(k)} line={{ stroke: mc[k], strokeWidth: 2, strokeDasharray: DASH[k] }} fill={mc[k]} shape={() => <g />} isAnimationActive={false} />)}
      </ScatterChart></ResponsiveContainer>
    </div>
  );
}

export function ReliabilityChart({ height = 320 }: { height?: number }) {
  const c = useThemeColors(), mc = useModelColors();
  return (
    <div role="img" aria-label="Reliability diagram: observed positive rate against mean predicted probability in five equal-count bins of the 61 test predictions" style={{ height }}>
      <ResponsiveContainer><ScatterChart margin={{ top: 8, right: 16, bottom: 28, left: 8 }}>
        <CartesianGrid stroke={c.line} strokeOpacity={0.6} />
        <XAxis type="number" dataKey="x" domain={[0, 1]} {...axis(c)} label={{ value: 'Mean predicted probability', position: 'insideBottom', offset: -16, fill: c.ink, fontSize: 12 }} />
        <YAxis type="number" dataKey="y" domain={[0, 1]} {...axis(c)} label={{ value: 'Observed fraction with disease', angle: -90, position: 'insideLeft', fill: c.ink, fontSize: 12 }} />
        <ReferenceLine segment={[{ x: 0, y: 0 }, { x: 1, y: 1 }]} stroke={c.muted} strokeDasharray="3 3" />
        <Tooltip cursor={false} contentStyle={{ background: c.surface, border: `1px solid ${c.line}`, color: c.ink }} formatter={(v: number) => v.toFixed(3)} />
        <Legend verticalAlign="top" height={28} />
        {MODEL_KEYS.map((k) => <Scatter key={k} name={MODEL_NAMES[k]} data={CURVES.curves[k].reliability.map((b) => ({ x: b.meanPred, y: b.obsRate }))} line={{ stroke: mc[k], strokeWidth: 2, strokeDasharray: DASH[k] }} fill={mc[k]} isAnimationActive={false} />)}
      </ScatterChart></ResponsiveContainer>
    </div>
  );
}

export function ProbHistogram({ model, height = 240 }: { model: ModelKey; height?: number }) {
  const c = useThemeColors(), mc = useModelColors();
  const { probs } = CURVES.curves[model], y = CURVES.yTest, bins = 10;
  const data = Array.from({ length: bins }, (_, i) => ({ bin: `${(i / bins).toFixed(1)}-${((i + 1) / bins).toFixed(1)}`, absent: 0, present: 0 }));
  probs.forEach((p, i) => { const b = Math.min(bins - 1, Math.floor(p * bins)); if (y[i] === 1) data[b].present++; else data[b].absent++; });
  return (
    <div role="img" aria-label={`Histogram of test-set predicted probabilities for ${MODEL_NAMES[model]}, split by true class`} style={{ height }}>
      <ResponsiveContainer><BarChart data={data} margin={{ top: 8, right: 16, bottom: 28, left: 0 }}><CartesianGrid stroke={c.line} strokeOpacity={0.6} /><XAxis dataKey="bin" {...axis(c)} label={{ value: 'Predicted probability', position: 'insideBottom', offset: -16, fill: c.ink, fontSize: 12 }} /><YAxis allowDecimals={false} {...axis(c)} label={{ value: 'Records', angle: -90, position: 'insideLeft', fill: c.ink, fontSize: 12 }} />
        <Tooltip contentStyle={{ background: c.surface, border: `1px solid ${c.line}`, color: c.ink }} /><Legend verticalAlign="top" height={28} />
        <Bar dataKey="absent" name="No disease (true)" stackId="a" fill={c.classes[1]} /><Bar dataKey="present" name="Disease (true)" stackId="a" fill={mc[model]} /></BarChart></ResponsiveContainer>
    </div>
  );
}

export function HBars({ data, unit, height }: { data: { name: string; value: number }[]; unit: string; height?: number }) {
  const c = useThemeColors();
  return (
    <div role="img" aria-label={`Bar chart: ${data.map((d) => `${d.name} ${d.value.toFixed(3)}`).join(', ')}`} style={{ height: height ?? Math.max(180, data.length * 26 + 50) }}>
      <ResponsiveContainer><BarChart data={data} layout="vertical" margin={{ top: 4, right: 24, bottom: 24, left: 8 }}><CartesianGrid stroke={c.line} strokeOpacity={0.6} horizontal={false} />
        <XAxis type="number" {...axis(c)} label={{ value: unit, position: 'insideBottom', offset: -12, fill: c.ink, fontSize: 12 }} /><YAxis type="category" dataKey="name" width={150} {...axis(c)} />
        <Tooltip contentStyle={{ background: c.surface, border: `1px solid ${c.line}`, color: c.ink }} formatter={(v: number) => v.toFixed(4)} />
        <ReferenceLine x={0} stroke={c.muted} />
        <Bar dataKey="value" isAnimationActive={false}>{data.map((d, i) => <Cell key={i} fill={d.value >= 0 ? c.classes[2] : c.classes[0]} />)}</Bar></BarChart></ResponsiveContainer>
    </div>
  );
}

export function GroupedMetricBars({ metric, height = 260 }: { metric: { key: string; label: string; get: (k: ModelKey) => number }[]; height?: number }) {
  const c = useThemeColors(), mc = useModelColors();
  const data = metric.map((m) => ({ metric: m.label, ...Object.fromEntries(MODEL_KEYS.map((k) => [MODEL_SHORT[k], m.get(k)])) }));
  return (
    <div role="img" aria-label="Grouped bar chart comparing the four models on test-set metrics" style={{ height }}>
      <ResponsiveContainer><ComposedChart data={data} margin={{ top: 8, right: 16, bottom: 8, left: 0 }}><CartesianGrid stroke={c.line} strokeOpacity={0.6} /><XAxis dataKey="metric" {...axis(c)} /><YAxis domain={[0, 1]} {...axis(c)} />
        <Tooltip contentStyle={{ background: c.surface, border: `1px solid ${c.line}`, color: c.ink }} formatter={(v: number) => v.toFixed(3)} /><Legend />
        {MODEL_KEYS.map((k) => <Bar key={k} dataKey={MODEL_SHORT[k]} fill={mc[k]} isAnimationActive={false} />)}</ComposedChart></ResponsiveContainer>
    </div>
  );
}
void Line; void LineChart;

/** SHAP beeswarm drawn from the saved SHAP values: one row per feature, dots are the 61 test records. */
export function Beeswarm({ features, shap, values, labels, height = 460 }: { features: string[]; shap: number[][]; values: (number | null)[][]; labels: Record<string, string>; height?: number }) {
  const c = useThemeColors();
  const order = features.map((f, j) => ({ f, j, m: shap.reduce((s, r) => s + Math.abs(r[j]), 0) / shap.length })).sort((a, b) => b.m - a.m);
  const lim = Math.max(...shap.flat().map(Math.abs)) * 1.05, W = 640, rowH = (height - 50) / features.length, L = 170;
  const x = (v: number) => L + ((v + lim) / (2 * lim)) * (W - L - 16);
  const color = (t: number) => { const a = [c.classes[0], c.classes[2]]; return t < 0.5 ? a[0] : a[1]; };
  return (
    <svg viewBox={`0 0 ${W} ${height}`} className="w-full" role="img" aria-label="SHAP summary (beeswarm) for the random forest on the 61 test records. Each dot is one record; horizontal position is its SHAP value in probability units; colour shows whether the feature value was low or high.">
      <line x1={x(0)} x2={x(0)} y1={6} y2={height - 36} stroke={c.muted} />
      {order.map(({ f, j }, r) => {
        const col = values.map((row) => row[j]).filter((v): v is number => v !== null); const lo = Math.min(...col), hi = Math.max(...col);
        const cy = 20 + r * rowH + rowH / 2;
        const dots = shap.map((s, i) => ({ s: s[j], t: values[i][j] === null || hi === lo ? 0.5 : ((values[i][j] as number) - lo) / (hi - lo) })).sort((a, b) => a.s - b.s);
        let prevX = -1e9, k = 0;
        return (<g key={f}><text x={L - 8} y={cy + 4} textAnchor="end" fontSize={12} fill={c.ink}>{labels[f] ?? f}</text><line x1={L} x2={W - 16} y1={cy + rowH / 2} y2={cy + rowH / 2} stroke={c.line} strokeOpacity={0.4} />
          {dots.map((d, i) => { const px = x(d.s); k = Math.abs(px - prevX) < 6 ? k + 1 : 0; prevX = px; const off = ((k % 2 ? 1 : -1) * Math.ceil(k / 2) * 5); return <circle key={i} cx={px} cy={cy + Math.max(-rowH / 2 + 3, Math.min(rowH / 2 - 3, off))} r={3} fill={color(d.t)} fillOpacity={0.85} stroke={d.t >= 0.5 ? c.ink : 'none'} strokeWidth={0.4} />; })}</g>);
      })}
      <text x={(L + W) / 2} y={height - 18} textAnchor="middle" fontSize={12} fill={c.ink}>SHAP value (change in predicted probability)</text>
      <g fontSize={11} fill={c.ink}><circle cx={L} cy={height - 4} r={4} fill={c.classes[0]} /><text x={L + 8} y={height - 1}>low feature value</text><circle cx={L + 130} cy={height - 4} r={4} fill={c.classes[2]} stroke={c.ink} strokeWidth={0.4} /><text x={L + 138} y={height - 1}>high feature value</text></g>
    </svg>
  );
}
