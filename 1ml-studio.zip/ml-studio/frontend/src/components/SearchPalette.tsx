import { Search } from 'lucide-react';
import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import type { SearchEntry } from '../lib/search';

export function SearchPalette({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [q, setQ] = useState(''); const [sel, setSel] = useState(0);
  const nav = useNavigate(); const input = useRef<HTMLInputElement>(null);
  const [mod, setMod] = useState<typeof import('../lib/search') | null>(null);
  useEffect(() => { if (open && !mod) void import('../lib/search').then(setMod); }, [open, mod]);
  const results: SearchEntry[] = useMemo(() => (mod ? mod.search(q) : []), [mod, q]);
  const suggestions: SearchEntry[] = useMemo(() => (mod ? mod.INDEX.filter((e) => ['what-is-ml', 'linear-regression', 'shap', 'roc-auc'].includes(e.id) || e.to === '/playground' || e.to === '/research') : []), [mod]);
  const list = q.trim() ? results : suggestions;
  useEffect(() => { if (open) { setQ(''); setSel(0); setTimeout(() => input.current?.focus(), 0); } }, [open]);
  useEffect(() => setSel(0), [q]);
  if (!open) return null;
  const go = (to: string) => { onClose(); nav(to); };
  const onKey = (e: React.KeyboardEvent) => {
    if (e.key === 'Escape') { e.preventDefault(); onClose(); }
    else if (e.key === 'ArrowDown') { e.preventDefault(); setSel((s) => Math.min(s + 1, list.length - 1)); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); setSel((s) => Math.max(s - 1, 0)); }
    else if (e.key === 'Enter' && list[sel]) { e.preventDefault(); go(list[sel].to); }
    else if (e.key === 'Tab') { e.preventDefault(); input.current?.focus(); }
  };
  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center bg-navy/60 p-4 pt-[12vh]" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div role="dialog" aria-modal="true" aria-label="Search ML Studio" className="card w-full max-w-xl overflow-hidden shadow-xl" onKeyDown={onKey}>
        <div className="flex items-center gap-3 border-b border-line px-4">
          <Search size={18} className="text-muted" aria-hidden />
          <input ref={input} value={q} onChange={(e) => setQ(e.target.value)} role="combobox" aria-expanded="true" aria-controls="search-results" aria-activedescendant={list[sel] ? `sr-${sel}` : undefined}
            placeholder="Search lessons, algorithms, metrics, research" className="h-12 w-full bg-transparent text-base outline-none" aria-label="Search" />
          <kbd className="hidden rounded border border-line px-1.5 text-xs text-muted sm:block">Esc</kbd>
        </div>
        <ul id="search-results" role="listbox" className="max-h-[50vh] overflow-y-auto p-2">
          {!q.trim() && <li className="px-3 pb-1 pt-2 text-xs text-muted">Suggestions</li>}
          {list.map((r, i) => (
            <li key={r.kind + r.id} id={`sr-${i}`} role="option" aria-selected={i === sel}>
              <button type="button" onClick={() => go(r.to)} onMouseEnter={() => setSel(i)} className={`flex w-full items-center justify-between gap-3 rounded-md px-3 py-2 text-left ${i === sel ? 'bg-raised' : ''}`}>
                <span className="text-sm font-medium">{r.title}</span><span className="chip shrink-0">{r.kind}</span>
              </button>
            </li>
          ))}
          {!mod && <li className="p-4 text-sm text-muted">Loading search index</li>}
          {mod && q.trim() && results.length === 0 && <li className="p-4 text-sm text-muted">No results for "{q}". Try a broader word such as "tree", "recall" or "calibration".</li>}
        </ul>
      </div>
    </div>
  );
}
