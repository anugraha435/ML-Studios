import { AlertTriangle, ChevronRight, FlaskConical, Info, Sparkles, Cpu, BarChart3 } from 'lucide-react';
import type { ReactNode } from 'react';
import { Link } from 'react-router-dom';

export type Evidence = 'measured' | 'inference' | 'simulation' | 'illustrative';
const EV: Record<Evidence, { label: string; tip: string; cls: string; Icon: typeof Info }> = {
  measured: { label: 'Measured result', tip: 'Computed by the CardioNepal Python experiment on the held-out test set or training folds.', cls: 'text-good', Icon: BarChart3 },
  inference: { label: 'Actual model inference', tip: 'Produced by the fitted CardioNepal model for the inputs you entered.', cls: 'text-brand', Icon: Cpu },
  simulation: { label: 'Educational simulation', tip: 'A real calculation running in your browser to teach an idea. Not a research result.', cls: 'text-muted', Icon: FlaskConical },
  illustrative: { label: 'Illustrative example', tip: 'Invented numbers used only to explain a concept.', cls: 'text-warn', Icon: Sparkles }
};
export function EvidenceBadge({ kind }: { kind: Evidence }) {
  const e = EV[kind];
  return <span title={e.tip} className={`inline-flex items-center gap-1.5 border-b border-dotted border-current pb-px text-xs font-medium ${e.cls}`}><e.Icon size={13} aria-hidden />{e.label}</span>;
}

export function Disclaimer({ compact = false }: { compact?: boolean }) {
  return (
    <div role="note" className="flex gap-3 rounded-lg border border-warn/50 bg-warn/10 p-4 text-sm">
      <AlertTriangle className="mt-0.5 shrink-0 text-warn" size={18} aria-hidden />
      <div>
        <p className="font-medium text-ink">Research demonstration. Not a medical product.</p>
        {!compact && (
          <p className="mt-1 text-muted">
            The models were trained on the historical Cleveland (United States) benchmark and have not been validated on a Nepalese population. They estimate a cross-sectional
            diagnostic label from benchmark data, not future cardiovascular events. Do not use them for diagnosis, treatment or any clinical decision.
          </p>
        )}
      </div>
    </div>
  );
}

export function Breadcrumbs({ items }: { items: { label: string; to?: string }[] }) {
  return (
    <nav aria-label="Breadcrumb" className="mb-4 text-sm text-muted">
      <ol className="flex flex-wrap items-center gap-1">
        {items.map((it, i) => (
          <li key={i} className="flex items-center gap-1">
            {i > 0 && <ChevronRight size={14} aria-hidden />}
            {it.to ? <Link to={it.to} className="underline-offset-2 hover:text-ink hover:underline">{it.label}</Link> : <span aria-current="page" className="text-ink">{it.label}</span>}
          </li>
        ))}
      </ol>
    </nav>
  );
}

export function PageHeader({ title, lead, children }: { title: string; lead?: ReactNode; children?: ReactNode }) {
  return (
    <header className="mb-8 max-w-3xl">
      <h1 className="text-3xl sm:text-4xl">{title}</h1>
      {lead && <p className="mt-3 font-serif text-xl leading-relaxed text-muted">{lead}</p>}
      {children}
    </header>
  );
}

export function Section({ title, children, id, aside }: { title: string; children: ReactNode; id?: string; aside?: ReactNode }) {
  return (
    <section id={id} className="mb-12 scroll-mt-24">
      <div className="mb-4 flex flex-wrap items-baseline justify-between gap-2">
        <h2 className="text-2xl">{title}</h2>
        {aside}
      </div>
      {children}
    </section>
  );
}

export function Callout({ title, children, tone = 'info' }: { title?: string; children: ReactNode; tone?: 'info' | 'warn' }) {
  const c = tone === 'warn' ? 'border-warn/50 bg-warn/10' : 'border-accent/40 bg-accent/5';
  return <div className={`rounded-lg border p-4 text-sm ${c}`}>{title && <p className="mb-1 font-medium">{title}</p>}<div className="text-muted">{children}</div></div>;
}

export function Spinner({ label = 'Loading' }: { label?: string }) {
  return <div role="status" className="flex items-center gap-3 p-6 text-muted"><span className="h-5 w-5 animate-spin rounded-full border-2 border-line border-t-accent" aria-hidden />{label}</div>;
}
export function ErrorBox({ children }: { children: ReactNode }) {
  return <div role="alert" className="rounded-lg border border-bad/50 bg-bad/10 p-4 text-sm text-bad">{children}</div>;
}
