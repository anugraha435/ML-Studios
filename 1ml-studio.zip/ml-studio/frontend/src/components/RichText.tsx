import katex from 'katex';
import { Fragment, memo, useMemo, type ReactNode } from 'react';

const cache = new Map<string, string>();
export function texHtml(tex: string, display = false): string {
  const key = (display ? 'D' : 'I') + tex;
  let h = cache.get(key);
  if (h === undefined) {
    try { h = katex.renderToString(tex, { displayMode: display, throwOnError: false, output: 'htmlAndMathml', strict: 'ignore' }); } catch { h = tex; }
    cache.set(key, h);
  }
  return h;
}
export const Tex = memo(function Tex({ tex, display = false }: { tex: string; display?: boolean }) {
  return <span dangerouslySetInnerHTML={{ __html: texHtml(tex, display) }} />;
});

const INLINE = /(\*\*[^*]+\*\*|\*[^*\n]+\*|`[^`]+`|(?<!\\)\$[^$\n]+?\$)/g;
function inline(text: string): ReactNode[] {
  return text.split(INLINE).filter((s) => s !== '').map((tok, i) => {
    if (tok.startsWith('**') && tok.endsWith('**') && tok.length > 4) return <strong key={i} className="font-semibold">{tok.slice(2, -2)}</strong>;
    if (tok.startsWith('`') && tok.endsWith('`')) return <code key={i}>{tok.slice(1, -1)}</code>;
    if (tok.startsWith('$') && tok.endsWith('$') && tok.length > 2) return <Tex key={i} tex={tok.slice(1, -1)} />;
    if (tok.startsWith('*') && tok.endsWith('*') && tok.length > 2) return <em key={i}>{tok.slice(1, -1)}</em>;
    return <Fragment key={i}>{tok}</Fragment>;
  });
}

/** Renders the lesson mini-markup: blank-line paragraphs, "- " lists, **bold**, *italic*, `code`, $math$. */
export const RichText = memo(function RichText({ text, className = '', serif = false }: { text: string; className?: string; serif?: boolean }) {
  const blocks = useMemo(() => text.split(/\n{2,}/).map((b) => b.trim()).filter(Boolean), [text]);
  return (
    <div className={`prose-ml ${serif ? 'serif-body' : ''} ${className}`}>
      {blocks.map((b, i) => {
        const lines = b.split('\n');
        if (lines.every((l) => l.startsWith('- '))) return <ul key={i}>{lines.map((l, j) => <li key={j}>{inline(l.slice(2))}</li>)}</ul>;
        return <p key={i}>{inline(b.replace(/\n/g, ' '))}</p>;
      })}
    </div>
  );
});
export const plain = (s: string) => s.replace(/\$([^$]+)\$/g, '$1').replace(/[*`]/g, '');
