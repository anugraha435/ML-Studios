import katex from 'katex';
import { useMemo } from 'react';

export function Tex({ tex, display = false }: { tex: string; display?: boolean }) {
  const html = useMemo(() => { try { return katex.renderToString(tex, { displayMode: display, throwOnError: false, strict: 'ignore', output: 'htmlAndMathml' }); } catch { return tex; } }, [tex, display]);
  return <span role={display ? 'math' : undefined} className={!display && tex.length > 28 ? 'tex-long' : undefined} dangerouslySetInnerHTML={{ __html: html }} />;
}

/** Renders the lesson mini-markup: paragraphs, "- " lists, **bold**, *italic*, `code`, $math$. */
function inline(s: string, key: string) {
  const out: React.ReactNode[] = [];
  const re = /(\$[^$\n]+\$|\*\*[^*]+\*\*|`[^`]+`|\*[^*\n]+\*)/g;
  let last = 0, m: RegExpExecArray | null, i = 0;
  while ((m = re.exec(s))) {
    if (m.index > last) out.push(s.slice(last, m.index));
    const t = m[0];
    if (t.startsWith('$')) out.push(<Tex key={`${key}-${i++}`} tex={t.slice(1, -1)} />);
    else if (t.startsWith('**')) out.push(<strong key={`${key}-${i++}`}>{inline(t.slice(2, -2), `${key}b${i}`)}</strong>);
    else if (t.startsWith('`')) out.push(<code key={`${key}-${i++}`}>{t.slice(1, -1)}</code>);
    else out.push(<em key={`${key}-${i++}`}>{t.slice(1, -1)}</em>);
    last = m.index + t.length;
  }
  if (last < s.length) out.push(s.slice(last));
  return out;
}
export function RichText({ text, className = '' }: { text: string; className?: string }) {
  const blocks = text.split(/\n\s*\n/).map((b) => b.trim()).filter(Boolean);
  return (
    <div className={`prose-ml ${className}`}>
      {blocks.map((b, i) => {
        const lines = b.split('\n');
        if (lines.every((l) => l.trim().startsWith('- '))) return <ul key={i}>{lines.map((l, j) => <li key={j}>{inline(l.trim().slice(2), `${i}-${j}`)}</li>)}</ul>;
        return <p key={i}>{inline(lines.join(' '), String(i))}</p>;
      })}
    </div>
  );
}
