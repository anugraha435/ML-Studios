import { ChevronRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useTitle } from '@/hooks/useTitle';
import type { ReactNode } from 'react';

export interface Crumb { label: string; to?: string }
export function Breadcrumbs({ items }: { items: Crumb[] }) {
  return (
    <nav aria-label="Breadcrumb" className="mb-4 text-sm text-muted">
      <ol className="flex flex-wrap items-center gap-1">
        <li><Link to="/" className="hover:text-ink">Home</Link></li>
        {items.map((c, i) => (
          <li key={i} className="flex items-center gap-1"><ChevronRight size={14} aria-hidden />
            {c.to && i < items.length - 1 ? <Link to={c.to} className="hover:text-ink">{c.label}</Link> : <span aria-current="page" className="text-ink">{c.label}</span>}</li>
        ))}
      </ol>
    </nav>
  );
}
export function PageHeader({ title, lead, crumbs, children }: { title: string; lead?: ReactNode; crumbs?: Crumb[]; children?: ReactNode }) {
  useTitle(title);
  return (
    <header className="mb-8">
      {crumbs && <Breadcrumbs items={crumbs} />}
      <h1 className="text-3xl sm:text-4xl">{title}</h1>
      {lead && <p className="mt-3 max-w-prose font-serif text-xl leading-relaxed text-muted">{lead}</p>}
      {children}
    </header>
  );
}
export const Container = ({ children, className = '' }: { children: ReactNode; className?: string }) => <div className={`mx-auto w-full max-w-6xl px-4 sm:px-6 ${className}`}>{children}</div>;
export function Section({ title, id, children, lead }: { title: string; id?: string; children: ReactNode; lead?: ReactNode }) {
  return (<section id={id} className="mb-10"><h2 className="mb-2 text-2xl font-semibold">{title}</h2>{lead && <p className="mb-4 max-w-prose text-muted">{lead}</p>}{children}</section>);
}
