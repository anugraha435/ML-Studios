import { ShieldAlert } from 'lucide-react';
import { Link } from 'react-router-dom';
export function Disclaimer({ compact = false }: { compact?: boolean }) {
  return (
    <aside role="note" aria-label="Medical and research disclaimer" className="rounded-lg border border-warn/40 bg-warn-soft p-4 text-sm text-ink">
      <p className="flex items-start gap-2"><ShieldAlert className="mt-0.5 shrink-0 text-warn" size={18} aria-hidden />
        <span><strong>Research demonstration, not a medical product.</strong> Do not use it for diagnosis, treatment or clinical decisions.
          {!compact && <> The data are a historical Cleveland (US) benchmark, not a Nepalese population, and the model has not been validated on a representative Nepalese population. It predicts a cross-sectional diagnostic label from that benchmark, not future events or 10-year risk. Good benchmark performance does not establish clinical usefulness.</>}{' '}
          <Link to="/research/limitations" className="underline">Read the full limitations</Link>.</span></p>
    </aside>
  );
}
