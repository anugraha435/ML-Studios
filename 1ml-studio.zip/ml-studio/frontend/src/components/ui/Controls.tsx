import { useId, type ReactNode } from 'react';

export function Slider({ label, value, min, max, step = 1, onChange, format, hint }: { label: string; value: number; min: number; max: number; step?: number; onChange: (v: number) => void; format?: (v: number) => string; hint?: string }) {
  const id = useId();
  return (
    <div>
      <div className="flex items-baseline justify-between"><label htmlFor={id} className="label !mb-0">{label}</label><output htmlFor={id} className="font-mono text-sm text-accent">{format ? format(value) : value}</output></div>
      <input id={id} type="range" className="w-full" min={min} max={max} step={step} value={value} onChange={(e) => onChange(Number(e.target.value))} aria-valuetext={format ? format(value) : String(value)} />
      {hint && <p className="hint">{hint}</p>}
    </div>
  );
}
export function Segmented<T extends string>({ label, value, options, onChange }: { label: string; value: T; options: { value: T; label: string }[]; onChange: (v: T) => void }) {
  return (
    <div role="radiogroup" aria-label={label}>
      <span className="label">{label}</span>
      <div className="inline-flex flex-wrap gap-1 rounded-lg bg-sunken p-1">
        {options.map((o) => (<button key={o.value} type="button" role="radio" aria-checked={value === o.value} onClick={() => onChange(o.value)}
          className={`rounded-md px-3 py-1.5 text-sm transition-colors ${value === o.value ? 'bg-surface font-medium text-ink shadow-sm' : 'text-muted hover:text-ink'}`} style={{ minHeight: 36 }}>{o.label}</button>))}
      </div>
    </div>
  );
}
export function Stat({ label, value, sub }: { label: string; value: ReactNode; sub?: string }) {
  return (<div className="rounded-md bg-sunken px-3 py-2"><div className="text-xs text-muted">{label}</div><div className="font-mono text-lg tabular-nums">{value}</div>{sub && <div className="text-xs text-muted">{sub}</div>}</div>);
}
export function Panel({ title, children, className = '' }: { title?: string; children: ReactNode; className?: string }) {
  return (<div className={`card p-4 ${className}`}>{title && <h3 className="mb-3 text-base font-semibold">{title}</h3>}{children}</div>);
}
export const fmt = (v: number, d = 3) => (Number.isFinite(v) ? v.toFixed(d) : 'n/a');
