import { Beaker, BarChart3, Cpu, Lightbulb } from 'lucide-react';
/** The four kinds of content the platform keeps strictly apart (see Documentation > Honesty labels). */
export type Provenance = 'measured' | 'simulation' | 'illustrative' | 'inference';
const META: Record<Provenance, { label: string; Icon: typeof Beaker; cls: string; help: string }> = {
  measured: { label: 'Measured result', Icon: BarChart3, cls: 'text-brand', help: 'Computed from the fitted research models and saved in this repository.' },
  inference: { label: 'Actual model inference', Icon: Cpu, cls: 'text-brand', help: 'Produced by the fitted CardioNepal model, in the browser or on the API server.' },
  simulation: { label: 'Educational simulation', Icon: Beaker, cls: 'text-muted', help: 'A real calculation on small, user-controlled data, meant for learning, not research.' },
  illustrative: { label: 'Illustrative example', Icon: Lightbulb, cls: 'text-warn', help: 'Made-up or simplified numbers that show an idea. Not a research result.' }
};
export function Badge({ kind }: { kind: Provenance }) {
  const { label, Icon, cls, help } = META[kind];
  return <span title={help} className={`inline-flex items-center gap-1.5 border-b border-dotted border-current pb-px text-xs font-medium ${cls}`}><Icon size={13} aria-hidden />{label}</span>;
}
