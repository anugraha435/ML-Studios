import { useId, type ReactNode } from 'react';
import { EvidenceBadge } from './ui';

export function Slider({ label, value, min, max, step = 1, onChange, format, hint, disabled }: { label: string; value: number; min: number; max: number; step?: number; onChange: (v: number) => void; format?: (v: number) => string; hint?: string; disabled?: boolean }) {
  const id = useId();
  return (
    <div>
      <div className="flex items-baseline justify-between"><label htmlFor={id} className="label !mb-0">{label}</label><output htmlFor={id} className="num text-sm text-muted">{format ? format(value) : value}</output></div>
      <input id={id} type="range" className="mt-2 h-6 w-full accent-[rgb(var(--accent))]" min={min} max={max} step={step} value={value} disabled={disabled} onChange={(e) => onChange(Number(e.target.value))} aria-describedby={hint ? id + 'h' : undefined} />
      {hint && <p id={id + 'h'} className="hint">{hint}</p>}
    </div>
  );
}
export function Segmented<T extends string | number>({ label, value, options, onChange }: { label: string; value: T; options: { value: T; label: string }[]; onChange: (v: T) => void }) {
  return (
    <div role="radiogroup" aria-label={label}>
      <p className="label">{label}</p>
      <div className="flex flex-wrap gap-1.5">{options.map((o) => <button key={String(o.value)} type="button" role="radio" aria-checked={o.value === value} onClick={() => onChange(o.value)} className={`rounded-md border px-3 py-1.5 text-sm ${o.value === value ? 'border-accent bg-accent/10 font-medium text-ink' : 'border-line text-muted hover:bg-raised'}`}>{o.label}</button>)}</div>
    </div>
  );
}
export function Stat({ label, value, sub }: { label: string; value: ReactNode; sub?: string }) {
  return <div className="rounded-md border border-line bg-surface p-3"><p className="text-xs text-muted">{label}</p><p className="num text-xl font-semibold">{value}</p>{sub && <p className="text-xs text-muted">{sub}</p>}</div>;
}
export function DemoShell({ title, controls, plot, readout, note }: { title: string; controls: ReactNode; plot: ReactNode; readout?: ReactNode; note?: string }) {
  return (
    <div className="card p-4 sm:p-6">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-2"><h3 className="text-xl font-semibold">{title}</h3><EvidenceBadge kind="simulation" /></div>
      {note && <p className="mb-4 text-sm text-muted">{note}</p>}
      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_320px]">
        <div className="min-w-0">{plot}{readout && <div className="mt-4">{readout}</div>}</div>
        <div className="space-y-5">{controls}</div>
      </div>
    </div>
  );
}
