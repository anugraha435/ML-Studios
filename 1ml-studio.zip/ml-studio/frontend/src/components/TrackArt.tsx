import type { CategoryId } from '@/content/types';

const G = 'rgb(var(--brand))', T = 'rgb(var(--c1))', B = 'rgb(var(--c0))', O = 'rgb(var(--c3))', L = 'rgb(var(--line))', M = 'rgb(var(--muted))';
const pts = (a: [number, number][], f: string, r = 3.2) => a.map(([x, y], i) => <circle key={i} cx={x} cy={y} r={r} fill={f} />);

/** Small hand-built diagrams, one per track. Decorative: the card carries the text. */
export function TrackArt({ id, className = '' }: { id: CategoryId; className?: string }) {
  const frame = <><line x1="14" y1="86" x2="186" y2="86" stroke={L} strokeWidth="1.5" /><line x1="14" y1="86" x2="14" y2="12" stroke={L} strokeWidth="1.5" /></>;
  let art: JSX.Element;
  switch (id) {
    case 'foundations': // regression line through scatter
      art = <>{frame}{pts([[32, 74], [48, 66], [60, 70], [74, 56], [90, 58], [104, 46], [118, 48], [134, 34], [150, 36], [168, 24]], B)}<line x1="24" y1="78" x2="178" y2="22" stroke={T} strokeWidth="2.4" strokeLinecap="round" /></>; break;
    case 'supervised': // decision boundary
      art = <>{frame}{pts([[34, 30], [52, 44], [44, 58], [70, 36], [64, 66], [86, 26]], B)}{[[120, 70], [140, 56], [158, 72], [132, 40], [170, 48], [150, 30]].map(([x, y], i) => <rect key={i} x={x - 3} y={y - 3} width="6.4" height="6.4" fill={T} />)}<path d="M72 84 C 84 62, 104 50, 118 12" fill="none" stroke={G} strokeWidth="2.4" strokeLinecap="round" strokeDasharray="1 0" /></>; break;
    case 'unsupervised': // clusters + centroids
      art = <>{pts([[36, 30], [48, 40], [30, 46], [44, 24], [54, 34]], B)}{pts([[110, 72], [124, 64], [102, 60], [118, 80], [132, 76]], T)}{pts([[150, 26], [164, 34], [172, 22], [156, 44], [140, 32]], O)}{[[43, 35, B], [117, 70, T], [156, 31, O]].map(([x, y, c], i) => <g key={i} stroke={G} strokeWidth="2"><circle cx={x as number} cy={y as number} r="15" fill="none" strokeDasharray="3 3" stroke={c as string} /><path d={`M${(x as number) - 5} ${y}h10M${x} ${(y as number) - 5}v10`} /></g>)}</>; break;
    case 'advanced': { // neural nodes
      const cols = [[22, 40, 70], [66, 24, 55, 86], [110, 40, 70], [154, 55]];
      const edges: JSX.Element[] = []; for (let c = 0; c < 3; c++) for (const a of cols[c].slice(1)) for (const b of cols[c + 1].slice(1)) edges.push(<line key={`${c}-${a}-${b}`} x1={cols[c][0]} y1={a} x2={cols[c + 1][0]} y2={b} stroke={L} strokeWidth="1.2" />);
      art = <>{edges}{cols.map((col, ci) => col.slice(1).map((y, i) => <circle key={`${ci}-${i}`} cx={col[0]} cy={y} r="6.5" fill={ci === 3 ? T : ci === 0 ? B : 'rgb(var(--surface))'} stroke={G} strokeWidth="1.8" />))}</>; break; }
    case 'evaluation': // ROC curve
      art = <>{frame}<line x1="14" y1="86" x2="170" y2="14" stroke={L} strokeWidth="1.4" strokeDasharray="4 4" /><path d="M14 86 C 20 38, 44 20, 90 16 S 150 12, 172 12" fill="none" stroke={G} strokeWidth="2.6" strokeLinecap="round" /><circle cx="52" cy="26" r="4.6" fill={T} /></>; break;
    default: // SHAP waterfall
      art = <>{[[18, 0, 40, B], [34, 40, 28, T], [50, 68, -20, B], [66, 48, 36, T], [82, 84, -14, B]].map(([y, x, w, c], i) => <rect key={i} x={Math.min(x as number, (x as number) + (w as number)) + 20} y={y as number} width={Math.abs(w as number)} height="11" fill={c as string} rx="1.5" />)}<line x1="20" y1="10" x2="20" y2="96" stroke={M} strokeWidth="1" /></>;
  }
  return <svg viewBox="0 0 200 100" role="presentation" aria-hidden className={className}>{art}</svg>;
}
