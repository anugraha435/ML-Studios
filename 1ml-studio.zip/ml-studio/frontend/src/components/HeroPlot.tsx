import { useMemo, useState } from 'react';
import { CLASS_COLORS, Marker, Plot2D } from './Plot2D';
import { fitKnn } from '../lib/ml/models';
import { makeShape, type LabeledPoint } from '../lib/data/synthetic';

/** Hero demo: a real 5-nearest-neighbour model that is refitted as you add points. */
export default function HeroPlot() {
  const [pts, setPts] = useState<LabeledPoint[]>(() => makeShape('moons', 60, 3, 0.8)); const [cls, setCls] = useState(0);
  const model = useMemo(() => fitKnn(pts.map((p) => [p.x, p.y]), pts.map((p) => p.c), 2, 5), [pts]);
  return (
    <figure className="card overflow-hidden p-3 sm:p-4">
      <Plot2D height={380} ariaLabel="Interactive demonstration: a nearest-neighbour classifier whose decision regions update as you click to add points"
        region={{ fn: (x, y) => model.predictProba([[x, y]])[0], version: pts.length, res: 70 }} onPlotClick={(x, y) => setPts((p) => [...p, { x, y, c: cls }])}>
        {(s) => <>{pts.map((p, i) => <Marker key={i} x={s.sx(p.x)} y={s.sy(p.y)} c={p.c} r={4.5} />)}</>}
      </Plot2D>
      <figcaption className="mt-3 flex flex-wrap items-center justify-between gap-3 text-sm">
        <span className="text-muted">Click to add a point. The tinted regions come from a real 5-nearest-neighbour model, refitted after every click.</span>
        <span className="flex items-center gap-2" role="radiogroup" aria-label="Class of the point you add">
          {[0, 1].map((c) => <button key={c} type="button" role="radio" aria-checked={cls === c} onClick={() => setCls(c)} className={`rounded-md border px-2.5 py-1 ${cls === c ? 'border-accent bg-accent/10 font-medium' : 'border-line text-muted'}`}><span style={{ color: CLASS_COLORS[c] }}>{c ? '■' : '●'}</span> Class {c ? 'B' : 'A'}</button>)}
          <button type="button" className="rounded-md border border-line px-2.5 py-1 text-muted" onClick={() => setPts(makeShape('moons', 60, 3, 0.8))}>Reset</button>
        </span>
      </figcaption>
    </figure>
  );
}
