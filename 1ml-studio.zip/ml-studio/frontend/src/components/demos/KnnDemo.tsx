import { useMemo, useState } from 'react';
import { DemoShell, Slider, Stat } from '../controls';
import { DragPoint, Plot2D } from '../Plot2D';
import { Legend, NeedBoth, useClassPoints } from './shared';
import { fitKnn, predictClass } from '../../lib/ml/models';

export default function KnnDemo() {
  const d = useClassPoints('moons', 70); const [k, setK] = useState(5); const [weighted, setWeighted] = useState(false);
  const [probe, setProbe] = useState<{ x: number; y: number } | null>({ x: 5, y: 5 });
  const model = useMemo(() => (d.hasBoth ? fitKnn(d.X, d.y, 2, Math.min(k, d.pts.length), weighted) : null), [d.pts, k, weighted, d.hasBoth]); // eslint-disable-line react-hooks/exhaustive-deps
  const nn = useMemo(() => (probe ? d.pts.map((p, i) => ({ i, d: Math.hypot(p.x - probe.x, p.y - probe.y) })).sort((a, b) => a.d - b.d).slice(0, k) : []), [probe, d.pts, k]);
  const pp = model && probe ? model.predictProba([[probe.x, probe.y]])[0] : null;
  const trainAcc = model ? predictClass(model, d.X).filter((v, i) => v === d.y[i]).length / d.y.length : NaN;
  const nb = new Set(nn.map((o) => o.i));
  return (
    <DemoShell title="Let the closest examples vote" note="Real calculation: for every location the k nearest training points (Euclidean distance) vote. Move the pointer over the plot, or click to pin the probe."
      plot={<>
        <Plot2D ariaLabel="k-nearest-neighbour map with probe and its neighbours" region={{ fn: (x, y) => (model ? model.predictProba([[x, y]])[0] : [0.5, 0.5]), version: [model, k, weighted] }} res={70} onPlotClick={(x, y) => setProbe({ x, y })} onPlotMove={(x, y) => setProbe({ x, y })}>
          {(s) => (<>
            {probe && nn.map((o) => <line key={o.i} x1={s.sx(probe.x)} y1={s.sy(probe.y)} x2={s.sx(d.pts[o.i].x)} y2={s.sy(d.pts[o.i].y)} stroke="rgb(var(--ink))" strokeOpacity={0.55} />)}
            {probe && nn.length > 0 && <circle cx={s.sx(probe.x)} cy={s.sy(probe.y)} r={Math.abs(s.sx(nn[nn.length - 1].d) - s.sx(0))} fill="none" stroke="rgb(var(--ink))" strokeDasharray="4 4" strokeOpacity={0.6} />}
            {d.pts.map((q, i) => <DragPoint key={i} s={s} x={q.x} y={q.y} c={q.c} ring={nb.has(i)} dim={nn.length > 0 && !nb.has(i)} label={`Class ${q.c ? 'B' : 'A'} point${nb.has(i) ? ', one of the nearest neighbours' : ''}`} onDrag={(x, y) => d.move(i, x, y)} onRemove={() => d.remove(i)} />)}
            {probe && <circle cx={s.sx(probe.x)} cy={s.sy(probe.y)} r={4} fill="rgb(var(--ink))" pointerEvents="none" />}
          </>)}
        </Plot2D>
        <div className="mt-2"><Legend /></div>
      </>}
      readout={model ? <div className="grid grid-cols-2 gap-3 sm:grid-cols-3"><Stat label="Probe prediction" value={pp ? (pp[1] >= 0.5 ? 'Class B' : 'Class A') : '–'} sub={pp ? `P(B) = ${pp[1].toFixed(2)}` : 'move over the plot'} /><Stat label="Neighbours that are class B" value={`${nn.filter((o) => d.pts[o.i].c === 1).length} of ${nn.length}`} /><Stat label="Training accuracy" value={trainAcc.toFixed(3)} sub={k === 1 ? 'k = 1 always memorises the data' : 'optimistic: measured on training points'} /></div> : <NeedBoth />}
      controls={<>
        {d.panel}
        <Slider label="k (neighbours)" value={k} min={1} max={25} onChange={setK} hint="Small k follows noise. Large k blurs real structure." />
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" className="accent-[rgb(var(--accent))]" checked={weighted} onChange={(e) => setWeighted(e.target.checked)} />Weight votes by 1 / distance</label>
      </>}
    />
  );
}
