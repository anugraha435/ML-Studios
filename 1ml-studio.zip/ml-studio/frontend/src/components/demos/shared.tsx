import { useState } from 'react';
import { Segmented } from '../controls';
import { makeShape, SHAPES, type LabeledPoint, type ShapeId } from '../../lib/data/synthetic';
import { CLASS_COLORS } from '../Plot2D';

export function useClassPoints(initial: ShapeId = 'overlap', n = 70) {
  const [shape, setShape] = useState<ShapeId>(initial); const [seed, setSeed] = useState(1); const [paint, setPaint] = useState(0);
  const [pts, setPts] = useState<LabeledPoint[]>(() => makeShape(initial, n, 1));
  return {
    pts, setPts, shape, paint,
    X: pts.map((p) => [p.x, p.y]), y: pts.map((p) => p.c),
    add: (x: number, y: number) => setPts((a) => [...a, { x, y, c: paint }]),
    move: (i: number, x: number, y: number) => setPts((a) => a.map((p, j) => (j === i ? { ...p, x, y } : p))),
    remove: (i: number) => setPts((a) => a.filter((_, j) => j !== i)),
    panel: (
      <div className="space-y-4">
        <Segmented label="Dataset shape" value={shape} options={SHAPES.map((s) => ({ value: s.id, label: s.label }))} onChange={(v) => { setShape(v); setPts(makeShape(v, n, seed)); }} />
        <Segmented label="Class to add when you click" value={paint} options={[{ value: 0, label: 'Class A (circle)' }, { value: 1, label: 'Class B (square)' }]} onChange={setPaint} />
        <div className="flex flex-wrap gap-2">
          <button type="button" className="btn btn-ghost" onClick={() => { const s = seed + 1; setSeed(s); setPts(makeShape(shape, n, s)); }}>New random sample</button>
          <button type="button" className="btn btn-ghost" onClick={() => setPts([])}>Clear</button>
        </div>
        <p className="hint">Click to add a point, drag to move, double-click to remove. Keyboard: focus a point, arrow keys move it, Delete removes it. Colour tints show what the model would predict at each location.</p>
      </div>
    ),
    hasBoth: new Set(pts.map((p) => p.c)).size === 2 && pts.length >= 6
  };
}
export const Legend = () => (
  <p className="flex flex-wrap gap-x-4 text-xs text-muted"><span><span style={{ color: CLASS_COLORS[0] }}>●</span> Class A</span><span><span style={{ color: CLASS_COLORS[1] }}>■</span> Class B</span></p>
);
export const NeedBoth = () => <p className="rounded-md border border-line p-4 text-sm text-muted">Add at least three points of each class to train a model.</p>;
