import { useMemo, useState } from 'react';
import { DemoShell, Segmented, Slider, Stat } from '../controls';
import { DragPoint, Plot2D } from '../Plot2D';
import { Legend, NeedBoth, useClassPoints } from './shared';
import { fitSvmBinary, type Kernel } from '../../lib/ml/models';
import { contourSegments } from '../../lib/contour';

export default function SvmDemo() {
  const d = useClassPoints('overlap', 60);
  const [kernel, setKernel] = useState<'linear' | 'rbf' | 'poly'>('linear'); const [C, setC] = useState(1); const [gamma, setGamma] = useState(0.3); const [degree, setDegree] = useState(3);
  const k: Kernel = kernel === 'linear' ? { type: 'linear' } : kernel === 'rbf' ? { type: 'rbf', gamma } : { type: 'poly', degree, gamma: gamma / 5, coef0: 1 };
  const model = useMemo(() => (d.hasBoth ? fitSvmBinary(d.X, d.y, C, k) : null), [d.pts, kernel, C, gamma, degree, d.hasBoth]); // eslint-disable-line react-hooks/exhaustive-deps
  const f = (x: number, y: number) => (model ? model.decision([[x, y]])[0] : 0);
  const segs = useMemo(() => (model ? { mid: contourSegments(f, 0, { x: [0, 10], y: [0, 10] }, 56), up: contourSegments(f, 1, { x: [0, 10], y: [0, 10] }, 56), lo: contourSegments(f, -1, { x: [0, 10], y: [0, 10] }, 56) } : null), [model]); // eslint-disable-line react-hooks/exhaustive-deps
  const svSet = new Set(model?.svIdx ?? []);
  const acc = model ? model.decision(d.X).filter((v, i) => (v > 0 ? 1 : 0) === d.y[i]).length / d.y.length : NaN;
  const atC = model ? model.alpha.filter((a) => a >= C - 1e-6).length : 0;
  const lin = kernel === 'linear' && model ? (() => { const w = [0, 0]; model.svIdx.forEach((i, t) => { w[0] += model.coef[t] * d.X[i][0]; w[1] += model.coef[t] * d.X[i][1]; }); const n = Math.hypot(w[0], w[1]); return n ? 2 / n : NaN; })() : NaN;
  return (
    <DemoShell title="Widest street between the classes" note="Real calculation: a soft-margin SVM solved with sequential minimal optimisation. Solid line: decision value 0. Dashed lines: decision values −1 and +1 (the margin). Ringed points are support vectors."
      plot={<>
        <Plot2D ariaLabel="SVM decision boundary, margins and support vectors" region={{ fn: (x, y) => { const v = f(x, y); const p = 1 / (1 + Math.exp(-2 * v)); return [1 - p, p]; }, version: [model, kernel, C, gamma, degree], res: 64 }} onPlotClick={d.add}>
          {(s) => (<>
            {segs?.up.map((g, i) => <line key={'u' + i} x1={s.sx(g[0])} y1={s.sy(g[1])} x2={s.sx(g[2])} y2={s.sy(g[3])} stroke="rgb(var(--ink))" strokeDasharray="5 4" strokeWidth={1.3} />)}
            {segs?.lo.map((g, i) => <line key={'l' + i} x1={s.sx(g[0])} y1={s.sy(g[1])} x2={s.sx(g[2])} y2={s.sy(g[3])} stroke="rgb(var(--ink))" strokeDasharray="5 4" strokeWidth={1.3} />)}
            {segs?.mid.map((g, i) => <line key={'m' + i} x1={s.sx(g[0])} y1={s.sy(g[1])} x2={s.sx(g[2])} y2={s.sy(g[3])} stroke="rgb(var(--ink))" strokeWidth={2.6} />)}
            {d.pts.map((q, i) => <DragPoint key={i} s={s} x={q.x} y={q.y} c={q.c} ring={svSet.has(i)} label={`Class ${q.c ? 'B' : 'A'} point${svSet.has(i) ? ', support vector' : ''}`} onDrag={(x, y) => d.move(i, x, y)} onRemove={() => d.remove(i)} />)}
          </>)}
        </Plot2D>
        <div className="mt-2"><Legend /></div>
      </>}
      readout={model ? <div className="grid grid-cols-2 gap-3 sm:grid-cols-4"><Stat label="Support vectors" value={model.svIdx.length} sub={`${atC} inside or beyond the margin`} /><Stat label="Training accuracy" value={acc.toFixed(3)} /><Stat label="Margin width" value={Number.isFinite(lin) ? lin.toFixed(2) : '–'} sub={kernel === 'linear' ? '2 / ‖w‖' : 'defined for the linear kernel'} /><Stat label="SMO iterations" value={model.iterations} /></div> : <NeedBoth />}
      controls={<>
        {d.panel}
        <Segmented label="Kernel" value={kernel} options={[{ value: 'linear', label: 'Linear' }, { value: 'rbf', label: 'RBF' }, { value: 'poly', label: 'Polynomial' }]} onChange={setKernel} />
        <Slider label="C (penalty for margin violations)" value={Math.log10(C)} min={-2} max={3} step={0.1} onChange={(v) => setC(+Math.pow(10, v).toFixed(3))} format={() => C.toPrecision(3)} hint="Small C: wide, tolerant margin. Large C: narrow margin that tries to classify every point." />
        {kernel !== 'linear' && <Slider label="Gamma (kernel width)" value={gamma} min={0.02} max={3} step={0.02} onChange={setGamma} format={(v) => v.toFixed(2)} hint="Large gamma gives a very local, wiggly boundary." />}
        {kernel === 'poly' && <Slider label="Polynomial degree" value={degree} min={2} max={5} onChange={setDegree} />}
      </>}
    />
  );
}
