import { useMemo, useState } from 'react';
import { DemoShell, Segmented, Slider, Stat } from '../controls';
import { CLASS_COLORS, DragPoint, Plot2D } from '../Plot2D';
import { argmin, kmeansInit } from '../../lib/ml/models';
import { makeBlobs } from '../../lib/data/synthetic';

type P = { x: number; y: number };
interface S { cents: P[]; assign: number[]; iter: number; phase: 'init' | 'assigned' | 'updated'; trails: P[][]; inertia: number[]; converged: boolean }
const sqd = (a: P, b: P) => (a.x - b.x) ** 2 + (a.y - b.y) ** 2;
const inertia = (pts: P[], cents: P[], assign: number[]) => pts.reduce((s, p, i) => s + sqd(p, cents[assign[i]]), 0);
function fresh(pts: P[], k: number, seed: number, pp: boolean): S {
  const cents = pts.length >= k ? kmeansInit(pts.map((p) => [p.x, p.y]), k, seed, pp).map(([x, y]) => ({ x, y })) : [];
  return { cents, assign: [], iter: 0, phase: 'init', trails: cents.map((c) => [c]), inertia: [], converged: false };
}
function assignStep(pts: P[], s: S): S { const assign = pts.map((p) => argmin(s.cents.map((c) => sqd(p, c)))); const same = s.assign.length === assign.length && assign.every((a, i) => a === s.assign[i]); return { ...s, assign, phase: 'assigned', inertia: [...s.inertia, inertia(pts, s.cents, assign)], converged: same && s.phase === 'updated' }; }
function updateStep(pts: P[], s: S): S {
  const cents = s.cents.map((c, k) => { const m = pts.filter((_, i) => s.assign[i] === k); return m.length ? { x: m.reduce((a, p) => a + p.x, 0) / m.length, y: m.reduce((a, p) => a + p.y, 0) / m.length } : c; });
  return { ...s, cents, phase: 'updated', iter: s.iter + 1, trails: s.trails.map((t, k) => [...t, cents[k]]) };
}

export default function KMeansDemo() {
  const [pts, setPts] = useState<P[]>(() => makeBlobs(3, 24)); const [k, setK] = useState(3); const [seed, setSeed] = useState(3); const [pp, setPp] = useState(true);
  const [st, setSt] = useState<S>(() => fresh(makeBlobs(3, 24), 3, 3, true));
  const reset = (p = pts, kk = k, sd = seed, plus = pp) => setSt(fresh(p, kk, sd, plus));
  const canRun = pts.length >= k && k >= 1;
  const step = () => setSt((s) => (s.phase === 'init' || s.phase === 'updated' ? assignStep(pts, s) : updateStep(pts, s)));
  const run = () => setSt((s0) => { let s = s0.phase === 'assigned' ? updateStep(pts, s0) : s0; for (let i = 0; i < 100; i++) { s = assignStep(pts, s); if (s.converged) break; s = updateStep(pts, s); } return s; });
  const sizes = useMemo(() => st.cents.map((_, c) => st.assign.filter((a) => a === c).length), [st]);
  const next = st.phase === 'assigned' ? 'Update: move centroids' : 'Assign: nearest centroid';
  const dirty = (p: P[]) => { setPts(p); setSt((s) => ({ ...s, assign: [], phase: s.iter === 0 ? 'init' : s.phase, converged: false })); };
  return (
    <DemoShell title="Step through k-means" note="Real calculation: Lloyd's algorithm. Assign every point to its nearest centroid, then move each centroid to the mean of its points, and repeat until nothing changes."
      plot={<>
        <Plot2D ariaLabel="Points coloured by cluster with centroid positions and trails" onPlotClick={(x, y) => dirty([...pts, { x, y }])}>
          {(s) => (<>
            {st.trails.map((t, c) => <polyline key={c} fill="none" stroke={CLASS_COLORS[c % 6]} strokeWidth={1.6} strokeDasharray="3 3" points={t.map((q) => `${s.sx(q.x)},${s.sy(q.y)}`).join(' ')} />)}
            {pts.map((q, i) => st.assign.length === pts.length
              ? <DragPoint key={i} s={s} x={q.x} y={q.y} c={st.assign[i]} r={4.5} label={`Point in cluster ${st.assign[i] + 1}`} onDrag={(x, y) => dirty(pts.map((p, j) => (j === i ? { x, y } : p)))} onRemove={() => dirty(pts.filter((_, j) => j !== i))} />
              : <DragPoint key={i} s={s} x={q.x} y={q.y} c={0} dim r={4.5} label="Unassigned point" onDrag={(x, y) => dirty(pts.map((p, j) => (j === i ? { x, y } : p)))} onRemove={() => dirty(pts.filter((_, j) => j !== i))} />)}
            {st.cents.map((c, i) => <g key={i} pointerEvents="none"><circle cx={s.sx(c.x)} cy={s.sy(c.y)} r={11} fill={CLASS_COLORS[i % 6]} stroke="rgb(var(--ink))" strokeWidth={2.4} /><text x={s.sx(c.x)} y={s.sy(c.y) + 4} fontSize="11" fontWeight="600" textAnchor="middle" fill="#fff">{i + 1}</text></g>)}
          </>)}
        </Plot2D>
        <p className="mt-2 text-xs text-muted">Numbered discs are centroids; dashed lines are their paths. Faded points have not been assigned yet.</p>
      </>}
      readout={<div className="space-y-3">
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4"><Stat label="Iterations" value={st.iter} /><Stat label="Inertia" value={st.inertia.length ? st.inertia[st.inertia.length - 1].toFixed(1) : '–'} sub="sum of squared distances" /><Stat label="Cluster sizes" value={sizes.length && st.assign.length ? sizes.join(' / ') : '–'} /><Stat label="Status" value={st.converged ? 'Converged' : 'Running'} /></div>
        {st.inertia.length > 1 && <InertiaChart v={st.inertia} />}
        <p className="text-sm text-muted" aria-live="polite">{st.converged ? 'No assignment changed in the last pass, so the algorithm has converged. Try another seed: a different start can end in a different, sometimes worse, solution.' : `Next step: ${next}.`}</p>
      </div>}
      controls={<>
        <Slider label="Number of clusters k" value={k} min={1} max={6} onChange={(v) => { setK(v); reset(pts, v); }} />
        <Segmented label="Initialisation" value={pp ? 'pp' : 'rand'} options={[{ value: 'pp', label: 'k-means++' }, { value: 'rand', label: 'Random points' }]} onChange={(v) => { setPp(v === 'pp'); reset(pts, k, seed, v === 'pp'); }} />
        <div className="flex flex-wrap gap-2">
          <button type="button" className="btn btn-primary" disabled={!canRun || st.converged} onClick={step}>{next}</button>
          <button type="button" className="btn btn-ghost" disabled={!canRun || st.converged} onClick={run}>Run to convergence</button>
        </div>
        <div className="flex flex-wrap gap-2">
          <button type="button" className="btn btn-ghost" onClick={() => { const s = seed + 1; setSeed(s); reset(pts, k, s); }}>New starting centroids</button>
          <button type="button" className="btn btn-ghost" onClick={() => reset()}>Restart</button>
        </div>
        <div className="flex flex-wrap gap-2">
          <button type="button" className="btn btn-ghost" onClick={() => { const p = makeBlobs(3, 24, seed + 10); setPts(p); reset(p); }}>Three blobs</button>
          <button type="button" className="btn btn-ghost" onClick={() => { setPts([]); reset([], k); }}>Clear points</button>
        </div>
        <p className="hint">Click the plot to add points, drag to move them, double-click to remove. Changing the points restarts the assignment.</p>
        {!canRun && <p className="text-sm text-bad" role="alert">Add at least {k} points to place {k} centroids.</p>}
      </>}
    />
  );
}
function InertiaChart({ v }: { v: number[] }) {
  const W = 360, H = 90, m = 8, max = Math.max(...v), min = Math.min(...v);
  const pts = v.map((y, i) => `${m + (i / Math.max(1, v.length - 1)) * (W - 2 * m)},${m + (1 - (y - min) / Math.max(1e-9, max - min)) * (H - 2 * m)}`).join(' ');
  return <figure><svg viewBox={`0 0 ${W} ${H}`} className="w-full max-w-sm" role="img" aria-label={`Inertia falls from ${max.toFixed(1)} to ${min.toFixed(1)} over ${v.length} assignment steps`}><polyline points={pts} fill="none" stroke="rgb(var(--accent))" strokeWidth={2.4} />{v.map((_, i) => { const [x, y] = pts.split(' ')[i].split(','); return <circle key={i} cx={x} cy={y} r={3} fill="rgb(var(--accent))" />; })}</svg><figcaption className="hint">Inertia after each assignment step never increases.</figcaption></figure>;
}
