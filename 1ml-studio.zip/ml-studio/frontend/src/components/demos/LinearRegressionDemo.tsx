import { useMemo, useState } from 'react';
import { DemoShell, Slider, Stat } from '../controls';
import { DragPoint, Plot2D } from '../Plot2D';
import { fitLinear } from '../../lib/ml/models';
import { r2 } from '../../lib/ml/metrics';
import { makeLine } from '../../lib/data/synthetic';

interface P { x: number; y: number }
export default function LinearRegressionDemo() {
  const [pts, setPts] = useState<P[]>(() => makeLine());
  const [showRes, setShowRes] = useState(true); const [mySlope, setMySlope] = useState(0.2); const [myInt, setMyInt] = useState(5);
  const [xq, setXq] = useState(7); const [edit, setEdit] = useState(false);
  const fit = useMemo(() => (pts.length >= 2 && new Set(pts.map((p) => p.x)).size >= 2 ? fitLinear(pts.map((p) => [p.x]), pts.map((p) => p.y)) : null), [pts]);
  const b0 = fit?.intercept ?? 0, b1 = fit?.coef[0] ?? 0;
  const sse = (a: number, b: number) => pts.reduce((s, p) => s + (p.y - (a + b * p.x)) ** 2, 0);
  const yhat = pts.map((p) => b0 + b1 * p.x);
  const R2 = fit ? r2(pts.map((p) => p.y), yhat) : NaN;
  return (
    <DemoShell title="Fit a line to your own data" note="Real calculation: the best-fit line is the exact least-squares solution recomputed every time a point changes."
      plot={
        <Plot2D ariaLabel={`Scatter plot of ${pts.length} points with the least-squares line`} xLabel="x" yLabel="y" onPlotClick={(x, y) => setPts((p) => [...p, { x, y }])}>
          {(s) => (<>
            {fit && showRes && pts.map((p, i) => <line key={'r' + i} x1={s.sx(p.x)} x2={s.sx(p.x)} y1={s.sy(p.y)} y2={s.sy(yhat[i])} stroke="#C86D51" strokeWidth={1.6} />)}
            <line x1={s.sx(0)} y1={s.sy(myInt)} x2={s.sx(10)} y2={s.sy(myInt + mySlope * 10)} stroke="rgb(var(--muted))" strokeDasharray="6 4" strokeWidth={2} />
            {fit && <line x1={s.sx(0)} y1={s.sy(b0)} x2={s.sx(10)} y2={s.sy(b0 + b1 * 10)} stroke="rgb(var(--accent))" strokeWidth={2.6} />}
            {fit && <g><line x1={s.sx(xq)} x2={s.sx(xq)} y1={s.sy(0)} y2={s.sy(b0 + b1 * xq)} stroke="rgb(var(--accent))" strokeDasharray="3 3" /><circle cx={s.sx(xq)} cy={s.sy(b0 + b1 * xq)} r={6} fill="none" stroke="rgb(var(--accent))" strokeWidth={2.4} /></g>}
            {pts.map((p, i) => <DragPoint key={i} s={s} x={p.x} y={p.y} c={0} label={`Point ${i + 1} at x ${p.x.toFixed(1)}, y ${p.y.toFixed(1)}`} onDrag={(x, y) => setPts((a) => a.map((q, j) => (j === i ? { x, y } : q)))} onRemove={() => setPts((a) => a.filter((_, j) => j !== i))} />)}
          </>)}
        </Plot2D>
      }
      readout={
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <Stat label="Best-fit slope" value={fit ? b1.toFixed(3) : '–'} /><Stat label="Best-fit intercept" value={fit ? b0.toFixed(3) : '–'} />
            <Stat label="Sum of squared residuals" value={fit ? sse(b0, b1).toFixed(2) : '–'} sub="smallest possible" /><Stat label="R²" value={Number.isFinite(R2) ? R2.toFixed(3) : '–'} sub="share of variance explained" />
          </div>
          <p className="text-sm" aria-live="polite">{fit ? <>Your dashed line has error <strong className="num">{sse(myInt, mySlope).toFixed(2)}</strong> against <strong className="num">{sse(b0, b1).toFixed(2)}</strong> for the best-fit line. At x = {xq.toFixed(1)} the model predicts y = <strong className="num">{(b0 + b1 * xq).toFixed(2)}</strong>.</> : 'Add at least two points with different x values to fit a line.'}</p>
          <button type="button" className="text-sm underline" onClick={() => setEdit((e) => !e)} aria-expanded={edit}>{edit ? 'Hide' : 'Edit points as numbers'}</button>
          {edit && (
            <div className="max-h-64 overflow-auto rounded-md border border-line"><table className="w-full text-sm"><caption className="sr-only">Data points</caption><thead className="bg-raised"><tr><th className="p-2 text-left">#</th><th className="p-2 text-left">x</th><th className="p-2 text-left">y</th><th className="p-2"><span className="sr-only">Remove</span></th></tr></thead><tbody>
              {pts.map((p, i) => <tr key={i} className="border-t border-line"><td className="p-2 num">{i + 1}</td>{(['x', 'y'] as const).map((k) => <td key={k} className="p-1"><input aria-label={`Point ${i + 1} ${k}`} type="number" step="0.1" min={0} max={10} className="input !min-h-8 !py-1" value={+p[k].toFixed(2)} onChange={(e) => { const v = Math.min(10, Math.max(0, Number(e.target.value))); if (Number.isFinite(v)) setPts((a) => a.map((q, j) => (j === i ? { ...q, [k]: v } : q))); }} /></td>)}<td className="p-1"><button type="button" className="btn btn-ghost !min-h-8 !px-2" onClick={() => setPts((a) => a.filter((_, j) => j !== i))} aria-label={`Remove point ${i + 1}`}>Remove</button></td></tr>)}
            </tbody></table></div>
          )}
        </div>
      }
      controls={<>
        <p className="text-sm text-muted">Click the plot to add a point. Drag a point to move it, double-click to remove it. With the keyboard, focus a point and use the arrow keys.</p>
        <Slider label="Your line: slope" value={mySlope} min={-2} max={2} step={0.05} onChange={setMySlope} format={(v) => v.toFixed(2)} />
        <Slider label="Your line: intercept" value={myInt} min={-5} max={10} step={0.1} onChange={setMyInt} format={(v) => v.toFixed(1)} />
        <Slider label="Predict at x" value={xq} min={0} max={10} step={0.1} onChange={setXq} format={(v) => v.toFixed(1)} />
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" className="accent-[rgb(var(--accent))]" checked={showRes} onChange={(e) => setShowRes(e.target.checked)} />Show residuals (pink)</label>
        <div className="flex gap-2"><button type="button" className="btn btn-ghost" onClick={() => setPts(makeLine())}>Reset data</button><button type="button" className="btn btn-ghost" onClick={() => setPts([])}>Clear</button></div>
      </>}
    />
  );
}
