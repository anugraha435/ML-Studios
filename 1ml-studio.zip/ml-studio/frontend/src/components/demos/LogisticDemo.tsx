import { useMemo, useState } from 'react';
import { DemoShell, Slider, Stat } from '../controls';
import { DragPoint, Plot2D } from '../Plot2D';
import { Legend, NeedBoth, useClassPoints } from './shared';
import { fitLogisticBinary } from '../../lib/ml/models';
import { sigmoid } from '../../lib/ml/linalg';
import { confusion, accuracy, precision, recall } from '../../lib/ml/metrics';

export default function LogisticDemo() {
  const d = useClassPoints('overlap');
  const [w1, setW1] = useState(0.5), [w2, setW2] = useState(0.5), [b, setB] = useState(-5), [thr, setThr] = useState(0.5);
  const p = (x: number, y: number) => sigmoid(w1 * x + w2 * y + b);
  const probs = d.pts.map((q) => p(q.x, q.y)), pred = probs.map((v) => (v >= thr ? 1 : 0));
  const c = confusion(d.y, pred);
  const logloss = d.pts.length ? -d.pts.reduce((s, q, i) => s + (q.c ? Math.log(Math.max(probs[i], 1e-12)) : Math.log(Math.max(1 - probs[i], 1e-12))), 0) / d.pts.length : NaN;
  const version = [w1, w2, b, d.pts.length].join('|');
  const fit = () => { const m = fitLogisticBinary(d.X, d.y, 10); setW1(+m.coef[0].toFixed(3)); setW2(+m.coef[1].toFixed(3)); setB(+m.intercept.toFixed(3)); };
  const boundary = useMemo(() => {
    const t = Math.log(thr / (1 - thr)), seg: [number, number][] = [];
    for (const x of [0, 10]) { if (Math.abs(w2) > 1e-9) seg.push([x, (t - b - w1 * x) / w2]); }
    if (seg.length < 2 && Math.abs(w1) > 1e-9) { const x = (t - b) / w1; return [[x, 0], [x, 10]] as [number, number][]; }
    return seg;
  }, [w1, w2, b, thr]);
  const zs = d.pts.map((q) => w1 * q.x + w2 * q.y + b);
  return (
    <DemoShell title="Move the boundary, read the probabilities" note="Real calculation: each point's probability is the sigmoid of w₁x₁ + w₂x₂ + b with the weights you set. Press Fit to compute the maximum-likelihood weights (L2 strength C = 10)."
      plot={<>
        <Plot2D ariaLabel="Classification data with logistic regression probability map and decision boundary" region={{ fn: (x, y) => [1 - p(x, y), p(x, y)], version }} onPlotClick={d.add}>
          {(s) => (<>
            {boundary.length === 2 && <line x1={s.sx(boundary[0][0])} y1={s.sy(boundary[0][1])} x2={s.sx(boundary[1][0])} y2={s.sy(boundary[1][1])} stroke="rgb(var(--ink))" strokeWidth={2.4} />}
            {d.pts.map((q, i) => <DragPoint key={i} s={s} x={q.x} y={q.y} c={q.c} dim={pred[i] !== q.c} label={`Class ${q.c ? 'B' : 'A'} point, probability of B ${probs[i].toFixed(2)}`} onDrag={(x, y) => d.move(i, x, y)} onRemove={() => d.remove(i)} />)}
          </>)}
        </Plot2D>
        <div className="mt-2 flex items-center justify-between"><Legend /><p className="text-xs text-muted">Faded points are misclassified at the current threshold. Black line: where p equals the threshold.</p></div>
      </>}
      readout={<div className="space-y-4">
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4"><Stat label="Accuracy" value={Number.isFinite(accuracy(c)) ? accuracy(c).toFixed(3) : '–'} /><Stat label="Precision" value={Number.isFinite(precision(c)) ? precision(c).toFixed(3) : '–'} /><Stat label="Recall" value={Number.isFinite(recall(c)) ? recall(c).toFixed(3) : '–'} /><Stat label="Log-loss" value={Number.isFinite(logloss) ? logloss.toFixed(3) : '–'} sub="lower is better" /></div>
        <SigmoidChart zs={zs} cs={d.y} thr={thr} />
      </div>}
      controls={<>
        {d.panel}
        {d.hasBoth ? <button type="button" className="btn btn-primary w-full" onClick={fit}>Fit to the data</button> : <NeedBoth />}
        <Slider label="Weight w₁ (x₁)" value={w1} min={-3} max={3} step={0.05} onChange={setW1} format={(v) => v.toFixed(2)} />
        <Slider label="Weight w₂ (x₂)" value={w2} min={-3} max={3} step={0.05} onChange={setW2} format={(v) => v.toFixed(2)} />
        <Slider label="Bias b" value={b} min={-20} max={20} step={0.1} onChange={setB} format={(v) => v.toFixed(1)} />
        <Slider label="Classification threshold" value={thr} min={0.05} max={0.95} step={0.01} onChange={setThr} format={(v) => v.toFixed(2)} hint="Lower it to catch more of class B at the cost of more false alarms." />
      </>}
    />
  );
}

function SigmoidChart({ zs, cs, thr }: { zs: number[]; cs: number[]; thr: number }) {
  const W = 560, H = 170, m = { l: 36, r: 10, t: 8, b: 26 }, zr = 8;
  const sx = (z: number) => m.l + ((Math.max(-zr, Math.min(zr, z)) + zr) / (2 * zr)) * (W - m.l - m.r), sy = (p: number) => H - m.b - p * (H - m.t - m.b);
  const path = Array.from({ length: 81 }, (_, i) => { const z = -zr + (2 * zr * i) / 80; return `${i ? 'L' : 'M'}${sx(z).toFixed(1)},${sy(sigmoid(z)).toFixed(1)}`; }).join(' ');
  return (
    <figure>
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full" role="img" aria-label="Sigmoid curve with each data point placed at its score z. Points to the right of the threshold are predicted class B.">
        <rect x={m.l} y={m.t} width={W - m.l - m.r} height={H - m.t - m.b} fill="none" stroke="rgb(var(--line))" />
        <line x1={m.l} x2={W - m.r} y1={sy(thr)} y2={sy(thr)} stroke="rgb(var(--warn))" strokeDasharray="5 4" /><text x={W - m.r - 4} y={sy(thr) - 4} fontSize="11" textAnchor="end" fill="rgb(var(--warn))">threshold {thr.toFixed(2)}</text>
        <path d={path} fill="none" stroke="rgb(var(--accent))" strokeWidth={2.5} />
        {zs.map((z, i) => <circle key={i} cx={sx(z)} cy={sy(cs[i] ? 0.04 : 0.96) + (cs[i] ? 0 : 0)} r={3.2} fill={cs[i] ? '#C86D51' : '#3B82F6'} opacity={0.65} />)}
        {[-8, -4, 0, 4, 8].map((t) => <text key={t} x={sx(t)} y={H - 8} textAnchor="middle" fontSize="11" fill="rgb(var(--muted))">{t}</text>)}
        {[0, 0.5, 1].map((t) => <text key={t} x={m.l - 5} y={sy(t) + 4} textAnchor="end" fontSize="11" fill="rgb(var(--muted))">{t}</text>)}
        <text x={(W + m.l) / 2} y={H - 0} fontSize="11" textAnchor="middle" fill="rgb(var(--muted))" />
      </svg>
      <figcaption className="hint">Sigmoid: probability p = 1 / (1 + e^−z). Dots show each point's score z = w₁x₁ + w₂x₂ + b (top row class A, bottom row class B). Scores beyond ±8 are drawn at the edge.</figcaption>
    </figure>
  );
}
