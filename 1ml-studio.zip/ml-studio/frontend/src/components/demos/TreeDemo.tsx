import { useMemo, useState } from 'react';
import { DemoShell, Slider, Stat } from '../controls';
import { CLASS_COLORS, DragPoint, Plot2D } from '../Plot2D';
import { Legend, NeedBoth, useClassPoints } from './shared';
import { fitTree, giniOf, predictClass, type TreeNode } from '../../lib/ml/models';

interface Laid { n: TreeNode; x: number; y: number }
function layout(root: TreeNode): { nodes: Laid[]; leaves: number; depth: number } {
  const nodes: Laid[] = []; let leaf = 0, depth = 0;
  const go = (n: TreeNode): number => { depth = Math.max(depth, n.depth); const x = n.left && n.right ? (go(n.left) + go(n.right)) / 2 : leaf++; nodes.push({ n, x, y: n.depth }); return x; };
  go(root); return { nodes, leaves: leaf, depth };
}
function splitLines(n: TreeNode, box: [number, number, number, number], out: { x1: number; y1: number; x2: number; y2: number; depth: number }[]) {
  if (!n.left || !n.right) return;
  const [x0, y0, x1, y1] = box, t = n.threshold!;
  if (n.feature === 0) { out.push({ x1: t, y1: y0, x2: t, y2: y1, depth: n.depth }); splitLines(n.left, [x0, y0, t, y1], out); splitLines(n.right, [t, y0, x1, y1], out); }
  else { out.push({ x1: x0, y1: t, x2: x1, y2: t, depth: n.depth }); splitLines(n.left, [x0, y0, x1, t], out); splitLines(n.right, [x0, t, x1, y1], out); }
}
const fname = (f: number) => (f === 0 ? 'x₁' : 'x₂');

export default function TreeDemo() {
  const d = useClassPoints('xor', 80);
  const [depth, setDepth] = useState(2); const [sel, setSel] = useState(0);
  const tree = useMemo(() => (d.hasBoth ? fitTree(d.X, d.y, 2, { maxDepth: depth, minSamplesSplit: 2 }) : null), [d.pts, depth, d.hasBoth]); // eslint-disable-line react-hooks/exhaustive-deps
  const lay = useMemo(() => (tree ? layout(tree.root) : null), [tree]);
  const lines = useMemo(() => { const o: { x1: number; y1: number; x2: number; y2: number; depth: number }[] = []; if (tree) splitLines(tree.root, [0, 0, 10, 10], o); return o; }, [tree]);
  const node = lay?.nodes.find((o) => o.n.id === sel)?.n ?? tree?.root;
  const acc = tree ? predictClass(tree, d.X).filter((v, i) => v === d.y[i]).length / d.y.length : NaN;
  const maxDepthUsed = lay?.depth ?? 0;
  return (
    <DemoShell title="Grow a tree and watch the plane get cut up" note="Real calculation: at every node the algorithm tries every feature and every midpoint threshold and keeps the split with the largest Gini impurity decrease (CART)."
      plot={<>
        <Plot2D ariaLabel="Data with decision tree regions and split lines" region={{ fn: (x, y) => (tree ? tree.predictProba([[x, y]])[0] : [0.5, 0.5]), version: [tree, depth] }} onPlotClick={d.add}>
          {(s) => (<>
            {lines.map((l, i) => <line key={i} x1={s.sx(l.x1)} y1={s.sy(l.y1)} x2={s.sx(l.x2)} y2={s.sy(l.y2)} stroke="rgb(var(--ink))" strokeWidth={Math.max(1, 3 - l.depth * 0.6)} />)}
            {d.pts.map((q, i) => <DragPoint key={i} s={s} x={q.x} y={q.y} c={q.c} label={`Class ${q.c ? 'B' : 'A'} point`} onDrag={(x, y) => d.move(i, x, y)} onRemove={() => d.remove(i)} />)}
          </>)}
        </Plot2D>
        <div className="mt-2 flex items-center justify-between"><Legend /><p className="text-xs text-muted">Thicker lines are earlier (higher) splits.</p></div>
      </>}
      readout={tree && lay && node ? (
        <div className="space-y-4">
          <div className="grid grid-cols-3 gap-3"><Stat label="Training accuracy" value={acc.toFixed(3)} /><Stat label="Leaves" value={lay.leaves} /><Stat label="Depth used" value={maxDepthUsed} sub={`of ${depth} allowed`} /></div>
          <div className="overflow-x-auto rounded-md border border-line bg-surface"><TreeDiagram lay={lay} sel={node.id} onSel={setSel} /></div>
          <div className="rounded-md border border-line p-4 text-sm" aria-live="polite">
            <p className="font-medium">Node {node.id}: {node.n} points ({node.counts[0]} class A, {node.counts[1]} class B)</p>
            <p className="mt-1">Gini impurity = 1 − ({node.counts[0]}/{node.n})² − ({node.counts[1]}/{node.n})² = <strong className="num">{node.gini.toFixed(3)}</strong></p>
            {node.left && node.right ? (() => { const gl = node.left!.gini, gr = node.right!.gini, w = (node.left!.n / node.n) * gl + (node.right!.n / node.n) * gr; return (
              <p className="mt-1">Best split: <strong>{fname(node.feature!)} ≤ {node.threshold!.toFixed(2)}</strong>. Left has {node.left.n} points (Gini {gl.toFixed(3)}), right has {node.right.n} (Gini {gr.toFixed(3)}). Weighted child impurity = <span className="num">{w.toFixed(3)}</span>, so the gain is <strong className="num">{(node.gini - w).toFixed(3)}</strong>.</p>); })()
              : <p className="mt-1 text-muted">This is a leaf. It predicts class {node.counts[1] >= node.counts[0] ? 'B' : 'A'} with probability {(Math.max(...node.counts) / node.n).toFixed(2)}{node.gini === 0 ? ' (pure)' : depth === node.depth ? ' (stopped by the depth limit)' : ''}.</p>}
            <p className="hint mt-2">Impurity check with the formula: {node.n ? giniOf(node.counts).toFixed(3) : '–'}.</p>
          </div>
        </div>) : <NeedBoth />}
      controls={<>{d.panel}<Slider label="Maximum depth" value={depth} min={1} max={6} onChange={(v) => { setDepth(v); setSel(0); }} hint="Try XOR corners at depth 1, then 2. Then use overlapping blobs and raise the depth to see the tree start to memorise noise." /></>}
    />
  );
}

function TreeDiagram({ lay, sel, onSel }: { lay: { nodes: Laid[]; leaves: number; depth: number }; sel: number; onSel: (id: number) => void }) {
  const cw = 74, ch = 64, W = Math.max(300, lay.leaves * cw + 20), H = (lay.depth + 1) * ch + 20;
  const pos = (o: Laid) => [10 + o.x * cw + cw / 2, 14 + o.y * ch] as const;
  return (
    <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} role="group" aria-label="Decision tree diagram. Select a node for details." style={{ minWidth: W }}>
      {lay.nodes.map((o) => o.n.left && o.n.right ? [o.n.left, o.n.right].map((c) => { const ch2 = lay.nodes.find((q) => q.n.id === c.id)!; const [x1, y1] = pos(o), [x2, y2] = pos(ch2); return <line key={o.n.id + '-' + c.id} x1={x1} y1={y1 + 12} x2={x2} y2={y2 - 12} stroke="rgb(var(--line))" strokeWidth={1.5} />; }) : null)}
      {lay.nodes.map((o) => {
        const [x, y] = pos(o), leaf = !o.n.left, maj = o.n.counts[1] >= o.n.counts[0] ? 1 : 0, active = o.n.id === sel;
        return (
          <g key={o.n.id} tabIndex={0} role="button" aria-label={`Node ${o.n.id}: ${leaf ? 'leaf' : `${fname(o.n.feature!)} at most ${o.n.threshold!.toFixed(2)}`}, ${o.n.n} points`} style={{ cursor: 'pointer' }} onClick={() => onSel(o.n.id)} onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ') && (e.preventDefault(), onSel(o.n.id))}>
            <rect x={x - 32} y={y - 12} width={64} height={26} rx={5} fill={leaf ? CLASS_COLORS[maj] : 'rgb(var(--raised))'} fillOpacity={leaf ? 0.28 : 1} stroke={active ? 'rgb(var(--accent))' : 'rgb(var(--line))'} strokeWidth={active ? 2.5 : 1} />
            <text x={x} y={y + 1} textAnchor="middle" fontSize="10.5" fill="rgb(var(--ink))">{leaf ? `${o.n.counts[0]} | ${o.n.counts[1]}` : `${fname(o.n.feature!)} ≤ ${o.n.threshold!.toFixed(1)}`}</text>
            <text x={x} y={y + 11} textAnchor="middle" fontSize="9" fill="rgb(var(--muted))">{leaf ? 'leaf' : `n=${o.n.n}`}</text>
          </g>
        );
      })}
    </svg>
  );
}
