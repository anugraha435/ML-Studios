import { useMemo, useState } from 'react';
import { DemoShell, Slider, Stat } from '../controls';
import { DragPoint, Plot2D } from '../Plot2D';
import { Legend, NeedBoth, useClassPoints } from './shared';
import { fitForest, fitTree, predictClass } from '../../lib/ml/models';
import { makeShape } from '../../lib/data/synthetic';

export default function ForestDemo() {
  const d = useClassPoints('overlap', 70);
  const [nTrees, setNTrees] = useState(25), [depth, setDepth] = useState(5), [seed, setSeed] = useState(7), [pick, setPick] = useState(0);
  const [probe, setProbe] = useState<{ x: number; y: number }>({ x: 5, y: 5 });
  const forest = useMemo(() => (d.hasBoth ? fitForest(d.X, d.y, 2, { nTrees, maxDepth: depth, seed }) : null), [d.pts, nTrees, depth, seed, d.hasBoth]); // eslint-disable-line react-hooks/exhaustive-deps
  const single = useMemo(() => (d.hasBoth ? fitTree(d.X, d.y, 2, { maxDepth: depth, minSamplesSplit: 2 }) : null), [d.pts, depth, d.hasBoth]); // eslint-disable-line react-hooks/exhaustive-deps
  // Fresh hold-out sample from the same generator and shape, to show generalisation (only meaningful for generated shapes)
  const test = useMemo(() => makeShape(d.shape, 400, 999), [d.shape]);
  const acc = (m: { predictProba: (X: number[][]) => number[][] } | null) => m ? predictClass({ classes: 2, predictProba: m.predictProba }, test.map((q) => [q.x, q.y])).filter((v, i) => v === test[i].c).length / test.length : NaN;
  const tIdx = Math.min(pick, nTrees - 1), tree = forest?.trees[tIdx];
  const votes = forest ? forest.trees.map((t) => t.predictProba([[probe.x, probe.y]])[0][1]) : [];
  const avg = votes.length ? votes.reduce((a, b) => a + b, 0) / votes.length : NaN;
  const bag = forest ? new Set(forest.inBag[tIdx]) : new Set<number>();
  const uniqueShare = forest ? bag.size / d.pts.length : NaN;
  return (
    <DemoShell title="Many trees, each seeing a different bootstrap sample" note="Real calculation: every tree is trained on rows drawn with replacement and sees a random subset of features at each split. The forest averages their class probabilities. Click the plot to move the probe point."
      plot={<>
        <Plot2D ariaLabel="Random forest probability map with training points and probe" region={{ fn: (x, y) => (forest ? forest.predictProba([[x, y]])[0] : [0.5, 0.5]), version: [forest, nTrees, depth, seed] }} res={64} onPlotClick={(x, y) => setProbe({ x, y })}>
          {(s) => (<>
            {d.pts.map((q, i) => <DragPoint key={i} s={s} x={q.x} y={q.y} c={q.c} dim={forest ? !bag.has(i) : false} label={`Class ${q.c ? 'B' : 'A'} point${forest && !bag.has(i) ? ', out of bag for the selected tree' : ''}`} onDrag={(x, y) => d.move(i, x, y)} onRemove={() => d.remove(i)} />)}
            <g pointerEvents="none"><circle cx={s.sx(probe.x)} cy={s.sy(probe.y)} r={9} fill="none" stroke="rgb(var(--ink))" strokeWidth={2.4} /><line x1={s.sx(probe.x) - 13} x2={s.sx(probe.x) + 13} y1={s.sy(probe.y)} y2={s.sy(probe.y)} stroke="rgb(var(--ink))" /><line y1={s.sy(probe.y) - 13} y2={s.sy(probe.y) + 13} x1={s.sx(probe.x)} x2={s.sx(probe.x)} stroke="rgb(var(--ink))" /></g>
          </>)}
        </Plot2D>
        <div className="mt-2 flex items-center justify-between"><Legend /><p className="text-xs text-muted">Faded points were not drawn into the bootstrap sample of tree #{tIdx + 1} (out of bag).</p></div>
      </>}
      readout={forest && single ? (
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <Stat label="Forest, new data accuracy" value={acc(forest).toFixed(3)} sub="400 fresh points" /><Stat label="Single tree, new data accuracy" value={acc(single).toFixed(3)} sub="same depth" />
            <Stat label="Out-of-bag accuracy" value={forest.oobScore === null ? '–' : forest.oobScore.toFixed(3)} sub="no extra data needed" /><Stat label={`Rows in tree #${tIdx + 1}'s sample`} value={`${(uniqueShare * 100).toFixed(0)}%`} sub="distinct rows (about 63% expected)" />
          </div>
          <VoteStrip votes={votes} avg={avg} pick={tIdx} onPick={setPick} probe={probe} />
          <p className="text-sm text-muted">Hold-out accuracy uses newly generated points from the same shape (seeded), not the points on screen. If you drag or add points, the shape's hold-out set no longer describes your data exactly, so read it as a guide.</p>
        </div>) : <NeedBoth />}
      controls={<>
        {d.panel}
        <Slider label="Number of trees" value={nTrees} min={1} max={150} onChange={setNTrees} hint="One tree is a noisy classifier. Averaging many smooths the boundary." />
        <Slider label="Maximum tree depth" value={depth} min={1} max={10} onChange={setDepth} />
        <Slider label="Selected tree (#)" value={tIdx + 1} min={1} max={nTrees} onChange={(v) => setPick(v - 1)} hint="Fades the rows that tree never saw." />
        <button type="button" className="btn btn-ghost" onClick={() => setSeed((s) => s + 1)}>Resample bootstraps (seed {seed})</button>
        {tree && <p className="text-sm text-muted">Tree #{tIdx + 1} at the probe says P(class B) = <strong className="num text-ink">{tree.predictProba([[probe.x, probe.y]])[0][1].toFixed(2)}</strong>; the forest says <strong className="num text-ink">{avg.toFixed(2)}</strong>.</p>}
      </>}
    />
  );
}

function VoteStrip({ votes, avg, pick, onPick, probe }: { votes: number[]; avg: number; pick: number; onPick: (i: number) => void; probe: { x: number; y: number } }) {
  const W = 560, H = 120, m = { l: 36, r: 10, t: 10, b: 24 }, n = votes.length, bw = Math.min(14, (W - m.l - m.r) / n);
  const sy = (p: number) => H - m.b - p * (H - m.t - m.b);
  return (
    <figure>
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full" role="img" aria-label={`Each tree's probability of class B at the probe (${probe.x.toFixed(1)}, ${probe.y.toFixed(1)}), and the forest average ${avg.toFixed(2)}`}>
        <rect x={m.l} y={m.t} width={W - m.l - m.r} height={H - m.t - m.b} fill="none" stroke="rgb(var(--line))" />
        {votes.map((v, i) => <rect key={i} x={m.l + 2 + i * ((W - m.l - m.r - 4) / n)} y={sy(v)} width={Math.max(1.5, bw - 1)} height={Math.max(1, sy(0) - sy(v))} fill={i === pick ? 'rgb(var(--ink))' : 'rgb(var(--accent))'} opacity={i === pick ? 1 : 0.55} onClick={() => onPick(i)} style={{ cursor: 'pointer' }}><title>Tree {i + 1}: {v.toFixed(2)}</title></rect>)}
        <line x1={m.l} x2={W - m.r} y1={sy(avg)} y2={sy(avg)} stroke="#C86D51" strokeWidth={2} strokeDasharray="6 4" /><text x={W - m.r - 3} y={sy(avg) - 4} textAnchor="end" fontSize="11" fill="#C86D51">forest average {avg.toFixed(2)}</text>
        {[0, 0.5, 1].map((t) => <text key={t} x={m.l - 5} y={sy(t) + 4} textAnchor="end" fontSize="11" fill="rgb(var(--muted))">{t}</text>)}
        <text x={(W + m.l) / 2} y={H - 6} textAnchor="middle" fontSize="11" fill="rgb(var(--muted))">each bar is one tree's P(class B) at the probe</text>
      </svg>
    </figure>
  );
}
