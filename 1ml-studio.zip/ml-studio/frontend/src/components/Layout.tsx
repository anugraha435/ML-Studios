import { Github, Menu, Moon, Search, Sun, X } from 'lucide-react';
import { useEffect, useState } from 'react';
import { Link, NavLink, Outlet, useLocation } from 'react-router-dom';
import { REPO_URL } from '../config';
import { useTheme } from '../hooks/useTheme';
import { SearchPalette } from './SearchPalette';

const NAV: { to: string; label: string; end?: boolean }[] = [
  { to: '/learn', label: 'Visual Essays' }, { to: '/algorithms', label: 'Algorithms' },
  { to: '/playground', label: 'Playground' }, { to: '/research', label: 'CardioNepal Research' }
];

export function Logo({ className = '' }: { className?: string }) {
  return (
    <span className={`inline-flex items-center gap-2 font-serif text-xl font-medium tracking-tight ${className}`}>
      <svg width="26" height="26" viewBox="0 0 32 32" aria-hidden><rect width="32" height="32" rx="6" fill="#2E5A44" /><path d="M6 23 L13 13 L19 19 L26 8" fill="none" stroke="#FAF7F0" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" /><circle cx="26" cy="8" r="2.4" fill="#D4A359" /></svg>
      ML Studio
    </span>
  );
}

export default function Layout() {
  const { theme, toggle } = useTheme(); const [menu, setMenu] = useState(false); const [searchOpen, setSearchOpen] = useState(false);
  const loc = useLocation();
  useEffect(() => { setMenu(false); window.scrollTo(0, 0); }, [loc.pathname]);
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      const typing = /input|textarea|select/i.test((e.target as HTMLElement)?.tagName ?? '');
      if ((e.key === 'k' && (e.ctrlKey || e.metaKey)) || (e.key === '/' && !typing)) { e.preventDefault(); setSearchOpen(true); }
    };
    window.addEventListener('keydown', h); return () => window.removeEventListener('keydown', h);
  }, []);
  const link = ({ isActive }: { isActive: boolean }) => `px-3 py-2 text-sm transition-colors ${isActive ? 'font-medium text-ink underline decoration-brand decoration-2 underline-offset-8' : 'text-muted hover:text-ink'}`;
  return (
    <div className="flex min-h-screen flex-col">
      <a href="#main" className="skip">Skip to content</a>
      <header className="sticky top-0 z-40 border-b border-line bg-bg/92 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-3 px-4 sm:px-6">
          <Link to="/" aria-label="ML Studio home"><Logo /></Link>
          <nav aria-label="Main" className="hidden items-center gap-1 lg:flex">{NAV.map((n) => <NavLink key={n.to} to={n.to} end={n.end} className={link}>{n.label}</NavLink>)}</nav>
          <div className="flex items-center gap-1">
            <button type="button" onClick={() => setSearchOpen(true)} className="btn btn-ghost !min-h-10 !border-transparent !bg-transparent !px-3 hover:!bg-raised" aria-label="Search (press Ctrl+K)"><Search size={16} aria-hidden /><span className="hidden text-muted sm:inline">Search</span><kbd className="hidden rounded border border-line px-1 text-xs text-muted md:inline">Ctrl K</kbd></button>
            <button type="button" onClick={toggle} className="btn btn-ghost !min-h-10 !border-transparent !bg-transparent !px-3 hover:!bg-raised" aria-label={`Switch to ${theme === 'dark' ? 'light' : 'dark'} theme`}>{theme === 'dark' ? <Sun size={16} aria-hidden /> : <Moon size={16} aria-hidden />}</button>
            {REPO_URL && <a href={REPO_URL} className="btn btn-ghost !min-h-10 !border-transparent !bg-transparent !px-3 hover:!bg-raised" aria-label="Source code on GitHub" target="_blank" rel="noreferrer"><Github size={16} aria-hidden /></a>}
            <button type="button" className="btn btn-ghost !min-h-10 !border-transparent !bg-transparent !px-3 hover:!bg-raised lg:hidden" onClick={() => setMenu((m) => !m)} aria-expanded={menu} aria-controls="mobile-nav" aria-label={menu ? 'Close menu' : 'Open menu'}>{menu ? <X size={18} aria-hidden /> : <Menu size={18} aria-hidden />}</button>
          </div>
        </div>
        {menu && <nav id="mobile-nav" aria-label="Main" className="border-t border-line bg-bg px-4 py-3 lg:hidden"><div className="flex flex-col">{NAV.map((n) => <NavLink key={n.to} to={n.to} end={n.end} className={(s) => link(s) + ' !py-3'}>{n.label}</NavLink>)}</div></nav>}
      </header>
      <main id="main" className="flex-1 outline-none" tabIndex={-1}><Outlet /></main>
      <Footer />
      <SearchPalette open={searchOpen} onClose={() => setSearchOpen(false)} />
    </div>
  );
}

function Footer() {
  const col = (title: string, links: [string, string][]) => (
    <div><h2 className="font-sans text-sm font-semibold">{title}</h2><ul className="mt-3 space-y-2 text-sm">{links.map(([l, t]) => <li key={t}><Link className="text-muted hover:text-ink hover:underline" to={t}>{l}</Link></li>)}</ul></div>
  );
  return (
    <footer className="mt-20 border-t border-line bg-raised/60">
      <div className="mx-auto grid max-w-6xl gap-8 px-4 py-10 sm:px-6 md:grid-cols-5">
        <div className="md:col-span-2"><Logo /><p className="mt-3 max-w-sm text-sm text-muted">Understand the mathematics. Explore the models. Discover the intelligence.</p>
          {REPO_URL && <a href={REPO_URL} target="_blank" rel="noreferrer" className="mt-3 inline-flex items-center gap-2 text-sm text-muted hover:text-ink"><Github size={16} aria-hidden />Source code</a>}</div>
        {col('Read', [['All visual essays', '/learn'], ['Algorithms', '/algorithms'], ['Playground', '/playground']])}
        {col('Research', [['CardioNepal overview', '/research'], ['Model performance', '/research/performance'], ['Limitations and privacy', '/research/limitations']])}
        {col('Project', [['Documentation', '/docs'], ['References and licenses', '/docs#references'], ['About', '/about']])}
      </div>
      <div className="border-t border-line px-4 py-4 text-center text-xs text-muted sm:px-6">Educational and research demonstration. Not a medical product and not medical advice. Code under the MIT license; lesson text under CC BY 4.0; datasets under their own licenses.</div>
    </footer>
  );
}
