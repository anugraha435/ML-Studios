import { Check, RotateCcw, X } from 'lucide-react';
import { useId, useState } from 'react';
import type { QuizQuestion } from '../content/types';
import { RichText } from './RichText';

export function Quiz({ questions }: { questions: QuizQuestion[] }) {
  const [picked, setPicked] = useState<(number | null)[]>(() => questions.map(() => null));
  const [shown, setShown] = useState<boolean[]>(() => questions.map(() => false));
  const base = useId();
  const answered = shown.filter(Boolean).length, correct = questions.filter((q, i) => shown[i] && picked[i] === q.answerIndex).length;
  return (
    <div className="space-y-6">
      {questions.map((q, qi) => {
        const done = shown[qi];
        return (
          <fieldset key={qi} className="card p-4 sm:p-5">
            <legend className="px-1 text-base font-medium"><span className="mr-2 text-muted num">{qi + 1}.</span><span className="inline"><RichText text={q.question} className="!inline [&_p]:!inline" /></span></legend>
            <div className="mt-3 space-y-2">
              {q.options.map((o, oi) => {
                const isRight = oi === q.answerIndex, isPicked = picked[qi] === oi;
                const state = done ? (isRight ? 'border-good bg-good/10' : isPicked ? 'border-bad bg-bad/10' : 'border-line') : isPicked ? 'border-accent bg-accent/5' : 'border-line hover:bg-raised';
                return (
                  <label key={oi} className={`flex cursor-pointer items-start gap-3 rounded-md border p-3 text-sm ${state} ${done ? 'cursor-default' : ''}`}>
                    <input type="radio" name={`${base}-${qi}`} className="mt-1 accent-[rgb(var(--accent))]" checked={isPicked} disabled={done} onChange={() => setPicked((p) => p.map((v, i) => (i === qi ? oi : v)))} />
                    <span className="flex-1"><RichText text={o} className="!inline [&_p]:!inline [&_p]:!mb-0" /></span>
                    {done && isRight && <Check size={16} className="mt-0.5 text-good" aria-label="Correct answer" />}
                    {done && isPicked && !isRight && <X size={16} className="mt-0.5 text-bad" aria-label="Your answer, incorrect" />}
                  </label>
                );
              })}
            </div>
            {!done ? (
              <button type="button" className="btn btn-ghost mt-3" disabled={picked[qi] === null} onClick={() => setShown((s) => s.map((v, i) => (i === qi ? true : v)))}>Check answer</button>
            ) : (
              <div role="status" className="mt-3 rounded-md bg-raised p-3 text-sm">
                <p className="font-medium">{picked[qi] === q.answerIndex ? 'Correct.' : 'Not quite.'}</p>
                <RichText text={q.explanation} className="mt-1 text-muted [&_p]:!mb-0" />
              </div>
            )}
          </fieldset>
        );
      })}
      <div className="flex flex-wrap items-center gap-3" aria-live="polite">
        <p className="text-sm text-muted">{answered === 0 ? 'Answer each question and check it to see your score.' : `Score so far: ${correct} of ${answered} checked (${questions.length} questions).`}</p>
        {answered > 0 && <button type="button" className="btn btn-ghost !min-h-9" onClick={() => { setPicked(questions.map(() => null)); setShown(questions.map(() => false)); }}><RotateCcw size={14} aria-hidden />Try again</button>}
      </div>
    </div>
  );
}
