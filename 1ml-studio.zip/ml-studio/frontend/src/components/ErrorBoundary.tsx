import { Component, type ReactNode } from 'react';
export default class ErrorBoundary extends Component<{ children: ReactNode }, { error: Error | null }> {
  state = { error: null as Error | null };
  static getDerivedStateFromError(error: Error) { return { error }; }
  render() {
    if (!this.state.error) return this.props.children;
    return (<div role="alert" className="mx-auto max-w-xl p-10"><h1 className="text-2xl font-semibold">Something went wrong on this page</h1><p className="mt-2 text-muted">The page failed to render. Reload it, or go back to the home page. If it keeps happening, report it with the steps you took.</p>
      <p className="mt-2 font-mono text-xs text-muted">{this.state.error.message}</p><div className="mt-4 flex gap-2"><button className="btn btn-primary" onClick={() => location.reload()}>Reload</button><a className="btn btn-secondary" href="/">Home</a></div></div>);
  }
}
