import { useEffect, useMemo, useRef, type ReactNode } from 'react';

export interface Scale { sx: (x: number) => number; sy: (y: number) => number; ix: (px: number) => number; iy: (py: number) => number }
export const CLASS_COLORS = ['#3B82F6', '#C86D51', '#3B6E54', '#D4A359', '#7A5C99', '#6B8E9B'];
const hex = (h: string) => [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)];

export function Marker({ x, y, c, r = 5, ring, dim }: { x: number; y: number; c: number; r?: number; ring?: boolean; dim?: boolean }) {
  const fill = CLASS_COLORS[c % CLASS_COLORS.length], o = dim ? 0.35 : 1, common = { fill, stroke: 'rgb(var(--surface))', strokeWidth: 1.4, opacity: o };
  const shape = c % 3 === 0 ? <circle cx={x} cy={y} r={r} {...common} /> : c % 3 === 1 ? <rect x={x - r} y={y - r} width={2 * r} height={2 * r} rx={1} {...common} /> : <path d={`M${x},${y - r * 1.2} L${x + r * 1.1},${y + r * 0.9} L${x - r * 1.1},${y + r * 0.9}Z`} {...common} />;
  return <g>{shape}{ring && <circle cx={x} cy={y} r={r + 4} fill="none" stroke="rgb(var(--ink))" strokeWidth={1.4} />}</g>;
}

interface Props {
  xDomain?: [number, number]; yDomain?: [number, number]; xLabel?: string; yLabel?: string; ariaLabel: string; height?: number;
  /** Returns class probabilities (or one value for a heat) at a data coordinate; drawn as a tinted background. */
  region?: { fn: (x: number, y: number) => number[]; version: unknown; res?: number }; res?: number;
  onPlotClick?: (x: number, y: number) => void; onPlotMove?: (x: number, y: number) => void; onPlotLeave?: () => void;
  children: (s: Scale) => ReactNode; cursor?: string;
}
const W = 640;
export function Plot2D({ xDomain = [0, 10], yDomain = [0, 10], xLabel = 'x₁', yLabel = 'x₂', ariaLabel, height = 440, region, res: resProp, onPlotClick, onPlotMove, onPlotLeave, children, cursor }: Props) {
  const m = { l: 44, r: 12, t: 10, b: 36 }, H = height;
  const s: Scale = useMemo(() => ({
    sx: (x) => m.l + ((x - xDomain[0]) / (xDomain[1] - xDomain[0])) * (W - m.l - m.r),
    sy: (y) => H - m.b - ((y - yDomain[0]) / (yDomain[1] - yDomain[0])) * (H - m.t - m.b),
    ix: (px) => xDomain[0] + ((px - m.l) / (W - m.l - m.r)) * (xDomain[1] - xDomain[0]),
    iy: (py) => yDomain[0] + ((H - m.b - py) / (H - m.t - m.b)) * (yDomain[1] - yDomain[0])
  }), [xDomain[0], xDomain[1], yDomain[0], yDomain[1], H]); // eslint-disable-line react-hooks/exhaustive-deps
  const svg = useRef<SVGSVGElement>(null), canvas = useRef<HTMLCanvasElement>(null);
  const toData = (e: React.PointerEvent | React.MouseEvent) => { const r = svg.current!.getBoundingClientRect(); return [s.ix(((e.clientX - r.left) / r.width) * W), s.iy(((e.clientY - r.top) / r.height) * H)] as const; };
  useEffect(() => {
    const cv = canvas.current; if (!cv || !region) return;
    const res = region.res ?? resProp ?? 80, rw = res, rh = Math.round((res * (H - m.t - m.b)) / (W - m.l - m.r));
    cv.width = rw; cv.height = rh; const ctx = cv.getContext('2d'); if (!ctx) return;
    const img = ctx.createImageData(rw, rh); const cols = CLASS_COLORS.map(hex);
    for (let j = 0; j < rh; j++) for (let i = 0; i < rw; i++) {
      const x = xDomain[0] + ((i + 0.5) / rw) * (xDomain[1] - xDomain[0]), y = yDomain[1] - ((j + 0.5) / rh) * (yDomain[1] - yDomain[0]);
      const p = region.fn(x, y); let rr = 0, gg = 0, bb = 0;
      p.forEach((w, k) => { const c = cols[k % cols.length]; rr += w * c[0]; gg += w * c[1]; bb += w * c[2]; });
      const o = (j * rw + i) * 4; img.data[o] = rr; img.data[o + 1] = gg; img.data[o + 2] = bb; img.data[o + 3] = 70;
    }
    ctx.putImageData(img, 0, 0);
  }, [region?.version, H]); // eslint-disable-line react-hooks/exhaustive-deps
  const ticks = (d: [number, number]) => { const n = 5, out: number[] = []; for (let i = 0; i <= n; i++) out.push(d[0] + ((d[1] - d[0]) * i) / n); return out; };
  const f = (v: number) => (Math.abs(v) >= 100 ? v.toFixed(0) : +v.toFixed(2)).toString();
  return (
    <div className="relative w-full select-none" style={{ aspectRatio: `${W} / ${H}`, touchAction: onPlotClick ? 'none' : 'auto' }}>
      {region && <canvas ref={canvas} aria-hidden className="absolute" style={{ left: `${(m.l / W) * 100}%`, top: `${(m.t / H) * 100}%`, width: `${((W - m.l - m.r) / W) * 100}%`, height: `${((H - m.t - m.b) / H) * 100}%`, imageRendering: 'auto' }} />}
      <svg ref={svg} viewBox={`0 0 ${W} ${H}`} className="absolute inset-0 h-full w-full" role="img" aria-label={ariaLabel} style={{ cursor: cursor ?? (onPlotClick ? 'crosshair' : 'default') }}
        onClick={(e) => { if ((e.target as Element).closest('[data-pt]')) return; if (onPlotClick) { const [x, y] = toData(e); if (x >= xDomain[0] && x <= xDomain[1] && y >= yDomain[0] && y <= yDomain[1]) onPlotClick(x, y); } }}
        onPointerMove={(e) => { if (onPlotMove) { const [x, y] = toData(e); onPlotMove(x, y); } }} onPointerLeave={() => onPlotLeave?.()}>
        <rect x={m.l} y={m.t} width={W - m.l - m.r} height={H - m.t - m.b} fill={region ? 'none' : 'rgb(var(--surface))'} stroke="rgb(var(--line))" />
        {ticks(xDomain).map((t, i) => <g key={'x' + i}><line x1={s.sx(t)} x2={s.sx(t)} y1={m.t} y2={H - m.b} stroke="rgb(var(--line))" strokeOpacity={0.5} /><text x={s.sx(t)} y={H - m.b + 16} textAnchor="middle" fontSize="11" fill="rgb(var(--muted))">{f(t)}</text></g>)}
        {ticks(yDomain).map((t, i) => <g key={'y' + i}><line x1={m.l} x2={W - m.r} y1={s.sy(t)} y2={s.sy(t)} stroke="rgb(var(--line))" strokeOpacity={0.5} /><text x={m.l - 6} y={s.sy(t) + 4} textAnchor="end" fontSize="11" fill="rgb(var(--muted))">{f(t)}</text></g>)}
        <text x={(W + m.l - m.r) / 2} y={H - 4} textAnchor="middle" fontSize="12" fill="rgb(var(--muted))">{xLabel}</text>
        <text transform={`translate(12 ${(H - m.b + m.t) / 2}) rotate(-90)`} textAnchor="middle" fontSize="12" fill="rgb(var(--muted))">{yLabel}</text>
        <clipPath id="plot-clip"><rect x={m.l} y={m.t} width={W - m.l - m.r} height={H - m.t - m.b} /></clipPath>
        <g clipPath="url(#plot-clip)">{children(s)}</g>
      </svg>
    </div>
  );
}

/** A draggable, keyboard-movable data point for use inside Plot2D. Arrow keys nudge it, Delete removes it. */
export function DragPoint({ s, x, y, c, onDrag, onRemove, label, ring, dim, r }: { s: Scale; x: number; y: number; c: number; onDrag: (x: number, y: number) => void; onRemove?: () => void; label: string; ring?: boolean; dim?: boolean; r?: number }) {
  const active = useRef(false);
  const conv = (e: React.PointerEvent) => { const svg = (e.currentTarget as SVGElement).ownerSVGElement!; const b = svg.getBoundingClientRect(); const k = 640 / b.width; return [s.ix((e.clientX - b.left) * k), s.iy((e.clientY - b.top) * k)] as const; };
  const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));
  return (
    <g data-pt tabIndex={0} role="button" aria-label={`${label}. Arrow keys move, Delete removes.`} style={{ cursor: 'grab' }}
      onPointerDown={(e) => { (e.currentTarget as Element).setPointerCapture(e.pointerId); active.current = true; e.stopPropagation(); }}
      onPointerMove={(e) => { if (active.current) { const [px, py] = conv(e); onDrag(clamp(px, 0, 10), clamp(py, 0, 10)); } }}
      onPointerUp={(e) => { active.current = false; (e.currentTarget as Element).releasePointerCapture(e.pointerId); }}
      onDoubleClick={() => onRemove?.()}
      onKeyDown={(e) => {
        const d = e.shiftKey ? 1 : 0.2;
        if (e.key === 'ArrowLeft') { e.preventDefault(); onDrag(clamp(x - d, 0, 10), y); } else if (e.key === 'ArrowRight') { e.preventDefault(); onDrag(clamp(x + d, 0, 10), y); }
        else if (e.key === 'ArrowUp') { e.preventDefault(); onDrag(x, clamp(y + d, 0, 10)); } else if (e.key === 'ArrowDown') { e.preventDefault(); onDrag(x, clamp(y - d, 0, 10)); }
        else if ((e.key === 'Delete' || e.key === 'Backspace') && onRemove) { e.preventDefault(); onRemove(); }
      }}>
      <circle cx={s.sx(x)} cy={s.sy(y)} r={14} fill="transparent" />
      <Marker x={s.sx(x)} y={s.sy(y)} c={c} ring={ring} dim={dim} r={r} />
    </g>
  );
}
