import { makeLine, makeShape } from '../lib/data/synthetic';

export interface SampleDataset { id: string; label: string; file?: string; target: string; task: 'classification' | 'regression'; synthetic?: boolean; description: string; attribution: string; text?: () => string }
export const SAMPLES: SampleDataset[] = [
  { id: 'iris', label: 'Iris flowers', file: 'iris.csv', target: 'species', task: 'classification', description: '150 flowers, 4 measurements, 3 species. The classic first dataset.', attribution: 'Fisher (1936); UCI Machine Learning Repository, CC BY 4.0.' },
  { id: 'wine', label: 'Wine chemistry', file: 'wine.csv', target: 'target', task: 'classification', description: '178 wines, 13 chemical measurements, 3 cultivars. Try alcohol as a regression target too.', attribution: 'UCI Machine Learning Repository, CC BY 4.0.' },
  { id: 'bc', label: 'Breast cancer Wisconsin (diagnostic)', file: 'breast_cancer_wisconsin.csv', target: 'target', task: 'classification', description: '569 cell-nucleus measurements, benign or malignant. For learning only.', attribution: 'Wolberg, Street and Mangasarian; UCI Machine Learning Repository, CC BY 4.0.' },
  { id: 'heart', label: 'Heart disease (Cleveland)', file: 'heart_cleveland.csv', target: 'target', task: 'classification', description: '303 patients, 13 clinical features, with missing values. The CardioNepal dataset. Educational use only.', attribution: 'Janosi, Steinbrunn, Pfisterer and Detrano (1988); UCI Machine Learning Repository, CC BY 4.0.' },
  { id: 'moons', label: 'Two moons (synthetic)', target: 'class', task: 'classification', synthetic: true, description: '200 generated points in two interleaved crescents. Shows where linear models fail.', attribution: 'Generated in your browser from a seeded random generator.',
    text: () => 'x1,x2,class\n' + makeShape('moons', 200, 11, 0.7).map((p) => `${p.x.toFixed(3)},${p.y.toFixed(3)},${p.c}`).join('\n') },
  { id: 'line', label: 'Noisy line (synthetic)', target: 'y', task: 'regression', synthetic: true, description: '120 generated points around a straight line, for regression.', attribution: 'Generated in your browser from a seeded random generator.',
    text: () => 'x,y\n' + makeLine(120, 5).map((p) => `${p.x.toFixed(3)},${(p.y * 3 - 2).toFixed(3)}`).join('\n') }
];
