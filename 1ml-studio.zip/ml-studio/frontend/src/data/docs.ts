export interface DocSection { id: string; title: string; body: string }

/** Documentation shown at /docs. Uses the same mini-markup as lessons (see content/types.ts). */
export const DOC_SECTIONS: DocSection[] = [
  { id: 'introduction', title: 'Platform introduction', body:
`ML Studio is a free, open learning and research platform for machine learning. It has four parts that share one design and one set of rules about honesty.

- **Learn ML** has 53 written lessons in six categories. Each lesson has a plain explanation, a technical one, equations, a worked example with real numbers, pros and cons, applications and a knowledge check.
- **Algorithms** has seven interactive explorers. Every control changes a real calculation that runs in your browser.
- **Playground** trains demonstration models on sample data or on a CSV file you provide. The file never leaves your computer.
- **Research Lab** presents CardioNepal, a cardiovascular disease classification study on a public benchmark, with measured results, explanations and the limits of what they show.

Throughout the site, every figure is labelled by where it comes from: **Measured** (computed from the research experiment), **Actual inference** (a fitted model produced the output), **Simulation** (an educational calculation in your browser) or **Illustrative** (made up to explain an idea).` },
  { id: 'getting-started', title: 'Getting started', body:
`Open **Learn ML** and begin with *What is machine learning?* Lessons are ordered, and each ends with related topics. Use the search box (press Ctrl+K or Cmd+K) to jump to any lesson, algorithm or documentation page.

To run the project on your own computer you need Node.js 20 or newer for the web app and Python 3.11 or newer for the API.

- Web app: \`cd frontend\`, \`npm install\`, \`npm run dev\`, then open http://localhost:5173.
- API: \`cd backend\`, create a virtual environment, \`pip install -r requirements.txt\`, then \`uvicorn app.main:app --reload\`. The interactive API reference is at http://localhost:8000/docs.

The research demonstration works without the API because the fitted models are also exported for exact in-browser inference. The API adds server-side inference and SHAP explanations for a single record.` },
  { id: 'learning-paths', title: 'Learning paths', body:
`**Beginner path.** What is machine learning, Types of machine learning, Datasets and features, Training, validation and testing, Generalization, Linear regression, Logistic regression, Decision trees, Accuracy, Confusion matrix.

**Practitioner path.** Cross-validation, Overfitting and underfitting, Regularization, Hyperparameter optimization, Random forest, Support vector machines, Precision, Recall, ROC-AUC, Probability calibration.

**Research and explainability path.** Bias-variance tradeoff, Ensemble learning, Brier score, SHAP, Global and local explanations, Explainability in healthcare, then the CardioNepal Research Lab.

Progress (completed and bookmarked lessons) is saved only in your browser. Clearing site data removes it. There are no accounts.` },
  { id: 'algorithms', title: 'Algorithm documentation', body:
`Each explorer page shows the idea, the steps, the mathematics, a live experiment with adjustable parameters, example predictions, strengths, weaknesses, applications and limitations.

The algorithms are implemented from scratch in TypeScript so that every step can be shown. They are tested against scikit-learn on fixed data: linear and ridge regression coefficients, logistic regression coefficients and probabilities, SVM decision values and support vectors for linear, RBF and polynomial kernels, k-nearest-neighbour probabilities, decision tree predictions and feature importances, ROC-AUC, Brier score and silhouette score. The tests live in \`frontend/tests/ml.test.ts\`.

Random forests and k-means depend on random numbers. They use a seeded generator, so the same settings always give the same result.` },
  { id: 'playground', title: 'Playground instructions', body:
`1. Choose a sample dataset or upload a CSV file. Accepted: .csv or .txt, up to 5 MB, 10,000 rows and 100 columns, with a header row, unique column names and at least 20 rows. Comma, semicolon and tab separators are detected automatically.
2. Review the preview. Each column shows its detected type, missing values and a warning if it looks like an identifier or a constant.
3. Pick an algorithm, a target column and the input features. The task (classification or regression) is inferred from the target and can be changed.
4. Adjust parameters and press **Train**. The data are split into training and test rows with a fixed seed. Preprocessing is fitted on the training rows only.
5. Read the metrics, confusion matrix, ROC curve and feature effects, and try a new record in the prediction panel.
6. Press **Compare algorithms** to train every applicable algorithm on the same split.

Preprocessing rules: numeric missing values take the training median, categorical missing values take the most frequent level, numeric features are standardised for distance and margin based methods, and categorical features are one-hot encoded (at most 20 levels). Rows with a missing target are removed.

Everything runs in your browser in a background thread. Your file is not uploaded.` },
  { id: 'datasets', title: 'Dataset documentation', body:
`The playground sample datasets are real, public and licensed for redistribution with attribution.

- **Iris** (150 rows, 4 numeric features, 3 species). Fisher, 1936; UCI Machine Learning Repository, CC BY 4.0.
- **Wine** (178 rows, 13 chemical measurements, 3 cultivars). UCI Machine Learning Repository, CC BY 4.0.
- **Breast Cancer Wisconsin (Diagnostic)** (569 rows, 30 numeric features, benign or malignant). UCI Machine Learning Repository, CC BY 4.0.
- **Heart disease, Cleveland** (303 rows, 13 clinical features, binary target). UCI Machine Learning Repository, CC BY 4.0. This is the dataset used by the CardioNepal study.
- **Synthetic shapes** (moons, circles, blobs, XOR, noisy line). Generated in your browser from a seeded random generator. They are not real measurements.

These copies were exported from the scikit-learn data bundle (Iris, Wine, Breast Cancer) and from the verified Cleveland copy used in the study. Column names were lightly renamed for readability. The Cleveland copy has 6 missing values (4 in \`ca\`, 2 in \`thal\`).` },
  { id: 'methodology', title: 'CardioNepal research methodology', body:
`The study compares four classifiers on the Cleveland subset of the UCI Heart Disease data (303 records, 13 predictors). The original 0 to 4 diagnosis label is converted to absence (0) and presence (1 to 4) of heart disease: 164 absent and 139 present.

- **Split.** Stratified 80/20 split with seed 42: 242 training and 61 test records. The test set is used once, for the final evaluation.
- **Preprocessing inside the pipeline.** Median imputation and standardisation for numeric features, most-frequent imputation and one-hot encoding for categorical ones, fitted on training folds only, so nothing leaks from validation or test data. This yields 22 model inputs.
- **Tuning.** Grid search with stratified 5-fold cross-validation, scored by ROC-AUC, on the training set only. Three imbalance conditions (none, class weights, SMOTE) were compared with a parsimony rule.
- **Calibration.** None, sigmoid or isotonic calibration was chosen per model by out-of-fold Brier score.
- **Threshold.** The decision threshold is the largest value whose out-of-fold sensitivity on the training set is at least 0.90, so no test data influence it.
- **Evaluation.** Accuracy, precision, recall, specificity, F1, ROC-AUC, PR-AUC and Brier score on the test set, with bootstrap confidence intervals (2,000 resamples) and exact Clopper-Pearson intervals for proportions. Nested cross-validation gives a less optimistic estimate.
- **Explainability.** TreeSHAP for the random forest (probability units, 100 background rows) and linear SHAP for logistic regression, plus permutation importance.

All numbers are on the **Model performance** page, read directly from the experiment output.` },
  { id: 'evaluation', title: 'Model evaluation explanations', body:
`With 61 test records every metric is uncertain, and the confidence intervals on the Research Lab pages are wide. Treat differences of a few percentage points between models as unresolved.

**Sensitivity (recall)** is the share of people with the condition that the model flags. **Specificity** is the share without it that the model clears. A screening-style threshold deliberately favours sensitivity, so specificity falls. **Precision** depends on how common the condition is in the data, so it does not transfer to a population with a different prevalence.

**ROC-AUC** is the probability that a random positive case scores higher than a random negative case. **Brier score** is the mean squared error of the predicted probabilities, and lower is better. A **calibration** plot compares predicted probabilities with observed frequencies. With 61 records the reliability points each rest on about a dozen cases and should be read as indicative only.

The matching lessons in **Learn ML** explain each metric with a worked example.` },
  { id: 'shap', title: 'SHAP documentation', body:
`SHAP assigns each feature a contribution to one prediction so that the base value plus all contributions equals the model output. It is built on Shapley values from cooperative game theory.

- **Random forest:** TreeSHAP with interventional feature perturbation and 100 training rows as background. Contributions are in probability units. One-hot columns are summed back to the original feature.
- **Logistic regression:** linear SHAP with an independent background. Contributions are in log-odds units: coefficient times the feature's distance from its training mean.

The numbers on the explainability page come from a stored computation on the 61 test records. The API endpoint \`/api/v1/explain/{model}\` recomputes the same quantities for any valid record.

SHAP values describe how a fitted model uses its inputs. They do not show that a feature causes disease, and importance in one model can differ from another trained on the same data.` },
  { id: 'api', title: 'API documentation', body:
`Base URL in development: http://localhost:8000. Interactive reference (OpenAPI): /docs on the API server.

- **GET /health.** Returns the status and whether the models are loaded.
- **GET /api/v1/model-info.** Feature list, decision thresholds, calibration methods and dataset summary.
- **POST /api/v1/predict.** Body: \`{"features": {...13 fields...}, "models": ["lr","dt","rf","svm"]}\`. Returns for each model a probability, its threshold and whether the probability is above or below it.
- **POST /api/v1/explain/rf** and **/api/v1/explain/lr.** Same body. Return the base value and one contribution per feature.

Features use the UCI coding: \`age\`, \`sex\` (0, 1), \`cp\` (1 to 4), \`trestbps\`, \`chol\`, \`fbs\` (0, 1), \`restecg\` (0 to 2), \`thalach\`, \`exang\` (0, 1), \`oldpeak\`, \`slope\` (1 to 3), \`ca\` (0 to 3 or null), \`thal\` (3, 6, 7 or null). Unknown fields, out-of-range values and wrong types return HTTP 422 with a description of the problem. Requests are rate limited per client address and cross-origin calls are restricted to the configured origins.

Example: \`curl -X POST http://localhost:8000/api/v1/predict -H "Content-Type: application/json" -d @record.json\`.` },
  { id: 'privacy', title: 'Privacy information', body:
`ML Studio has no accounts, no analytics and no advertising. The web app stores two things in your browser: your theme choice and your learning progress.

CSV files you open in the playground are read and processed in your browser. They are not uploaded anywhere.

If you press the button to run the CardioNepal demonstration on the server, the 13 values you entered are sent over HTTPS to the API, used to compute the result and not stored. Do not enter real patient information into any demonstration. The in-browser option sends nothing.` },
  { id: 'limitations', title: 'Limitations', body:
`ML Studio is an educational and research demonstration, not a medical product.

- The CardioNepal data are a historical Cleveland, United States clinical benchmark, not a Nepalese population dataset.
- The models have not been validated on a representative Nepalese population.
- They predict a cross-sectional diagnostic label in the benchmark. They do not predict future cardiovascular events or ten-year risk.
- They must not be used for diagnosis, treatment or clinical decisions.
- Good performance on a benchmark does not establish clinical usefulness.
- Lifestyle education content is not a validated model output, and no lifestyle variable is an input to the fitted models.
- The playground trains small demonstration models in your browser. They are fitted for learning, not tuned for performance.` },
  { id: 'references', title: 'References and dataset attribution', body:
`**Dataset.** Janosi, A., Steinbrunn, W., Pfisterer, M. and Detrano, R. (1988). *Heart Disease* [dataset]. UCI Machine Learning Repository. https://doi.org/10.24432/C52P4X. License CC BY 4.0.

Detrano, R., Janosi, A., Steinbrunn, W., et al. (1989). International application of a new probability algorithm for the diagnosis of coronary artery disease. *American Journal of Cardiology*, 64(5), 304-310.

Pedregosa, F., et al. (2011). Scikit-learn: machine learning in Python. *Journal of Machine Learning Research*, 12, 2825-2830.

Lundberg, S. M. and Lee, S.-I. (2017). A unified approach to interpreting model predictions. *Advances in Neural Information Processing Systems*, 30.

Lundberg, S. M., et al. (2020). From local explanations to global understanding with explainable AI for trees. *Nature Machine Intelligence*, 2, 56-67.

Breiman, L. (2001). Random forests. *Machine Learning*, 45, 5-32.

Cortes, C. and Vapnik, V. (1995). Support-vector networks. *Machine Learning*, 20, 273-297.

Fan, R.-E., Chen, P.-H. and Lin, C.-J. (2005). Working set selection using second order information for training support vector machines. *Journal of Machine Learning Research*, 6, 1889-1918.

Chawla, N. V., et al. (2002). SMOTE: synthetic minority over-sampling technique. *Journal of Artificial Intelligence Research*, 16, 321-357.

Platt, J. (1999). Probabilistic outputs for support vector machines and comparisons to regularized likelihood methods. In *Advances in Large Margin Classifiers*. MIT Press.

Brier, G. W. (1950). Verification of forecasts expressed in terms of probability. *Monthly Weather Review*, 78(1), 1-3.

Clopper, C. J. and Pearson, E. S. (1934). The use of confidence or fiducial limits illustrated in the case of the binomial. *Biometrika*, 26, 404-413.

Fisher, R. A. (1936). The use of multiple measurements in taxonomic problems. *Annals of Eugenics*, 7, 179-188.` },
  { id: 'license', title: 'Software license information', body:
`**Source code:** MIT License. **Original lesson text and diagrams:** Creative Commons Attribution 4.0 (CC BY 4.0). **Datasets:** each under its own license, listed above (UCI datasets are CC BY 4.0).

Third-party software used: React, React Router, Vite, Tailwind CSS, Framer Motion, Lucide, Recharts, KaTeX and PapaParse (all MIT); fonts Source Serif 4, Inter and JetBrains Mono (SIL Open Font License 1.1); scikit-learn (BSD 3-clause), SHAP (MIT), FastAPI (MIT), NumPy, pandas and imbalanced-learn (BSD / MIT).

ML Studio is inspired by the idea of visual, interactive machine learning education. It does not reuse the code, text, illustrations or design of any other site. Complete attributions are in \`THIRD_PARTY_NOTICES.md\` in the repository.` }
];
export const getDoc = (id: string) => DOC_SECTIONS.find((d) => d.id === id);
