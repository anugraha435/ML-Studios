import { PageHeader, Section } from '@/components/ui/Page';
import { Badge } from '@/components/ui/Badge';
import { DATA, FEATURE_INFO, SPLIT } from '@/data/metrics';
import { Disclaimer } from '@/components/ui/Disclaimer';

export default function Dataset() {
  const miss = Object.entries(DATA.missing).filter(([, v]) => v > 0);
  return (
    <>
      <PageHeader title="Dataset" crumbs={[{ label: 'Research Lab', to: '/research' }, { label: 'Dataset' }]} lead="The UCI Heart Disease dataset, Cleveland subset: a historical US clinical benchmark." />
      <Section title="Source and license"><div className="prose-ml"><p>Janosi, A., Steinbrunn, W., Pfisterer, M. and Detrano, R. Heart Disease. UCI Machine Learning Repository (Cleveland Clinic Foundation subset), distributed under the Creative Commons Attribution 4.0 (CC BY 4.0) license, which permits redistribution with attribution. The file in this repository is a coded copy of that subset with 303 rows and the 13 predictors plus the original 0 to 4 diagnosis column. Please verify the license on the repository page before redistributing the data further.</p></div></Section>
      <Section title="Characteristics"><div className="mb-2"><Badge kind="measured" /></div><div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {[['Records', DATA.n], ['Predictors', DATA.n_features], ['No heart disease (0)', DATA.n_absent], ['Heart disease (1 to 4)', DATA.n_present]].map(([k, v]) => <div key={k} className="card p-4"><div className="text-xs text-muted">{k}</div><div className="font-serif text-3xl">{v}</div></div>)}</div>
        <div className="prose-ml mt-3"><p>The original target takes the values 0 (no disease) to 4. Following common practice it is converted to binary: 0 means absence and 1 to 4 means presence of angiographic disease. Original distribution: {Object.entries(DATA.num_distribution).map(([k, v]) => `${k}: ${v}`).join(', ')}. Missing values: {miss.map(([k, v]) => `${k} (${v})`).join(' and ')}; they are imputed inside the training pipeline, never before the split. The stratified split gives {SPLIT.nTrain} training records ({SPLIT.trainPresent} with disease) and {SPLIT.nTest} test records ({SPLIT.testPresent} with disease).</p></div></Section>
      <Section title="Input variables" lead="Exactly these 13 variables are model inputs. No lifestyle variable is used by any fitted model.">
        <div className="table-wrap"><table className="data"><caption className="sr-only">The 13 model input features</caption><thead><tr><th>Variable</th><th>Type</th><th>Meaning and role</th><th>Range</th><th>Coding</th></tr></thead><tbody>
          {Object.entries(FEATURE_INFO).map(([k, f]) => <tr key={k}><td><strong>{f.label}</strong><div className="font-mono text-xs text-muted">{k}</div></td><td>{f.type}</td><td className="min-w-[16rem]">{f.role}</td><td>{f.range}</td><td className="min-w-[12rem]">{f.coding ?? ''}</td></tr>)}</tbody></table></div></Section>
      <Disclaimer />
    </>
  );
}
