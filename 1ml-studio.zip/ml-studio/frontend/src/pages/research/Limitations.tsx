import { PageHeader, Section } from '@/components/ui/Page';
import { Disclaimer } from '@/components/ui/Disclaimer';
import { API_URL } from '@/lib/cardio/api';
import { NOT_YET_REPORTED, UNREPORTED } from '@/data/metrics';

export default function Limitations() {
  return (
    <>
      <PageHeader title="Limitations and privacy" crumbs={[{ label: 'Research Lab', to: '/research' }, { label: 'Limitations and privacy' }]} lead="What this research can and cannot support." />
      <Disclaimer />
      <Section title="Limitations of the research"><ul className="prose-ml">
        <li>The dataset is a historical Cleveland, US-based clinical benchmark. It is not a Nepalese population dataset.</li>
        <li>The models have not been validated on a representative Nepalese population. External validation: {UNREPORTED.externalValidation}.</li>
        <li>The target is a cross-sectional diagnostic label from the benchmark. The models do not predict future cardiovascular events or 10-year cardiovascular risk.</li>
        <li>The models must not be used for medical diagnosis, treatment or clinical decisions.</li>
        <li>Performance on the benchmark does not establish clinical usefulness. The 61-record test set gives wide confidence intervals, and the models were tuned on the same 242 training records the thresholds were derived from.</li>
        <li>Feature importance and SHAP values describe what a fitted model uses, not causes of disease. Correlated features share credit.</li>
        <li>Lifestyle education content (salt, fruit and vegetables, physical activity) is general public-health guidance. It is not an input to any model and is not a validated model output.</li>
        <li>The usability study of the demonstration has not produced results: {NOT_YET_REPORTED}.</li></ul></Section>
      <Section title="What is and is not implemented"><div className="table-wrap"><table className="data"><thead><tr><th>Capability</th><th>Status</th></tr></thead><tbody>
        <tr><td>Fitted scikit-learn models trained and evaluated on the benchmark</td><td>Implemented; results are reproducible with the provided scripts</td></tr>
        <tr><td>In-browser inference identical to scikit-learn</td><td>Implemented; parity tests to 1e-9 on 81 records for all four models</td></tr>
        <tr><td>Server inference and random forest SHAP for new records</td><td>Implemented in the FastAPI service; {API_URL ? 'this deployment is connected to an API' : 'this deployment is not connected to an API, so the demonstration runs in the browser'}</td></tr>
        <tr><td>Clinical validation, regulatory approval, Nepalese-population performance</td><td>Not done</td></tr></tbody></table></div></Section>
      <Section title="Privacy"><ul className="prose-ml">
        <li>There are no user accounts, no analytics and no advertising scripts.</li>
        <li>With in-browser inference (the default) the values you type never leave your device.</li>
        <li>If an API is configured and you choose server inference, only the 13 form values are sent over HTTPS. They are not stored, and request bodies are not logged.</li>
        <li>CSV files uploaded to the playground are parsed and trained on inside your browser. They are not uploaded.</li>
        <li>Theme choice and reading progress are kept in your browser local storage and can be cleared in your browser settings or on the Learn page.</li></ul></Section>
    </>
  );
}
