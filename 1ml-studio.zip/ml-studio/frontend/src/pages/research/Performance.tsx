import { useState } from 'react';
import { PageHeader, Section } from '@/components/ui/Page';
import { Badge } from '@/components/ui/Badge';
import { Segmented } from '@/components/ui/Controls';
import { CurveChart, GroupedMetricBars, ProbHistogram, ReliabilityChart } from '@/components/viz/Charts';
import { AUC_DIFFS, BASELINE, MODEL_KEYS, MODEL_NAMES, NOT_YET_REPORTED, RESULTS, SETTINGS, SPLIT, ci, num, pct, type Counts, type ModelKey } from '@/data/metrics';
import { Disclaimer } from '@/components/ui/Disclaimer';

const ROWS: { key: string; label: string; pct?: boolean }[] = [
  { key: 'accuracy', label: 'Accuracy', pct: true }, { key: 'precision', label: 'Precision', pct: true }, { key: 'sensitivity', label: 'Recall (sensitivity)', pct: true }, { key: 'specificity', label: 'Specificity', pct: true },
  { key: 'f1', label: 'F1 score' }, { key: 'roc_auc', label: 'ROC-AUC' }, { key: 'pr_auc', label: 'PR-AUC' }, { key: 'brier', label: 'Brier score (lower is better)' }
];
function Confusion({ c, title }: { c: Counts; title: string }) {
  const cell = (v: number, good: boolean, label: string) => <td className={`border border-line p-3 text-center ${good ? 'bg-accent-soft' : 'bg-warn-soft'}`}><div className="font-mono text-xl">{v}</div><div className="text-xs text-muted">{label}</div></td>;
  return (<table className="w-full text-sm" aria-label={`${title}: true negatives ${c.tn}, false positives ${c.fp}, false negatives ${c.fn}, true positives ${c.tp}`}><caption className="mb-1 text-left font-medium">{title}</caption>
    <thead><tr><th /><th scope="col" className="p-1 text-xs font-normal text-muted">Predicted no</th><th scope="col" className="p-1 text-xs font-normal text-muted">Predicted yes</th></tr></thead>
    <tbody><tr><th scope="row" className="pr-2 text-left text-xs font-normal text-muted">Actual no</th>{cell(c.tn, true, 'true neg.')}{cell(c.fp, false, 'false pos.')}</tr><tr><th scope="row" className="pr-2 text-left text-xs font-normal text-muted">Actual yes</th>{cell(c.fn, false, 'false neg.')}{cell(c.tp, true, 'true pos.')}</tr></tbody></table>);
}

export default function Performance() {
  const [thr, setThr] = useState<'selected' | '0.5'>('selected');
  const [hist, setHist] = useState<ModelKey>('rf');
  const names: Record<string, string> = { 'lr-dt': 'LR − DT', 'lr-rf': 'LR − RF', 'lr-svm': 'LR − SVM', 'dt-rf': 'DT − RF', 'dt-svm': 'DT − SVM', 'rf-svm': 'RF − SVM' };
  return (
    <>
      <PageHeader title="Model performance" crumbs={[{ label: 'Research Lab', to: '/research' }, { label: 'Model performance' }]} lead={`Everything on this page was measured on the ${SPLIT.nTest} held-out test records (${SPLIT.testPresent} with disease, ${SPLIT.testAbsent} without). Models, hyperparameters, calibration and thresholds were chosen using the ${SPLIT.nTrain} training records only.`}><div className="mt-3"><Badge kind="measured" /></div></PageHeader>
      <Disclaimer compact />
      <Section title="Test-set metrics at the pre-specified decision threshold" lead={`The threshold of each model is the largest value whose training-only out-of-fold sensitivity is at least ${SETTINGS.target_sensitivity.toFixed(2)}. Brackets are ${SETTINGS.n_boot}-resample bootstrap 95% confidence intervals.`}>
        <div className="table-wrap"><table className="data"><caption className="sr-only">Test-set metrics with 95 percent confidence intervals for each model</caption><thead><tr><th>Metric</th>{MODEL_KEYS.map((k) => <th key={k}>{MODEL_NAMES[k]}</th>)}</tr></thead><tbody>
          {ROWS.map((r) => <tr key={r.key}><th scope="row" className="font-normal">{r.label}</th>{MODEL_KEYS.map((k) => { const v = (RESULTS[k].test as any)[r.key] as number; const c = (RESULTS[k].ci95 as Record<string, [number, number]>)[r.key]; return <td key={k}><div>{r.pct ? pct(v) : num(v)}</div><div className="text-xs text-muted">[{c ? (r.pct ? `${(c[0] * 100).toFixed(1)}, ${(c[1] * 100).toFixed(1)}` : `${c[0].toFixed(3)}, ${c[1].toFixed(3)}`) : NOT_YET_REPORTED}]</div></td>; })}</tr>)}
          <tr><th scope="row" className="font-normal">Decision threshold</th>{MODEL_KEYS.map((k) => <td key={k}>{num(RESULTS[k].threshold, 3)}</td>)}</tr>
          <tr><th scope="row" className="font-normal">Final configuration</th>{MODEL_KEYS.map((k) => <td key={k} className="text-xs">class handling: {RESULTS[k].condition}<br />calibration: {RESULTS[k].calibration}</td>)}</tr></tbody></table></div>
        <p className="mt-2 text-sm text-muted">Baselines on the same test set: always predicting the majority class gives accuracy {pct(BASELINE.majority_accuracy_test)} and a constant-probability Brier score of {num(BASELINE.constant_brier_test)}.</p></Section>
      <Section title="Model comparison"><GroupedMetricBars metric={[{ key: 'acc', label: 'Accuracy', get: (k) => RESULTS[k].test.accuracy }, { key: 'sens', label: 'Sensitivity', get: (k) => RESULTS[k].test.sensitivity }, { key: 'spec', label: 'Specificity', get: (k) => RESULTS[k].test.specificity }, { key: 'auc', label: 'ROC-AUC', get: (k) => RESULTS[k].test.roc_auc }]} />
        <p className="mt-2 text-sm text-muted">With 61 records the intervals overlap heavily; the differences below are the only comparison tested formally.</p>
        <div className="table-wrap mt-3"><table className="data"><caption className="sr-only">Paired bootstrap differences in ROC-AUC</caption><thead><tr><th>Pair</th><th>Mean AUC difference</th><th>95% interval</th><th>Interval excludes 0?</th></tr></thead><tbody>
          {Object.entries(AUC_DIFFS).map(([k, v]) => <tr key={k}><td>{names[k] ?? k}</td><td>{num(v.mean_diff)}</td><td>{ci(v.ci95)}</td><td>{v.ci95[0] > 0 || v.ci95[1] < 0 ? 'Yes' : 'No'}</td></tr>)}</tbody></table></div></Section>
      <Section title="Confusion matrices"><div className="mb-3"><Segmented label="Threshold" value={thr} onChange={setThr} options={[{ value: 'selected', label: 'Pre-specified (sensitivity ≥ 0.90 target)' }, { value: '0.5', label: 'Conventional 0.5' }]} /></div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{MODEL_KEYS.map((k) => <div key={k} className="card p-3"><Confusion title={`${MODEL_NAMES[k]} (${thr === 'selected' ? `threshold ${RESULTS[k].threshold.toFixed(3)}` : 'threshold 0.5'})`} c={thr === 'selected' ? RESULTS[k].test : RESULTS[k].testAt05} /></div>)}</div>
        <p className="mt-2 text-sm text-muted">Lowering the threshold to meet a sensitivity target trades away specificity. The clinical cost of each error type is a judgement the benchmark cannot make.</p></Section>
      <div className="grid gap-8 lg:grid-cols-2"><Section title="ROC curves"><CurveChart kind="roc" /></Section><Section title="Precision-recall curves"><CurveChart kind="pr" /></Section></div>
      <Section title="Calibration" lead="A calibrated model's predicted 30% should correspond to about 30% of such patients having the disease.">
        <div className="grid gap-6 lg:grid-cols-2"><div><ReliabilityChart /><p className="mt-1 text-xs text-muted">Five equal-count bins of the 61 test predictions: each point averages only about 12 records, so the points are noisy.</p></div>
          <div className="table-wrap self-start"><table className="data"><caption className="sr-only">Calibration summary per model</caption><thead><tr><th>Model</th><th>Calibration</th><th>Brier before</th><th>Brier final</th><th>Slope</th><th>Intercept</th></tr></thead><tbody>
            {MODEL_KEYS.map((k) => <tr key={k}><td>{MODEL_NAMES[k]}</td><td>{RESULTS[k].calibration}</td><td>{RESULTS[k].brierUncalibrated === null ? "Not applicable (no probability before calibration)" : num(RESULTS[k].brierUncalibrated)}</td><td>{num(RESULTS[k].test.brier)}</td><td>{num(RESULTS[k].calSlope, 2)}</td><td>{num(RESULTS[k].calIntercept, 2)}</td></tr>)}</tbody></table>
            <p className="p-3 text-xs text-muted">“Brier before” is the model output before the chosen calibration step. For the SVM it is not defined because uncalibrated SVM scores are not probabilities, so the cell shows {NOT_YET_REPORTED} where no probability existed. Ideal slope is 1 and intercept 0; with this few records both are imprecise.</p></div></div></Section>
      <Section title="Distribution of predicted probabilities"><div className="mb-3"><Segmented label="Model" value={hist} onChange={setHist} options={MODEL_KEYS.map((k) => ({ value: k, label: MODEL_NAMES[k] }))} /></div><ProbHistogram model={hist} /></Section>
      <Section title="Cross-validation" lead={`Hyperparameters were tuned by ${SETTINGS.cv_folds}-fold stratified grid search on the training data. Nested cross-validation gives a less optimistic estimate that includes the tuning step.`}>
        <div className="table-wrap"><table className="data"><caption className="sr-only">Cross-validation ROC-AUC per model</caption><thead><tr><th>Model</th><th>Best tuning CV ROC-AUC (mean ± SD)</th><th>Nested CV ROC-AUC by outer fold</th><th>Nested mean</th></tr></thead><tbody>
          {MODEL_KEYS.map((k) => { const n = RESULTS[k].nestedAuc; return <tr key={k}><td>{MODEL_NAMES[k]}</td><td>{num(RESULTS[k].cvAuc.mean)} ± {num(RESULTS[k].cvAuc.sd)}</td><td>{n.map((v) => v.toFixed(3)).join(', ')}</td><td>{num(n.reduce((a, b) => a + b, 0) / n.length)}</td></tr>; })}</tbody></table></div></Section>
    </>
  );
}
