import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Badge } from '@/components/ui/Badge';
import { Disclaimer } from '@/components/ui/Disclaimer';
import { PageHeader, Section } from '@/components/ui/Page';
import { HBars } from '@/components/viz/Charts';
import { FEATURES_META, MODEL_KEYS, MODEL_NAMES, SHAP, featureLabel, type FeatureInfo } from '@/data/metrics';
import { ApiError, API_URL, apiExplain, apiPredict, type ApiContribution } from '@/lib/cardio/api';
import { explainLogistic, predictProba, type FeatureName, type ModelBundle, type ModelKey, type RawRecord } from '@/lib/cardio/inference';
let bundlePromise: Promise<ModelBundle> | null = null;
/** The fitted models are about 800 KB of JSON, so they are fetched only when the visitor first runs the demo. */
const loadBundle = () => (bundlePromise ??= import('@/data/research/models.json').then((m) => m.default as unknown as ModelBundle));
type Vals = Record<FeatureName, string>;
const defaults = (): Vals => Object.fromEntries(FEATURES_META.map((f) => [f.name, String(f.typical)])) as Vals;
const GROUPS: { title: string; names: FeatureName[] }[] = [
  { title: 'Background', names: ['age', 'sex'] }, { title: 'Symptoms', names: ['cp', 'exang'] },
  { title: 'Resting measurements', names: ['trestbps', 'chol', 'fbs', 'restecg'] }, { title: 'Exercise test', names: ['thalach', 'oldpeak', 'slope'] }, { title: 'Imaging', names: ['ca', 'thal'] }
];
const META = Object.fromEntries(FEATURES_META.map((f) => [f.name, f])) as Record<FeatureName, FeatureInfo>;

function validate(v: Vals): Partial<Record<FeatureName, string>> {
  const e: Partial<Record<FeatureName, string>> = {};
  for (const f of FEATURES_META) {
    const raw = v[f.name].trim();
    if (raw === '' && f.nullable) continue;
    if (raw === '') { e[f.name] = 'Enter a value.'; continue; }
    const n = Number(raw);
    if (!Number.isFinite(n)) { e[f.name] = 'Enter a number.'; continue; }
    if (f.kind === 'numeric') { if (n < f.min! || n > f.max!) e[f.name] = `Enter a value from ${f.min} to ${f.max}${f.unit ? ' ' + f.unit : ''}.`; }
    else if (!f.options!.some((o) => o.value === n)) e[f.name] = 'Choose one of the listed options.';
  }
  return e;
}
const toRecord = (v: Vals): RawRecord => Object.fromEntries(FEATURES_META.map((f) => [f.name, v[f.name].trim() === '' ? null : Number(v[f.name])])) as RawRecord;

interface Out { browser: { model: ModelKey; p: number; thr: number }[]; lr: { base: number; contributions: { feature: string; contribution: number }[] }; rec: RawRecord }
interface Srv { preds: { model: ModelKey; probability: number; threshold: number }[]; rf: { base: number; contributions: ApiContribution[] } | null }

export default function Demo() {
  const [vals, setVals] = useState<Vals>(defaults); const [touched, setTouched] = useState(false);
  const [out, setOut] = useState<Out | null>(null); const [srv, setSrv] = useState<Srv | null>(null); const [srvErr, setSrvErr] = useState<string | null>(null); const [srvBusy, setSrvBusy] = useState(false);
  const errors = useMemo(() => validate(vals), [vals]); const nErr = Object.keys(errors).length;
  const set = (k: FeatureName, v: string) => { setVals((o) => ({ ...o, [k]: v })); setOut(null); setSrv(null); setSrvErr(null); };

  const run = async () => {
    setTouched(true); if (nErr) { document.getElementById('form-errors')?.focus(); return; }
    const rec = toRecord(vals); const bundle = await loadBundle();
    const e = explainLogistic(bundle.models.lr, rec);
    setOut({ rec, browser: MODEL_KEYS.map((m) => ({ model: m, p: predictProba(bundle.models[m], rec), thr: bundle.models[m].threshold })), lr: { base: e.base, contributions: e.contributions } });
    setSrv(null); setSrvErr(null);
  };
  const runServer = async () => {
    if (!out) return; setSrvBusy(true); setSrvErr(null);
    try { const [p, x] = await Promise.all([apiPredict(out.rec), apiExplain(out.rec, 'rf')]); setSrv({ preds: p.predictions, rf: { base: x.base_value, contributions: x.contributions } }); }
    catch (e) { setSrvErr(e instanceof ApiError ? e.message : 'The server request failed.'); setSrv(null); } finally { setSrvBusy(false); }
  };
  const loadCase = (id: string) => {
    if (id === 'typical') { setVals(defaults()); setOut(null); return; }
    const c = SHAP.cases[id]; if (!c) return;
    setVals(Object.fromEntries(FEATURES_META.map((f) => [f.name, String(c.values[f.name])])) as Vals); setOut(null); setSrv(null); setTouched(false);
  };
  const above = out ? out.browser.filter((b) => b.p >= b.thr).length : 0;
  const maxDiff = out && srv ? Math.max(...srv.preds.map((s) => Math.abs(s.probability - out.browser.find((b) => b.model === s.model)!.p))) : null;

  return (
    <>
      <PageHeader title="Model demonstration" crumbs={[{ label: 'Research Lab', to: '/research' }, { label: 'Demonstration' }]}
        lead="Enter the 13 benchmark variables and see what each fitted model outputs. This shows how the models behave on a public dataset. It does not assess any person." />
      <Disclaimer />
      <div className="mt-8 grid gap-8 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
        <form noValidate onSubmit={(e) => { e.preventDefault(); void run(); }} aria-label="Model inputs">
          <div className="mb-4 flex flex-wrap items-end gap-3">
            <div><label htmlFor="case" className="label">Start from</label>
              <select id="case" className="input" defaultValue="typical" onChange={(e) => loadCase(e.target.value)}>
                <option value="typical">Typical values (not a real patient)</option>
                {Object.entries(SHAP.cases).map(([id, c]) => <option key={id} value={id}>Held-out test record {c.test_row}: {id.replace(/^[A-Z]_/, '').replace(/_/g, ' ')}</option>)}
              </select></div>
            <button type="button" className="btn btn-ghost" onClick={() => { setVals(defaults()); setOut(null); setSrv(null); setTouched(false); }}>Reset</button>
          </div>
          <p className="hint mb-4">Test records come from the 61 held-out records of the Cleveland dataset and are shown with their recorded label on the explainability page. They are historical benchmark rows.</p>
          {touched && nErr > 0 && <div id="form-errors" tabIndex={-1} role="alert" className="mb-4 rounded-md border border-bad/50 bg-bad/10 p-3 text-sm text-bad">Fix {nErr} field{nErr > 1 ? 's' : ''} before running: {Object.keys(errors).map((k) => featureLabel(k)).join(', ')}.</div>}
          {GROUPS.map((g) => (
            <fieldset key={g.title} className="mb-5 rounded-lg border border-line p-4">
              <legend className="px-1 text-sm font-semibold">{g.title}</legend>
              <div className="grid gap-4 sm:grid-cols-2">
                {g.names.map((n) => {
                  const f = META[n], err = touched ? errors[n] : undefined, id = `f-${n}`;
                  return (
                    <div key={n} className={f.kind === 'numeric' ? '' : 'sm:col-span-2'}>
                      <label htmlFor={id} className="label">{f.label}{f.unit ? <span className="font-normal text-muted"> ({f.unit})</span> : null}</label>
                      {f.kind === 'numeric'
                        ? <input id={id} className="input" type="number" inputMode="decimal" step={f.step} min={f.min} max={f.max} value={vals[n]} aria-invalid={!!err} aria-describedby={`${id}-d`} onChange={(e) => set(n, e.target.value)} />
                        : <select id={id} className="input" value={vals[n]} aria-invalid={!!err} aria-describedby={`${id}-d`} onChange={(e) => set(n, e.target.value)}>
                            {f.nullable && <option value="">Not available (the model fills it in)</option>}
                            {f.options!.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}</select>}
                      <p id={`${id}-d`} className={`mt-1 text-xs ${err ? 'text-bad' : 'text-muted'}`}>{err ?? f.description}</p>
                    </div>
                  );
                })}
              </div>
            </fieldset>
          ))}
          <button type="submit" className="btn btn-primary">Run the four models</button>
        </form>

        <div className="lg:sticky lg:top-24 lg:self-start">
          {!out ? (
            <div className="rounded-lg border border-dashed border-line p-8 text-center text-muted">
              <p className="font-medium text-ink">No result yet</p><p className="mt-1 text-sm">Fill in the form and press Run. The calculation uses the actual fitted models and happens in your browser; nothing is sent anywhere.</p>
            </div>
          ) : (
            <div aria-live="polite">
              <div className="mb-3 flex flex-wrap items-center justify-between gap-2"><h2 className="text-xl font-semibold">Model outputs</h2><Badge kind="inference" /></div>
              <p className="mb-4 text-sm text-muted">Each number is the model's estimated probability that a record like this carried the "heart disease present" label in the benchmark data. It is not a diagnosis and not a personal risk. The marker shows each model's pre-set threshold, chosen on training data to catch at least 90% of cases.</p>
              <ul className="space-y-4">
                {out.browser.map((b) => (
                  <li key={b.model}>
                    <div className="flex items-baseline justify-between"><span className="font-medium">{MODEL_NAMES[b.model]}</span><span className="num text-sm"><strong>{(b.p * 100).toFixed(1)}%</strong> <span className="text-muted">threshold {(b.thr * 100).toFixed(1)}%</span></span></div>
                    <div className="relative mt-1.5 h-3 rounded-full bg-raised" role="img" aria-label={`${MODEL_NAMES[b.model]}: probability ${(b.p * 100).toFixed(1)} percent, ${b.p >= b.thr ? 'above' : 'below'} the threshold of ${(b.thr * 100).toFixed(1)} percent`}>
                      <div className={`h-full rounded-full ${b.p >= b.thr ? 'bg-warn' : 'bg-accent'}`} style={{ width: `${Math.max(1, b.p * 100)}%` }} /><div className="absolute -top-1 h-5 w-0.5 bg-ink" style={{ left: `${b.thr * 100}%` }} />
                    </div>
                    <p className="mt-1 text-xs text-muted">{b.p >= b.thr ? 'Above the threshold: the model would flag this record.' : 'Below the threshold: the model would not flag this record.'}</p>
                  </li>
                ))}
              </ul>
              <p className="mt-4 rounded-md bg-raised p-3 text-sm">{above} of 4 models place this record above their threshold. {above > 0 && above < 4 ? 'The models disagree, which is common near the decision boundary.' : ''}</p>

              <Section title="What moves the logistic regression score">
                <div className="mb-2"><Badge kind="inference" /></div>
                <HBars unit="Contribution to log-odds (positive raises the score)" data={out.lr.contributions.slice(0, 8).map((c) => ({ name: featureLabel(c.feature), value: c.contribution }))} />
                <p className="text-xs text-muted">Exact linear SHAP: each input's contribution relative to an average training record. These show how this model uses its inputs, not what causes disease.</p>
              </Section>

              <div className="mt-6 rounded-lg border border-line p-4">
                <h3 className="font-semibold">Server inference and random-forest explanation</h3>
                {API_URL ? (<>
                  <p className="mt-1 text-sm text-muted">Send these 13 values over HTTPS to the FastAPI service. It returns predictions from the original scikit-learn objects plus TreeSHAP for the random forest. Values are not stored.</p>
                  <button type="button" className="btn btn-ghost mt-3" onClick={runServer} disabled={srvBusy}>{srvBusy ? 'Contacting server' : 'Run on the server'}</button>
                  {srvErr && <p role="alert" className="mt-3 text-sm text-bad">{srvErr}</p>}
                  {srv && (<div className="mt-4 space-y-3">
                    <p className="text-sm">Server probabilities: {srv.preds.map((s) => `${s.model.toUpperCase()} ${(s.probability * 100).toFixed(1)}%`).join(', ')}. Largest difference from the in-browser result: <strong className="num">{maxDiff!.toExponential(1)}</strong> (the two implementations agree).</p>
                    {srv.rf && <><HBars unit="Random forest SHAP (probability units)" data={srv.rf.contributions.slice(0, 8).map((c) => ({ name: featureLabel(c.feature), value: c.contribution }))} /></>}
                  </div>)}
                </>) : (
                  <p className="mt-1 text-sm text-muted">No API server is configured for this deployment, so everything above ran in your browser with the exported fitted models. TreeSHAP for the random forest needs the server; precomputed explanations for all 61 test records are on the <Link className="underline" to="/research/explainability">explainability page</Link>. See the documentation for how to run the API.</p>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
      <Section title="Before you read anything into these numbers">
        <ul className="prose-ml list-disc pl-5">
          <li>The data are a historical Cleveland, United States clinical benchmark. They are not a Nepalese population dataset, and the models have not been validated on one.</li>
          <li>The label is a cross-sectional diagnostic finding in that dataset. The models do not predict future cardiovascular events or ten-year risk.</li>
          <li>Good benchmark performance does not show clinical usefulness. Do not use this page for diagnosis, treatment or any clinical decision.</li>
          <li>Lifestyle questions about salt, fruit and vegetables or physical activity are education content. They are not inputs of these models and do not change any output here.</li>
        </ul>
      </Section>
    </>
  );
}
