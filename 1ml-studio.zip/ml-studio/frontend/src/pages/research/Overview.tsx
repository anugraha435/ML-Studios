import { Link } from 'react-router-dom';
import { PageHeader, Section } from '@/components/ui/Page';
import { Badge } from '@/components/ui/Badge';
import { Disclaimer } from '@/components/ui/Disclaimer';
import { DATA, MODEL_KEYS, MODEL_NAMES, NOT_YET_REPORTED, RESULTS, SETTINGS, SPLIT, UNREPORTED, num, pct } from '@/data/metrics';

export default function Overview() {
  return (
    <>
      <PageHeader title="CardioNepal research module" crumbs={[{ label: 'Research Lab' }]} lead="How well can standard classifiers separate patients with and without angiographic heart disease on a public benchmark, how well calibrated are their probabilities, and what do they rely on?" />
      <Disclaimer />
      <div className="mt-8 grid gap-4 md:grid-cols-3">
        <div className="card p-4"><h3 className="font-semibold">Try the models</h3><p className="mt-1 text-sm text-muted">Enter the 13 benchmark variables and get probabilities from the fitted models.</p><Link className="btn btn-primary mt-3" to="/research/demo">Open the demonstration</Link></div>
        <div className="card p-4"><h3 className="font-semibold">Check the results</h3><p className="mt-1 text-sm text-muted">Metrics with confidence intervals, confusion matrices, ROC, precision-recall and calibration plots.</p><Link className="btn btn-secondary mt-3" to="/research/performance">Model performance</Link></div>
        <div className="card p-4"><h3 className="font-semibold">See what drives them</h3><p className="mt-1 text-sm text-muted">Global and per-record SHAP explanations computed from the fitted models.</p><Link className="btn btn-secondary mt-3" to="/research/explainability">Explainability</Link></div>
      </div>
      <div className="mt-10 grid gap-10 lg:grid-cols-2">
        <div>
          <Section title="Background and problem statement"><div className="prose-ml"><p>Cardiovascular disease is a leading cause of death worldwide, and screening decisions often combine many clinical measurements. Machine-learning classifiers can combine such measurements, but a high score on a benchmark does not show that a model is well calibrated, that it is understandable, or that it works in a different population.</p>
            <p>CardioNepal studies these questions on one well-known public dataset. It is a methodological study of model evaluation and explanation. It is not a clinical tool and makes no claim about Nepalese patients, for whom no validation has been performed.</p></div></Section>
          <Section title="Research questions addressed here"><ol className="prose-ml list-decimal pl-6"><li>How do logistic regression, a decision tree, a random forest and a support vector machine compare on held-out data when preprocessing, tuning and thresholding are done without leakage?</li><li>Are the predicted probabilities calibrated, and does explicit calibration help?</li><li>Which features do the models rely on, and do two explanation methods agree?</li><li>How uncertain are the conclusions with only {SPLIT.nTest} test records?</li></ol></Section>
        </div>
        <div>
          <Section title="At a glance"><dl className="grid grid-cols-2 gap-3 text-sm">
            {[['Dataset', `UCI Cleveland, ${DATA.n} records`], ['Predictors', `${DATA.n_features} clinical variables`], ['Target', `Heart disease: ${DATA.n_present} present, ${DATA.n_absent} absent`], ['Split', `${SPLIT.nTrain} train / ${SPLIT.nTest} test, stratified, seed ${SETTINGS.seed}`], ['Tuning', `${SETTINGS.cv_folds}-fold stratified CV on training data`], ['Confidence intervals', `${SETTINGS.n_boot} bootstrap resamples`]].map(([k, v]) => <div key={k} className="card p-3"><dt className="text-xs text-muted">{k}</dt><dd className="font-medium">{v}</dd></div>)}</dl></Section>
          <Section title="Headline test-set results"><div className="mb-2"><Badge kind="measured" /></div>
            <div className="table-wrap"><table className="data"><caption className="sr-only">Test-set ROC-AUC and Brier score per model</caption><thead><tr><th>Model</th><th>ROC-AUC</th><th>Brier</th><th>Sensitivity at threshold</th></tr></thead><tbody>
              {MODEL_KEYS.map((k) => <tr key={k}><td>{MODEL_NAMES[k]}</td><td>{num(RESULTS[k].test.roc_auc)}</td><td>{num(RESULTS[k].test.brier)}</td><td>{pct(RESULTS[k].test.sensitivity)}</td></tr>)}</tbody></table></div>
            <p className="mt-2 text-sm text-muted">61 test records is a small sample; read these numbers with their confidence intervals on the performance page. Usability study (SUS): {UNREPORTED.usabilitySus}. External validation: {NOT_YET_REPORTED}.</p></Section>
        </div>
      </div>
      <Section title="Prototype architecture" lead="Two ways to run the same fitted models, chosen so the public site works without a server and the same results can be reproduced on one.">
        <div className="grid gap-4 md:grid-cols-3">
          <div className="card p-4"><h3 className="font-semibold">1. Training pipeline (Python)</h3><p className="mt-1 text-sm text-muted">scikit-learn pipelines are tuned and evaluated; the fitted objects, metrics and SHAP values are saved.</p></div>
          <div className="card p-4"><h3 className="font-semibold">2. In-browser inference</h3><p className="mt-1 text-sm text-muted">The fitted pipelines are exported to JSON (imputation values, scaling, one-hot categories, tree nodes, support vectors, calibration) and evaluated in TypeScript. Tests require agreement with scikit-learn to 1e-9.</p></div>
          <div className="card p-4"><h3 className="font-semibold">3. FastAPI service (optional)</h3><p className="mt-1 text-sm text-muted">The original scikit-learn objects behind a validated API, which also serves random forest TreeSHAP for a record you enter.</p></div></div></Section>
      <Section title="Future improvements"><ul className="prose-ml"><li>External validation on a prospective and locally collected cohort before any claim about Nepalese patients.</li><li>Larger and more diverse data, with repeated cross-validation to tighten intervals.</li><li>Decision-curve analysis to judge clinical net benefit, and subgroup performance checks.</li><li>A usability study of the demonstration; its result is currently {NOT_YET_REPORTED.toLowerCase()}.</li></ul></Section>
    </>
  );
}
