import { useState } from 'react';
import { PageHeader, Section } from '@/components/ui/Page';
import { Badge } from '@/components/ui/Badge';
import { Beeswarm, HBars } from '@/components/viz/Charts';
import { CURVES, FEATURE_INFO, MODEL_KEYS, MODEL_SHORT, SHAP, num } from '@/data/metrics';
import { Disclaimer } from '@/components/ui/Disclaimer';

const label = (f: string) => FEATURE_INFO[f]?.label ?? f;
export default function Explain() {
  const [i, setI] = useState(0);
  const imp = [...SHAP.importance].sort((a, b) => b.rf_shap_mean_abs - a.rf_shap_mean_abs);
  const impLr = [...SHAP.importance].sort((a, b) => b.lr_shap_mean_abs - a.lr_shap_mean_abs);
  const j = (f: string) => SHAP.features.indexOf(f);
  const local = (S: number[][]) => SHAP.features.map((f, k) => ({ name: `${label(f)} = ${SHAP.X_test[i][k] === null ? 'missing' : SHAP.X_test[i][k]}`, value: S[i][k] })).sort((a, b) => Math.abs(b.value) - Math.abs(a.value)).slice(0, 8);
  const y = CURVES.yTest[i];
  const rfSum = SHAP.rf_base_value + SHAP.S_rf[i].reduce((a, b) => a + b, 0);
  return (
    <>
      <PageHeader title="Explainability (SHAP)" crumbs={[{ label: 'Research Lab', to: '/research' }, { label: 'Explainability' }]} lead="Which inputs do the fitted models rely on, overall and for one patient record?"><div className="mt-3"><Badge kind="measured" /></div></PageHeader>
      <div className="prose-ml mb-6 rounded-lg border border-line bg-sunken p-4 text-sm"><p><strong>What was explained.</strong> The final random forest (500 trees, depth 5; TreeSHAP, interventional, probability units, 100 background training rows) and the final logistic regression (linear SHAP, log-odds units), both trained on the {242} Cleveland training records and explained on the {61} test records. SHAP values split one prediction into additive contributions from each feature relative to a base value. They describe what the model uses. They are <strong>not</strong> evidence that a feature causes disease, and correlated features share credit.</p></div>
      <Section title="Global importance">
        <div className="grid gap-6 lg:grid-cols-2"><div><h3 className="mb-1 font-semibold">Random forest: mean |SHAP|</h3><HBars unit="Probability units" data={imp.map((r) => ({ name: label(r.feature), value: r.rf_shap_mean_abs }))} /></div>
          <div><h3 className="mb-1 font-semibold">Logistic regression: mean |SHAP|</h3><HBars unit="Log-odds units" data={impLr.map((r) => ({ name: label(r.feature), value: r.lr_shap_mean_abs }))} /></div></div>
        <p className="mt-2 text-sm text-muted">Top five by random forest SHAP: {SHAP.top_rf.map(label).join(', ')}. Top five by logistic regression: {SHAP.top_lr.map(label).join(', ')}. The two models are on different scales (probability versus log-odds), so compare ranks, not bar lengths: Spearman rank correlation between RF SHAP and LR SHAP is {num(SHAP.spearman.rf_shap_vs_lr_shap, 2)}, between RF SHAP and RF impurity importance {num(SHAP.spearman.rf_shap_vs_rf_mdi, 2)}, and between RF SHAP and RF permutation importance {num(SHAP.spearman.rf_shap_vs_rf_perm, 2)}.</p>
        <div className="table-wrap mt-3"><table className="data"><caption className="sr-only">Importance measures per feature</caption><thead><tr><th>Feature</th><th>RF mean |SHAP|</th><th>LR mean |SHAP|</th><th>RF impurity (MDI)</th><th>RF permutation (drop in ROC-AUC ± SD)</th></tr></thead><tbody>
          {imp.map((r) => <tr key={r.feature}><td>{label(r.feature)}</td><td>{num(r.rf_shap_mean_abs, 4)}</td><td>{num(r.lr_shap_mean_abs, 4)}</td><td>{num(r.rf_mdi, 4)}</td><td>{num(r.rf_perm_auc_drop, 4)} ± {num(r.rf_perm_sd, 4)}</td></tr>)}</tbody></table></div></Section>
      <Section title="SHAP summary plot (random forest)"><Beeswarm features={SHAP.features} shap={SHAP.S_rf} values={SHAP.X_test} labels={Object.fromEntries(Object.entries(FEATURE_INFO).map(([k, v]) => [k, v.label]))} />
        <p className="text-sm text-muted">Each dot is one of the 61 test records. Dots to the right raised that record’s predicted probability relative to the base value ({num(SHAP.rf_base_value, 3)}); dots to the left lowered it. Colour shows low versus high values of the feature (within the test set).</p></Section>
      <Section title="Explain one test record" lead="Pick a record from the held-out test set to see how each model’s prediction splits into feature contributions.">
        <div className="mb-4 flex flex-wrap items-end gap-4"><div><label htmlFor="rec" className="label">Test record</label><select id="rec" className="field" value={i} onChange={(e) => setI(Number(e.target.value))}>{CURVES.yTest.map((_, k) => <option key={k} value={k}>Record {k + 1}</option>)}</select></div>
          <div className="text-sm"><div>Recorded label: <strong>{y === 1 ? 'heart disease present' : 'no heart disease'}</strong></div><div>Model probabilities: {MODEL_KEYS.map((k) => `${MODEL_SHORT[k]} ${(CURVES.curves[k].probs[i] * 100).toFixed(1)}%`).join(', ')}</div></div></div>
        <div className="grid gap-6 lg:grid-cols-2"><div><h3 className="mb-1 font-semibold">Random forest (probability units)</h3><HBars unit="Contribution to predicted probability" data={local(SHAP.S_rf)} />
          <p className="text-xs text-muted">Base value {num(SHAP.rf_base_value, 3)} + sum of all 13 contributions = {num(rfSum, 3)}; the forest’s output for this record is {num(CURVES.curves.rf.probs[i], 3)}. Largest additivity gap across all records: {SHAP.rf_additivity_max_abs_error.toExponential(1)}.</p></div>
          <div><h3 className="mb-1 font-semibold">Logistic regression (log-odds units)</h3><HBars unit="Contribution to log-odds" data={local(SHAP.S_lr)} /><p className="text-xs text-muted">Showing the 8 largest of 13 contributions. Red bars push toward disease, blue bars away.</p></div></div>
        <p className="mt-3 text-sm text-muted">Reading it: a contribution of +0.10 in the forest panel means that, for this record, that feature’s value moved the predicted probability up by 10 percentage points relative to the average background record. {j('ca') >= 0 && 'Missing values (ca, thal) were imputed before explaining, so their contribution reflects the imputed value.'}</p></Section>
      <Disclaimer compact />
    </>
  );
}
