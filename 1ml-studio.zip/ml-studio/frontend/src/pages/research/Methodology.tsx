import { PageHeader, Section } from '@/components/ui/Page';
import { Badge } from '@/components/ui/Badge';
import { MODEL_KEYS, MODEL_NAMES, RESULTS, SETTINGS, SPLIT, VERSIONS } from '@/data/metrics';

const STEPS = [
  ['Data and target', 'The Cleveland subset (303 records, 13 predictors). The diagnosis column (0 to 4) is converted to a binary target: 0 absent, 1 to 4 present.'],
  ['Split', `One stratified ${(1 - SETTINGS.test_size) * 100}/${SETTINGS.test_size * 100} train/test split with seed ${SETTINGS.seed}: ${SPLIT.nTrain} training and ${SPLIT.nTest} test records. The test set is used once, for final evaluation.`],
  ['Leakage-aware preprocessing', 'Median imputation and standardisation for the six numeric variables, most-frequent imputation and one-hot encoding for the four categorical variables, passthrough for the three binary variables: 22 model inputs. All of it is a scikit-learn pipeline fitted inside every cross-validation fold, so no statistic is learned from validation or test rows.'],
  ['Tuning', `Grid search with ${SETTINGS.cv_folds}-fold stratified cross-validation on the training set, scored by ROC-AUC, for each classifier and each class-handling option (none, class weights, SMOTE inside the pipeline). The simplest option within ${SETTINGS.parsimony_tolerance} AUC of the best is kept (parsimony rule).`],
  ['Calibration', 'For each model, no calibration, sigmoid (Platt) and isotonic calibration (5-fold, via CalibratedClassifierCV) are compared by the out-of-fold Brier score on training data; the best is used.'],
  ['Decision threshold', `The threshold is the largest value at which the training-only out-of-fold sensitivity is at least ${SETTINGS.target_sensitivity.toFixed(2)}. It is fixed before the test set is touched.`],
  ['Evaluation', `Accuracy, precision, recall, specificity, F1, ROC-AUC, PR-AUC and Brier score on the test set, with ${SETTINGS.n_boot}-resample bootstrap 95% intervals, Clopper-Pearson intervals for proportions, calibration slope and intercept, paired bootstrap AUC differences, and nested cross-validation.`],
  ['Explainability', 'TreeSHAP for the random forest (probability units) and linear SHAP for logistic regression (log-odds units), plus impurity and permutation importance for comparison.']
];
export default function Methodology() {
  return (
    <>
      <PageHeader title="Methodology" crumbs={[{ label: 'Research Lab', to: '/research' }, { label: 'Methodology' }]} lead="What was done, in order. Settings and values on this page are read from the saved experiment output." />
      <Section title="Procedure"><ol className="space-y-3">{STEPS.map(([t, d], k) => <li key={t} className="card flex gap-4 p-4"><span className="font-serif text-2xl text-accent" aria-hidden>{k + 1}</span><div><h3 className="font-semibold">{t}</h3><p className="text-sm text-muted">{d}</p></div></li>)}</ol></Section>
      <Section title="Final model configurations"><div className="mb-2"><Badge kind="measured" /></div>
        <div className="table-wrap"><table className="data"><caption className="sr-only">Final configuration of each model</caption><thead><tr><th>Model</th><th>Selected hyperparameters</th><th>Class handling</th><th>Calibration</th><th>Threshold</th></tr></thead><tbody>
          {MODEL_KEYS.map((k) => <tr key={k}><td>{MODEL_NAMES[k]}</td><td className="font-mono text-xs">{Object.entries(RESULTS[k].bestParams).map(([a, b]) => `${a.replace('clf__', '')}=${String(b)}`).join(', ')}</td><td>{RESULTS[k].condition}</td><td>{RESULTS[k].calibration}</td><td>{RESULTS[k].threshold.toFixed(3)}</td></tr>)}</tbody></table></div></Section>
      <Section title="Why these four algorithms"><ul className="prose-ml"><li><strong>Logistic regression:</strong> a transparent, well-calibrated baseline whose weights can be read directly.</li><li><strong>Decision tree:</strong> human-readable rules, at the cost of instability.</li><li><strong>Random forest:</strong> an ensemble that usually improves on one tree and captures interactions.</li><li><strong>Support vector machine:</strong> a margin-based method with a flexible kernel; its scores need calibration to become probabilities.</li></ul></Section>
      <Section title="Experimental findings versus proposed methodology"><div className="prose-ml"><p><strong>Experimental findings</strong> are the numbers on the performance and explainability pages: they were produced by running the pipeline above. <strong>Proposed methodology</strong> that has not been executed is limited to the future work listed on the overview (external validation, decision-curve analysis, usability study). Nothing in the second group appears as a number anywhere on this site.</p></div></Section>
      <Section title="Reproducibility"><div className="prose-ml"><p>Run <code>research/run_experiment.py</code> then <code>make_figures.py</code> and <code>export_artifacts.py</code>. With the same package versions the saved results reproduce exactly (random seed {SETTINGS.seed}). Versions used: {Object.entries(VERSIONS).map(([k, v]) => `${k} ${v}`).join(', ')}.</p></div></Section>
    </>
  );
}
