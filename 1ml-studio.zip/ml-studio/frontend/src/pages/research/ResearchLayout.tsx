import { NavLink, Outlet } from 'react-router-dom';
import { Container } from '@/components/ui/Page';
const TABS = [['/research', 'Overview', true], ['/research/demo', 'Demonstration', false], ['/research/performance', 'Model performance', false], ['/research/explainability', 'Explainability', false], ['/research/dataset', 'Dataset', false], ['/research/methodology', 'Methodology', false], ['/research/limitations', 'Limitations and privacy', false]] as const;
export default function ResearchLayout() {
  return (
    <>
      <div className="border-b border-line bg-sunken">
        <Container><nav aria-label="Research Lab sections" className="-mb-px flex gap-1 overflow-x-auto py-2">
          <span className="mr-2 hidden self-center font-serif text-sm font-semibold sm:inline">CardioNepal Research Lab</span>
          {TABS.map(([to, label, end]) => <NavLink key={to} to={to} end={end} className={({ isActive }) => `whitespace-nowrap rounded-md px-3 py-2 text-sm ${isActive ? 'bg-surface font-medium text-ink shadow-sm' : 'text-muted hover:text-ink'}`}>{label}</NavLink>)}
        </nav></Container>
      </div>
      <Container className="py-10"><Outlet /></Container>
    </>
  );
}
