import { Container, PageHeader, Section } from '@/components/ui/Page';
import { Badge } from '@/components/ui/Badge';
export default function About() {
  return (
    <Container className="py-10">
      <PageHeader title="About ML Studio" crumbs={[{ label: 'About' }]} lead="An educational and research platform built to make machine learning understandable and checkable." />
      <Section title="Purpose"><div className="prose-ml"><p>ML Studio combines written lessons, interactive algorithm experiments, a playground for your own CSV data and a research lab that presents the CardioNepal study of heart-disease classification on a public benchmark. The lessons, diagrams and code were written for this project. The two sites that inspired its scope, the MLU-Explain project and the original CardioNepal prototype, were used for ideas only; no text, code, layout or illustration was copied from them.</p></div></Section>
      <Section title="How the platform labels its content" lead="Every number or chart belongs to exactly one of these kinds, and the page says which."><ul className="grid gap-3 md:grid-cols-2">
        <li className="card p-4"><Badge kind="measured" /><p className="mt-2 text-sm">Results computed from the fitted CardioNepal models on the held-out test set, stored with the source code.</p></li>
        <li className="card p-4"><Badge kind="inference" /><p className="mt-2 text-sm">A prediction made by the fitted CardioNepal pipeline for values you enter, in the browser or by the API.</p></li>
        <li className="card p-4"><Badge kind="simulation" /><p className="mt-2 text-sm">A real calculation on small data you control, used to teach how an algorithm behaves. Not a research finding.</p></li>
        <li className="card p-4"><Badge kind="illustrative" /><p className="mt-2 text-sm">Made-up numbers chosen to show an idea, such as a confusion matrix with round counts. Not a research finding.</p></li></ul>
        <p className="mt-3 text-sm text-muted">Quantities the research has not produced, such as usability scores or validation on a Nepalese population, appear as “Not yet reported”.</p></Section>
      <Section title="Dataset attribution and licenses"><div className="table-wrap"><table className="data"><thead><tr><th>Dataset</th><th>Source</th><th>License</th></tr></thead><tbody>
        <tr><td>Heart Disease (Cleveland subset, 303 records)</td><td>Janosi, A., Steinbrunn, W., Pfisterer, M., Detrano, R. UCI Machine Learning Repository, doi:10.24432/C52P4X</td><td>CC BY 4.0</td></tr>
        <tr><td>Iris</td><td>Fisher, R. A. (1936). UCI Machine Learning Repository, doi:10.24432/C56C76</td><td>CC BY 4.0</td></tr>
        <tr><td>Wine</td><td>Aeberhard, S. and Forina, M. UCI Machine Learning Repository, doi:10.24432/C5PC7J</td><td>CC BY 4.0</td></tr>
        <tr><td>Breast Cancer Wisconsin (Diagnostic)</td><td>Wolberg, W. H., Street, W. N., Mangasarian, O. L. UCI Machine Learning Repository, doi:10.24432/C5DW2B</td><td>CC BY 4.0</td></tr>
        <tr><td>Synthetic datasets (blobs, moons, circles, XOR)</td><td>Generated in the browser with a seeded random number generator</td><td>Original to this project (MIT)</td></tr></tbody></table></div>
        <p className="mt-2 text-sm text-muted">DOIs are those listed on each dataset page of the UCI repository at the time of writing; check them there before citing.</p></Section>
      <Section title="Software"><p className="prose-ml">Source code: MIT License. Built with React, TypeScript, Vite, Tailwind CSS, Framer Motion, Lucide, Recharts, KaTeX, PapaParse on the front end and FastAPI, scikit-learn, SHAP, pandas and NumPy on the back end; each keeps its own license (see THIRD_PARTY_NOTICES.md in the repository). Fonts: Source Serif 4, Inter and JetBrains Mono (SIL Open Font License 1.1).</p></Section>
    </Container>
  );
}
