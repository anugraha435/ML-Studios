import { ArrowRight } from 'lucide-react';
import { Suspense, lazy, type ComponentType } from 'react';
import { Link, useParams } from 'react-router-dom';
import { getLesson } from '../content';
import { ALGORITHMS, getAlgorithm } from '../data/algorithms';
import { RichText, Tex } from '../components/RichText';
import { Breadcrumbs, PageHeader, Section, Spinner } from '../components/ui';
import NotFound from './NotFound';

const DEMOS: Record<string, React.LazyExoticComponent<ComponentType>> = {
  'linear-regression': lazy(() => import('../components/demos/LinearRegressionDemo')),
  'logistic-regression': lazy(() => import('../components/demos/LogisticDemo')),
  'decision-tree': lazy(() => import('../components/demos/TreeDemo')),
  'random-forest': lazy(() => import('../components/demos/ForestDemo')),
  svm: lazy(() => import('../components/demos/SvmDemo')),
  'k-means': lazy(() => import('../components/demos/KMeansDemo')),
  knn: lazy(() => import('../components/demos/KnnDemo'))
};

export function AlgorithmsIndex() {
  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
      <PageHeader title="Algorithm explorer" lead="Seven algorithms, each with a live experiment. Every control changes a real calculation running in your browser, and the implementations are tested against scikit-learn." />
      <ul className="divide-y divide-line border-y border-line">
        {ALGORITHMS.map((a) => (
          <li key={a.id}>
            <Link to={`/algorithms/${a.id}`} className="group grid gap-2 py-5 hover:bg-raised/60 sm:grid-cols-[220px_1fr_auto] sm:items-center sm:gap-6">
              <div><h2 className="text-xl font-semibold group-hover:text-brand">{a.title}</h2><p className="text-sm text-muted">{a.family}</p></div>
              <p className="text-muted">{a.tagline} {a.controls.split('.')[0]}.</p>
              <span className="inline-flex items-center gap-1 text-sm font-medium text-accent">Open explorer <ArrowRight size={16} aria-hidden /></span>
            </Link>
          </li>
        ))}
      </ul>
      <p className="mt-6 text-sm text-muted">Want to run these on data of your own? Use the <Link className="underline" to="/playground">playground</Link>.</p>
    </div>
  );
}

export function AlgorithmPage() {
  const { id = '' } = useParams(); const a = getAlgorithm(id); const lesson = a ? getLesson(a.lessonId) : undefined;
  if (!a || !lesson) return <NotFound what="algorithm" />;
  const Demo = DEMOS[a.id];
  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
      <Breadcrumbs items={[{ label: 'Algorithms', to: '/algorithms' }, { label: a.title }]} />
      <PageHeader title={a.title} lead={a.tagline}><p className="mt-2 text-sm text-muted">{a.family}</p></PageHeader>
      <div className="grid gap-x-12 lg:grid-cols-2">
        <Section title="Introduction"><RichText text={lesson.intro.split(/\n{2,}/)[0]} serif /></Section>
        <Section title="How it works"><ol className="max-w-prose list-decimal space-y-2 pl-5">{a.howItWorks.map((s, i) => <li key={i}><RichText text={s} className="!inline [&_p]:!inline [&_p]:!mb-0" /></li>)}</ol></Section>
      </div>
      {!!lesson.math?.length && <Section title="Mathematical explanation"><div className="grid gap-4 md:grid-cols-2">{lesson.math.slice(0, 4).map((m, i) => <figure key={i} className="card p-4"><figcaption className="mb-1 text-sm font-medium">{m.label}</figcaption><div className="overflow-x-auto"><Tex display tex={m.tex} /></div>{m.note && <RichText text={m.note} className="mt-2 text-sm text-muted [&_p]:!mb-0" />}</figure>)}</div></Section>}
      <Section title="Interactive experiment">
        <p className="mb-4 max-w-prose text-sm text-muted">{a.controls}</p>
        <Suspense fallback={<Spinner label="Loading experiment" />}><Demo /></Suspense>
      </Section>
      <Section title="Worked example by hand"><div className="card max-w-3xl p-5"><h3 className="mb-2 text-lg font-semibold">{lesson.example.title}</h3><RichText text={lesson.example.body} /></div></Section>
      <div className="grid gap-4 md:grid-cols-3">
        <div className="card p-5"><h2 className="mb-2 font-sans text-base font-semibold text-good">Advantages</h2><ul className="list-disc space-y-1.5 pl-5 text-sm">{lesson.pros.map((x, i) => <li key={i}><RichText text={x} className="!inline [&_p]:!inline [&_p]:!mb-0" /></li>)}</ul></div>
        <div className="card p-5"><h2 className="mb-2 font-sans text-base font-semibold text-warn">Disadvantages</h2><ul className="list-disc space-y-1.5 pl-5 text-sm">{lesson.cons.map((x, i) => <li key={i}><RichText text={x} className="!inline [&_p]:!inline [&_p]:!mb-0" /></li>)}</ul></div>
        <div className="card p-5"><h2 className="mb-2 font-sans text-base font-semibold">Common limitations</h2><ul className="list-disc space-y-1.5 pl-5 text-sm">{a.limitations.map((x, i) => <li key={i}>{x}</li>)}</ul></div>
      </div>
      <Section title="Practical applications"><ul className="mt-12 max-w-prose list-disc space-y-1.5 pl-5">{lesson.applications.map((x, i) => <li key={i}><RichText text={x} className="!inline [&_p]:!inline [&_p]:!mb-0" /></li>)}</ul></Section>
      <div className="flex flex-wrap gap-3"><Link to={`/learn/${lesson.id}`} className="btn btn-primary">Read the full lesson</Link><Link to="/playground" className="btn btn-ghost">Try it on a dataset in the playground</Link></div>
    </div>
  );
}
