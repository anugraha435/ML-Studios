import { Database, Play, Upload } from 'lucide-react';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { Bar, BarChart, CartesianGrid, Legend as RLegend, Line, LineChart, ResponsiveContainer, Scatter, ScatterChart, Tooltip, XAxis, YAxis, Cell, ReferenceLine } from 'recharts';
import { Segmented, Slider, Stat } from '../components/controls';
import { CLASS_COLORS } from '../components/Plot2D';
import { Callout, ErrorBox, EvidenceBadge, PageHeader, Section, Spinner } from '../components/ui';
import { SAMPLES, type SampleDataset } from '../data/samples';
import { inferTask, type TaskType } from '../lib/data/preprocess';
import { LIMITS, parseCsvText, readFile, type Table } from '../lib/data/table';
import { DEFAULT_PARAMS, algoSupports, type AlgoId, type Params, type RunRequest, type RunResult } from '../lib/pipeline/run';
import { scoreRecord, type Scored } from '../lib/pipeline/score';
import { useTrainer } from '../lib/pipeline/useTrainer';

const ALGOS: { id: AlgoId; label: string }[] = [
  { id: 'linear-regression', label: 'Linear regression' }, { id: 'logistic-regression', label: 'Logistic regression' }, { id: 'decision-tree', label: 'Decision tree' },
  { id: 'random-forest', label: 'Random forest' }, { id: 'svm', label: 'Support vector machine' }, { id: 'knn', label: 'K-nearest neighbours' }, { id: 'k-means', label: 'K-means clustering' }
];
const METRIC_LABEL: Record<string, string> = { accuracy: 'Accuracy', precision: 'Precision', recall: 'Recall', specificity: 'Specificity', f1: 'F1', roc_auc: 'ROC-AUC', brier: 'Brier score', macro_precision: 'Macro precision', macro_recall: 'Macro recall', macro_f1: 'Macro F1', r2: 'R²', rmse: 'RMSE', mae: 'MAE', inertia: 'Inertia', silhouette: 'Silhouette' };
const num = (v: number) => (Number.isFinite(v) ? (Math.abs(v) >= 1000 ? v.toFixed(1) : v.toFixed(3)) : '–');

export default function Playground() {
  const train = useTrainer();
  const [table, setTable] = useState<Table | null>(null); const [sample, setSample] = useState<SampleDataset | null>(null);
  const [loadErr, setLoadErr] = useState<string | null>(null); const [loading, setLoading] = useState(false);
  const [algo, setAlgo] = useState<AlgoId>('logistic-regression'); const [target, setTarget] = useState<string | null>(null);
  const [features, setFeatures] = useState<string[]>([]); const [task, setTask] = useState<TaskType>('classification'); const [taskWhy, setTaskWhy] = useState('');
  const [params, setParams] = useState<Params>(DEFAULT_PARAMS); const [testFrac, setTestFrac] = useState(0.25);
  const [busy, setBusy] = useState(false); const [err, setErr] = useState<string | null>(null);
  const [result, setResult] = useState<RunResult | null>(null); const [compare, setCompare] = useState<RunResult[] | null>(null); const [cmpErr, setCmpErr] = useState<string[]>([]);
  const fileRef = useRef<HTMLInputElement>(null); const [drag, setDrag] = useState(false);

  const setupTable = useCallback((t: Table, defTarget?: string) => {
    setTable(t); setResult(null); setCompare(null); setErr(null);
    const tg = defTarget && t.columns.some((c) => c.name === defTarget) ? defTarget : t.columns[t.columns.length - 1].name;
    setTarget(tg); setFeatures(t.columns.filter((c) => c.name !== tg && !c.warning).map((c) => c.name));
    const it = inferTask(t, tg); setTask(it.task); setTaskWhy(it.reason);
    setAlgo((a) => (a === 'k-means' ? a : algoSupports(a, it.task) ? a : it.task === 'regression' ? 'linear-regression' : 'logistic-regression'));
  }, []);
  const loadSample = useCallback(async (s: SampleDataset) => {
    setLoading(true); setLoadErr(null); setSample(s);
    try {
      let text: string;
      if (s.text) text = s.text(); else { const r = await fetch(`${import.meta.env.BASE_URL}datasets/${s.file}`); if (!r.ok) throw new Error(`Could not load ${s.file} (HTTP ${r.status}).`); text = await r.text(); }
      setupTable(parseCsvText(text, s.label), s.target);
    } catch (e) { setLoadErr((e as Error).message); } finally { setLoading(false); }
  }, [setupTable]);
  useEffect(() => { void loadSample(SAMPLES[0]); }, [loadSample]);
  const onFile = async (f: File | undefined) => {
    if (!f) return; setLoading(true); setLoadErr(null);
    try { setSample(null); setupTable(await readFile(f)); } catch (e) { setLoadErr((e as Error).message); } finally { setLoading(false); if (fileRef.current) fileRef.current.value = ''; }
  };
  const changeTarget = (name: string) => { if (!table) return; setTarget(name); setFeatures((f) => f.filter((x) => x !== name)); const it = inferTask(table, name); setTask(it.task); setTaskWhy(it.reason); setResult(null); setCompare(null); if (!algoSupports(algo, it.task) && algo !== 'k-means') setAlgo(it.task === 'regression' ? 'linear-regression' : 'logistic-regression'); };
  const req = useMemo<RunRequest | null>(() => (table ? { table, algo, target: algo === 'k-means' ? null : target, features, params, task, testFraction: testFrac } : null), [table, algo, target, features, params, task, testFrac]);
  const run = async () => {
    if (!req) return; setBusy(true); setErr(null); setResult(null);
    try { const [o] = await train([req]); if (o.ok) setResult(o.result); else setErr(o.error); } catch (e) { setErr((e as Error).message); } finally { setBusy(false); }
  };
  const runCompare = async () => {
    if (!req || !table) return; setBusy(true); setErr(null); setCompare(null);
    try {
      const ids = ALGOS.filter((a) => a.id !== 'k-means' && algoSupports(a.id, task) && !(task === 'regression' && !['linear-regression', 'knn'].includes(a.id))).map((a) => a.id);
      const outs = await train(ids.map((id) => ({ ...req, algo: id, target })), 180000);
      setCompare(outs.filter((o): o is { ok: true; result: RunResult } => o.ok).map((o) => o.result)); setCmpErr(outs.filter((o) => !o.ok).map((o) => `${(o as { algo: string; error: string }).algo}: ${(o as { error: string }).error}`));
    } catch (e) { setErr((e as Error).message); } finally { setBusy(false); }
  };
  const setP = <K extends keyof Params>(k: K, v: Params[K]) => setParams((p) => ({ ...p, [k]: v }));

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
      <PageHeader title="Interactive playground" lead="Train real models on sample data or on your own CSV file, then inspect the results. Everything runs in your browser; your file is never uploaded." />
      <Callout title="What this is"><span>These are small demonstration models fitted with the same from-scratch code as the algorithm explorers. They are meant for learning, not for tuned performance or for decisions about real people.</span></Callout>

      <Section title="1. Choose data" id="data">
        <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_340px]">
          <div>
            <p className="label">Sample datasets</p>
            <ul className="grid gap-2 sm:grid-cols-2" role="list">
              {SAMPLES.map((s) => (
                <li key={s.id}><button type="button" onClick={() => loadSample(s)} aria-pressed={sample?.id === s.id} className={`w-full rounded-lg border p-3 text-left text-sm ${sample?.id === s.id ? 'border-accent bg-accent/5' : 'border-line hover:bg-raised'}`}>
                  <span className="flex items-center gap-2 font-medium"><Database size={14} aria-hidden />{s.label}{s.synthetic && <span className="chip">synthetic</span>}</span><span className="mt-1 block text-muted">{s.description}</span></button></li>
              ))}
            </ul>
            {sample && <p className="hint mt-2">Source: {sample.attribution}</p>}
          </div>
          <div>
            <p className="label">Or upload your own CSV</p>
            <div onDragOver={(e) => { e.preventDefault(); setDrag(true); }} onDragLeave={() => setDrag(false)} onDrop={(e) => { e.preventDefault(); setDrag(false); void onFile(e.dataTransfer.files[0]); }}
              className={`rounded-lg border-2 border-dashed p-5 text-center ${drag ? 'border-accent bg-accent/5' : 'border-line'}`}>
              <Upload className="mx-auto text-muted" aria-hidden /><p className="mt-2 text-sm">Drop a .csv file here, or</p>
              <label className="btn btn-ghost mt-2 cursor-pointer">Choose file<input ref={fileRef} type="file" accept=".csv,.txt,text/csv,text/plain" className="sr-only" onChange={(e) => onFile(e.target.files?.[0])} /></label>
              <p className="hint mt-3">Up to {LIMITS.maxBytes / 1048576} MB, {LIMITS.maxRows.toLocaleString()} rows, {LIMITS.maxCols} columns. Header row required. Processed locally.</p>
            </div>
          </div>
        </div>
        {loading && <Spinner label="Reading data" />}
        {loadErr && <div className="mt-4"><ErrorBox><strong>Could not use this file.</strong> {loadErr}</ErrorBox></div>}
        {table && !loading && <DataPreview table={table} />}
      </Section>

      {table && (
        <>
          <Section title="2. Choose algorithm, target and features" id="setup">
            <div className="grid gap-6 lg:grid-cols-2">
              <div className="space-y-5">
                <div><label htmlFor="algo" className="label">Algorithm</label>
                  <select id="algo" className="input" value={algo} onChange={(e) => { setAlgo(e.target.value as AlgoId); setResult(null); }}>
                    {ALGOS.map((a) => <option key={a.id} value={a.id} disabled={a.id !== 'k-means' && !algoSupports(a.id, task) && !(task === 'regression' && a.id === 'knn')}>{a.label}{a.id !== 'k-means' && !algoSupports(a.id, task) && !(task === 'regression' && a.id === 'knn') ? ` (needs ${a.id === 'linear-regression' ? 'a numeric target' : 'a class target'})` : ''}</option>)}
                  </select></div>
                {algo !== 'k-means' && (<>
                  <div><label htmlFor="target" className="label">Target column (what to predict)</label>
                    <select id="target" className="input" value={target ?? ''} onChange={(e) => changeTarget(e.target.value)}>{table.columns.map((c) => <option key={c.name} value={c.name}>{c.name} ({c.kind})</option>)}</select>
                    <p className="hint mt-1">{taskWhy}</p></div>
                  <Segmented label="Task" value={task} options={[{ value: 'classification', label: 'Classification' }, { value: 'regression', label: 'Regression' }]} onChange={(v) => { setTask(v); setResult(null); if (!algoSupports(algo, v) && !(v === 'regression' && algo === 'knn')) setAlgo(v === 'regression' ? 'linear-regression' : 'logistic-regression'); }} />
                  {task === 'regression' && table.columns.find((c) => c.name === target)?.kind === 'categorical' && <ErrorBox>The target is text, so it cannot be used for regression. Choose classification or a numeric target.</ErrorBox>}
                </>)}
                {algo === 'k-means' && <p className="text-sm text-muted">K-means is unsupervised: it ignores any target and groups rows by similarity of numeric features.</p>}
              </div>
              <fieldset>
                <legend className="label">Input features ({features.length} selected)</legend>
                <div className="mb-2 flex gap-3 text-sm"><button type="button" className="underline" onClick={() => setFeatures(table.columns.filter((c) => c.name !== target && (algo !== 'k-means' || c.kind === 'numeric')).map((c) => c.name))}>Select all</button><button type="button" className="underline" onClick={() => setFeatures([])}>Clear</button></div>
                <div className="grid max-h-64 gap-1 overflow-auto rounded-md border border-line p-3 sm:grid-cols-2">
                  {table.columns.filter((c) => c.name !== target || algo === 'k-means').map((c) => {
                    const disabled = algo === 'k-means' && c.kind !== 'numeric';
                    return <label key={c.name} className={`flex items-start gap-2 text-sm ${disabled ? 'opacity-50' : ''}`}><input type="checkbox" className="mt-1 accent-[rgb(var(--accent))]" disabled={disabled} checked={features.includes(c.name)} onChange={(e) => setFeatures((f) => (e.target.checked ? [...f, c.name] : f.filter((x) => x !== c.name)))} /><span>{c.name} <span className="text-muted">({c.kind}{c.warning ? ', see warning' : ''})</span></span></label>;
                  })}
                </div>
                {table.columns.some((c) => c.warning) && <p className="hint mt-2">Columns with warnings (identifiers, constants, free text) are unticked by default because they rarely help and can mislead a model.</p>}
              </fieldset>
            </div>
          </Section>

          <Section title="3. Settings and training" id="train">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {algo === 'logistic-regression' && <Slider label="C (inverse regularisation)" value={Math.log10(params.C)} min={-2} max={2} step={0.1} onChange={(v) => setP('C', +Math.pow(10, v).toFixed(3))} format={() => params.C.toPrecision(3)} hint="Smaller C shrinks the weights more." />}
              {algo === 'linear-regression' && <Slider label="Ridge penalty" value={params.ridge} min={0} max={20} step={0.5} onChange={(v) => setP('ridge', v)} hint="0 is ordinary least squares." />}
              {(algo === 'decision-tree' || algo === 'random-forest') && <><Slider label="Maximum depth" value={params.maxDepth} min={1} max={12} onChange={(v) => setP('maxDepth', v)} /><Slider label="Minimum samples to split" value={params.minSamplesSplit} min={2} max={30} onChange={(v) => setP('minSamplesSplit', v)} /></>}
              {algo === 'random-forest' && <Slider label="Number of trees" value={params.nTrees} min={5} max={200} onChange={(v) => setP('nTrees', v)} />}
              {algo === 'svm' && <><Segmented label="Kernel" value={params.kernel} options={[{ value: 'linear', label: 'Linear' }, { value: 'rbf', label: 'RBF' }, { value: 'poly', label: 'Polynomial' }]} onChange={(v) => setP('kernel', v)} /><Slider label="C" value={Math.log10(params.C)} min={-2} max={3} step={0.1} onChange={(v) => setP('C', +Math.pow(10, v).toFixed(3))} format={() => params.C.toPrecision(3)} />{params.kernel !== 'linear' && <Slider label="Gamma (0 = 1 / number of inputs)" value={params.gamma} min={0} max={2} step={0.01} onChange={(v) => setP('gamma', v)} format={(v) => (v === 0 ? 'auto' : v.toFixed(2))} />}</>}
              {algo === 'knn' && <><Slider label="k (neighbours)" value={params.k} min={1} max={30} onChange={(v) => setP('k', v)} />{task === 'classification' && <label className="flex items-center gap-2 text-sm"><input type="checkbox" className="accent-[rgb(var(--accent))]" checked={params.weighted} onChange={(e) => setP('weighted', e.target.checked)} />Weight votes by 1 / distance</label>}</>}
              {algo === 'k-means' && <Slider label="Number of clusters" value={params.clusters} min={2} max={10} onChange={(v) => setP('clusters', v)} />}
              {algo !== 'k-means' && <Slider label="Share of rows held out for testing" value={testFrac} min={0.1} max={0.5} step={0.05} onChange={setTestFrac} format={(v) => `${Math.round(v * 100)}%`} />}
              <Slider label="Random seed" value={params.seed} min={1} max={99} onChange={(v) => setP('seed', v)} hint="Same seed, same split and same result." />
            </div>
            <div className="mt-6 flex flex-wrap gap-3">
              <button type="button" className="btn btn-primary" disabled={busy || features.length === 0} onClick={run}><Play size={16} aria-hidden />{busy ? 'Training' : 'Train model'}</button>
              {algo !== 'k-means' && <button type="button" className="btn btn-ghost" disabled={busy || features.length === 0} onClick={runCompare}>Compare all algorithms</button>}
              {features.length === 0 && <span className="self-center text-sm text-bad">Select at least one input feature.</span>}
            </div>
            {busy && <Spinner label="Training in a background thread" />}
            {err && <div className="mt-4"><ErrorBox>{err}</ErrorBox></div>}
          </Section>

          {result && <ResultView res={result} table={table} />}
          {compare && <CompareView results={compare} errors={cmpErr} task={task} />}
        </>
      )}
      <p className="mt-10 text-sm text-muted">New to these ideas? Start with the <Link className="underline" to="/learn/train-validation-test">training, validation and testing lesson</Link> and the <Link className="underline" to="/learn/confusion-matrix">confusion matrix lesson</Link>.</p>
    </div>
  );
}

function DataPreview({ table }: { table: Table }) {
  const show = table.columns.slice(0, 12);
  return (
    <div className="mt-6 space-y-3">
      <p className="text-sm"><strong className="num">{table.rows.length.toLocaleString()}</strong> rows, <strong className="num">{table.columns.length}</strong> columns, <strong className="num">{table.columns.reduce((s, c) => s + c.missing, 0)}</strong> missing values in total ({table.source}).</p>
      {table.notes.map((n, i) => <p key={i} className="text-sm text-warn">{n}</p>)}
      <div className="max-h-72 overflow-auto rounded-md border border-line">
        <table className="w-full text-sm"><caption className="sr-only">Column summary</caption>
          <thead className="sticky top-0 bg-raised text-left"><tr><th className="p-2">Column</th><th className="p-2">Type</th><th className="p-2">Missing</th><th className="p-2">Distinct</th><th className="p-2">Examples</th><th className="p-2">Note</th></tr></thead>
          <tbody>{table.columns.map((c) => <tr key={c.name} className="border-t border-line"><td className="p-2 font-medium">{c.name}</td><td className="p-2">{c.kind}</td><td className="p-2 num">{c.missing}</td><td className="p-2 num">{c.unique}</td><td className="p-2 text-muted">{c.sample.join(', ')}</td><td className="p-2 text-warn">{c.warning ?? ''}</td></tr>)}</tbody>
        </table>
      </div>
      <div className="max-h-56 overflow-auto rounded-md border border-line">
        <table className="w-full text-xs"><caption className="sr-only">First rows of the data</caption><thead className="sticky top-0 bg-raised text-left"><tr>{show.map((c) => <th key={c.name} className="whitespace-nowrap p-2">{c.name}</th>)}{table.columns.length > show.length && <th className="p-2">…</th>}</tr></thead>
          <tbody>{table.rows.slice(0, 8).map((r, i) => <tr key={i} className="border-t border-line">{r.slice(0, 12).map((v, j) => <td key={j} className="whitespace-nowrap p-2 num">{v === null ? <span className="text-warn">missing</span> : typeof v === 'number' ? +v.toFixed(4) : v}</td>)}{table.columns.length > show.length && <td className="p-2 text-muted">…</td>}</tr>)}</tbody></table>
      </div>
    </div>
  );
}

function ResultView({ res, table }: { res: RunResult; table: Table }) {
  const [rec, setRec] = useState<Record<string, string>>({}); const [scored, setScored] = useState<Scored | null>(null); const [recErr, setRecErr] = useState<string | null>(null);
  useEffect(() => { setScored(null); setRecErr(null); const init: Record<string, string> = {}; res.scorer.spec.features.forEach((f) => { init[f.name] = String(f.kind === 'numeric' ? +(+f.fill).toFixed(3) : f.fill); }); setRec(init); }, [res]);
  const score = () => {
    try {
      const out: Record<string, number | string | null> = {};
      for (const f of res.scorer.spec.features) { const v = rec[f.name]; if (f.kind === 'numeric') { if (v === '' || v === undefined) out[f.name] = null; else if (!Number.isFinite(Number(v))) throw new Error(`${f.name} must be a number.`); else out[f.name] = Number(v); } else out[f.name] = v ?? null; }
      setScored(scoreRecord(res, out)); setRecErr(null);
    } catch (e) { setRecErr((e as Error).message); setScored(null); }
  };
  const label = ALGOS.find((a) => a.id === res.algo)!.label;
  return (
    <Section title={`4. Results: ${label}`} id="results" aside={<EvidenceBadge kind="simulation" />}>
      <p className="mb-4 text-sm text-muted">{res.task === 'clustering' ? `${res.nTrain} rows clustered` : `Trained on ${res.nTrain} rows, evaluated on ${res.nTest} unseen test rows`} in {Math.round(res.ms)} ms. Educational demonstration model, not a validated predictor.</p>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">{Object.entries(res.metrics).map(([k, v]) => <Stat key={k} label={METRIC_LABEL[k] ?? k} value={num(v)} />)}</div>
      {res.task === 'classification' && res.metrics.accuracy !== undefined && <p className="mt-2 text-sm text-muted">With a small test set, one row can move accuracy by several points, so compare algorithms with caution. Accuracy can also mislead when classes are unbalanced; check recall and the confusion matrix.</p>}
      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        {res.confusion && <ConfusionTable m={res.confusion} labels={res.classLabels!} />}
        {res.roc && <RocChart roc={res.roc} auc={res.metrics.roc_auc} positive={res.positiveClass!} />}
        {res.scatter && <PredActual data={res.scatter} />}
        {res.importances && <Importances items={res.importances} />}
        {res.cluster && <ClusterPlot c={res.cluster} />}
      </div>
      {res.testPreview.length > 0 && (
        <details className="mt-6"><summary className="cursor-pointer text-sm font-medium">Example predictions on test rows ({res.testPreview.length} shown)</summary>
          <div className="mt-2 overflow-auto rounded-md border border-line"><table className="w-full text-sm"><caption className="sr-only">Predictions</caption><thead className="bg-raised text-left"><tr><th className="p-2">Actual</th><th className="p-2">Predicted</th>{res.testPreview[0].probability !== undefined && <th className="p-2">Confidence</th>}<th className="p-2">Match</th></tr></thead>
            <tbody>{res.testPreview.map((r, i) => <tr key={i} className="border-t border-line"><td className="p-2">{r.actual}</td><td className="p-2">{r.predicted}</td>{r.probability !== undefined && <td className="p-2 num">{r.probability}</td>}<td className="p-2">{res.task === 'classification' ? (r.actual === r.predicted ? 'yes' : 'no') : ''}</td></tr>)}</tbody></table></div></details>
      )}
      <details className="mt-4"><summary className="cursor-pointer text-sm font-medium">How the data were prepared</summary><ul className="mt-2 max-w-prose list-disc space-y-1 pl-5 text-sm text-muted">{res.prepNotes.map((n, i) => <li key={i}>{n}</li>)}{res.extra.map((n, i) => <li key={'e' + i}>{n}</li>)}</ul></details>
      <div className="card mt-8 p-5">
        <h3 className="text-lg font-semibold">Try a new record</h3><p className="mb-4 text-sm text-muted">Enter values, then score them with the model you just trained. Blank numeric fields are treated as missing and filled with the training median.</p>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {res.scorer.spec.features.map((f) => (
            <div key={f.name}><label htmlFor={`rec-${f.name}`} className="label">{f.name}</label>
              {f.kind === 'numeric' ? <input id={`rec-${f.name}`} className="input" inputMode="decimal" value={rec[f.name] ?? ''} onChange={(e) => setRec((r) => ({ ...r, [f.name]: e.target.value }))} />
                : <select id={`rec-${f.name}`} className="input" value={rec[f.name] ?? ''} onChange={(e) => setRec((r) => ({ ...r, [f.name]: e.target.value }))}>{f.levels!.map((l) => <option key={l}>{l}</option>)}</select>}</div>
          ))}
        </div>
        <div className="mt-4 flex flex-wrap items-center gap-3"><button type="button" className="btn btn-primary" onClick={score}>{res.task === 'clustering' ? 'Find cluster' : 'Predict'}</button>
          {scored && <p role="status" className="text-sm">{res.task === 'regression' ? 'Predicted value' : res.task === 'clustering' ? 'Assigned to' : 'Predicted class'}: <strong className="text-base">{String(scored.label)}</strong>{scored.probabilities && <span className="text-muted"> ({scored.probabilities.map((o) => `${o.label} ${(o.p * 100).toFixed(0)}%`).join(', ')})</span>}</p>}
          {recErr && <span role="alert" className="text-sm text-bad">{recErr}</span>}</div>
        {res.algo === 'svm' && <p className="hint mt-2">SVM percentages are squashed decision values, not calibrated probabilities.</p>}
      </div>
      <p className="sr-only">{table.rows.length}</p>
    </Section>
  );
}

function ConfusionTable({ m, labels }: { m: number[][]; labels: string[] }) {
  const max = Math.max(...m.flat(), 1);
  return (
    <figure><figcaption className="mb-2 font-medium">Confusion matrix (test rows)</figcaption>
      <div className="overflow-x-auto"><table className="text-sm"><caption className="sr-only">Rows are actual classes, columns are predicted classes</caption>
        <thead><tr><th className="p-2" /><th colSpan={labels.length} className="p-2 text-center text-muted">Predicted</th></tr><tr><th className="p-2 text-left text-muted">Actual</th>{labels.map((l) => <th key={l} className="max-w-[8rem] truncate p-2">{l}</th>)}</tr></thead>
        <tbody>{m.map((row, i) => <tr key={i}><th scope="row" className="max-w-[8rem] truncate p-2 text-left">{labels[i]}</th>{row.map((v, j) => <td key={j} className="num h-12 w-16 border border-line text-center font-medium" style={{ background: `rgb(var(--${i === j ? 'good' : 'bad'}) / ${(v / max) * 0.35})` }}>{v}</td>)}</tr>)}</tbody></table></div>
      <p className="hint mt-1">Diagonal (green) cells are correct predictions; off-diagonal (red) cells are mistakes.</p></figure>
  );
}
function RocChart({ roc, auc, positive }: { roc: { fpr: number; tpr: number }[]; auc: number; positive: string }) {
  return (
    <figure><figcaption className="mb-2 font-medium">ROC curve (positive class: {positive}), AUC {auc.toFixed(3)}</figcaption>
      <div role="img" aria-label={`ROC curve with area under the curve ${auc.toFixed(3)}`} className="h-64"><ResponsiveContainer width="100%" height="100%"><LineChart data={roc} margin={{ left: 0, right: 12, top: 8, bottom: 16 }}>
        <CartesianGrid stroke="rgb(var(--line))" strokeOpacity={0.6} /><XAxis type="number" dataKey="fpr" domain={[0, 1]} tick={{ fontSize: 11 }} label={{ value: 'False positive rate', position: 'insideBottom', offset: -8, fontSize: 12 }} /><YAxis type="number" domain={[0, 1]} tick={{ fontSize: 11 }} label={{ value: 'True positive rate', angle: -90, position: 'insideLeft', fontSize: 12 }} />
        <ReferenceLine segment={[{ x: 0, y: 0 }, { x: 1, y: 1 }]} stroke="rgb(var(--muted))" strokeDasharray="4 4" /><Tooltip formatter={(v: number) => v.toFixed(3)} /><Line dataKey="tpr" stroke="rgb(var(--accent))" strokeWidth={2.4} dot={false} isAnimationActive={false} /></LineChart></ResponsiveContainer></div></figure>
  );
}
function PredActual({ data }: { data: { actual: number; predicted: number }[] }) {
  return (
    <figure><figcaption className="mb-2 font-medium">Predicted vs actual (test rows)</figcaption>
      <div role="img" aria-label="Scatter plot of predicted against actual values; points near the diagonal are accurate" className="h-64"><ResponsiveContainer width="100%" height="100%"><ScatterChart margin={{ left: 0, right: 12, top: 8, bottom: 16 }}>
        <CartesianGrid stroke="rgb(var(--line))" strokeOpacity={0.6} /><XAxis type="number" dataKey="actual" name="Actual" tick={{ fontSize: 11 }} domain={['auto', 'auto']} label={{ value: 'Actual', position: 'insideBottom', offset: -8, fontSize: 12 }} /><YAxis type="number" dataKey="predicted" name="Predicted" tick={{ fontSize: 11 }} domain={['auto', 'auto']} label={{ value: 'Predicted', angle: -90, position: 'insideLeft', fontSize: 12 }} />
        <Tooltip cursor={{ strokeDasharray: '3 3' }} formatter={(v: number) => v.toFixed(3)} /><Scatter data={data} fill={CLASS_COLORS[0]} isAnimationActive={false} /></ScatterChart></ResponsiveContainer></div></figure>
  );
}
function Importances({ items }: { items: { name: string; value: number; kind: string }[] }) {
  const data = items.slice(0, 10).map((i) => ({ name: i.name.length > 22 ? i.name.slice(0, 21) + '…' : i.name, value: +i.value.toFixed(4) }));
  return (
    <figure><figcaption className="mb-2 font-medium">Feature effects ({items[0].kind})</figcaption>
      <div role="img" aria-label="Bar chart of feature effects" style={{ height: Math.max(180, data.length * 28 + 40) }}><ResponsiveContainer width="100%" height="100%"><BarChart data={data} layout="vertical" margin={{ left: 8, right: 16, top: 4, bottom: 4 }}>
        <CartesianGrid stroke="rgb(var(--line))" strokeOpacity={0.6} horizontal={false} /><XAxis type="number" tick={{ fontSize: 11 }} /><YAxis type="category" dataKey="name" width={130} tick={{ fontSize: 11 }} /><Tooltip /><Bar dataKey="value" isAnimationActive={false}>{data.map((d, i) => <Cell key={i} fill={d.value >= 0 ? CLASS_COLORS[0] : CLASS_COLORS[1]} />)}</Bar></BarChart></ResponsiveContainer></div>
      <p className="hint mt-1">Model effects, not causes. Coefficients are per standard deviation of the feature; tree importances are shares of impurity reduction.</p></figure>
  );
}
function ClusterPlot({ c }: { c: NonNullable<RunResult['cluster']> }) {
  const groups = c.sizes.map((_, k) => c.xy.map((p, i) => ({ x: p[0], y: p[1], k: c.assign[i] })).filter((p) => p.k === k));
  return (
    <figure><figcaption className="mb-2 font-medium">Clusters on {c.axisNames[0]} and {c.axisNames[1]} (standardised)</figcaption>
      <div role="img" aria-label="Scatter plot of points coloured by cluster" className="h-72"><ResponsiveContainer width="100%" height="100%"><ScatterChart margin={{ left: 0, right: 12, top: 8, bottom: 16 }}><CartesianGrid stroke="rgb(var(--line))" strokeOpacity={0.6} /><XAxis type="number" dataKey="x" tick={{ fontSize: 11 }} /><YAxis type="number" dataKey="y" tick={{ fontSize: 11 }} /><Tooltip formatter={(v: number) => v.toFixed(2)} /><RLegend />
        {groups.map((g, k) => <Scatter key={k} name={`Cluster ${k + 1} (${c.sizes[k]})`} data={g} fill={CLASS_COLORS[k % 6]} isAnimationActive={false} />)}</ScatterChart></ResponsiveContainer></div>
      <p className="hint mt-1">Only the first two selected features are drawn; clustering used all selected features. Silhouette {c.silhouette.toFixed(3)} (1 is best, 0 means overlapping clusters).</p></figure>
  );
}

function CompareView({ results, errors, task }: { results: RunResult[]; errors: string[]; task: TaskType }) {
  const key = task === 'regression' ? 'r2' : results[0]?.metrics.roc_auc !== undefined ? 'roc_auc' : 'accuracy';
  const cols = task === 'regression' ? ['r2', 'rmse', 'mae'] : results[0]?.metrics.roc_auc !== undefined ? ['accuracy', 'precision', 'recall', 'f1', 'roc_auc', 'brier'] : ['accuracy', 'macro_precision', 'macro_recall', 'macro_f1'];
  const best = results.reduce((b, r) => ((r.metrics[key] ?? -Infinity) > (b.metrics[key] ?? -Infinity) ? r : b), results[0]);
  const data = results.map((r) => ({ name: ALGOS.find((a) => a.id === r.algo)!.label, value: +(r.metrics[key] ?? 0).toFixed(4) }));
  return (
    <Section title="Algorithm comparison" id="compare" aside={<EvidenceBadge kind="simulation" />}>
      <p className="mb-3 max-w-prose text-sm text-muted">All algorithms use default settings on the same split, so the comparison is fair but not tuned. Differences of a few percentage points on a small test set are usually within noise.</p>
      <div className="overflow-x-auto rounded-md border border-line"><table className="w-full text-sm"><caption className="sr-only">Metrics by algorithm</caption><thead className="bg-raised text-left"><tr><th className="p-2">Algorithm</th>{cols.map((c) => <th key={c} className="p-2">{METRIC_LABEL[c]}</th>)}<th className="p-2">Time</th></tr></thead>
        <tbody>{results.map((r) => <tr key={r.algo} className={`border-t border-line ${r === best ? 'bg-good/10' : ''}`}><td className="p-2 font-medium">{ALGOS.find((a) => a.id === r.algo)!.label}{r === best ? ' (highest ' + METRIC_LABEL[key] + ')' : ''}</td>{cols.map((c) => <td key={c} className="p-2 num">{num(r.metrics[c])}</td>)}<td className="p-2 num">{Math.round(r.ms)} ms</td></tr>)}</tbody></table></div>
      <div className="mt-4 h-60 max-w-xl" role="img" aria-label={`Bar chart of ${METRIC_LABEL[key]} by algorithm`}><ResponsiveContainer width="100%" height="100%"><BarChart data={data} margin={{ left: 0, right: 8, top: 8, bottom: 24 }}><CartesianGrid stroke="rgb(var(--line))" strokeOpacity={0.6} vertical={false} /><XAxis dataKey="name" tick={{ fontSize: 10 }} interval={0} angle={-15} textAnchor="end" height={50} /><YAxis tick={{ fontSize: 11 }} domain={task === 'regression' ? ['auto', 'auto'] : [0, 1]} /><Tooltip /><Bar dataKey="value" fill="rgb(var(--accent))" isAnimationActive={false} /></BarChart></ResponsiveContainer></div>
      {errors.length > 0 && <div className="mt-3 text-sm text-muted"><p>Skipped:</p><ul className="list-disc pl-5">{errors.map((e, i) => <li key={i}>{e}</li>)}</ul></div>}
    </Section>
  );
}
