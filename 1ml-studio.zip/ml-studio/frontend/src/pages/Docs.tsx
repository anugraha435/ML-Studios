import { Container, PageHeader } from '@/components/ui/Page';
import { DOC_SECTIONS } from '@/data/docs';
import { RichText } from '@/components/ui/Math';
import { Link } from 'react-router-dom';

const API_EXAMPLE = `curl -X POST "$API_URL/api/v1/predict" \\
  -H "Content-Type: application/json" \\
  -d '{"features": {"age": 57, "sex": 1, "cp": 4, "trestbps": 140, "chol": 241, "fbs": 0,
        "restecg": 0, "thalach": 123, "exang": 1, "oldpeak": 0.2, "slope": 2, "ca": 0, "thal": 7},
       "models": ["lr", "rf"]}'`;
const API_RESPONSE = `{
  "predictions": [
    {"model": "lr", "probability": 0.xxx, "threshold": 0.211, "classification": "above_threshold", "calibration": "none"},
    {"model": "rf", "probability": 0.xxx, "threshold": 0.288, "classification": "above_threshold", "calibration": "none"}
  ],
  "notice": "Educational research demonstration ... Not a medical device ..."
}`;
export default function Docs() {
  return (
    <Container className="py-10">
      <PageHeader title="Documentation" crumbs={[{ label: 'Documentation' }]} lead="How the platform works, how to use it, and how to run and deploy it yourself." />
      <div className="grid grid-cols-1 gap-10 lg:grid-cols-[14rem_minmax(0,1fr)]">
        <nav aria-label="Documentation sections" className="lg:sticky lg:top-24 lg:self-start"><ul className="space-y-1.5 border-l border-line pl-3 text-sm">{DOC_SECTIONS.map((d) => <li key={d.id}><a className="text-muted hover:text-ink" href={`#${d.id}`}>{d.title}</a></li>)}</ul></nav>
        <div className="min-w-0">
          {DOC_SECTIONS.map((d) => (
            <section key={d.id} id={d.id} className="mb-10 scroll-mt-24"><h2 className="mb-2 text-2xl font-semibold">{d.title}</h2><RichText text={d.body} />
              {d.id === 'getting-started' && <ul className="mt-2 flex flex-wrap gap-2"><li><Link className="btn btn-secondary" to="/learn">Learn ML</Link></li><li><Link className="btn btn-secondary" to="/algorithms">Algorithms</Link></li><li><Link className="btn btn-secondary" to="/playground">Playground</Link></li><li><Link className="btn btn-secondary" to="/research">Research Lab</Link></li></ul>}
              {d.id === 'api' && (<div className="mt-3 space-y-3">
                <div className="table-wrap"><table className="data"><thead><tr><th>Method and path</th><th>Purpose</th></tr></thead><tbody>
                  <tr><td className="font-mono">GET /health</td><td>Liveness and whether the model is loaded.</td></tr>
                  <tr><td className="font-mono">GET /api/v1/model-info</td><td>Feature list, decision thresholds and calibration method per model.</td></tr>
                  <tr><td className="font-mono">POST /api/v1/predict</td><td>Probability and classification at the stored threshold for one or more models (lr, dt, rf, svm).</td></tr>
                  <tr><td className="font-mono">POST /api/v1/explain/{'{rf|lr}'}</td><td>SHAP contributions for one record: TreeSHAP (probability units) for rf, linear SHAP (log-odds) for lr.</td></tr></tbody></table></div>
                <p className="text-sm text-muted">Inputs are validated strictly: unknown fields are rejected, numeric values must be inside the clinical ranges of the training data, and coded fields must use the dataset codes. Errors return HTTP 422 with the offending field. Requests are rate limited per IP. Interactive OpenAPI docs are served at <code className="inline">/docs</code> on the API host.</p>
                <pre className="overflow-x-auto rounded-lg bg-sunken p-4 text-xs"><code>{API_EXAMPLE}</code></pre><p className="text-sm text-muted">Response shape (probabilities depend on the input; xxx is a placeholder, not a result):</p><pre className="overflow-x-auto rounded-lg bg-sunken p-4 text-xs"><code>{API_RESPONSE}</code></pre></div>)}
            </section>))}
          <section id="run" className="mb-10 scroll-mt-24"><h2 className="mb-2 text-2xl font-semibold">Run locally</h2>
            <pre className="overflow-x-auto rounded-lg bg-sunken p-4 text-xs"><code>{`# front end
cd frontend && npm install && npm run dev          # http://localhost:5173

# back end (optional: only needed for server-side inference)
cd backend && python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload                       # http://localhost:8000/docs

# reproduce the research
cd research && python run_experiment.py --data data/cleveland_uci_coded.csv --out results
python make_figures.py results && python export_artifacts.py`}</code></pre></section>
        </div>
      </div>
    </Container>
  );
}
