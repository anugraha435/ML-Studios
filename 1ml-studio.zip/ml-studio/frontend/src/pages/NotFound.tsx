import { Link } from 'react-router-dom';
export default function NotFound({ what = 'page' }: { what?: string }) {
  return (
    <div className="mx-auto max-w-2xl px-4 py-24 text-center">
      <h1 className="text-3xl font-semibold">That {what} does not exist</h1>
      <p className="mt-3 text-muted">The link may be mistyped or the {what} may have moved. Search for what you need, or start from one of these.</p>
      <div className="mt-6 flex flex-wrap justify-center gap-3"><Link className="btn btn-primary" to="/learn">Browse lessons</Link><Link className="btn btn-ghost" to="/algorithms">Algorithms</Link><Link className="btn btn-ghost" to="/">Home</Link></div>
    </div>
  );
}
