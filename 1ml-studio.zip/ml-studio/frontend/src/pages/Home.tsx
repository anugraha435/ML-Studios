import { ArrowRight, BarChart3, BookOpen, FlaskConical, Layers, Search, ShieldCheck, SlidersHorizontal, Sun, Upload } from 'lucide-react';
import { Link } from 'react-router-dom';
import HeroPlot from '@/components/HeroPlot';
import { TrackArt } from '@/components/TrackArt';
import { TRACK_MINUTES, TRACK_SUMMARY } from '@/content/tracks';
import { Badge } from '@/components/ui/Badge';
import { Container } from '@/components/ui/Page';
import { ALGORITHMS } from '@/data/algorithms';
import { MODEL_KEYS, MODEL_NAMES, RESULTS, SPLIT, ci, num } from '@/data/metrics';
import { CATEGORIES, LESSON_INDEX } from '@/content/lessonIndex';

const lessonsIn = (c: string) => LESSON_INDEX.filter((l) => l.category === c);
import { useTitle } from '@/hooks/useTitle';

const PATHS = [
  { title: 'Beginner path', who: 'No prior knowledge needed', steps: ['what-is-ml', 'types-of-ml', 'datasets-features-labels', 'train-validation-test', 'linear-regression', 'logistic-regression', 'confusion-matrix'] },
  { title: 'Practitioner path', who: 'You can code and want sound habits', steps: ['cross-validation', 'overfitting-underfitting', 'regularization', 'random-forest', 'roc-auc', 'probability-calibration'] },
  { title: 'Research path', who: 'You want to evaluate and explain models', steps: ['bias-variance-tradeoff', 'brier-score', 'shap', 'local-explanations', 'explainability-in-healthcare'] }
];
const FEATURES = [
  [Search, 'Search everything', 'Press Ctrl+K (Cmd+K on Mac) to jump to any lesson, algorithm, metric or research page.'],
  [SlidersHorizontal, 'Controls that compute', 'Every slider and drag in the explorers changes a real calculation. There are no decorative controls.'],
  [Upload, 'Your data stays yours', 'CSV files are validated and processed in your browser. Nothing is uploaded.'],
  [ShieldCheck, 'Honest labels', 'Each result is marked as measured, actual inference, educational simulation or illustrative.'],
  [Layers, 'Tested against scikit-learn', 'The in-browser algorithms and the exported research models are checked against scikit-learn in automated tests.'],
  [Sun, 'Readable anywhere', 'Light and dark themes, keyboard navigation, reduced-motion support and layouts that work on a phone.']
] as const;

export default function Home() {
  useTitle();
  return (
    <>
      <section className="border-b border-line">
        <Container className="grid items-center gap-8 py-10 lg:grid-cols-[1.02fr_1fr] lg:gap-6 lg:py-14">
          <div className="max-w-xl">
            <h1 className="text-[2.5rem] leading-[1.08] sm:text-5xl lg:text-[3.4rem]">Visual, Interactive Explanations of Machine Learning</h1>
            <p className="mt-6 text-lg leading-relaxed text-muted">ML Studio explains the ideas behind machine learning with interactive lessons, an algorithm playground you can train on your own data, and one applied healthcare study you can inspect end to end.</p>
            <p className="mt-8 flex flex-wrap items-center gap-x-6 gap-y-3">
              <a href="#essays" className="btn btn-primary">Read the visual essays</a>
              <Link to="/playground" className="btn btn-ghost">Open the playground</Link>
              <Link to="/research" className="text-sm font-medium text-brand underline underline-offset-4">CardioNepal research</Link>
            </p>
          </div>
          <picture className="block">
            <source srcSet="/images/hero-instructor.webp" type="image/webp" />
            <img src="/images/hero-instructor.png" width={1000} height={913} fetchPriority="high" decoding="async" className="hero-art mx-auto h-auto w-full max-w-[34rem] lg:max-w-none"
              alt="A hand-drawn teacher stands beside a green chalkboard showing a neural network, a fitted line through scattered points, a loss curve and the words gradient descent." />
          </picture>
        </Container>
      </section>

      <Container className="py-16">
        <div className="mx-auto max-w-3xl">
          <h2 className="text-3xl">Start by breaking a model</h2>
          <p className="serif-body mt-3 text-muted">Click anywhere on the plot to add a point. A real 5-nearest-neighbour classifier is refitted after each click, and the shaded regions show what it would predict there.</p>
        </div>
        <div className="mx-auto mt-6 max-w-5xl"><HeroPlot /></div>
      </Container>

      <section id="essays" className="scroll-mt-20 border-y border-line bg-raised/50 py-16"><Container>
        <div className="max-w-2xl"><h2 className="text-3xl sm:text-4xl">Visual essays</h2>
          <p className="serif-body mt-3 text-muted">{LESSON_INDEX.length} lessons in six tracks, in an order that builds on itself. Each idea is explained twice, once plainly and once with the mathematics.</p></div>
        <ul className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {CATEGORIES.map((c) => (
            <li key={c.id}>
              <Link to={`/learn#cat-${c.id}`} className="essay-card card group flex h-full flex-col overflow-hidden">
                <div className="border-b border-line bg-bg px-5 pt-4"><TrackArt id={c.id} className="h-28 w-full" /></div>
                <div className="flex flex-1 flex-col p-5">
                  <h3 className="text-xl leading-snug group-hover:text-brand">{c.title}</h3>
                  <p className="mt-1 text-xs text-muted">{lessonsIn(c.id).length} lessons · {TRACK_MINUTES[c.id]} min of reading</p>
                  <p className="line-clamp-2 mt-3 text-sm text-muted">{TRACK_SUMMARY[c.id]}</p>
                </div>
              </Link>
            </li>
          ))}
        </ul>
      </Container></section>

      <Container className="py-16">
        <div className="flex flex-wrap items-end justify-between gap-3"><div><h2 className="text-3xl">Algorithms you can poke</h2><p className="mt-2 max-w-prose text-muted">Seven explorers. Drag the data, change the settings, and watch the model respond.</p></div><Link to="/algorithms" className="btn btn-ghost">All algorithms <ArrowRight size={16} aria-hidden /></Link></div>
        <ul className="mt-8 divide-y divide-line border-y border-line">
          {ALGORITHMS.map((a) => <li key={a.id}><Link to={`/algorithms/${a.id}`} className="group grid gap-1 py-4 hover:bg-raised/60 sm:grid-cols-[220px_1fr]"><span className="font-semibold group-hover:text-brand">{a.title}</span><span className="text-muted">{a.tagline}</span></Link></li>)}
        </ul>
        <div className="mt-8 grid gap-4 sm:grid-cols-2">
          <Link to="/playground" className="card flex gap-4 p-5 hover:bg-raised/60"><FlaskConical className="mt-1 shrink-0 text-accent" aria-hidden /><span><span className="block font-semibold">Interactive playground</span><span className="text-sm text-muted">Pick a sample dataset or upload a CSV, train any of seven algorithms in a background thread, and compare them on the same split.</span></span></Link>
          <Link to="/learn/confusion-matrix" className="card flex gap-4 p-5 hover:bg-raised/60"><BookOpen className="mt-1 shrink-0 text-accent" aria-hidden /><span><span className="block font-semibold">Interactive lessons</span><span className="text-sm text-muted">Selected lessons embed their own experiment, such as a confusion matrix whose counts you set and a threshold slider on a ROC curve.</span></span></Link>
        </div>
      </Container>

      <section className="border-y border-line bg-surface py-16"><Container>
        <div className="flex flex-wrap items-center gap-3"><h2 className="text-3xl">Featured research: CardioNepal</h2><Badge kind="measured" /></div>
        <p className="mt-3 max-w-prose text-muted">Four classifiers, one public benchmark (UCI Cleveland, 303 records), a stratified train/test split, and decision thresholds fixed before the test set was touched. Results on the {SPLIT.nTest} held-out records:</p>
        <div className="table-wrap mt-6 max-w-3xl"><table className="data"><caption className="sr-only">Test-set ROC-AUC with 95% bootstrap interval</caption><thead><tr><th>Model</th><th>ROC-AUC</th><th>95% interval</th></tr></thead><tbody>
          {MODEL_KEYS.map((k) => <tr key={k}><td>{MODEL_NAMES[k]}</td><td className="num">{num(RESULTS[k].test.roc_auc)}</td><td className="num">{ci(RESULTS[k].ci95.roc_auc)}</td></tr>)}</tbody></table></div>
        <p className="mt-3 max-w-prose text-sm text-muted">The intervals overlap heavily: with 61 records these models cannot be ranked with confidence. This is a methodological study of evaluation and explanation, not a clinical tool, and it has not been validated on a Nepalese population.</p>
        <div className="mt-6 flex flex-wrap gap-3"><Link to="/research" className="btn btn-primary">Open the Research Lab</Link><Link to="/research/demo" className="btn btn-ghost">Try the models</Link><Link to="/research/explainability" className="btn btn-ghost">See the SHAP explanations</Link></div>
      </Container></section>

      <Container className="py-16">
        <h2 className="text-3xl">Learning paths</h2>
        <div className="mt-8 grid gap-6 md:grid-cols-3">
          {PATHS.map((p) => (
            <div key={p.title} className="card p-5"><h3 className="text-lg font-semibold">{p.title}</h3><p className="text-sm text-muted">{p.who}</p>
              <ol className="mt-3 list-decimal space-y-1.5 pl-5 text-sm">{p.steps.map((s) => { const l = LESSON_INDEX.find((x) => x.id === s); return l ? <li key={s}><Link className="hover:text-brand hover:underline" to={`/learn/${s}`}>{l.title}</Link></li> : null; })}</ol></div>
          ))}
        </div>
      </Container>

      <section className="bg-raised/50 py-16"><Container>
        <h2 className="text-3xl">Built to be trusted</h2>
        <ul className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map(([Icon, t, d]) => <li key={t} className="flex gap-3"><Icon className="mt-1 shrink-0 text-accent" size={20} aria-hidden /><div><h3 className="font-sans text-base font-semibold">{t}</h3><p className="mt-1 text-sm text-muted">{d}</p></div></li>)}
        </ul>
      </Container></section>

      <Container className="py-16 text-center">
        <BarChart3 className="mx-auto text-accent" aria-hidden />
        <h2 className="mt-3 text-3xl">Start with one idea</h2>
        <p className="mx-auto mt-2 max-w-prose text-muted">Read the first lesson, or go straight to an experiment and learn by changing things.</p>
        <div className="mt-6 flex flex-wrap justify-center gap-3"><Link to="/learn/what-is-ml" className="btn btn-primary">Read: What is machine learning?</Link><Link to="/algorithms/linear-regression" className="btn btn-ghost">Fit a line to your own data</Link></div>
      </Container>
    </>
  );
}
