import { ArrowLeft, ArrowRight, Bookmark, CheckCircle2, FlaskConical } from 'lucide-react';
import { useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import { CATEGORIES, LESSONS, getLesson } from '../content';
import type { Lesson } from '../content/types';
import { Quiz } from '../components/Quiz';
import { RichText, Tex } from '../components/RichText';
import { Breadcrumbs, Section } from '../components/ui';
import { useProgress } from '../hooks/useProgress';
import { useActiveStep } from '../hooks/useActiveStep';
import NotFound from './NotFound';
import { LESSON_VIZ, type Step } from '../components/viz/lessonViz';

type VizComponent = (p: { step?: Step; stage?: boolean }) => JSX.Element;

export default function LessonPage() {
  const { id = '' } = useParams(); const lesson = getLesson(id);
  if (!lesson) return <NotFound what="lesson" />;
  return <LessonBody key={lesson.id} lesson={lesson} />;
}

function LessonBody({ lesson }: { lesson: Lesson }) {
  const p = useProgress();
  useEffect(() => { p.visit(lesson.id); document.title = `${lesson.title} · ML Studio`; }, [lesson.id]); // eslint-disable-line react-hooks/exhaustive-deps
  const idx = LESSONS.findIndex((l) => l.id === lesson.id), prev = LESSONS[idx - 1], next = LESSONS[idx + 1];
  const cat = CATEGORIES.find((c) => c.id === lesson.category)!;
  const Viz = (LESSON_VIZ as Record<string, VizComponent | undefined>)[lesson.id];
  const hasMath = !!lesson.math?.length;
  const stepIds: Step[] = ['intro', 'simple', 'technical', ...(hasMath ? ['math' as const] : []), 'example'];
  const active = useActiveStep(stepIds, !!Viz) as Step;
  const done = p.completed.includes(lesson.id), marked = p.bookmarks.includes(lesson.id);
  const jump: [string, string][] = [['intro', 'Introduction'], ['simple', 'Simple explanation'], ['technical', 'Technical explanation'], ...(hasMath ? [['math', 'Mathematics'] as [string, string]] : []), ['example', 'Worked example'], ['quiz', 'Knowledge check']];
  const wrap = (stepId: Step, node: React.ReactNode) => <div className={Viz ? 'step' : ''} data-active={Viz ? active === stepId : undefined}>{node}</div>;

  const narrative = (
    <div>
      {wrap('intro', <Section id="intro" title="Introduction"><RichText text={lesson.intro} serif /></Section>)}
      {wrap('simple', <Section id="simple" title="Simple explanation"><RichText text={lesson.simple} serif /></Section>)}
      {wrap('technical', <Section id="technical" title="Technical explanation"><RichText text={lesson.technical} serif /></Section>)}
      {hasMath && wrap('math', (
        <Section id="math" title="Mathematics">
          <div className="space-y-5">
            {lesson.math!.map((m, i) => (
              <figure key={i} className="eq-callout"><figcaption className="mb-1 font-serif text-sm italic text-muted">{m.label}</figcaption><div className="overflow-x-auto"><Tex display tex={m.tex} /></div>{m.note && <RichText text={m.note} className="mt-2 text-sm text-muted [&_p]:!mb-0" />}</figure>
            ))}
          </div>
        </Section>
      ))}
      {wrap('example', <Section id="example" title="Worked example"><div className="rounded-xl border border-line bg-raised/60 p-5"><h3 className="mb-2 text-lg">{lesson.example.title}</h3><RichText text={lesson.example.body} /></div></Section>)}
    </div>
  );

  return (
    <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
      <header className="max-w-3xl">
        <Breadcrumbs items={[{ label: 'Visual Essays', to: '/learn' }, { label: cat.title, to: `/learn#cat-${cat.id}` }, { label: lesson.title }]} />
        <h1 className="text-4xl leading-[1.1] sm:text-5xl">{lesson.title}</h1>
        <p className="mt-4 font-serif text-xl leading-relaxed text-muted">{lesson.summary}</p>
        <p className="mt-5 flex flex-wrap items-center gap-x-4 gap-y-2 text-sm text-muted">
          <span>{lesson.readingMinutes} min read</span><span aria-hidden>·</span><span>{cat.title}</span>
          <button type="button" className="inline-flex items-center gap-1.5 text-brand underline underline-offset-4" aria-pressed={marked} onClick={() => p.toggleBookmark(lesson.id)}><Bookmark size={14} className={marked ? 'fill-current' : ''} aria-hidden />{marked ? 'Bookmarked' : 'Bookmark'}</button>
        </p>
        <nav aria-label="In this lesson" className="mt-5 flex flex-wrap gap-x-4 gap-y-1 text-sm">{jump.map(([h, t]) => <a key={h} className="text-muted underline-offset-4 hover:text-ink hover:underline" href={`#${h}`}>{t}</a>)}</nav>
        {lesson.algorithmId && (
          <Link to={`/algorithms/${lesson.algorithmId}`} className="mt-6 flex items-center gap-3 rounded-xl border border-line bg-raised/60 p-4 hover:border-brand"><FlaskConical className="text-brand" aria-hidden /><span><span className="block font-medium">Try it: interactive {lesson.title.toLowerCase()} explorer</span><span className="text-sm text-muted">Change parameters and watch the calculation respond.</span></span><ArrowRight className="ml-auto" size={18} aria-hidden /></Link>
        )}
      </header>

      <div className="mt-12">
        {Viz ? (
          <div className="grid grid-cols-1 gap-10 lg:grid-cols-[minmax(0,34rem)_minmax(0,1fr)] lg:gap-14">
            <div className="order-2 min-w-0 lg:order-1">{narrative}</div>
            <div className="order-1 min-w-0 lg:order-2"><div className="lg:sticky lg:top-24"><Viz step={active} stage /><p className="mt-2 hidden text-xs text-muted lg:block">The figure follows the section you are reading. Move any control to explore on your own.</p></div></div>
          </div>
        ) : <div className="max-w-3xl">{narrative}</div>}

        <div className="max-w-3xl">
          <Section id="tradeoffs" title="Advantages and disadvantages">
            <div className="grid gap-8 md:grid-cols-2">
              <div className="border-t-2 border-good pt-3"><h3 className="mb-2 font-sans text-base font-semibold text-good">Advantages</h3><ul className="list-disc space-y-1.5 pl-5 text-sm">{lesson.pros.map((x, i) => <li key={i}><RichText text={x} className="!inline [&_p]:!inline [&_p]:!mb-0" /></li>)}</ul></div>
              <div className="border-t-2 border-warn pt-3"><h3 className="mb-2 font-sans text-base font-semibold text-warn">Disadvantages</h3><ul className="list-disc space-y-1.5 pl-5 text-sm">{lesson.cons.map((x, i) => <li key={i}><RichText text={x} className="!inline [&_p]:!inline [&_p]:!mb-0" /></li>)}</ul></div>
            </div>
          </Section>
          <Section id="uses" title="Real-world applications"><ul className="list-disc space-y-1.5 pl-5">{lesson.applications.map((x, i) => <li key={i}><RichText text={x} className="!inline [&_p]:!inline [&_p]:!mb-0" /></li>)}</ul></Section>
          <Section id="quiz" title="Knowledge check"><Quiz key={lesson.id} questions={lesson.quiz} /></Section>
          <Section id="related" title="Related topics">
            <ul className="flex flex-wrap gap-2">{lesson.related.map((r) => { const l = getLesson(r); return l ? <li key={r}><Link className="btn btn-ghost !min-h-9" to={`/learn/${r}`}>{l.title}</Link></li> : null; })}</ul>
          </Section>
          <div className="mt-6 flex flex-wrap items-center justify-between gap-3 border-t border-line pt-6">
            <button type="button" className={`btn ${done ? 'btn-ghost' : 'btn-primary'}`} aria-pressed={done} onClick={() => p.toggleComplete(lesson.id)}><CheckCircle2 size={16} aria-hidden />{done ? 'Completed. Undo' : 'Mark as completed'}</button>
            <div className="flex gap-2">
              {prev && <Link to={`/learn/${prev.id}`} className="btn btn-ghost"><ArrowLeft size={16} aria-hidden /><span className="max-w-[10rem] truncate">{prev.title}</span></Link>}
              {next && <Link to={`/learn/${next.id}`} className="btn btn-ghost"><span className="max-w-[10rem] truncate">{next.title}</span><ArrowRight size={16} aria-hidden /></Link>}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
