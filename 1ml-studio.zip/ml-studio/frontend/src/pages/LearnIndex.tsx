import { Bookmark, CheckCircle2, Clock, Search } from 'lucide-react';
import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { CATEGORIES, LESSONS, getLesson } from '../content';
import { PageHeader } from '../components/ui';
import { useProgress } from '../hooks/useProgress';
import { search } from '../lib/search';
import { TrackArt } from '../components/TrackArt';
import { TRACK_MINUTES } from '../content/tracks';

export default function LearnIndex() {
  const [q, setQ] = useState(''); const { completed, bookmarks, last, reset } = useProgress();
  const ids = useMemo(() => (q.trim() ? new Set(search(q, 60).filter((r) => r.kind === 'Lesson').map((r) => r.id)) : null), [q]);
  const lastLesson = last ? getLesson(last) : undefined;
  const pctDone = Math.round((completed.length / LESSONS.length) * 100);
  return (
    <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
      <PageHeader title="Visual essays on machine learning" lead={`${LESSONS.length} lessons in six tracks. Each one explains an idea twice, simply and technically, with the mathematics, a worked example you can follow by hand, and a short knowledge check.`} />
      <div className="mb-8 flex flex-wrap items-center gap-4">
        <div className="relative w-full max-w-sm">
          <label htmlFor="lesson-filter" className="sr-only">Filter lessons</label>
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted" aria-hidden />
          <input id="lesson-filter" className="input !pl-9" placeholder="Filter lessons, for example recall" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <div className="text-sm text-muted" aria-live="polite">
          <span className="num font-medium text-ink">{completed.length}</span> of {LESSONS.length} completed ({pctDone}%) <span className="hidden sm:inline">, saved in this browser only</span>
        </div>
        {lastLesson && <Link className="btn btn-primary" to={`/learn/${lastLesson.id}`}>Continue: {lastLesson.title}</Link>}
        {(completed.length > 0 || bookmarks.length > 0) && <button type="button" className="text-sm text-muted underline" onClick={() => { if (confirm('Clear completed lessons and bookmarks from this browser?')) reset(); }}>Reset progress</button>}
      </div>
      <div className="mb-8 h-1.5 w-full max-w-sm overflow-hidden rounded-full bg-raised" role="progressbar" aria-valuenow={pctDone} aria-valuemin={0} aria-valuemax={100} aria-label="Lessons completed"><div className="h-full bg-accent transition-all" style={{ width: `${pctDone}%` }} /></div>
      {!ids && <ul className="mb-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3" aria-label="Tracks">
        {CATEGORIES.map((c) => { const n = LESSONS.filter((l) => l.category === c.id); const d = n.filter((l) => completed.includes(l.id)).length; return (
          <li key={c.id}><a href={`#cat-${c.id}`} className="essay-card card group flex h-full flex-col overflow-hidden">
            <div className="border-b border-line bg-bg px-5 pt-4"><TrackArt id={c.id} className="h-24 w-full" /></div>
            <div className="p-5"><h2 className="text-lg leading-snug group-hover:text-brand">{c.title}</h2><p className="mt-1 text-xs text-muted">{n.length} lessons · {TRACK_MINUTES[c.id]} min{d > 0 ? ` · ${d} done` : ''}</p><p className="line-clamp-2 mt-2 text-sm text-muted">{c.blurb}</p></div>
          </a></li>); })}
      </ul>}
      {ids && ids.size === 0 && <p className="rounded-lg border border-line p-6 text-muted">No lessons match "{q}". Try a broader word, or clear the filter to see all lessons.</p>}
      <div className="max-w-3xl space-y-14">
        {CATEGORIES.map((c) => {
          const ls = LESSONS.filter((l) => l.category === c.id && (!ids || ids.has(l.id)));
          if (!ls.length) return null;
          return (
            <section key={c.id} aria-labelledby={`cat-${c.id}`} className="scroll-mt-24">
              <h2 id={`cat-${c.id}`} className="text-2xl">{c.title}</h2>
              <p className="mb-3 mt-1 text-sm text-muted">{c.blurb}</p>
              <ul className="divide-y divide-line border-y border-line">
                {ls.map((l) => (
                  <li key={l.id}>
                    <Link to={`/learn/${l.id}`} className="group flex items-start gap-3 py-3 hover:bg-raised/60">
                      <span className="mt-1 w-5 shrink-0">{completed.includes(l.id) ? <CheckCircle2 size={18} className="text-good" aria-label="Completed" /> : <span className="block h-[18px] w-[18px] rounded-full border border-line" aria-hidden />}</span>
                      <span className="min-w-0 flex-1"><span className="block font-medium group-hover:text-brand">{l.title}</span><span className="block text-sm text-muted">{l.summary}</span></span>
                      <span className="flex shrink-0 items-center gap-2 text-xs text-muted">{bookmarks.includes(l.id) && <Bookmark size={14} className="fill-current text-accent" aria-label="Bookmarked" />}<Clock size={13} aria-hidden />{l.readingMinutes} min</span>
                    </Link>
                  </li>
                ))}
              </ul>
            </section>
          );
        })}
      </div>
    </div>
  );
}
